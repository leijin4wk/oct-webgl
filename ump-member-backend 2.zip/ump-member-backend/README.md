# ump-member-backend

迁移aws上的cn-member 项目

# 数据库

数据库脚本在 dbscript 文件夹里
