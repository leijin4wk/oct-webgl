package com.oyo.ump.member.biz.member;

import com.alibaba.fastjson.JSON;
import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import com.oyo.ump.member.biz.push.PushBizServiceImpl;
import com.oyo.ump.member.common.test.TestApplication;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.stereotype.Component;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Map;

/**
 * @Description: 升级包对外接口测试类
 * @Author: dong
 * @create: 2019-04-12
 **/
@Component
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class PushBizServiceImplTest {
    @Autowired
    private PushBizServiceImpl pushBizServiceImpl;

    @Test
    public void getDepartmentMap(){
        BaseResponse<Map<Long, String>> response = new BaseResponse<>();
        Map<Long, String> departmentMap;
        departmentMap = pushBizServiceImpl.getAllDepartment();

        response.setCode(ResponseCode.SUCCESS.getCode());
        response.setMsg(ResponseCode.SUCCESS.getMsg());
        response.setData(departmentMap);

        log.info(" response: {}", JSON.toJSONString(response));
    }

}
