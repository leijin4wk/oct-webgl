package com.oyo.ump.member.biz.member;

import com.alibaba.fastjson.JSON;
import com.oyo.common.response.BaseResponse;
import com.oyo.ump.member.common.constants.MemberConstants;
import com.oyo.ump.member.common.test.TestApplication;
import com.oyo.ump.member.service.dto.ChangeGradeRequestDTO;
import com.oyo.ump.member.service.member.ChangeGradeBizService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author Dong
 * @Classname ChangeGradeBizServiceImplTest
 * @Description 升降级对外接口测试
 * @Date 2019-04-12
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class ChangeGradeBizServiceImplTest {
    @Autowired
    ChangeGradeBizService changeGradeBizService;

    @Test
    public void upGrade(){
        ChangeGradeRequestDTO changeGradeRequestDTO = new ChangeGradeRequestDTO();
        changeGradeRequestDTO.setUserId(19330659L);
        changeGradeRequestDTO.setSkuCode("K00023747378");
        changeGradeRequestDTO.setChangeType(MemberConstants.UPGRADE);
        BaseResponse response = changeGradeBizService.changeGradeByPackage(changeGradeRequestDTO);
        log.info("get coupon response: {}", JSON.toJSONString(response));
    }


    @Test
    public void deGrade(){
        ChangeGradeRequestDTO changeGradeRequestDTO = new ChangeGradeRequestDTO();
        changeGradeRequestDTO.setUserId(19330659L);
        changeGradeRequestDTO.setSkuCode("K00023747378");
        changeGradeRequestDTO.setChangeType(MemberConstants.DEGRADE);
        BaseResponse response = changeGradeBizService.changeGradeByPackage(changeGradeRequestDTO);
        log.info("get coupon response: {}", JSON.toJSONString(response));
    }

}
