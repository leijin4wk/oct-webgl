package com.oyo.ump.member.biz.member;

import com.alibaba.fastjson.JSON;
import com.oyo.common.response.PagedResponse;
import com.oyo.ump.member.common.test.TestApplication;
import com.oyo.ump.member.service.bo.MemberIdentityBO;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;

import static com.oyo.ump.member.common.constants.MemberConstants.OYO_JP_TENANT;
import static com.oyo.ump.member.common.constants.MemberConstants.OYO_TENANT;
import static org.junit.Assert.*;

/**
 * @Author hubin
 * @Description:
 * @Date 2019/8/30
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class MemberIdentityListBizServiceTest {
    @Autowired
    MemberIdentityListBizService memberIdentityListBizService;

    @Test
    public void getMemberIdentityList() {
        Map<String, Object> params = new HashMap<>();
        params.put("refreshRule", "");
        params.put("pageNum", 1);
        params.put("pageSize", 10);
        params.put("tenant",OYO_JP_TENANT);
//        params.put("phone", "138000000000");
        PagedResponse<MemberIdentityBO> memberIdentityBOPagedResponse = memberIdentityListBizService.getMemberIdentityList(params);
        log.info("get identity list: {}", JSON.toJSONString(memberIdentityBOPagedResponse));
        System.out.println(JSON.toJSONString(memberIdentityBOPagedResponse));
    }
}
