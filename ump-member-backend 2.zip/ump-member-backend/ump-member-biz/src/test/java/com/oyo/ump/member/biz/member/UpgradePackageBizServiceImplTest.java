package com.oyo.ump.member.biz.member;

import com.alibaba.fastjson.JSON;
import com.oyo.common.response.BaseResponse;
import com.oyo.ump.member.common.test.TestApplication;
import com.oyo.ump.member.service.dto.UpgradePackageDTO;
import com.oyo.ump.member.service.member.UpgradePackageBizService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.stereotype.Component;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.junit.Assert.assertTrue;

/**
 * @Description: 升级包对外接口测试类
 * @Author: dong
 * @create: 2019-04-12
 **/
@Component
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class UpgradePackageBizServiceImplTest {
    @Autowired
    private UpgradePackageBizService upgradePackageBizService;
    @Test
    public void canBuy(){
        Integer gradeId = 1;
        BaseResponse<List<UpgradePackageDTO>> response = upgradePackageBizService.getUpgradePackageListByGradeId(gradeId);
        log.info("get  response: {}", JSON.toJSONString(response));
    }

    @Test
    public void packageDetail(){
        // "K00015640319", "K00023747378", "1234569"
        String skuCode = "K00015640319";
        BaseResponse<UpgradePackageDTO> response = upgradePackageBizService.getUpgradePackageByCode(skuCode);
        log.info("get  response: {}", JSON.toJSONString(response));
    }
}
