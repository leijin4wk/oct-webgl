package com.oyo.ump.member.biz.push;

import com.alibaba.fastjson.JSON;
import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import com.oyo.sso.core.user.SsoUser;
import com.oyo.sso.core.util.SsoUtil;
import com.oyo.ump.member.service.enums.WeChatMiniAPPEnum;
import com.oyo.ump.member.common.test.TestApplication;
import com.oyo.ump.member.integration.service.user.UserInfoRemoteService;
import com.oyo.ump.member.service.bo.PushTemplateRelationBO;
import com.oyo.ump.member.service.dto.PushTemplateDTO;
import com.oyo.ump.member.service.enums.TriggerChannelEnum;
import com.oyo.ump.member.service.push.PushRPCBizService;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.util.Lists;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Map;

import static org.junit.Assert.*;

/**
 * @author Dong
 * @Description
 * @Date 2019-09-06
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class PushBizServiceImplTest {
    @Autowired
    private PushBizServiceImpl pushBizServiceImpl;
    @Autowired
    UserInfoRemoteService userInfoRemoteService;



    @Test
    public void getDepartmentMap(){
        BaseResponse<Map<Long, String>> response = new BaseResponse<>();
        Map<Long, String> departmentMap;
        departmentMap = pushBizServiceImpl.getAllDepartment();

        response.setCode(ResponseCode.SUCCESS.getCode());
        response.setMsg(ResponseCode.SUCCESS.getMsg());
        response.setData(departmentMap);

        log.info(" response: {}", JSON.toJSONString(response));
        assertFalse(response.getData().isEmpty());
    }
    /**
     * C端apppush模板
     * @param
     * @return void
     */
    @Test
    public void createCAPPPUSHTemplate() {
        //设置sso user
        SsoUser ssoUser=new SsoUser();
        ssoUser.setUserId(-1L);
        ssoUser.setUserName("admin@oyohotel.com");
        SsoUtil.setUser(ssoUser);
        PushTemplateDTO.TemplateInfo pushTemplateInfo = new PushTemplateDTO.TemplateInfo();
        pushTemplateInfo.setTemplateName("测试的第一条推送");
        pushTemplateInfo.setTemplateTitle("标题啊");
        pushTemplateInfo.setTemplateContent("这里是推送的内容啊");
        pushTemplateInfo.setTriggerChannel(TriggerChannelEnum.APPPUSH.getType());
        pushTemplateInfo.setContentParams(Lists.newArrayList());
        pushTemplateInfo.setUrlParams(Lists.newArrayList());
        pushTemplateInfo.setUtmParameter("{}");
        pushTemplateInfo.setPushId(888888L);
        pushTemplateInfo.setPercent(30);
        pushTemplateInfo.setCreateAccountId(ssoUser.getUserId());
        pushTemplateInfo.setCreateAccountName(ssoUser.getUserName());
        String templateCode = pushBizServiceImpl.createTemplate(pushTemplateInfo);
        assertNotNull(templateCode);
    }
    /**
     * 站内信模板
     * @param
     * @return void
     */
    @Test
    public void createInternalMsgTemplate() {
        //设置sso user
        SsoUser ssoUser=new SsoUser();
        ssoUser.setUserId(-1L);
        ssoUser.setUserName("admin@oyohotel.com");
        SsoUtil.setUser(ssoUser);
        PushTemplateDTO.TemplateInfo pushTemplateInfo = new PushTemplateDTO.TemplateInfo();
        pushTemplateInfo.setTemplateName("站内信模板模板UT");
        pushTemplateInfo.setInternalMsgTitle("公司上市通知");
        pushTemplateInfo.setInternalMsgContent("亲爱的OYO Partner 我们经过两年努力终于要上市了！虽然你知道这是假的，但是我得编造内容啊！！！！");
        pushTemplateInfo.setTriggerChannel(TriggerChannelEnum.INTERNALMSG.getType());
        pushTemplateInfo.setContentParams(Lists.newArrayList());
        pushTemplateInfo.setUrlParams(Lists.newArrayList());
        pushTemplateInfo.setUtmParameter("{}");
        pushTemplateInfo.setPushId(888888L);
        pushTemplateInfo.setPercent(30);
        pushTemplateInfo.setCreateAccountId(ssoUser.getUserId());
        pushTemplateInfo.setCreateAccountName(ssoUser.getUserName());
        pushTemplateInfo.setAppId(WeChatMiniAPPEnum.WECHAT_HOTEL_HERO.getAppId());
        String templateCode = pushBizServiceImpl.createTemplate(pushTemplateInfo);
        assertNotNull(templateCode);
    }

    /**
     * apollo站内信模板
     * @param
     * @return void
     */
    @Test
    public void createApolloInternalMsgTemplate() {
        //设置sso user
        SsoUser ssoUser=new SsoUser();
        ssoUser.setUserId(-1L);
        ssoUser.setUserName("admin@oyohotel.com");
        SsoUtil.setUser(ssoUser);
        PushTemplateDTO.TemplateInfo pushTemplateInfo = new PushTemplateDTO.TemplateInfo();
        pushTemplateInfo.setTemplateName("apollo站内信模板模板UT");
        pushTemplateInfo.setIsAttachInternalMsg(true);
        pushTemplateInfo.setSendLink("https://www.zzuli.edu.cn");
        pushTemplateInfo.setUpdateJson("999L");
        pushTemplateInfo.setTriggerChannel(TriggerChannelEnum.APPPUSH.getType());
        pushTemplateInfo.setContentParams(Lists.newArrayList());
        pushTemplateInfo.setUrlParams(Lists.newArrayList());
        pushTemplateInfo.setUtmParameter("{}");
        pushTemplateInfo.setPushId(888888L);
        pushTemplateInfo.setPercent(30);
        pushTemplateInfo.setCreateAccountId(ssoUser.getUserId());
        pushTemplateInfo.setCreateAccountName(ssoUser.getUserName());
        String templateCode = pushBizServiceImpl.createTemplate(pushTemplateInfo);
        assertNotNull(templateCode);
    }

    /**
     * 查询apollo站内信模板
     * @param
     * @return void
     */
    @Test
    public void queryApolloInternalMsgTemplate() {
        PushTemplateRelationBO pushTemplateRelationBO = new PushTemplateRelationBO();
        pushTemplateRelationBO.setPushId(888888L);
        PushTemplateDTO.TemplateInfo pushTemplateInfo = pushBizServiceImpl.queryTemplateInfo(pushTemplateRelationBO);
        assertNotNull(pushTemplateInfo);
    }



}