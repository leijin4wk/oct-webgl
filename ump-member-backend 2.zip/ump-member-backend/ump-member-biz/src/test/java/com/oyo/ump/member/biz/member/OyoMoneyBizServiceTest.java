package com.oyo.ump.member.biz.member;

import com.alibaba.fastjson.JSON;
import com.oyo.ump.member.common.test.TestApplication;
import com.oyo.ump.member.service.dto.OyoMoneyDelayRequestDTO;
import com.oyo.ump.member.service.dto.OyoMoneyDetailRequestDTO;
import com.oyo.ump.member.service.member.OyoMoneyBizService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @Description:
 * @Author: fang
 * @create: 2019-10-23
 **/
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class OyoMoneyBizServiceTest {
    @Autowired
    private OyoMoneyBizService oyoMoneyBizService;
    @Test
    public void test01(){
        System.out.println(JSON.toJSONString( oyoMoneyBizService.getMemberSignInMoney(19423116L)));
    }
    @Test
    public void test02(){
        System.out.println(JSON.toJSONString( oyoMoneyBizService.getOyoMoneyExchangeRate()));

    }
    @Test
    public void test03(){
        OyoMoneyDetailRequestDTO requestDTO =new OyoMoneyDetailRequestDTO();
        requestDTO.setUserId(19423116L);
        requestDTO.setAmount(10.1);
        requestDTO.setCardNo("123");
        requestDTO.setChannelId(175);
        requestDTO.setStatus(2);
        requestDTO.setHotelId(100545L);
        System.out.println(JSON.toJSONString( oyoMoneyBizService.getOyoMoneyDetailByOrderSn(requestDTO)));

    }
    @Test
    public void test04(){
        OyoMoneyDelayRequestDTO oyoMoneyDelayRequestDTO =new OyoMoneyDelayRequestDTO();
        oyoMoneyDelayRequestDTO.setType(1);
        System.out.println(JSON.toJSONString( oyoMoneyBizService.getOyoMoneyDelay(oyoMoneyDelayRequestDTO)));

    }

}
