package com.oyo.ump.member.biz.member;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import com.oyo.ump.member.common.test.TestApplication;
import com.oyo.ump.member.integration.service.trade.TradeRemoteService;
import com.oyo.ump.member.service.dto.GradePrivilegeDTO;
import com.oyo.ump.member.service.member.PrivilegeBizService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.junit.Assert.assertTrue;

/**
 * @Description: 会员权益测试类
 * @Author: fang
 * @create: 2019-04-07
 **/
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class PrivilegeBizServiceImplTest {
    @Autowired
    private PrivilegeBizService privilegeBizService;
    @Autowired
    private TradeRemoteService tradeRemoteService;
    @Test
    public void getPrivilege(){

        BaseResponse<List<GradePrivilegeDTO>>  response =privilegeBizService.getGradePrivilegeList();
        log.info(JSON.toJSONString(response, SerializerFeature.PrettyFormat));
        assertTrue(response != null && response.getCode().equals(ResponseCode.SUCCESS.getCode()));
        int gradeId=4;
        BaseResponse<GradePrivilegeDTO>  response1= privilegeBizService.getGradePrivilegeByGradeId(gradeId);
        log.info(JSON.toJSONString(response1, SerializerFeature.PrettyFormat));
        assertTrue(response1 != null && response1.getCode().equals(ResponseCode.SUCCESS.getCode()));
        int gradeId5=5;
        BaseResponse<GradePrivilegeDTO>  response2= privilegeBizService.getGradePrivilegeByGradeId(gradeId5);
        log.info(JSON.toJSONString(response2, SerializerFeature.PrettyFormat));
        assertTrue(response2 != null && response2.getCode().equals(ResponseCode.DATA_NOT_EXISTS.getCode()));

    }
    @Test
    public void testTrade(){
//        List<String> ordNo= Lists.newArrayList();
//        ordNo.add("SBD172710177");
////        Long userId =28775947l;
//        List<PromotionVo> list = tradeRemoteService.findLivingInfo(ordNo,null);
//        log.info(JSON.toJSONString(list, SerializerFeature.PrettyFormat));

    }
}
