package com.oyo.ump.member.biz.member;

import com.oyo.ump.member.common.test.TestApplication;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author Dong
 * @Classname UCM2Test
 * @Description ucm2的配置项测试
 * @Date 2019-04-16
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class UCM2Test {

    @Value("${V1_V3_ACTIVITY_ID}")
    private String V1_V3_ACTIVITY_ID;
    @Value("${V1_V3_IDENTITY_CODE}")
    private String V1_V3_IDENTITY_CODE ;
    @Value("${V2_V3_ACTIVITY_ID}")
    private String V2_V3_ACTIVITY_ID;
    @Value("${V2_V3_IDENTITY_CODE}")
    private String V2_V3_IDENTITY_CODE ;
    @Value("${COUPON_METADATA_ID}")
    private String COUPON_METADATA_ID;

    @Test
    public void printUCM2(){
        log.info("V1_V3_IDENTITY_CODE:{}", V1_V3_IDENTITY_CODE);
        log.info("V2_V3_IDENTITY_CODE:{}", V2_V3_IDENTITY_CODE);
    }



}
