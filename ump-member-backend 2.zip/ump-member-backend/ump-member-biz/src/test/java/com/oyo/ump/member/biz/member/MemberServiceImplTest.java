package com.oyo.ump.member.biz.member;

import org.junit.Test;

public class MemberServiceImplTest {






    @Test
    public void memberStatus() {

//        MemberStatusRequest request=new MemberStatusRequest();
//        request.setCountryCallingCode("+86");
//        request.setPhoneNumber("18556517170");
       // ServiceResponse<String> response=memberService.memberStatus("+86","18556517170");
        //System.out.println(response);




    }

    @Test
    public void memberInfoRSA() {







    }
}