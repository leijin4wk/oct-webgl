package com.oyo.ump.member.biz.member;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.oyo.common.response.BaseResponse;
import com.oyo.ump.member.common.test.TestApplication;
import com.oyo.ump.member.dal.model.UmpDataMemberDimRptEntity;
import com.oyo.ump.member.service.CrowdService;
import com.oyo.ump.member.service.bo.CrowdBO;
import com.oyo.ump.member.service.crowd.CrowdBizService;
import com.oyo.ump.member.service.dto.*;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * @Description: todo
 * @Author: fang
 * @create: 2019-11-12
 **/
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class CrowdServiceImplTest {
    @Autowired
    private CrowdBizService crowdBizService;
    @Autowired
    private CrowdService crowdService;

    @Test
    public void batchExistCrowdUser(){
        BatchExistCrowdRequestDTO batchExistCrowdRequestDTO =new BatchExistCrowdRequestDTO();
//        batchExistCrowdRequestDTO.setUserId(16145701L);
//        batchExistCrowdRequestDTO.setDistinctId("25237285");
        batchExistCrowdRequestDTO.setCrowdIdList(Lists.newArrayList(9L,11L,40L,100L,303L));

        System.out.println("接口返回结果"+JSON.toJSONString(crowdBizService.batchExistCrowdUser(batchExistCrowdRequestDTO)));
    }
    @Test
    public void getCrowdList(){
        CrowdListRequestDTO requestDTO =new CrowdListRequestDTO();
        CrowdDetailRequestDTO requestDTO1 =new CrowdDetailRequestDTO();
        requestDTO1.setCrowId(40L);
        System.out.println("人群列表接口返回结果"+JSON.toJSONString(crowdBizService.getCrowdList(requestDTO)));
        System.out.println("人群详情接口返回结果"+JSON.toJSONString(crowdBizService.getCrowdDetail(requestDTO1)));

    }
    @Test
    public void testV(){
        Date startDate =new Date();
        for (int i = 0; i <10000 ; i++) {
            CrowdBO crowdBO=JSON.parseObject("{\"createTime\":1560583091000,\"crowdCreateType\":\"1\",\"crowdName\":\"5555555\",\"crowdNum\":828242,\"crowdStatus\":\"1\",\"crowdTag\":[{\"itemId\":1,\"tagClassSelectValue\":\"1\",\"tagType\":2,\"tagSelectValue\":\"register_time\",\"tagOperatorValue\":\">\",\"tagValueSelectValue\":\"2019-05-01\",\"relationValue\":1}],\"dataUpdateTime\":1560583988000,\"id\":11,\"updateTime\":1573625412000}",
                    CrowdBO.class);
            UmpDataMemberDimRptEntity entity =JSON.parseObject("{\"alipay_user_flag\":0,\"auth_status\":\"Active\",\"auvp\":94.27,\"base_city\":\"北京\",\"base_city_id\":571,\"channel\":\"miniapp\",\"count_act\":0,\"count_act1\":0,\"count_act10\":0,\"count_act2\":0,\"count_act6\":0,\"count_activity_hotelacts\":0,\"count_activity_hotelcoupon\":0,\"count_alimpcheckin\":0,\"count_appcheckin\":0,\"count_checkin\":0,\"count_checkin_bymonth\":0,\"count_checkincity\":0,\"count_checkinhotel_bymonth\":0,\"count_checkinmosthotel\":0,\"count_checkinweekday\":0,\"count_checkinweekends\":0,\"count_checkoutmidnight\":0,\"count_coupon_midnight\":0,\"count_coupon_shortbookcheckin\":0,\"count_coupon_shorttime\":0,\"count_couponmax\":0,\"count_coupons\":0,\"count_couponuse_bymonth\":0,\"count_couponusemax\":0,\"count_meta_coupons\":0,\"count_meta_usecoupons\":0,\"count_miniappcheckin\":0,\"count_referothers\":0,\"count_reserve\":1,\"count_reservehotel\":1,\"count_shorttime\":0,\"count_unique_imei\":2,\"count_usecoupons\":0,\"counts_referuserforhotel\":0,\"counts_samehotel\":0,\"current_grade_id\":1,\"current_grade_name\":\"鸥游卡\",\"date_count_1madvance\":0,\"date_count_7dadvance\":0,\"date_count_advance\":8,\"days_reserveadvance_avg\":0.0,\"days_reserveadvance_max\":0.0,\"days_reserveadvance_min\":0.0,\"device_type\":\"System\",\"distinct_id\":\"25237285\",\"first_app_time\":1548943370000,\"first_booking_time\":1565793187000,\"first_mp_time\":1549018319000,\"frequency\":-1,\"hotel_reservemost\":40005,\"is_active_in_latest_month\":0,\"is_delete_app\":0,\"is_oyo_corporate\":0,\"is_oyo_wechat_fans\":0,\"is_push_flag\":0,\"is_recevie\":0,\"is_recevied_push\":0,\"is_reference\":0,\"last_app_time\":1567096665000,\"last_booking_time\":1565793187000,\"last_mp_time\":1549018319000,\"live_city\":\"北京\",\"live_city_id\":571,\"member_id\":16145701,\"next_grade_id\":2,\"next_grade_name\":\"鸥游银卡\",\"operator\":\"中国联通\",\"perfer_city_id\":550,\"perfer_citys\":\"深圳\",\"phone\":\"18600405810\",\"phone_city\":\"北京\",\"phone_ip\":\"0\",\"phone_prov\":\"北京市\",\"recency\":-1,\"refer_phone\":\"\",\"register_time\":1567444998000,\"sms_enable\":0,\"susceptibility\":2,\"suvp\":46.09,\"urn_next_level\":2,\"wechant_user_flag\":1,\"wechat_last_login_time\":1549018319000}",
                    UmpDataMemberDimRptEntity.class );
            crowdService.userFitCrowdRule(crowdBO,entity);
        }
        Date endDate =new Date();
        System.out.println("执行耗时"+(endDate.getTime()-startDate.getTime()));
        startDate =new Date();
        CrowdBO crowdBO=JSON.parseObject("{\"createTime\":1560583091000,\"crowdCreateType\":\"1\",\"crowdName\":\"5555555\",\"crowdNum\":828242,\"crowdStatus\":\"1\",\"crowdTag\":[{\"itemId\":1,\"tagClassSelectValue\":\"1\",\"tagType\":2,\"tagSelectValue\":\"register_time\",\"tagOperatorValue\":\">\",\"tagValueSelectValue\":\"2019-05-01\",\"relationValue\":1}],\"dataUpdateTime\":1560583988000,\"id\":11,\"updateTime\":1573625412000}",
                CrowdBO.class);
        UmpDataMemberDimRptEntity entity =JSON.parseObject("{\"alipay_user_flag\":0,\"auth_status\":\"Active\",\"auvp\":94.27,\"base_city\":\"北京\",\"base_city_id\":571,\"channel\":\"miniapp\",\"count_act\":0,\"count_act1\":0,\"count_act10\":0,\"count_act2\":0,\"count_act6\":0,\"count_activity_hotelacts\":0,\"count_activity_hotelcoupon\":0,\"count_alimpcheckin\":0,\"count_appcheckin\":0,\"count_checkin\":0,\"count_checkin_bymonth\":0,\"count_checkincity\":0,\"count_checkinhotel_bymonth\":0,\"count_checkinmosthotel\":0,\"count_checkinweekday\":0,\"count_checkinweekends\":0,\"count_checkoutmidnight\":0,\"count_coupon_midnight\":0,\"count_coupon_shortbookcheckin\":0,\"count_coupon_shorttime\":0,\"count_couponmax\":0,\"count_coupons\":0,\"count_couponuse_bymonth\":0,\"count_couponusemax\":0,\"count_meta_coupons\":0,\"count_meta_usecoupons\":0,\"count_miniappcheckin\":0,\"count_referothers\":0,\"count_reserve\":1,\"count_reservehotel\":1,\"count_shorttime\":0,\"count_unique_imei\":2,\"count_usecoupons\":0,\"counts_referuserforhotel\":0,\"counts_samehotel\":0,\"current_grade_id\":1,\"current_grade_name\":\"鸥游卡\",\"date_count_1madvance\":0,\"date_count_7dadvance\":0,\"date_count_advance\":8,\"days_reserveadvance_avg\":0.0,\"days_reserveadvance_max\":0.0,\"days_reserveadvance_min\":0.0,\"device_type\":\"System\",\"distinct_id\":\"25237285\",\"first_app_time\":1548943370000,\"first_booking_time\":1565793187000,\"first_mp_time\":1549018319000,\"frequency\":-1,\"hotel_reservemost\":40005,\"is_active_in_latest_month\":0,\"is_delete_app\":0,\"is_oyo_corporate\":0,\"is_oyo_wechat_fans\":0,\"is_push_flag\":0,\"is_recevie\":0,\"is_recevied_push\":0,\"is_reference\":0,\"last_app_time\":1567096665000,\"last_booking_time\":1565793187000,\"last_mp_time\":1549018319000,\"live_city\":\"北京\",\"live_city_id\":571,\"member_id\":16145701,\"next_grade_id\":2,\"next_grade_name\":\"鸥游银卡\",\"operator\":\"中国联通\",\"perfer_city_id\":550,\"perfer_citys\":\"深圳\",\"phone\":\"18600405810\",\"phone_city\":\"北京\",\"phone_ip\":\"0\",\"phone_prov\":\"北京市\",\"recency\":-1,\"refer_phone\":\"\",\"register_time\":1567444998000,\"sms_enable\":0,\"susceptibility\":2,\"suvp\":46.09,\"urn_next_level\":2,\"wechant_user_flag\":1,\"wechat_last_login_time\":1549018319000}",
                UmpDataMemberDimRptEntity.class );
        for (int i = 0; i <10000 ; i++) {
            crowdService.userFitCrowdRule(crowdBO,entity);
        }
        endDate =new Date();
        System.out.println("去除json解析执行耗时"+(endDate.getTime()-startDate.getTime()));
    }
    @Test
    public void testCreate(){
        AddCrowdUserDTO addCrowdUserDTO =new AddCrowdUserDTO();
        addCrowdUserDTO.setCrowdId(null);
        addCrowdUserDTO.setName("单元测试");
        Set<Long> userIds=new HashSet<>();
        userIds.add(111L);
        userIds.add(112L);
        addCrowdUserDTO.setUserIds(userIds);
        BaseResponse<AddCrowdUserResponseDTO> baseResponse= crowdBizService.createUserCrowd(addCrowdUserDTO);
        log.info(baseResponse.toString());
        BatchExistCrowdRequestDTO batchExistCrowdRequestDTO =new BatchExistCrowdRequestDTO();
        batchExistCrowdRequestDTO.setUserId(111L);
        batchExistCrowdRequestDTO.setCrowdIdList(Lists.newArrayList(baseResponse.getData().getCrowdId()));
        System.out.println("接口返回结果"+JSON.toJSONString(crowdBizService.batchExistCrowdUser(batchExistCrowdRequestDTO)));
    }
    @Test
    public void testAdd(){
        AddCrowdUserDTO addCrowdUserDTO =new AddCrowdUserDTO();
        addCrowdUserDTO.setCrowdId(148L);
        Set<Long> userIds=new HashSet<>();
        userIds.add(114L);
        userIds.add(113L);
        addCrowdUserDTO.setUserIds(userIds);
        BaseResponse<AddCrowdUserResponseDTO> baseResponse= crowdBizService.addUserToCrowdV2(addCrowdUserDTO);
        log.info(baseResponse.toString());
        BatchExistCrowdRequestDTO batchExistCrowdRequestDTO =new BatchExistCrowdRequestDTO();
        batchExistCrowdRequestDTO.setUserId(114L);
        batchExistCrowdRequestDTO.setCrowdIdList(Lists.newArrayList(148L));
        System.out.println("接口返回结果"+JSON.toJSONString(crowdBizService.batchExistCrowdUser(batchExistCrowdRequestDTO)));
    }

}
