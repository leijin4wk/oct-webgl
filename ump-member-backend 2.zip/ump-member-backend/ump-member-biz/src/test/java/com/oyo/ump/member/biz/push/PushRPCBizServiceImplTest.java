package com.oyo.ump.member.biz.push;

import com.oyo.ump.member.common.test.TestApplication;
import com.oyo.ump.member.service.dto.PromotionPushRequestDTO;
import com.oyo.ump.member.service.push.PushRPCBizService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

/**
 * @author Dong
 * @Description
 * @Date 2019-09-06
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class PushRPCBizServiceImplTest {
    @Autowired
    PushRPCBizService pushRPCBizService;

    @Test
    public void createTest(){
        PromotionPushRequestDTO pushRequestDTO = new PromotionPushRequestDTO();
        pushRequestDTO.setPromotionId("257");
        pushRequestDTO.setOperation("1");
        pushRequestDTO.setStartTime("2020-01-07 10:35:30");
        pushRequestDTO.setUserId(888L);
        pushRPCBizService.promotionPushOperation(pushRequestDTO);
    }


}