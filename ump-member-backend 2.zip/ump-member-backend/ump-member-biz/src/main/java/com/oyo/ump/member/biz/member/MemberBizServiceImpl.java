package com.oyo.ump.member.biz.member;

import com.alibaba.dubbo.config.annotation.Service;
import com.alibaba.fastjson.JSON;
import com.ctrip.framework.apollo.spring.annotation.ApolloJsonValue;
import com.google.common.collect.Maps;
import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import com.oyo.ump.member.biz.common.BizService;
import com.oyo.ump.member.biz.member.discount.DiscountConfig;
import com.oyo.ump.member.biz.member.discount.MemberDiscountService;
import com.oyo.ump.member.common.beanutils.MapperWrapper;
import com.oyo.ump.member.common.constants.MemberConstants;
import com.oyo.ump.member.common.enums.GradeEnum;
import com.oyo.ump.member.common.enums.GradeRefreshRuleEnum;
import com.oyo.ump.member.integration.service.user.JpUserInfoRemoteService;
import com.oyo.ump.member.integration.service.user.OyoUser;
import com.oyo.ump.member.service.producer.memberRegister.MemberMessage;
import com.oyo.ump.member.service.producer.memberRegister.MemberRegisterPublisher;
import com.oyo.ump.member.service.HotelService;
import com.oyo.ump.member.service.MemberInfoService;
import com.oyo.ump.member.service.bo.HotelBO;
import com.oyo.ump.member.service.bo.MemberInfoBO;
import com.oyo.ump.member.service.bo.SyncMemberGradeRequestBO;
import com.oyo.ump.member.service.dto.*;
import com.oyo.ump.member.service.member.MemberBizService;
import com.oyo.ump.member.service.member.PrivilegeBizService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cglib.beans.BeanCopier;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Component;
import top.rdfa.biz.actor.customer.client.request.AccountCustomerBasicRequest;
import top.rdfa.biz.actor.customer.client.request.BatchAccountCustomerInfoRequest;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.Map;

/**
 * @Description: 会员信息实现类
 * @Author: fang
 * @create: 2019-03-22
 **/
@BizService
@Service
@Component
@Slf4j
public class MemberBizServiceImpl implements MemberBizService {
    @Autowired
    private MemberInfoService memberInfoService;
    @Autowired
    private PrivilegeBizService privilegeBizService;

    @Autowired
    private HotelService hotelService;
    @Autowired
    private MemberRegisterPublisher memberRegisterPublisher;
    @Value("${ASYNC_REGISTER}")
    private String asyncRegister;
    private  final String ASYNC_REGISTER_SWITCH = "1";
    @Autowired
    @Qualifier("OyoMemberDiscountService")
    private  MemberDiscountService oyoMemberDiscountService;
    @Autowired
    @Qualifier("FliggyMemberDiscountService")
    private  MemberDiscountService fliggyMemberDiscountService;

    @Value("${FEIZHU_CHANNEL_ID}")
    private  Integer FEIZHU_CHANNEL_ID;

    @Autowired
    private JpUserInfoRemoteService jpUserInfoRemoteService;

    private  Map<Integer,MemberDiscountService> DISCOUNT_MAP= Maps.newHashMap();
    @PostConstruct
    void initDiscountService()
      {
        DISCOUNT_MAP.put(1,oyoMemberDiscountService);
        DISCOUNT_MAP.put(FEIZHU_CHANNEL_ID,fliggyMemberDiscountService);
    }
    @ApolloJsonValue("${DISCOUNT_CHANNEL_CONFIG}")
    private Map<Integer, DiscountConfig> DISCOUNT_CHANNEL_CONFIG;
    private final BeanCopier beanCopier = BeanCopier.create(UserMemberRegisterRequestDTO.class,BatchAccountCustomerInfoRequest.class,false);

    /**
     * 获取领域内的会员信息
     *
     * @param
     * @return
     */

    @Override
    public BaseResponse<MemberInfoDTO> getMemberInfoByUserV2(MemberInfoRequestDTO memberInfoRequestDTO) {
        log.info("查询会员信息接口入参userId:{}",JSON.toJSONString(memberInfoRequestDTO));
        if (memberInfoRequestDTO == null||memberInfoRequestDTO.getUserId()==null||memberInfoRequestDTO.getTenant()==null) {
            return BaseResponse.fail(ResponseCode.ILLEGAL_ARGUMENT);
        }
        MemberInfoBO memberInfoBO;
        MemberInfoDTO memberInfoDTO;
        try {
            memberInfoBO = memberInfoService.getMemberInfoByUserId(memberInfoRequestDTO.getUserId(),memberInfoRequestDTO.getTenant());
            if (memberInfoBO == null) {
                return BaseResponse.fail(ResponseCode.SUCCESS.getCode(), "未找到会员信息");
            }
            memberInfoDTO = assembleMemberInfo(memberInfoBO);
        } catch (Exception e) {
            log.error("获取会员信息 error,userId:{} error:{}:",memberInfoRequestDTO.getUserId(), e);
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(), "获取会员信息失败");
        }
        log.info("查询会员信息接口出参userId:{}",JSON.toJSONString(memberInfoDTO));
        return BaseResponse.success(memberInfoDTO);
    }

    /**
     * 获取会员折扣信息
     *
     * @param discountRequestDTO
     * @return
     */
    @Override
    public BaseResponse<List<MemberDiscountDTO>> getMemberDiscount(MemberDiscountRequestDTO discountRequestDTO) {
        if (discountRequestDTO == null || CollectionUtils.isEmpty(discountRequestDTO.getHotelIdList())) {
            return BaseResponse.fail(ResponseCode.ILLEGAL_ARGUMENT);
        }
        log.info("查询折扣接口入参{}",JSON.toJSONString(discountRequestDTO));
        if (discountRequestDTO.getUserId() == null) {
            return BaseResponse.success(getDefaultList(discountRequestDTO));
        }
        MemberInfoBO memberInfoBO = new MemberInfoBO();
        try {
            memberInfoBO = memberInfoService.getMemberInfoByUserId(discountRequestDTO.getUserId());
        } catch (Exception e) {
            log.error("获取会员信息 error: {}, {}", JSON.toJSONString(discountRequestDTO), e.getMessage());
        }
        if (memberInfoBO == null || memberInfoBO.getGradeId() == null||memberInfoBO.isFictitious()) {
            return BaseResponse.success(getDefaultList(discountRequestDTO));
//            return BaseResponse.fail(ResponseCode.DATA_NOT_EXISTS.getCode(), "未找到会员信息");
        }
        // 若非会员酒店，则默认折扣
        List<Long> memberHotelList = Lists.newArrayList();
        List<HotelBO> hotelBOList = hotelService.getSalesHotel(discountRequestDTO.getHotelIdList());
        if (CollectionUtils.isNotEmpty(hotelBOList)) {
            hotelBOList.forEach(hotelBO -> memberHotelList.add(hotelBO.getHotelId()));
        }

        BaseResponse<GradePrivilegeDTO> privilegeDTOBaseResponse = privilegeBizService.getGradePrivilegeByGradeId(memberInfoBO.getGradeId());
        if (!ResponseCode.SUCCESS.getCode().equals(privilegeDTOBaseResponse.getCode()) || privilegeDTOBaseResponse.getData() == null) {
            return BaseResponse.fail(ResponseCode.DATA_NOT_EXISTS.getCode(), "未找到对应等级折扣");
        }
        List<MemberDiscountDTO> discountDTOList = assembleMemberDiscount(privilegeDTOBaseResponse.getData(), memberInfoBO, memberHotelList, discountRequestDTO.getHotelIdList());
        log.info("查询折扣接口出参:{}",JSON.toJSONString(discountDTOList));
        return BaseResponse.success(discountDTOList);
    }

    @Override
    public BaseResponse<List<MemberDiscountDTO>> getMemberDiscountV2(MemberDiscountRequestDTO discountRequestDTO) {
        if (discountRequestDTO == null || CollectionUtils.isEmpty(discountRequestDTO.getHotelIdList())) {
            return BaseResponse.fail(ResponseCode.ILLEGAL_ARGUMENT);
        }
        MemberDiscountService memberDiscountService =DISCOUNT_MAP.get(discountRequestDTO.getPlatform());
        if(memberDiscountService==null){
            memberDiscountService=DISCOUNT_MAP.get(1);
        }
        log.info("查询折扣接口V2入参{}",JSON.toJSONString(discountRequestDTO));
        if(DISCOUNT_CHANNEL_CONFIG.containsKey(discountRequestDTO.getPlatform())){
            if(DISCOUNT_CHANNEL_CONFIG.get(discountRequestDTO.getPlatform()).isOriginalCost()){
                return BaseResponse.success(memberDiscountService.getOriginalCost(discountRequestDTO));
            }
        }
        if (discountRequestDTO.getUserId() == null) {
            return BaseResponse.success(memberDiscountService.getDefaultDiscount(discountRequestDTO,FEIZHU_CHANNEL_ID));
        }
        MemberInfoBO memberInfoBO = new MemberInfoBO();
        try {
            memberInfoBO = memberInfoService.getMemberInfoByUserId(discountRequestDTO.getUserId());
        } catch (Exception e) {
            log.error("折扣V2获取会员信息 error: {}, {}", JSON.toJSONString(discountRequestDTO), e.getMessage());
        }
        if (memberInfoBO == null || memberInfoBO.getGradeId() == null||memberInfoBO.isFictitious()) {
            return BaseResponse.success(memberDiscountService.getDefaultDiscount(discountRequestDTO,FEIZHU_CHANNEL_ID));
        }
        BaseResponse<GradePrivilegeDTO> privilegeDTOBaseResponse = privilegeBizService.getGradePrivilegeByGradeId(memberInfoBO.getGradeId());
        if (!ResponseCode.SUCCESS.getCode().equals(privilegeDTOBaseResponse.getCode()) || privilegeDTOBaseResponse.getData() == null) {
            return BaseResponse.fail(ResponseCode.DATA_NOT_EXISTS.getCode(), "折扣V2未找到对应等级折扣");
        }
        List<MemberDiscountDTO> memberDiscountDTOList =memberDiscountService.getUserDiscount(memberInfoBO,discountRequestDTO.getHotelIdList(),privilegeDTOBaseResponse.getData());
        log.info("查询折扣接口出参{}",JSON.toJSONString(memberDiscountDTOList));
        return BaseResponse.success(memberDiscountDTOList);
    }

    /**
     * 未登陆返回默认值
     *
     * @param discountRequestDTO
     * @return
     */
    private List<MemberDiscountDTO> getDefaultList(MemberDiscountRequestDTO discountRequestDTO) {
        List<MemberDiscountDTO> discountDTOList = Lists.newArrayList();
        discountRequestDTO.getHotelIdList().forEach(hotelId -> {
            MemberDiscountDTO memberDiscountDTO = new MemberDiscountDTO();
            memberDiscountDTO.setDiscount(MemberConstants.DEFAULT_DISCOUNT);
            memberDiscountDTO.setSubsidy(MemberConstants.CALCULATE_DISCOUNT - MemberConstants.DEFAULT_DISCOUNT);
            memberDiscountDTO.setUndertakeOwner(100);
            memberDiscountDTO.setUndertakeOyo(0);
            memberDiscountDTO.setUserId(discountRequestDTO.getUserId());
            memberDiscountDTO.setGradeId(1);
            memberDiscountDTO.setHotelId(hotelId);
            memberDiscountDTO.setFreightDiscount(MemberConstants.FREIGHT_DISCOUNT);
            discountDTOList.add(memberDiscountDTO);
        });
        return discountDTOList;

    }

    @Override
    public BaseResponse<List<MemberInfoDTO>> getMemberInfoByUserIdList(MemberInfoBatchRequestDTO memberInfoBatchRequestDTO) {
        if (memberInfoBatchRequestDTO==null||memberInfoBatchRequestDTO.getTenant()==null||CollectionUtils.isEmpty(memberInfoBatchRequestDTO.getUserIds()) || memberInfoBatchRequestDTO.getUserIds().size() > 40) {
            return BaseResponse.fail(ResponseCode.ILLEGAL_ARGUMENT);
        }
        List<MemberInfoDTO> memberInfoDTOList = Lists.newArrayList();
        try {
            List<MemberInfoBO> memberInfoBOList = memberInfoService.getMemberInfoByUserIdList(memberInfoBatchRequestDTO.getUserIds(),memberInfoBatchRequestDTO.getTenant());
            if (CollectionUtils.isNotEmpty(memberInfoBOList)) {
                memberInfoBOList.forEach(memberInfoBO -> memberInfoDTOList.add(assembleMemberInfo(memberInfoBO)));
            }
        } catch (Exception e) {
            log.error("获取会员信息 error:{}" , e);
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(), "批量获取会员信息失败");
        }

        return BaseResponse.success(memberInfoDTOList);    }

    @Override
    public BaseResponse<Boolean> registerMember(Long userId) {
        if (asyncRegister.equals(ASYNC_REGISTER_SWITCH)) {
            log.info("异步注册开启...");
            return BaseResponse.success(true);
        }
        RegisterRequestDTO registerRequestDTO =new RegisterRequestDTO();
        registerRequestDTO.setTenant("OYO");
        registerRequestDTO.setUserId(userId);
        return registerMemberV2(registerRequestDTO);
    }


    @Override
    public BaseResponse<Boolean> registerMemberV2(RegisterRequestDTO requestDTO) {
        if(requestDTO==null||requestDTO.getTenant()==null||requestDTO.getUserId()==null){
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(),"注册会员入参异常");
        }
        log.info("注册会员入参:{}",JSON.toJSONString(requestDTO));
        try {
            MemberRegisterDTO memberRegisterDTO =new MemberRegisterDTO();
            memberRegisterDTO.setTenant(requestDTO.getTenant());
            memberRegisterDTO.setUserId(requestDTO.getUserId());
            memberRegisterDTO.setGradeId(GradeEnum.getGradeByName(requestDTO.getGrade(),requestDTO.getTenant()));
            memberRegisterDTO.setPlatform(requestDTO.getPlatform());
            memberInfoService.registerMemberV2(memberRegisterDTO);
            try {
                MemberMessage memberMessage = new MemberMessage();
                memberMessage.setUserId(requestDTO.getUserId());
                memberRegisterPublisher.execute(memberMessage);
            } catch (Exception e) {
                log.error("会员注册MQ异常 memberRegisterPublisher：userId" + requestDTO.getUserId(), e);
            }
        } catch (DuplicateKeyException e) {
            log.info("注册用户已存在" + requestDTO.getUserId(), e);
            return BaseResponse.success(true);
        } catch (Exception e) {
            log.error("注册用户异常userId" + requestDTO.getUserId(), e);
            return BaseResponse.fail(ResponseCode.FAILURE);
        }
        return BaseResponse.success(true);    }

    @Override
    public BaseResponse<Boolean> syncMemberGrade(SyncMemberGradeRequestDTO requestDTO) {
        Integer gradeId = GradeEnum.getGradeByName(requestDTO.getGrade(),requestDTO.getTenant());
        if(requestDTO.getUserId()==null||requestDTO.getPlatform()==null){
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(),"参数错误");
        }
        SyncMemberGradeRequestBO syncMemberGradeRequestBO =new SyncMemberGradeRequestBO();
        if(requestDTO.getRefreshCode()!=null){
            GradeRefreshRuleEnum gradeRefreshRuleEnum =GradeRefreshRuleEnum.getByCode(requestDTO.getRefreshCode());
            if(gradeRefreshRuleEnum==GradeRefreshRuleEnum.SYS_ERROR){
                return BaseResponse.fail(ResponseCode.FAILURE.getCode(),"升级规则异常");
            }else {
                syncMemberGradeRequestBO.setPreGradeId(gradeRefreshRuleEnum.getPreviousId());
                syncMemberGradeRequestBO.setRule(gradeRefreshRuleEnum.getUpdateRuleType());
                gradeId=gradeRefreshRuleEnum.getGradeId();
            }
        }
        if(gradeId==null){
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(),"不能辨别等级");
        }
        syncMemberGradeRequestBO.setPlatform(requestDTO.getPlatform());
        syncMemberGradeRequestBO.setUserId(requestDTO.getUserId());
        syncMemberGradeRequestBO.setGradeId(gradeId);
        syncMemberGradeRequestBO.setTenant(requestDTO.getTenant()==null?MemberConstants.OYO_TENANT:requestDTO.getTenant());
        syncMemberGradeRequestBO.setValidTime(requestDTO.getValidTime());
        return BaseResponse.success(memberInfoService.syncMemberGrade(syncMemberGradeRequestBO));
    }
    @Override
    public BaseResponse<UserMemberRegisterResponseDTO> registerUserAndMember(UserMemberRegisterRequestDTO requestDTO) {
        UserMemberRegisterResponseDTO jpMemberRegisterResponseDTO=new UserMemberRegisterResponseDTO();
        Integer gradeId = GradeEnum.getGradeByName(requestDTO.getGrade(),requestDTO.getTenant());
        if(gradeId==null){
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(),"不能辨别等级");
        }
        log.info("日本注册入参：{}",JSON.toJSONString(requestDTO));
        Boolean registerSuccess =jpUserInfoRemoteService.register(convertJpRegisterRequest(requestDTO));
        if(registerSuccess==null||registerSuccess==false){
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(),"用户注册异常");
        }
        //todo 返回值 userid 用户中心暂时不支持
        AccountCustomerBasicRequest request = new AccountCustomerBasicRequest();
        if (StringUtils.isNotBlank(requestDTO.getAccountCustomers().get(0).getPhone())) {
            request.setPhone(requestDTO.getAccountCustomers().get(0).getPhone());
        }
        List<OyoUser> oyoUserList =jpUserInfoRemoteService.getAccountCustomersByBasic(request);
        if(CollectionUtils.isEmpty(oyoUserList)||oyoUserList.get(0).getUserId()==null){
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(),"用户查询异常");
        }
        MemberRegisterDTO memberRegisterDTO = new MemberRegisterDTO();
        try {
            memberRegisterDTO.setTenant(requestDTO.getTenant());
            memberRegisterDTO.setUserId(oyoUserList.get(0).getUserId());
            memberRegisterDTO.setGradeId(gradeId);
            memberRegisterDTO.setValidTime(requestDTO.getValidTime());
            memberInfoService.registerMemberV2(memberRegisterDTO);
            jpMemberRegisterResponseDTO.setGradeId(gradeId);
            jpMemberRegisterResponseDTO.setUserId(oyoUserList.get(0).getUserId());
        }catch (Exception e){
            log.error("注册会员异常,参数{}",JSON.toJSONString(memberRegisterDTO),e);
            return BaseResponse.fail(ResponseCode.FAILURE);
        }
        return BaseResponse.success(jpMemberRegisterResponseDTO);
    }




    /**
     * 转化日本注册信息
     * @param requestDTO
     * @return
     */
    private BatchAccountCustomerInfoRequest convertJpRegisterRequest(UserMemberRegisterRequestDTO requestDTO) {
        BatchAccountCustomerInfoRequest batchAccountCustomerInfoRequest =new BatchAccountCustomerInfoRequest();
        beanCopier.copy(requestDTO,batchAccountCustomerInfoRequest,null);
        return batchAccountCustomerInfoRequest;
    }


    /**
     * 组装折扣信息
     *
     * @param privilegeDTO
     * @param memberInfoBO
     * @param memberHotelList
     */
    private List<MemberDiscountDTO> assembleMemberDiscount(GradePrivilegeDTO privilegeDTO, MemberInfoBO memberInfoBO, List<Long> memberHotelList, List<Long> hotelList) {
        List<MemberDiscountDTO> result = Lists.newArrayList();
        hotelList.forEach(hotelId -> {
            MemberDiscountDTO memberDiscountDTO = new MemberDiscountDTO();
            memberDiscountDTO.setUserId(memberInfoBO.getUserId());
            memberDiscountDTO.setGradeId(memberInfoBO.getGradeId());
            memberDiscountDTO.setHotelId(hotelId);
            if (memberHotelList.contains(hotelId)) {
                memberDiscountDTO.setDiscount(privilegeDTO.getSpecialDiscount().getDiscount());
                memberDiscountDTO.setSubsidy(MemberConstants.CALCULATE_DISCOUNT - privilegeDTO.getSpecialDiscount().getDiscount());
                memberDiscountDTO.setUndertakeOwner(privilegeDTO.getSpecialDiscount().getUndertakeOwner());
                memberDiscountDTO.setUndertakeOyo(privilegeDTO.getSpecialDiscount().getUndertakeOyo());
            } else {
                memberDiscountDTO.setDiscount(MemberConstants.DEFAULT_DISCOUNT);
                memberDiscountDTO.setSubsidy(MemberConstants.CALCULATE_DISCOUNT - MemberConstants.DEFAULT_DISCOUNT);
                memberDiscountDTO.setUndertakeOwner(100);
                memberDiscountDTO.setUndertakeOyo(0);
            }
            memberDiscountDTO.setFreightDiscount(MemberConstants.FREIGHT_DISCOUNT);
            result.add(memberDiscountDTO);
        });
        return result;
    }

    /**
     * 转化为会员dto
     *
     * @param memberInfoBO
     * @return
     */
    private MemberInfoDTO assembleMemberInfo(MemberInfoBO memberInfoBO) {
        MemberInfoDTO memberInfoDTO = new MemberInfoDTO();
        memberInfoDTO.setUserId(memberInfoBO.getUserId());
        memberInfoDTO.setGrade(memberInfoBO.getGrade());
        memberInfoDTO.setGradeId(memberInfoBO.getGradeId());
        memberInfoDTO.setGradeName(memberInfoBO.getGradeName());
        memberInfoDTO.setRoomNight(memberInfoBO.getRoomNight());
        memberInfoDTO.setNoshow(memberInfoBO.getNoshow());
        memberInfoDTO.setUpgradeRoomNights(memberInfoBO.getUpgradeRoomNights());
        memberInfoDTO.setNextGradeId(memberInfoBO.getNextGradeId());
        memberInfoDTO.setGradeUpdateTime(memberInfoBO.getGradeUpdateTime());
        memberInfoDTO.setTenant(memberInfoBO.getTenant());
        memberInfoDTO.setValidPeriod(memberInfoBO.getValidPeriod());
        return memberInfoDTO;
    }
}
