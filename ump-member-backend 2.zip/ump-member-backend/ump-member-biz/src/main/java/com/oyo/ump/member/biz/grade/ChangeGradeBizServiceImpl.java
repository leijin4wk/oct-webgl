package com.oyo.ump.member.biz.grade;

import com.alibaba.dubbo.config.annotation.Service;
import com.alibaba.fastjson.JSON;
import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import com.oyo.ump.coupon.facade.dto.request.FailureCouponRequest;
import com.oyo.ump.coupon.facade.dto.request.MetadataInfoRequest;
import com.oyo.ump.coupon.facade.dto.request.SendCouponRequest;
import com.oyo.ump.coupon.facade.dto.request.SendMetadataInfo;
import com.oyo.ump.coupon.facade.dto.response.FailureCouponResponse;
import com.oyo.ump.coupon.facade.dto.response.SendCouponResponseDTO;
import com.oyo.ump.coupon.facade.util.GeneralResponse;
import com.oyo.ump.member.biz.common.BizService;
import com.oyo.ump.member.common.constants.MemberConstants;
import com.oyo.ump.member.integration.service.coupon.CouponRemoteService;
import com.oyo.ump.member.service.ChangeGradeService;
import com.oyo.ump.member.service.MemberInfoService;
import com.oyo.ump.member.service.RedisService;
import com.oyo.ump.member.service.UpgradePackageService;
import com.oyo.ump.member.service.bo.ChangeGradeBO;
import com.oyo.ump.member.service.bo.MemberInfoBO;
import com.oyo.ump.member.service.bo.UpgradePackageBO;
import com.oyo.ump.member.service.dto.ChangeGradeRequestDTO;
import com.oyo.ump.member.service.member.ChangeGradeBizService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


/**
 * @author Dong
 * @Classname ChangeGradeBizServiceImpl
 * @Description 会员等级变化业务实现类
 * @Date 2019-03-25
 */
@BizService
@Service
@Component
@Slf4j
public class ChangeGradeBizServiceImpl implements ChangeGradeBizService {
    @Autowired
    UpgradePackageService upgradePackageService;
    @Autowired
    ChangeGradeService changeGradeService;
    @Autowired
    CouponRemoteService couponRemoteService;
    @Autowired
    RedisService redisService;
    @Autowired
    MemberInfoService memberInfoService;
    @Value("${V1_V3_ACTIVITY_ID}")
    private String V1_V3_ACTIVITY_ID;
    @Value("${V1_V3_IDENTITY_CODE}")
    private String V1_V3_IDENTITY_CODE ;
    @Value("${V2_V3_ACTIVITY_ID}")
    private String V2_V3_ACTIVITY_ID;
    @Value("${V2_V3_IDENTITY_CODE}")
    private String V2_V3_IDENTITY_CODE ;
    @Value("${COUPON_METADATA_ID}")
    private String COUPON_METADATA_ID;

    @Override
    public BaseResponse changeGradeByPackage(ChangeGradeRequestDTO changeGradeRequestDTO) {
        log.info("等级变更请求信息changeGradeRequestDTO：{}", JSON.toJSONString(changeGradeRequestDTO));
        Long userId = changeGradeRequestDTO.getUserId();
        String skuCode = changeGradeRequestDTO.getSkuCode();
        Integer changeType = changeGradeRequestDTO.getChangeType();
        if(userId == null || skuCode == null || changeType == null || StringUtils.isBlank(skuCode)){
            return BaseResponse.fail(ResponseCode.ILLEGAL_ARGUMENT.getCode(),"必传参数不能为空");
        }

        MemberInfoBO memberInfoBO = memberInfoService.getMemberInfoFromDB(userId);
        if(memberInfoBO != null && memberInfoBO.getUserId() != null){
            // 1、根据skuCode 获取升级包信息
            ChangeGradeBO changeGradeBO = new ChangeGradeBO();
            UpgradePackageBO upgradePackageBO;

            try{
                upgradePackageBO = upgradePackageService.getUpgradePackageByCode(skuCode);
            }catch (Exception e){
                log.error("upgradeByPackage 查询升级包信息异常", e);
                return BaseResponse.fail(ResponseCode.INVALID_PARAMETER_VALUE);
            }

            if(upgradePackageBO != null){
                changeGradeBO.setUserId(userId);
                changeGradeBO.setUpdateRuleType(MemberConstants.UPDATE_GRADE_BY_PACKAGE);
            }else {
                return BaseResponse.fail(ResponseCode.INVALID_PARAMETER_VALUE.getCode(),"skuCode 对应的升级包不存在");
            }


            if(MemberConstants.UPGRADE.equals(changeType)){
                // 升级
                changeGradeBO.setPreviousGradeId(upgradePackageBO.getGradeId());
                changeGradeBO.setGradeId(upgradePackageBO.getUpgradeId());
                try{
                    changeGradeService.changeGrade(changeGradeBO);

                    if(MemberConstants.V1.equals(upgradePackageBO.getGradeName()) && MemberConstants.V3.equals(upgradePackageBO.getUpgradeName())){
                        sendCoupon(changeGradeRequestDTO.getUserId(),Long.parseLong(V1_V3_ACTIVITY_ID),V1_V3_IDENTITY_CODE);
                    }else if(MemberConstants.V2.equals(upgradePackageBO.getGradeName()) && MemberConstants.V3.equals(upgradePackageBO.getUpgradeName())){
                        sendCoupon(changeGradeRequestDTO.getUserId(),Long.parseLong(V2_V3_ACTIVITY_ID),V2_V3_IDENTITY_CODE);
                    }

                }catch (Exception e){
                    log.info("升级异常了，回滚等级变更，不发券");
                    return BaseResponse.fail(ResponseCode.SYSTEM_IS_BUSY.getCode(), "执行升级失败");
                }


            }else if(MemberConstants.DEGRADE.equals(changeType)){
                // 降级
                changeGradeBO.setPreviousGradeId(upgradePackageBO.getUpgradeId());
                changeGradeBO.setGradeId(upgradePackageBO.getGradeId());
                try{
                    changeGradeService.changeGrade(changeGradeBO);

                    // 废券
                    if(MemberConstants.V1.equals(upgradePackageBO.getGradeName()) && MemberConstants.V3.equals(upgradePackageBO.getUpgradeName())){
                        failureCoupon(changeGradeRequestDTO.getUserId(),Long.parseLong(V1_V3_ACTIVITY_ID),V1_V3_IDENTITY_CODE);
                    }else if(MemberConstants.V2.equals(upgradePackageBO.getGradeName()) && MemberConstants.V3.equals(upgradePackageBO.getUpgradeName())){
                        failureCoupon(changeGradeRequestDTO.getUserId(),Long.parseLong(V2_V3_ACTIVITY_ID),V2_V3_IDENTITY_CODE);
                    }
                }catch (Exception e){
                    log.info("降级异常了，回滚等级变更，不废券");
                    return BaseResponse.fail(ResponseCode.SYSTEM_IS_BUSY.getCode(), "执行降级失败");
                }

            }else {
                // changeType 值有误
                return BaseResponse.fail(ResponseCode.INVALID_PARAMETER_VALUE);
            }
            return BaseResponse.success(ResponseCode.SUCCESS);
        }else {
            return BaseResponse.fail(ResponseCode.DATA_NOT_EXISTS.getCode(), "用户不是会员");
        }

    }


    /**
     * RPC废券功能
     * @param userId
     * @param activityId
     * @param identifyCode
     * @return void
     */
    private void failureCoupon(Long userId, Long activityId, String identifyCode){
        FailureCouponRequest request = new FailureCouponRequest();
        request.setUserId(userId);
        MetadataInfoRequest metadataInfo = new MetadataInfoRequest();
        metadataInfo.setNum(MemberConstants.COUPON_NUM);
        request.setActivityId(activityId);
        metadataInfo.setIdentifyCode(identifyCode);
        request.setCouponInfo(Lists.newArrayList(metadataInfo));
        try{
            log.info("废券请求信息，request:{} ", JSON.toJSONString(request));
            GeneralResponse<FailureCouponResponse> response = couponRemoteService.failureUseCoupon(request);
            log.info("废券成功,response信息：{}", JSON.toJSONString(response));
        }catch (Exception e){
            log.info("废券失败,异常信息：", e);
            insertFailureRequest(request);
        }
    }

    /**
     * RPC发券功能
     * @param userId
     * @param activityId
     * @param identifyCode
     * @return void
     */
    private void sendCoupon(Long userId, Long activityId, String identifyCode){
        SendCouponRequest request = new SendCouponRequest();
        request.setUserId(userId);
        request.setActivityId(activityId);
        SendMetadataInfo metadataInfo = new SendMetadataInfo();
        metadataInfo.setIdentifyCode(identifyCode);
        metadataInfo.setNum(MemberConstants.COUPON_NUM);
        request.setCouponInfo(Lists.newArrayList(metadataInfo));
        try{
            log.info("发券请求信息，request:{} ", JSON.toJSONString(request));
            GeneralResponse<SendCouponResponseDTO> response = couponRemoteService.sendCouponByIdentifyCode(request);
            log.info("发券成功,response信息：{}", JSON.toJSONString(response));
        }catch (Exception e){
            log.info("发券失败,异常信息：", e);
            insertSentRequest(request);
        }
    }

    /**
     * 失败的发券请求放入redis
     * @param request
     * @return void
     */
    private void insertSentRequest(SendCouponRequest request){
        redisService.putMapEntry(MemberConstants.SEND_COUPON_REDIS, sendRequest2String(request), 0);
    }

    private void insertFailureRequest(FailureCouponRequest request){
        redisService.putMapEntry(MemberConstants.FAIL_COUPON_REDIS, failureRequest2String(request),0);
    }

    private String sendRequest2String(SendCouponRequest request){

        return request.getUserId().toString()+"*"+request.getActivityId().toString()+"*"+request.getCouponInfo().get(0).getIdentifyCode();
    }

    private String failureRequest2String(FailureCouponRequest request){

        return request.getUserId().toString()+"*"+request.getActivityId().toString()+"*"+request.getCouponInfo().get(0).getIdentifyCode();
    }

}
