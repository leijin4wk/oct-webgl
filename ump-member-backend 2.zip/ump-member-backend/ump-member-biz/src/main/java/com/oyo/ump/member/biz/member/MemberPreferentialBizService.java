package com.oyo.ump.member.biz.member;

import com.oyo.ump.coupon.facade.dto.request.ListUserCouponRequest;
import com.oyo.ump.coupon.facade.dto.response.UserCouponListDTO;
import com.oyo.ump.coupon.facade.util.GeneralResponse;
import com.oyo.ump.member.biz.common.BizService;
import com.oyo.ump.member.integration.service.coupon.CouponRemoteService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Dong
 * @Classname MemberPreferentialBizServiceImpl
 * @Description 聚合用户优惠信息
 * @Date 2019-07-04
 */
@BizService
@Component
@Slf4j
public class MemberPreferentialBizService {
    @Autowired
    private CouponRemoteService couponRemoteService;

    public GeneralResponse<UserCouponListDTO> getPreferential(ListUserCouponRequest request){
        GeneralResponse<UserCouponListDTO> response = couponRemoteService.listUserCoupon(request);
        if(response != null){
            return response;
        }
        return null;
    }
}
