package com.oyo.ump.member.biz.oyomoney;

import com.alibaba.dubbo.config.annotation.Service;
import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import com.oyo.ledger.client.response.CostDataVO;
import com.oyo.ump.member.biz.common.BizService;
import com.oyo.ump.member.common.constants.MemberConstants;
import com.oyo.ump.member.common.constants.RedisConstants;
import com.oyo.ump.member.integration.service.costcenter.CostCenterRemoteService;
import com.oyo.ump.member.integration.service.hotel.HotelRemoteService;
import com.oyo.ump.member.integration.service.user.OyoUser;
import com.oyo.ump.member.integration.service.user.UserInfoRemoteService;
import com.oyo.ump.member.service.*;
import com.oyo.ump.member.service.bo.GradeInfoBO;
import com.oyo.ump.member.service.bo.GradePrivilegeBO;
import com.oyo.ump.member.service.bo.MemberInfoBO;
import com.oyo.ump.member.service.dto.*;
import com.oyo.ump.member.service.member.OyoMoneyBizService;
import com.oyo.uum.api.user.request.user.QueryUserRequest;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


/**
 * @Description: 欧币实现类
 * @Author: fang
 * @create: 2019-10-21
 **/
@BizService
@Service
@Component
@Slf4j
public class OyoMoneyBizServiceImpl implements OyoMoneyBizService {
    @Autowired
    private BonusCostRuleService bonusCostRuleService;

    @Autowired
    private HotelRemoteService hotelRemoteService;

    @Autowired
    private BonusGainRuleService bonusGainRuleService;
    @Autowired
    private CostCenterRemoteService costCenterRemoteService;

    @Autowired
    private UserInfoRemoteService userInfoRemoteService;

    @Autowired
    private GradeService gradeService;

    @Autowired
    MemberInfoService memberInfoService;

    @Autowired
    HotelService hotelService;

    @Autowired
    PrivilegeService privilegeService;

    @Autowired
    private RedisService redisService;

    @Autowired
    private BonusDelayService bonusDelayService;




    private Map<String, CostDataVO> costCenterMap = Maps.newHashMap();

    private static final String CONSUME_POINTS_TYPE = "1";

    private static final String BONUS_POINTS_TYPE = "2";

    private static final String SIGN_POINTS_TYPE = "5";


    private static final int STATUS_NO_SHOW = 4;

    private static final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");



    @Value("${FEIZHU_CHANNEL_ID}")
    private Integer FEIZHU_CHANNEL_ID;
    @Value("${OYO_MONEY_UNDERTAKE_OYO}")
    private Integer OYO_MONEY_UNDERTAKE_OYO;
    @Value("${OYO_MONEY_UNDERTAKE_OWNER}")
    private Integer OYO_MONEY_UNDERTAKE_OWNER;

    /**
     * 初始化成本中心
     */
    @PostConstruct
    private void buildInitialMap() {
        List<CostDataVO> costCenterList = costCenterRemoteService.getCostCenterList();
        log.info("初始化成本中心列表: {}", JSON.toJSONString(costCenterList));
        if (CollectionUtils.isNotEmpty(costCenterList)) {
            costCenterList.forEach(costDataVO -> {
                costCenterMap.put(costDataVO.getCostCode(), costDataVO);
            });
        }else {
            log.error("初始化成本中心服务异常,加载数据异常");
        }
    }
    private Map<String, BonusGainRuleDTO.BonusGainRuleInfo> getBonusMap(){
         Map<String, BonusGainRuleDTO.BonusGainRuleInfo> bonusGainRuleInfoMap =Maps.newHashMap();
        List<BonusGainRuleDTO.BonusGainRuleInfo> bonusGainRuleInfoList = bonusGainRuleService.getGainRuleList(MemberConstants.OYO_TENANT).getBonusGainRuleInfoList();
        if (CollectionUtils.isNotEmpty(bonusGainRuleInfoList)) {
            bonusGainRuleInfoList.forEach(bonusGainRuleInfo -> {
                bonusGainRuleInfoMap.put(bonusGainRuleInfo.getBonusType(), bonusGainRuleInfo);
            });
        }
        return bonusGainRuleInfoMap;
    }

    /**
     * 获取欧币汇率
     * @return
     */
    @Override
    public BaseResponse<ExchangeRateDTO> getOyoMoneyExchangeRate() {
        BonusCostRuleDTO bonusCostRuleDTO = bonusCostRuleService.getCostRuleList();
        if(bonusCostRuleDTO!=null&& CollectionUtils.isNotEmpty(bonusCostRuleDTO.getBonusCostRuleInfoList())){
            BonusCostRuleDTO.BonusCostRuleInfo bonusCostRuleInfo =bonusCostRuleDTO.getBonusCostRuleInfoList().get(0);
            return BaseResponse.success(ExchangeRateDTO.builder().pricePerUnit(bonusCostRuleInfo.getPricePerUnit()).costPerUnit(new BigDecimal(1).divide(bonusCostRuleInfo.getPricePerUnit(),2,BigDecimal.ROUND_UP))
                    .undertakeOwner(OYO_MONEY_UNDERTAKE_OWNER).undertakeOyo(OYO_MONEY_UNDERTAKE_OYO).build());
        }
        return BaseResponse.fail(ResponseCode.FAILURE);
    }

    /**
     * 获取签到ob信息
     * @param userId
     * @return
     */
    @Override
    public BaseResponse<MemberSignInMoneyDTO> getMemberSignInMoney(Long userId) {
        if(userId==null){
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(),"必传参数缺失");
        }
        Map<String, BonusGainRuleDTO.BonusGainRuleInfo> bonusGainRuleInfoMap =getBonusMap();
        MemberSignInMoneyDTO memberSignInMoneyDTO =new MemberSignInMoneyDTO();
        memberSignInMoneyDTO.setUserId(userId);
        MemberInfoBO memberInfoBO = memberInfoService.getMemberInfoByUserId(userId);
        if(memberInfoBO==null||memberInfoBO.getUserId()==null){
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(),"该会员不存在");
        }
        GradePrivilegeBO.BonusConfig bonusConfig = privilegeService.getGradePrivilegeByGradeId(memberInfoBO.getGradeId()).getBonusConfig();
        if(bonusConfig!=null&&bonusConfig.getSignPoint()!=null){
            memberSignInMoneyDTO.setGradeId(memberInfoBO.getGradeId());
            memberSignInMoneyDTO.setTotalNum(bonusConfig.getSignPoint().getPointNum());
            memberSignInMoneyDTO.setEffectDate(DateUtils.addDays(new Date(),bonusDelayService.getDelayByType(2)));
        }
        memberSignInMoneyDTO.setPointsDetails( getOyoMoneySourceList(bonusConfig.getSignPoint().getPointNum(),SIGN_POINTS_TYPE ,"签到鸥币"));
        if(bonusGainRuleInfoMap.get(SIGN_POINTS_TYPE)!=null){
            try {
                memberSignInMoneyDTO.setValidDate(DateUtils.addDays(SIMPLE_DATE_FORMAT.parse(bonusGainRuleInfoMap.get(SIGN_POINTS_TYPE).getStrValidPeriod()),bonusDelayService.getDelayByType(2)));
            } catch (Exception e) {
               log.error("时间转化异常",e);
            }
        }
        log.info("{}签到返回信息:{}",userId,JSON.toJSONString(memberSignInMoneyDTO));
        return BaseResponse.success(memberSignInMoneyDTO);
    }

    /**
     * 根据积分类型获取明细
     * @param points
     * @param type
     * @param name
     * @return
     */
    private List<OyoMoneySourceDTO> getOyoMoneySourceList(int points, String type,String name) {
        if(points>0){
            List<PointsShare> consumePointsShareList = calcPointsShare(points, type);
           return consumePointsShareList.stream().map(consumePointsShare -> {
                OyoMoneySourceDTO consumePointsDetail = new OyoMoneySourceDTO();
                consumePointsDetail.setPointTypeCode(type);
                consumePointsDetail.setPointTypeName(name);
                consumePointsDetail.setCostCode(consumePointsShare.getCostCode());
                consumePointsDetail.setCostName(consumePointsShare.getCostName());
                consumePointsDetail.setPointsNum(consumePointsShare.getPoints());
                return consumePointsDetail;
            }).collect(Collectors.toList());
        }
        return Lists.newArrayList();
    }

    /**
     * 获取房单ob明细
     * @param requestDTO
     * @return
     */
    @Override
    public BaseResponse<OyoMoneyDetailDTO> getOyoMoneyDetailByOrderSn(OyoMoneyDetailRequestDTO requestDTO) {
        if(requestDTO==null||requestDTO.getUserId()==null||requestDTO.getAmount()==null||requestDTO.getHotelId()==null){
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(),"房单欧币明细参数缺失");
        }
        Map<String, BonusGainRuleDTO.BonusGainRuleInfo> bonusGainRuleInfoMap =getBonusMap();
        OyoMoneyDetailDTO oyoMoneyDetailDTO=new OyoMoneyDetailDTO();
        HotelRemoteService.HotelInfo hotelInfo =hotelRemoteService.getHotelInfo(requestDTO.getHotelId());
        if(hotelInfo==null){
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(),"该酒店信息不存在");
        }
        log.info("{}获取房单ob明细请求信息:{}",requestDTO.getUserId(),JSON.toJSONString(requestDTO));
        oyoMoneyDetailDTO.setMarketingName(hotelInfo.getName());
        oyoMoneyDetailDTO.setEffectDate(new Date());
        //消费积分的有效期
        if(MapUtils.isNotEmpty(bonusGainRuleInfoMap)&&bonusGainRuleInfoMap.get(CONSUME_POINTS_TYPE)!=null){
            try {
                oyoMoneyDetailDTO.setExpireDate(SIMPLE_DATE_FORMAT.parse(bonusGainRuleInfoMap.get(CONSUME_POINTS_TYPE).getStrValidPeriod()));
            } catch (Exception e) {
                log.error("时间转化异常",e);
            }
        }
        oyoMoneyDetailDTO.setProvideId(requestDTO.getHotelId().toString());
        oyoMoneyDetailDTO.setProvideName(hotelInfo.getOyoId());
        oyoMoneyDetailDTO.setProvideType("HOTEL");
        processMemberBonusNum(requestDTO,oyoMoneyDetailDTO);
        log.info("{}获取房单ob明细返回信息:{}",requestDTO.getUserId(),JSON.toJSONString(oyoMoneyDetailDTO));
        return BaseResponse.success(oyoMoneyDetailDTO);
    }

    @Override
    public BaseResponse<OyoMoneyDelayDTO> getOyoMoneyDelay(OyoMoneyDelayRequestDTO requestDTO) {
        if(requestDTO==null||requestDTO.getType()==null){
            return BaseResponse.fail(ResponseCode.ILLEGAL_ARGUMENT);
        }
        OyoMoneyDelayDTO oyoMoneyDelayDTO=new OyoMoneyDelayDTO();
        oyoMoneyDelayDTO.setDelay(bonusDelayService.getDelayByType(requestDTO.getType()));
        return BaseResponse.success(oyoMoneyDelayDTO);
    }

    /**
     * 获取用户欧币数量集合
     * @param requestDTO
     * @return
     */
    private void processMemberBonusNum(OyoMoneyDetailRequestDTO requestDTO,OyoMoneyDetailDTO oyoMoneyDetailDTO){
        List<OyoMoneySourceDTO>  moneySourceDTOList = Lists.newArrayList();
        MemberInfoBO memberInfoBO = memberInfoService.getMemberInfoByUserId(requestDTO.getUserId());
        log.info("{}房单欧币查询会员基本信息: {}", requestDTO.getUserId(),JSON.toJSONString(memberInfoBO));
        QueryUserRequest request =new QueryUserRequest();
        request.setUserId(requestDTO.getUserId());
        OyoUser oyoUser = userInfoRemoteService.getUserByUserId(request);
        log.info("{}用户基本信息: {}", request.getUserId(),JSON.toJSONString(oyoUser));
        Integer gradeId = memberInfoBO.getGradeId();
        Integer nextGradeId = memberInfoBO.getNextGradeId();
        GradeInfoBO nextGradeInfoBO = null;
        if (nextGradeId != null) {
            nextGradeInfoBO = gradeService.getGradeByGradeId(nextGradeId);
        }
        double bonusFactor = 0;
        boolean memberStay = false;
        // 判断等级是否需要本人入住才可累计
        if(nextGradeInfoBO==null||nextGradeInfoBO.getMemberLimit()){
            // 需校验预订人与入住人身份证完全一致，才可认为是本人入住
            if (oyoUser.getRealCertificationNo() != null
                    && requestDTO.getCardNo() != null
                    && oyoUser.getRealCertificationNo().equals(requestDTO.getCardNo())) {
                memberStay = true;
            }
        }
        // 奖励积分必须本人入住 + 会员酒店   19.08 飞猪可以不是会员酒店
        GradePrivilegeBO.BonusConfig bonusConfig = privilegeService.getGradePrivilegeByGradeId(gradeId).getBonusConfig();
        if (memberStay && hotelService.isMemberHotel(requestDTO.getHotelId())) {
            bonusFactor = NumberUtils.toDouble(bonusConfig.getBonusFactor());
        }
        if(FEIZHU_CHANNEL_ID.equals(requestDTO.getChannelId()) &&memberStay){
            bonusFactor = NumberUtils.toDouble(bonusConfig.getBonusFactor());
        }
        if (requestDTO.getStatus() == STATUS_NO_SHOW) {
            bonusFactor = 0;
        }
        if(redisService.hasKey(RedisConstants.MEMBER_OYO_MONEY+ SIMPLE_DATE_FORMAT.format(requestDTO.getDate())+":"+requestDTO.getUserId())){
            bonusFactor=0;
            log.info("该用户{}今日已计算过,奖励鸥币倍数为0",requestDTO.getUserId());
        }else {
            redisService.setValue(RedisConstants.MEMBER_OYO_MONEY+ SIMPLE_DATE_FORMAT.format(requestDTO.getDate())+":"+requestDTO.getUserId(),1,RedisConstants.MEMBER_OYO_MONEY_EXPIRE);
        }
        int  bonusPoints = (int) (bonusFactor* requestDTO.getAmount());
        int  consumePoints =(int) (Double.valueOf(bonusConfig.getConsumeFactor()) * requestDTO.getAmount());

        moneySourceDTOList.addAll(getOyoMoneySourceList(consumePoints,CONSUME_POINTS_TYPE,"消费鸥币"));
        moneySourceDTOList.addAll(getOyoMoneySourceList(bonusPoints,BONUS_POINTS_TYPE,"奖励鸥币"));
        oyoMoneyDetailDTO.setPointsDetails(moneySourceDTOList);
        oyoMoneyDetailDTO.setUserName(oyoUser.getUserName());
        oyoMoneyDetailDTO.setTotalPointsNum(bonusPoints+consumePoints);
    }


    /**
     * 计算各个承担中心数量
     * @param points
     * @param pointType
     * @return
     */
    private List<OyoMoneyBizServiceImpl.PointsShare> calcPointsShare(Integer points, String pointType) {
        List<OyoMoneyBizServiceImpl.PointsShare> pointsShareList = Lists.newArrayList();
        Map<String, BonusGainRuleDTO.BonusGainRuleInfo> bonusGainRuleInfoMap =getBonusMap();
        BonusGainRuleDTO.BonusGainRuleInfo ruleInfo = bonusGainRuleInfoMap.get(pointType);
        Integer remainPoints = points;
        Integer remainRatio = 100;
        if (ruleInfo.getComissionConfig().getUndertake1Ratio() > 0) {
            OyoMoneyBizServiceImpl.PointsShare pointsShare = new OyoMoneyBizServiceImpl.PointsShare();
            pointsShare.setCostCode(ruleInfo.getComissionConfig().getUndertake1());
            pointsShare.setCostName(costCenterMap.get(ruleInfo.getComissionConfig().getUndertake1())==null?"":costCenterMap.get(ruleInfo.getComissionConfig().getUndertake1()).getCostName());
            Integer points1 = remainPoints * ruleInfo.getComissionConfig().getUndertake1Ratio() / remainRatio;
            remainPoints -= points1;
            remainRatio -= ruleInfo.getComissionConfig().getUndertake1Ratio();
            pointsShare.setPoints(points1);
            pointsShareList.add(pointsShare);
        }
        if (ruleInfo.getComissionConfig().getUndertake2Ratio() > 0) {
            OyoMoneyBizServiceImpl.PointsShare pointsShare = new OyoMoneyBizServiceImpl.PointsShare();
            pointsShare.setCostCode(ruleInfo.getComissionConfig().getUndertake2());
            pointsShare.setCostName(costCenterMap.get(ruleInfo.getComissionConfig().getUndertake2())==null?"":costCenterMap.get(ruleInfo.getComissionConfig().getUndertake2()).getCostName());
            Integer points2 = remainPoints * ruleInfo.getComissionConfig().getUndertake2Ratio() / remainRatio;
            remainPoints -= points2;
            remainRatio -= ruleInfo.getComissionConfig().getUndertake2Ratio();
            pointsShare.setPoints(points2);
            pointsShareList.add(pointsShare);
        }
        if (ruleInfo.getComissionConfig().getUndertake3Ratio() > 0) {
            OyoMoneyBizServiceImpl.PointsShare pointsShare = new OyoMoneyBizServiceImpl.PointsShare();
            pointsShare.setCostCode(ruleInfo.getComissionConfig().getUndertake3());
            pointsShare.setCostName(costCenterMap.get(ruleInfo.getComissionConfig().getUndertake3())==null?"":costCenterMap.get(ruleInfo.getComissionConfig().getUndertake3()).getCostName());
            Integer points3 = remainPoints * ruleInfo.getComissionConfig().getUndertake3Ratio() / remainRatio;
            remainPoints -= points3;
            remainRatio -= ruleInfo.getComissionConfig().getUndertake3Ratio();
            pointsShare.setPoints(points3);
            pointsShareList.add(pointsShare);
        }
        if (ruleInfo.getComissionConfig().getUndertake4Ratio() > 0) {
            OyoMoneyBizServiceImpl.PointsShare pointsShare = new OyoMoneyBizServiceImpl.PointsShare();
            pointsShare.setCostCode(ruleInfo.getComissionConfig().getUndertake4());
            pointsShare.setCostName(costCenterMap.get(ruleInfo.getComissionConfig().getUndertake4())==null?"":costCenterMap.get(ruleInfo.getComissionConfig().getUndertake4()).getCostName());
            Integer points4 = remainPoints * ruleInfo.getComissionConfig().getUndertake4Ratio() / remainRatio;
            remainPoints -= points4;
            remainRatio -= ruleInfo.getComissionConfig().getUndertake4Ratio();
            pointsShare.setPoints(points4);
            pointsShareList.add(pointsShare);
        }
        if (ruleInfo.getComissionConfig().getUndertake5Ratio() > 0) {
            OyoMoneyBizServiceImpl.PointsShare pointsShare = new OyoMoneyBizServiceImpl.PointsShare();
            pointsShare.setCostCode(ruleInfo.getComissionConfig().getUndertake5());
            pointsShare.setCostName(costCenterMap.get(ruleInfo.getComissionConfig().getUndertake5())==null?"":costCenterMap.get(ruleInfo.getComissionConfig().getUndertake5()).getCostName());
            Integer points5 = remainPoints * ruleInfo.getComissionConfig().getUndertake5Ratio() / remainRatio;
            pointsShare.setPoints(points5);
            pointsShareList.add(pointsShare);
        }
        return pointsShareList;
    }

    @Data
    private static class PointsShare {
        private String costCode;
        private String costName;
        private Integer points;
    }



    }
