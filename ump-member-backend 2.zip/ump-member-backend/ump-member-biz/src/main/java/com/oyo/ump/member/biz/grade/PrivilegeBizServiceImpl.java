package com.oyo.ump.member.biz.grade;


import com.alibaba.dubbo.config.annotation.Service;
import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import com.oyo.ump.member.biz.common.BizService;
import com.oyo.ump.member.common.beanutils.MapperWrapper;
import com.oyo.ump.member.service.PrivilegeService;
import com.oyo.ump.member.service.bo.GradePrivilegeBO;
import com.oyo.ump.member.service.dto.GradePrivilegeDTO;
import com.oyo.ump.member.service.member.PrivilegeBizService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @Description: 会员权益实现类
 * @Author: fang
 * @create: 2019-03-22
 **/
@BizService
@Service
@Component
@Slf4j
public class PrivilegeBizServiceImpl implements PrivilegeBizService {
    @Autowired
    private PrivilegeService privilegeService;

    /**
     * 获取等级权益列表
     * @return
     */
    @Override
    public BaseResponse<List<GradePrivilegeDTO>> getGradePrivilegeList() {
        List<GradePrivilegeBO> gradePrivilegeBOList;
        List<GradePrivilegeDTO> gradePrivilegeDTOList;
        gradePrivilegeBOList =privilegeService.getGradePrivilegeList();
        gradePrivilegeDTOList=assemblePrivilegeInfo(gradePrivilegeBOList);
        if(CollectionUtils.isNotEmpty(gradePrivilegeDTOList)){
            return BaseResponse.success(gradePrivilegeDTOList);
        }else {
            return BaseResponse.fail(ResponseCode.DATA_NOT_EXISTS);
        }
    }

    /**
     * 获取单个等级对应的权益
     * @param gradeId
     * @return
     */
    @Override
    public BaseResponse<GradePrivilegeDTO> getGradePrivilegeByGradeId(Integer gradeId) {
        if(gradeId==null){
            return BaseResponse.fail(ResponseCode.ILLEGAL_ARGUMENT);
        }
        GradePrivilegeBO gradePrivilegeBO=privilegeService.getGradePrivilegeByGradeId(gradeId);
        GradePrivilegeDTO  gradeInfoDTO=null;
        if(gradePrivilegeBO!=null){
            gradeInfoDTO= MapperWrapper.instance().map(gradePrivilegeBO, GradePrivilegeDTO.class);
        }
        if(gradeInfoDTO!=null&&gradeInfoDTO.getGradeId()!=null){
            return BaseResponse.success(gradeInfoDTO);
        }else {
            return BaseResponse.fail(ResponseCode.DATA_NOT_EXISTS.getCode(),"未有该等级权益信息");
        }
    }

    /**
     * BOlist转化为dtolist
     * @param gradePrivilegeBOList
     * @return
     */
    private List<GradePrivilegeDTO> assemblePrivilegeInfo(List<GradePrivilegeBO> gradePrivilegeBOList) {
        List<GradePrivilegeDTO> gradePrivilegeDTOList = Lists.newArrayList();
        if(CollectionUtils.isNotEmpty(gradePrivilegeBOList)){
            gradePrivilegeBOList.forEach(privilegeBO -> {
                gradePrivilegeDTOList.add( MapperWrapper.instance().map(privilegeBO, GradePrivilegeDTO.class));
            });
        }
        return gradePrivilegeDTOList;
    }
}
