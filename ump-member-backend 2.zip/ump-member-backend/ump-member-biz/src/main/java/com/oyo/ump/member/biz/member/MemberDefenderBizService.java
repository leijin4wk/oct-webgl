package com.oyo.ump.member.biz.member;

import com.oyo.common.response.BaseResponse;
import com.oyo.ump.defender.service.member.dto.MemberdefRecordDTO;
import com.oyo.ump.member.biz.common.BizService;
import com.oyo.ump.member.integration.service.defender.DefenderRemoteService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author Dong
 * @Classname MemberDefenderBizServiceImpl
 * @Description 用用户活动风控记录接口
 * @Date 2019-07-25
 */
@BizService
@Component
@Slf4j
public class MemberDefenderBizService {
    @Autowired
    private DefenderRemoteService defenderRemoteService;

    public BaseResponse<List<MemberdefRecordDTO>> getMemberDefActivityRecord(Long userId, Long activityId){
        BaseResponse<List<MemberdefRecordDTO>> response = defenderRemoteService.getMemberDefActivityRecord(userId, activityId);
        if(response != null){
            return response;
        }
        return null;
    }
}
