package com.oyo.ump.member.biz.common;

/**
 * @author Ding
 * @description
 * @date 2019-02-03
 */
public @interface BizService {
}
