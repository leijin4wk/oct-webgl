package com.oyo.ump.member.biz.crowd;

import com.alibaba.dubbo.config.annotation.Service;
import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import com.oyo.common.response.PagedResponse;
import com.oyo.ump.data.service.label.MemberLabelEnum;
import com.oyo.ump.data.service.label.dto.MemberLabelDTO;
import com.oyo.ump.data.service.label.dto.MemberLabelRequestDTO;
import com.oyo.ump.member.biz.common.BizService;
import com.oyo.ump.member.common.constants.MemberConstants;
import com.oyo.ump.member.dal.model.UmpDataMemberDimRptEntity;
import com.oyo.ump.member.integration.service.data.UmpDataRemoteService;
import com.oyo.ump.member.service.CrowdService;
import com.oyo.ump.member.service.bo.AddUserToCrowdBO;
import com.oyo.ump.member.service.bo.CrowdBO;
import com.oyo.ump.member.service.bo.CrowdUsersBo;
import com.oyo.ump.member.service.crowd.CrowdBizService;
import com.oyo.ump.member.service.dto.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@BizService
@Service
@Component
@Slf4j
public class CrowdBizServiceImpl implements CrowdBizService {

    @Autowired
    private CrowdService crowdService;

    private static final SimpleDateFormat TIME_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    @Value("${NEW_GUEST_CROWD_ID}")
    private Long NEW_GUEST_CROWD_ID;

    @Autowired
    private UmpDataRemoteService umpDataRemoteService;




    @Override
    public BaseResponse<Long> addUserToCrowd(AddCrowdUserDTO addCrowdUserDTO) {
        BaseResponse<Long> baseResponse = new BaseResponse<>();
        if (StringUtils.isEmpty(addCrowdUserDTO.getName())) {
            baseResponse.setCode(ResponseCode.PARAMS_IS_EMPTY.getCode());
            baseResponse.setMsg("人群名称不能为空");
            return baseResponse;
        }
        if (CollectionUtils.isEmpty(addCrowdUserDTO.getUserIds())) {
            baseResponse.setCode(ResponseCode.PARAMS_IS_EMPTY.getCode());
            baseResponse.setMsg("人群不能为空");
            return baseResponse;
        }
        if (addCrowdUserDTO.getUserIds().size() > 2000) {
            baseResponse.setCode(ResponseCode.ILLEGAL_ARGUMENT.getCode());
            baseResponse.setMsg("单次用户id不能超过2000");
            return baseResponse;
        }

        long id = crowdService.addUserToCrowd(addCrowdUserDTO.getCrowdId(), addCrowdUserDTO.getUserIds(), addCrowdUserDTO.getName()).getCrowdId();
        baseResponse.setData(id);
        baseResponse.setCode("000");
        baseResponse.setMsg("ok");
        return baseResponse;
    }

    @Override
    public BaseResponse<String> deleteCrowdUser(DeleteCrowdUserDTO deleteCrowdUserDTO) {
        BaseResponse<String> baseResponse = new BaseResponse<>();
        if (deleteCrowdUserDTO.getCrowdId() == null) {
            baseResponse.setCode(ResponseCode.PARAMS_IS_EMPTY.getCode());
            baseResponse.setMsg("人群id不能为空");
            return baseResponse;
        }
        if (CollectionUtils.isNotEmpty(deleteCrowdUserDTO.getUserIds())) {
            if (deleteCrowdUserDTO.getUserIds().size() > 2000) {
                baseResponse.setCode(ResponseCode.ILLEGAL_ARGUMENT.getCode());
                baseResponse.setMsg("单次用户id不能超过2000");
                return baseResponse;
            }
        }
        crowdService.deleteCrowdUser(deleteCrowdUserDTO.getCrowdId(), deleteCrowdUserDTO.getUserIds());
        baseResponse.setData("ok");
        baseResponse.setCode(ResponseCode.SUCCESS.getCode());
        baseResponse.setMsg("ok");
        return baseResponse;
    }

    @Override
    public PagedResponse<CrowdUsersDTO> findCrowdUser(CrowdUserConditionDTO crowdUserConditionDTO) {
        PagedResponse<CrowdUsersBo> pagedResponseBo = crowdService.findCrowdUser(crowdUserConditionDTO.getCrowdIds(), crowdUserConditionDTO.getUserId(),
                crowdUserConditionDTO.getPageNum(), crowdUserConditionDTO.getPageSize());
        PagedResponse<CrowdUsersDTO> pagedResponse = new PagedResponse<>(pagedResponseBo.getPageNum(), pagedResponseBo.getPageSize(), pagedResponseBo.getTotalCount());
        List<CrowdUsersDTO> list = new ArrayList<>();
        pagedResponseBo.getResult().stream().forEach(item -> {
            CrowdUsersDTO crowdUsersDTO = new CrowdUsersDTO();
            crowdUsersDTO.setUserId(item.getUserId());
            crowdUsersDTO.setCreateTime(item.getCreateTime());
            crowdUsersDTO.setCrowdIds(item.getCrowdIds());
            list.add(crowdUsersDTO);
        });
        pagedResponse.setResult(list);
        return pagedResponse;
    }

    @Override
    public BaseResponse<Boolean> existCrowdUser(ExistCrowdUserDTO existCrowdUserDTO) {
        BaseResponse<Boolean> baseResponse = new BaseResponse<>();
        if (existCrowdUserDTO.getCrowdId() == null) {
            baseResponse.setCode(ResponseCode.PARAMS_IS_EMPTY.getCode());
            baseResponse.setMsg("人群id不能为空");
            return baseResponse;
        }
        if (existCrowdUserDTO.getUserId() == null) {
            baseResponse.setCode(ResponseCode.PARAMS_IS_EMPTY.getCode());
            baseResponse.setMsg("用户id不能为空");
            return baseResponse;
        }

        baseResponse.setData(crowdService.existCrowdUser(existCrowdUserDTO.getCrowdId(), existCrowdUserDTO.getUserId()));
        baseResponse.setCode(ResponseCode.SUCCESS.getCode());
        baseResponse.setMsg("ok");
        return baseResponse;
    }

    @Override
    public PagedResponse<CrowdDTO> getCrowdList(CrowdListRequestDTO requestDTO) {
        PagedResponse<CrowdDTO> response =new PagedResponse<CrowdDTO>();
        Map<String, String> params = Maps.newHashMap();
        params.put("startTime", requestDTO.getStartTime()==null?null:TIME_FORMAT.format(requestDTO.getStartTime()));
        params.put("endTime", requestDTO.getEndTime()==null?null:TIME_FORMAT.format(requestDTO.getEndTime()));
        params.put("crowdStatus", requestDTO.getCrowdStatus()==null?null:requestDTO.getCrowdStatus().toString());
        params.put("crowdName", requestDTO.getCrowdName());
        params.put("crowdCreateType","1");
        PagedResponse<CrowdBO> result =crowdService.selectByConditionPaged(params,requestDTO.getPageNum(),requestDTO.getPageSize());
        if(result!=null){
            response.setPageNum(requestDTO.getPageNum());
            response.setPageSize(requestDTO.getPageSize());
            response.setTotalCount(result.getTotalCount());
            if(CollectionUtils.isNotEmpty(result.getResult())){
                response.setResult(result.getResult().stream().map(crowdBO -> {
                    CrowdDTO crowdDTO =new CrowdDTO();
                    crowdDTO.setCreateTime(crowdBO.getCreateTime());
                    crowdDTO.setCrowdCreateType(crowdBO.getCrowdCreateType());
                    crowdDTO.setCrowdName(crowdBO.getCrowdName());
                    crowdDTO.setCrowdNum(crowdBO.getCrowdNum());
                    crowdDTO.setCrowdStatus(crowdBO.getCrowdStatus());
                    crowdDTO.setId(crowdBO.getId());
                    crowdDTO.setUpdateTime(crowdBO.getUpdateTime());
                    crowdDTO.setDataUpdateTime(crowdBO.getDataUpdateTime());
                    crowdDTO.setCrowdTag(crowdBO.getCrowdTag());
                    return crowdDTO;
                }).collect(Collectors.toList()));
            }
        }
        return response;
    }

    @Override
    public BaseResponse<CrowdDetailDTO> getCrowdDetail(CrowdDetailRequestDTO requestDTO) {
        if(requestDTO.getCrowId()==null){
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(),"参数缺失");
        }
        CrowdDetailDTO crowdDetailDTO =new CrowdDetailDTO();
        crowdDetailDTO.setCrowdId(requestDTO.getCrowId());
        crowdDetailDTO.setRuleList(crowdService.getCrowdDetailById(requestDTO.getCrowId()).stream().map(ruleBO -> {
            CrowdDetailDTO.RuleDTO ruleDTO =new CrowdDetailDTO.RuleDTO();
            ruleDTO.setRule(ruleBO.getRule());
            ruleDTO.setRuleRelation(ruleBO.getRuleRelation());
            return ruleDTO;
        }).collect(Collectors.toList()));
        return BaseResponse.success(crowdDetailDTO);
    }

    /**
     * 20191210 改造支持俩种类型的人群
     * @param requestDTO
     * @return
     */
    @Override
    public BaseResponse<List<ExistCrowdDTO>> batchExistCrowdUser(BatchExistCrowdRequestDTO requestDTO) {
        if(CollectionUtils.isEmpty(requestDTO.getCrowdIdList())){
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(),"参数缺失");
        }
        log.info("人群查询入参{}", JSON.toJSONString(requestDTO));
        List<ExistCrowdDTO> existCrowdDTOList = Lists.newArrayList();
        List<CrowdBO> crowdBOList = crowdService.batchGetCrowd(requestDTO.getCrowdIdList());
        if(CollectionUtils.isEmpty(crowdBOList)){
            return BaseResponse.success(Lists.newArrayList());
        }
        Map<Long,CrowdBO> crowdBOMap=crowdBOList.stream().collect(Collectors.toMap(CrowdBO::getId, crowdBo->crowdBo));
        List<Long> notExitIds= requestDTO.getCrowdIdList().stream().collect(Collectors.toList());
        List<Long> type2List=Lists.newArrayList();
        List<Long> type1List=Lists.newArrayList();
        crowdBOList.forEach(crowdBO -> {
            if(crowdBO!=null){
                if(MemberConstants.CREATE_BY_TAG.equals(crowdBO.getCrowdCreateType())){
                    type1List.add(crowdBO.getId());
                    notExitIds.remove(crowdBO.getId());
                }
                if(MemberConstants.CREATE_BY_CUSTOM.equals(crowdBO.getCrowdCreateType())){
                    type2List.add(crowdBO.getId());
                    notExitIds.remove(crowdBO.getId());
                }
            }
        });
        if(CollectionUtils.isNotEmpty(notExitIds)){
            notExitIds.forEach(id->{
                ExistCrowdDTO existCrowdDTO =new ExistCrowdDTO();
                existCrowdDTO.setCrowdId(id);
                existCrowdDTO.setExist(false);
                existCrowdDTOList.add(existCrowdDTO);
            });
        }
        if(CollectionUtils.isNotEmpty(type2List)){
            type2List.forEach(id->{
                ExistCrowdDTO existCrowdDTO =new ExistCrowdDTO();
                existCrowdDTO.setCrowdId(id);
                existCrowdDTO.setExist(crowdService.existCrowdUser(id, requestDTO.getUserId()));
                existCrowdDTOList.add(existCrowdDTO);
            });
        }
        //增加新客特殊逻辑处理
        if(type1List.contains(NEW_GUEST_CROWD_ID)){
            ExistCrowdDTO existCrowdDTO =new ExistCrowdDTO();
            existCrowdDTO.setCrowdId(NEW_GUEST_CROWD_ID);
            existCrowdDTO.setExist(false);
            MemberLabelRequestDTO memberLabelRequestDTO =new MemberLabelRequestDTO();
            memberLabelRequestDTO.setUserId(requestDTO.getUserId());
            memberLabelRequestDTO.setLabelSet(Sets.newHashSet(MemberLabelEnum.NewGuest.getCode()));
            List<MemberLabelDTO> memberLabelDTOS = umpDataRemoteService.getMemberLabel(memberLabelRequestDTO);
            if(CollectionUtils.isNotEmpty(memberLabelDTOS)){
                MemberLabelDTO memberLabelDTO = memberLabelDTOS.get(0);
                if(memberLabelDTO!=null&&(Boolean) memberLabelDTO.getResult()){
                    existCrowdDTO.setExist(true);
                }
            }
            existCrowdDTOList.add(existCrowdDTO);
            type1List.remove(NEW_GUEST_CROWD_ID);
        }
        if(CollectionUtils.isNotEmpty(type1List)){
            log.info("用户id{}distinctId{}人群入参{}", requestDTO.getUserId(),requestDTO.getDistinctId(),JSON.toJSONString(requestDTO));
            UmpDataMemberDimRptEntity  entity = crowdService.getMemberDimInfo(requestDTO.getUserId(),requestDTO.getDistinctId());
            if(entity==null){
                 existCrowdDTOList.addAll(type1List.stream().map(crowdId->{
                    ExistCrowdDTO existCrowdDTO =new ExistCrowdDTO();
                    existCrowdDTO.setCrowdId(crowdId);
                    existCrowdDTO.setExist(false);
                    return existCrowdDTO;
                }).collect(Collectors.toList()));
            }else {
                type1List.stream().forEach(crowdId->{
                    ExistCrowdDTO existCrowdDTO =new ExistCrowdDTO();
                    existCrowdDTO.setCrowdId(crowdId);
                    CrowdBO crowdBO = crowdBOMap.get(crowdId);
                    existCrowdDTO.setExist(crowdService.userFitCrowdRule(crowdBO,entity));
                    existCrowdDTOList.add(existCrowdDTO);
                });
            }
        }
        log.info("{}人群查询出参{}",requestDTO.getUserId(), JSON.toJSONString(existCrowdDTOList));
        return BaseResponse.success(existCrowdDTOList);
    }

    @Override
    public BaseResponse<AddCrowdUserResponseDTO> addUserToCrowdV2(AddCrowdUserDTO addCrowdUserDTO) {
        if(addCrowdUserDTO==null||addCrowdUserDTO.getCrowdId()==null||CollectionUtils.isEmpty(addCrowdUserDTO.getUserIds())){
            return BaseResponse.fail(ResponseCode.ILLEGAL_ARGUMENT);
        }
        if (addCrowdUserDTO.getUserIds().size() >5000) {

            return BaseResponse.fail(ResponseCode.FAILURE.getCode(),"单次上限不超过5000");
        }
        Long count =crowdService.getCrowdCount(addCrowdUserDTO.getCrowdId());
        if(count+addCrowdUserDTO.getUserIds().size()>100000){
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(),"总数量上限不超过100000");
        }
        return BaseResponse.success(getAddCrowdUserResponseDTO(addCrowdUserDTO));
    }

    /**
     * 创建/新增人群
     * @param addCrowdUserDTO
     * @return
     */
    private AddCrowdUserResponseDTO getAddCrowdUserResponseDTO(AddCrowdUserDTO addCrowdUserDTO) {
        AddUserToCrowdBO bo = crowdService.addUserToCrowd(addCrowdUserDTO.getCrowdId(), addCrowdUserDTO.getUserIds(), addCrowdUserDTO.getName());
        AddCrowdUserResponseDTO addCrowdUserResponseDTO =new AddCrowdUserResponseDTO();
        addCrowdUserResponseDTO.setCrowdId(bo.getCrowdId());
        addCrowdUserResponseDTO.setCount(bo.getCount());
        return addCrowdUserResponseDTO;
    }

    @Override
    public BaseResponse<AddCrowdUserResponseDTO> createUserCrowd(AddCrowdUserDTO addCrowdUserDTO) {
        if(addCrowdUserDTO==null||addCrowdUserDTO.getName()==null||CollectionUtils.isEmpty(addCrowdUserDTO.getUserIds())){
            return BaseResponse.fail(ResponseCode.ILLEGAL_ARGUMENT);
        }
        if (addCrowdUserDTO.getUserIds().size() >5000) {
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(),"创建单次上限不超过5000");
        }
        return BaseResponse.success(getAddCrowdUserResponseDTO(addCrowdUserDTO));
    }
}
