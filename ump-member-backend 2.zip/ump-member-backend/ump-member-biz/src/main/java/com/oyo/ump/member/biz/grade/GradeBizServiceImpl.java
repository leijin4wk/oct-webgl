package com.oyo.ump.member.biz.grade;

import com.alibaba.dubbo.config.annotation.Service;
import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import com.oyo.ump.member.biz.common.BizService;
import com.oyo.ump.member.common.beanutils.MapperWrapper;
import com.oyo.ump.member.common.enums.GradeRefreshRuleEnum;
import com.oyo.ump.member.service.GradeService;
import com.oyo.ump.member.service.bo.GradeInfoBO;
import com.oyo.ump.member.service.dto.GradeInfoDTO;
import com.oyo.ump.member.service.dto.RefreshRuleDTO;
import com.oyo.ump.member.service.member.GradeBizService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

/**
 * @Description: 等级实现类
 * @Author: fang
 * @create: 2019-03-22
 **/
@BizService
@Service
@Component
@Slf4j
public class GradeBizServiceImpl implements GradeBizService {
    @Autowired
    private GradeService gradeService;

    /**
     * 获取等级列表
     * @return
     */
    @Override
    public BaseResponse<List<GradeInfoDTO>> getGradeInfoList() {
        List<GradeInfoBO> gradeInfoBOList = gradeService.getGradeInfoList();
        List<GradeInfoDTO> gradeInfoDTOList=assembleGradeInfo(gradeInfoBOList);
        if(CollectionUtils.isNotEmpty(gradeInfoDTOList)){
            return BaseResponse.success(gradeInfoDTOList);
        }
        return BaseResponse.fail(ResponseCode.DATA_NOT_EXISTS);
    }

    /**
     * 获取单个等级
     * @param gradeId
     * @return
     */
    @Override
    public BaseResponse<GradeInfoDTO> getGradeByGradeId(Integer gradeId) {
        if(gradeId==null){
            return BaseResponse.fail(ResponseCode.ILLEGAL_ARGUMENT);
        }
        GradeInfoBO  gradeInfoBO = gradeService.getGradeByGradeId(gradeId);
        GradeInfoDTO  gradeInfoDTO =null;
        if(gradeInfoBO!=null){
            gradeInfoDTO= MapperWrapper.instance().map(gradeInfoBO, GradeInfoDTO.class);
        }
        if(gradeInfoDTO!=null&&gradeInfoDTO.getGradeId()!=null){
            return BaseResponse.success(gradeInfoDTO);
        }else {
            return BaseResponse.fail(ResponseCode.DATA_NOT_EXISTS.getCode(),"未有该等级信息");
        }
    }

    @Override
    public BaseResponse<List<GradeInfoDTO>> getGradeInfoList(String tenant) {
         return BaseResponse.success(assembleGradeInfo(gradeService.getGradeInfoList(tenant)));
    }


    private List<GradeInfoDTO> assembleGradeInfo(List<GradeInfoBO> gradeInfoBOList) {
        List<GradeInfoDTO> gradeInfoDTOList =Lists.newArrayList();
        if(CollectionUtils.isNotEmpty(gradeInfoBOList)){
            gradeInfoBOList.forEach(gradeInfoBO -> {
                gradeInfoDTOList.add( MapperWrapper.instance().map(gradeInfoBO, GradeInfoDTO.class));
            });
        }
        return gradeInfoDTOList;
    }

}
