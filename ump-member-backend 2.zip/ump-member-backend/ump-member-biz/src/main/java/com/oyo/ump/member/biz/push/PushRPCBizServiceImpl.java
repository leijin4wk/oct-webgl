package com.oyo.ump.member.biz.push;

import com.alibaba.dubbo.config.annotation.Service;
import com.alibaba.fastjson.JSON;
import com.ctrip.framework.apollo.spring.annotation.ApolloJsonValue;
import com.github.javaparser.utils.Log;
import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import com.oyo.ump.member.biz.common.BizService;
import com.oyo.ump.member.service.CrowdService;
import com.oyo.ump.member.service.PushPromotionService;
import com.oyo.ump.member.service.PushService;
import com.oyo.ump.member.service.PushTemplateRelationService;
import com.oyo.ump.member.service.bo.PushPromotionBO;
import com.oyo.ump.member.service.dto.PromotionPushRequestDTO;
import com.oyo.ump.member.service.enums.PushOperationTypeEnum;
import com.oyo.ump.member.service.push.PushRPCBizService;
import com.oyo.utp.pa.common.utils.DateUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * @author Dong
 * @Description
 * @Date 2019-12-31
 */
@BizService
@Service
@Component
@Slf4j
public class PushRPCBizServiceImpl implements PushRPCBizService {
    @Autowired
    PushService pushService;
    @Autowired
    PushPromotionService pushPromotionService;
    @Autowired
    CrowdService crowdService;
    @Autowired
    PushTemplateRelationService pushTemplateRelationService;
    @ApolloJsonValue("${PROMOTION_PUSH_INFO}")
    private Map<String, String> promotionConfigMap;

    @Override
    public BaseResponse<Boolean> promotionPushOperation(PromotionPushRequestDTO pushRequestDTO) {
        log.info("活动推送的请求信息:{}", JSON.toJSONString(pushRequestDTO));
        // 校验请求
        BaseResponse checkReaponse = checkRequest(pushRequestDTO);
        if(!ResponseCode.SUCCESS.getCode().equals(checkReaponse.getCode())){
            return checkReaponse;
        }
        if(!promotionConfigMap.get("promotionId").equals(pushRequestDTO.getPromotionId())){
            log.warn("警告：活动推送的活动工具ID可能有变化！");
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(),"promotionId有误！");
        }
        Set<Long> userIds = new HashSet<>();
        userIds.add(pushRequestDTO.getUserId());

        try{
            // 1、检查（promotionType+promotionId+startTime）push是否已创建（先查缓存，再查库）
            PushPromotionBO pushPromotionBO =  queryPromotionPush(pushRequestDTO);
            log.info("活动推送信息:{}", JSON.toJSONString(pushPromotionBO));
            if(null != pushPromotionBO && null != pushPromotionBO.getCrowdId()){

                // 2、如果场次push已经创建。查询 用户在人群中返回true，不在人群中返回false；关注 把用户加到人群返回true；取消 把用户从人群移除返回false
                if(PushOperationTypeEnum.QUERY.getType().equals(pushRequestDTO.getOperation())){
                    Boolean isInCrowd = crowdService.existCrowdUser(pushPromotionBO.getCrowdId(),pushRequestDTO.getUserId());
                    // 查询 用户在人群中返回true，不在人群中返回false
                    return BaseResponse.success(isInCrowd);
                }else if(PushOperationTypeEnum.ADD.getType().equals(pushRequestDTO.getOperation())){
                    // 关注 把用户加到人群返回true
                    crowdService.addUserToCrowd(pushPromotionBO.getCrowdId(),userIds,"");
                    return BaseResponse.success(true);
                }else if(PushOperationTypeEnum.CANCEL.getType().equals(pushRequestDTO.getOperation())){
                    // 取消 把用户从人群移除返回false
                    crowdService.deleteCrowdUser(pushPromotionBO.getCrowdId(),userIds);
                    return BaseResponse.success(false);
                }else {
                    return BaseResponse.fail(ResponseCode.ILLEGAL_ARGUMENT);
                }
            }else {
                log.warn("活动推送的场次还没有创建,进入兜底逻辑");
                // 3、如果没有场次push还没创建。查询 直接返回false；关注 创建场次push和人群（写缓存） 把用户加到人群返回true；取消 直接返回false
                if(PushOperationTypeEnum.QUERY.getType().equals(pushRequestDTO.getOperation())){
                    // 查询 直接返回false
                    return BaseResponse.success(false);
                }else if(PushOperationTypeEnum.ADD.getType().equals(pushRequestDTO.getOperation())){
                    Long crowdId = pushService.createPromotionPush(convert2BO(pushRequestDTO));
                    // 关注 把用户加到人群返回true
                    crowdService.addUserToCrowd(crowdId,userIds,"");
                    return BaseResponse.success(true);
                }else if(PushOperationTypeEnum.CANCEL.getType().equals(pushRequestDTO.getOperation())){
                    // 取消 直接返回false
                    return BaseResponse.success(false);
                }else {
                    return BaseResponse.fail(ResponseCode.ILLEGAL_ARGUMENT);
                }
            }
        }catch (Exception e){
            log.info("PRC 操作push出现异常：",e);
            return BaseResponse.fail(ResponseCode.FAILURE);
        }

    }

    /**
     * 检查（promotionType+promotionId+startTime）push是否已创建（先查缓存，再查库）
     * @param pushRequestDTO
     * @return PushPromotionBO
     */
    private PushPromotionBO queryPromotionPush(PromotionPushRequestDTO pushRequestDTO){
        try{
            PushPromotionBO pushPromotionBO = pushPromotionService.selectByCondition(convert2BO(pushRequestDTO));
            return pushPromotionBO;
        }catch (Exception e){
            Log.info("查询活动push信息异常",e);
        }
        return null;
    }

    private PushPromotionBO convert2BO(PromotionPushRequestDTO pushRequestDTO){
        PushPromotionBO pushPromotionBO = new PushPromotionBO();
        pushPromotionBO.setPromotionType(promotionConfigMap.get("promotionType"));
        pushPromotionBO.setPromotionId(pushRequestDTO.getPromotionId());
        pushPromotionBO.setStartTime(pushRequestDTO.getStartTime());
        return pushPromotionBO;
    }

    private BaseResponse checkRequest(PromotionPushRequestDTO pushRequestDTO){
        if(StringUtils.isBlank(pushRequestDTO.getPromotionId())||StringUtils.isBlank(pushRequestDTO.getOperation())||null==pushRequestDTO.getUserId()||StringUtils.isBlank(pushRequestDTO.getStartTime())){
            log.info("活动推送的请求参数非法");
            return BaseResponse.fail(ResponseCode.ILLEGAL_ARGUMENT.getCode(),"活动推送的请求参数非法");
        }
        Date startTime = DateUtils.formatByStringDate(pushRequestDTO.getStartTime(), "yyyy-MM-dd HH:mm:ss");
        if(!startTime.after(new Date(System.currentTimeMillis()))){
            log.info("活动推送时间早于当前时间");
            return BaseResponse.fail(ResponseCode.ILLEGAL_ARGUMENT.getCode(),"活动推送时间早于当前时间");
        }
        return BaseResponse.success(ResponseCode.SUCCESS);
    }

}
