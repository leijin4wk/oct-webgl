package com.oyo.ump.member.biz.member;

import com.google.common.collect.Maps;
import com.oyo.common.response.PagedResponse;
import com.oyo.ump.member.biz.common.BizService;
import com.oyo.ump.member.common.constants.MemberConstants;
import com.oyo.ump.member.integration.service.user.JpUserInfoRemoteService;
import com.oyo.ump.member.integration.service.user.OyoUser;
import com.oyo.ump.member.integration.service.user.UserInfoRemoteService;
import com.oyo.ump.member.integration.service.wallet.PointsRemoteService;
import com.oyo.ump.member.service.MemberIdentityListService;
import com.oyo.ump.member.service.bo.MemberIdentityBO;
import com.oyo.uum.api.user.request.user.QueryUserRequest;
import com.oyo.wallet.client.req.PointsBatchQueryBalanceDTO;
import com.oyo.wallet.client.resp.PointsBatchQueryBalanceVO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import top.rdfa.biz.actor.customer.client.request.AccountCustomerBasicRequest;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

/**
 * @author Dong
 * @Classname MemberIdentityListBizServiceImpl
 * @Description 会员身份列表 聚合业务
 * @Date 2019-03-26
 */
@BizService
@Component
@Slf4j
public class MemberIdentityListBizService {
    @Autowired
    private UserInfoRemoteService userInfoRemoteService;
    @Autowired
    PointsRemoteService pointsRemoteService;
    @Autowired
    MemberIdentityListService memberIdentityListService;
    @Autowired
    private JpUserInfoRemoteService jpUserInfoRemoteService;

    /**
     * 用户身份信息列表查询（支持 查询条件）
     *
     * @param params
     * @return com.oyo.ump.member.service.bo.MemberIdentityPageBO
     */
    public PagedResponse<MemberIdentityBO> getMemberIdentityList(Map<String, Object> params) {
        PagedResponse<MemberIdentityBO> pagedResponse = new PagedResponse<>();
        String phone = null;
        String nickName = null;
        String tenant = MemberConstants.OYO_TENANT;
        List<Long> userIds = Lists.newArrayList();

        if (params.get("phone") != null) {
             phone = params.get("phone").toString();
        }
        if (params.get("nickName") != null) {
            nickName = params.get("nickName").toString();
        }
        if (params.get("tenant") != null) {
            tenant = params.get("tenant").toString();
        }

        if (StringUtils.isNotBlank(phone) || StringUtils.isNotBlank(nickName)) {
            // phone nickName 有值的时候，先去用户中心查询
            Map<Long, OyoUser> oyoUserMap = getUserByCommon(phone, nickName, tenant);
            if (MapUtils.isNotEmpty(oyoUserMap)) {
                userIds = Lists.newArrayList(oyoUserMap.keySet());
            }

            // 2、根据1中用户列表的uerIds，结合其他查询条件 获取会员信息列表
            if (CollectionUtils.isNotEmpty(userIds)) {
                params.put("userIds", userIds);
                pagedResponse = memberIdentityListService.getMemberIdentityList(params);
                // 3、组合会员信息
                assembleOyoUserInfo(pagedResponse, oyoUserMap);
            }
        } else {
            // phone nickName 没有值得情况，直接本地查询
            // 1、取出本地的会员列表
            pagedResponse = memberIdentityListService.getMemberIdentityList(params);

            if (CollectionUtils.isNotEmpty(pagedResponse.getResult())) {
                for (MemberIdentityBO memberIdentityBO : pagedResponse.getResult()) {
                    userIds.add(memberIdentityBO.getUserId());
                }
            }

            // 2、根据本领域的List<userId>,获得RPC对应的外领域会员信息列表
            if (CollectionUtils.isNotEmpty(userIds)) {
                Map<Long, OyoUser> oyoUserMap = getUserByIds(userIds, tenant);
                assembleOyoUserInfo(pagedResponse, oyoUserMap);
            }
        }

        // 组装积分信息
        assemblePointsData(userIds, tenant, pagedResponse);

        return pagedResponse;
    }

    private void assembleOyoUserInfo(PagedResponse<MemberIdentityBO> pagedResponse, Map<Long, OyoUser> oyoUserMap) {
        if (CollectionUtils.isNotEmpty(pagedResponse.getResult())) {
            pagedResponse.getResult().forEach(memberIdentityBO -> {
                OyoUser oyoUser = oyoUserMap.get(memberIdentityBO.getUserId());
                if (oyoUser != null) {
                    memberIdentityBO.setNickName(oyoUser.getUserName());
                    memberIdentityBO.setPhone(oyoUser.getPhone());
                    memberIdentityBO.setPlatform(oyoUser.getPlatform());
                    memberIdentityBO.setPlatformName(oyoUser.getPlatformName());
                    memberIdentityBO.setEmail(oyoUser.getEmail());
                }
            });
        }
    }

    private void assemblePointsData(List<Long> userIds, String tenant, PagedResponse<MemberIdentityBO> pagedResponse) {
        // RPC 获取积分信息
        if (CollectionUtils.isEmpty(userIds)) {
            return;
        }
        PointsBatchQueryBalanceDTO pointsBatchQueryBalanceDTO = new PointsBatchQueryBalanceDTO();
        DateTimeFormatter dtFormatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS");
        String dateTime = LocalDateTime.now(ZoneOffset.of("+8")).format(dtFormatter);
        pointsBatchQueryBalanceDTO.setBatchNo(dateTime);
        pointsBatchQueryBalanceDTO.setSource("CRM");
        pointsBatchQueryBalanceDTO.setTenantId(tenant);
        // long list to string list
        List<String> pointsUserIds = Lists.newArrayList();
        userIds.forEach(userId -> {
            pointsUserIds.add(userId.toString());
        });
        pointsBatchQueryBalanceDTO.setUserIds(pointsUserIds);
        PointsBatchQueryBalanceVO pointsBatchQueryBalanceVO = pointsRemoteService.batchQueryBalance(pointsBatchQueryBalanceDTO);
        // 组合拼装积分信息
        if (pointsBatchQueryBalanceVO != null && pointsBatchQueryBalanceVO.getBalanceVOList() != null && CollectionUtils.isNotEmpty(pointsBatchQueryBalanceVO.getBalanceVOList())) {
            pagedResponse.getResult().forEach(memberIdentityBO -> {
                pointsBatchQueryBalanceVO.getBalanceVOList().forEach(pointsQueryBalanceVO -> {
                    if (memberIdentityBO.getUserId().toString().equals(pointsQueryBalanceVO.getUserId())) {
                        memberIdentityBO.setBonus(pointsQueryBalanceVO.getTotalPointsNum());
                        memberIdentityBO.setRecentExpirationDate(pointsQueryBalanceVO.getPointsLastExpireTime());
                    }
                });
            });
        }
    }

    private Map<Long, OyoUser> getUserByIds(List<Long> userIds, String tenant) {
        Map<Long, OyoUser> oyoUserMap = Maps.newHashMap();
        List<OyoUser> oyoUserList = Lists.newArrayList();
        if (MemberConstants.OYO_TENANT.equals(tenant)) {
            oyoUserList = userInfoRemoteService.queryUsersByUserIds(userIds);
        } else if (MemberConstants.OYO_JP_TENANT.equals(tenant)) {
            oyoUserList = jpUserInfoRemoteService.getAccountCustomersByBatch(userIds);
        }
        if(CollectionUtils.isNotEmpty(oyoUserList)){
            oyoUserList.forEach(oyoUser -> {
                oyoUserMap.put(oyoUser.getUserId(), oyoUser);
            });
        }
        return oyoUserMap;
    }

    private Map<Long, OyoUser> getUserByCommon(String phone, String nickName, String tenant) {
        Map<Long, OyoUser> oyoUserMap = Maps.newHashMap();
        List<OyoUser> oyoUserList = Lists.newArrayList();
        if (MemberConstants.OYO_TENANT.equals(tenant)) {
            QueryUserRequest request = new QueryUserRequest();
            request.setPageSize(MemberConstants.PAGE_SIZE);
            if (StringUtils.isNotBlank(phone)) {
                request.setPhone(phone);
            }
            if (StringUtils.isNotBlank(nickName)) {
                request.setUserName(nickName);
            }
            oyoUserList = userInfoRemoteService.getUserByUser(request);
        } else if (MemberConstants.OYO_JP_TENANT.equals(tenant)) {
            AccountCustomerBasicRequest request = new AccountCustomerBasicRequest();
            if (StringUtils.isNotBlank(phone)) {
                request.setPhone(phone);
            }
            if (StringUtils.isNotBlank(nickName)) {
                request.setName(nickName);
            }
            oyoUserList = jpUserInfoRemoteService.getAccountCustomersByBasic(request);
        }
        oyoUserList.forEach(oyoUser -> {
            if (oyoUser.getUserId() != null) {
                oyoUserMap.put(oyoUser.getUserId(), oyoUser);
            }
        });
        return oyoUserMap;
    }


}
