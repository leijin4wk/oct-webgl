package com.oyo.ump.member.biz.hotel;

import com.alibaba.dubbo.config.annotation.Service;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import com.oyo.ump.member.service.HotelService;
import com.oyo.ump.member.service.bo.HotelBO;
import com.oyo.ump.member.service.member.HotelBizService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author Dong
 * @Classname HotelBizServiceImpl
 * @Description 活动酒店对外接口实现类
 * @Date 2019-04-01
 */
@Service
@Component
@Slf4j
public class HotelBizServiceImpl implements HotelBizService {
    @Autowired
    private HotelService hotelService;

    @Override
    public BaseResponse<List<Long>> getSalesHotel(List<Long> hotelIds) {
        log.info("查询活动酒店入参: {}", JSON.toJSONString(hotelIds));

        List<Long> salesHotelIds = Lists.newArrayList();

        if(CollectionUtils.isNotEmpty(hotelIds)){
            List<HotelBO> hotelBOList = hotelService.getSalesHotel(hotelIds);
            hotelBOList.forEach(hotelBO -> {
                salesHotelIds.add(hotelBO.getHotelId());
            });
        }else {
            // 传入的酒店IDlist空
            BaseResponse.fail(ResponseCode.ILLEGAL_ARGUMENT);
        }
        log.info("查询活动酒店返回: {}", JSON.toJSONString(salesHotelIds));
        return BaseResponse.success(salesHotelIds);
    }
}
