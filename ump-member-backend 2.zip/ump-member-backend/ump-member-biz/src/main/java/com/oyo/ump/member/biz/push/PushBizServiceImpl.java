package com.oyo.ump.member.biz.push;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import com.oyo.cpush.client.dto.request.*;
import com.oyo.cpush.client.response.ClientBaseResponse;
import com.oyo.sso.core.util.SsoUtil;
import com.oyo.ump.member.biz.common.BizService;
import com.oyo.ump.member.common.beanutils.MapperWrapper;
import com.oyo.ump.member.common.constants.MemberConstants;
import com.oyo.ump.member.dal.dao.PushExtraMapper;
import com.oyo.ump.member.dal.dao.PushMapper;
import com.oyo.ump.member.dal.dao.PushRuleMapper;
import com.oyo.ump.member.integration.service.platform.PlatformRemoteService;
import com.oyo.ump.member.integration.service.push.PushTemplateService;
import com.oyo.ump.member.integration.service.user.BUserInfoRemoteService;
import com.oyo.ump.member.integration.service.user.RemoteOrganizationService;
import com.oyo.ump.member.integration.service.user.UserInfoRemoteService;
import com.oyo.ump.member.service.PushService;
import com.oyo.ump.member.service.PushTemplateRelationService;
import com.oyo.ump.member.service.bo.PushTemplateRelationBO;
import com.oyo.ump.member.service.dto.PushTemplateDTO;
import com.oyo.ump.member.service.enums.TriggerChannelEnum;
import com.oyo.ump.platform.service.activity.dto.OrganizationBizDTO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Dong
 * @Classname PushBizServiceImpl
 * @Description 事件推送聚合业务
 * @Date 2019-05-07
 */
@BizService
@Component
@Slf4j
public class PushBizServiceImpl {
    @Autowired
    PlatformRemoteService platformRemoteService;
    @Autowired
    PushTemplateService pushTemplateService;
    @Autowired
    PushTemplateRelationService pushTemplateRelationService;
    @Autowired
    PushService pushService;
    @Autowired
    PushMapper pushMapper;
    @Autowired
    PushRuleMapper pushRuleMapper;
    @Autowired
    PushExtraMapper pushExtraMapper;
    @Autowired
    UserInfoRemoteService userInfoRemoteService;
    @Autowired
    RemoteOrganizationService remoteOrganizationService;
    @Autowired
    BUserInfoRemoteService bUserInfoRemoteService;

    public Map<Long, String> getAllDepartment(){
        Map<Long, String> departmentMap = new HashMap<>();
        BaseResponse response = platformRemoteService.queryOrganization();
        if(response != null && response.getData() != null){
            List<OrganizationBizDTO> organizationBizDTOList = (List<OrganizationBizDTO>) response.getData();
            log.info("*********部门数量***********：{}", organizationBizDTOList.size());
            organizationBizDTOList.forEach(organizationBizDTO -> {
                departmentMap.put(organizationBizDTO.getId(),organizationBizDTO.getName());
            });
        }
        return departmentMap;
    }

    /**
     * 创建推送模板，维护模板推送关系表中模板参数
     * @param
     * @return java.lang.Long
     */
    public String createTemplate(PushTemplateDTO.TemplateInfo templateInfo){
        if(templateInfo.getUrlType()==2&&TriggerChannelEnum.APPPUSH.getType().equals(templateInfo.getTriggerChannel())&&null==templateInfo.getActivityUrl()){
            log.info("urlType==2(活动链接) 推送类型是c端用户的apppush的时候activityUrl 不能为空");
            return null;
        }
        templateInfo.setBizChannel(MemberConstants.MEMBER_CHANNEL);
        templateInfo.setCreateAccountId(SsoUtil.currentUser().getUserId());
        templateInfo.setUpdateAccountId(SsoUtil.currentUser().getUserId());
        templateInfo.setCreateAccountName(bUserInfoRemoteService.getNameById(SsoUtil.currentUser().getUserId()));
        templateInfo.setUpdateAccountName(bUserInfoRemoteService.getNameById(SsoUtil.currentUser().getUserId()));
        ClientBaseResponse response = new ClientBaseResponse();

        // 附加站内信
        if(templateInfo.getIsAttachInternalMsg()){
            log.info("附加站内信方式创建站内信模板");
            InternalMsgTemplateCreateDTO internalMsgTemplateCreateDTO = convert2internalMsgTemplateCreateDTO(templateInfo);
            response = pushTemplateService.createTemplate(internalMsgTemplateCreateDTO);
            if(null != response && ResponseCode.SUCCESS.getCode().equals(response.getCode()) && null != response.getData()){
                log.info("附加站内信方式创建站内信模板成功，站内信模板号:{}",response.getData().toString());
                return response.getData().toString();
            }else {
                log.info("附加站内信方式创建站内信模板失败");
                return null;
            }
        }

        // 远程服务创建模板
        if(TriggerChannelEnum.SMS.getType().equals(templateInfo.getTriggerChannel())){
            // 短信
            SmsPushTemplateCreateDTO smsPushTemplateCreateDTO = convert2SmsPushDTO(templateInfo);
            response = pushTemplateService.createTemplate(smsPushTemplateCreateDTO);
        }else if(TriggerChannelEnum.APPPUSH.getType().equals(templateInfo.getTriggerChannel())){
            // APP PUSH
            AppPushTemplateCreateDTO appPushTemplateCreateDTO = convert2APPPushDTO(templateInfo);
            response = pushTemplateService.createTemplate(appPushTemplateCreateDTO);
        }else if(TriggerChannelEnum.WECHAT.getType().equals(templateInfo.getTriggerChannel())){
            // 微信公众号
            WeChatPublicAccountTemplateCreateDTO wechatPushTemplateCreateDTO = convert2weChatPushDTO(templateInfo);
            response = pushTemplateService.createTemplate(wechatPushTemplateCreateDTO);
        }else if(TriggerChannelEnum.WECHATAPP.getType().equals(templateInfo.getTriggerChannel())){
            // 微信小程序
            WeChatMiniAppTemplateCreateDTO weChatMiniAppTemplateCreateDTO = convert2weChatMiniAPPPushDTO(templateInfo);
            response = pushTemplateService.createTemplate(weChatMiniAppTemplateCreateDTO);
        }else if(TriggerChannelEnum.INTERNALMSG.getType().equals(templateInfo.getTriggerChannel())){
            // 站内信
            InternalMsgTemplateCreateDTO internalMsgTemplateCreateDTO = convert2internalMsgTemplateCreateDTO(templateInfo);
            response = pushTemplateService.createTemplate(internalMsgTemplateCreateDTO);
        }else {
            log.info("----模板类型错误，类型不存在。");
            return null;
        }

        // 本地写模板推送关系表
        if(null != response && ResponseCode.SUCCESS.getCode().equals(response.getCode()) && null != response.getData()){
            PushTemplateRelationBO pushTemplateRelationBO = convert2RelationBO(templateInfo);
            pushTemplateRelationBO.setTemplateNum(response.getData().toString());
            pushTemplateRelationService.insertRelation(pushTemplateRelationBO);
            return pushTemplateRelationBO.getTemplateNum();
        }
        return null;
    }

    /**
     * 查询模板信息（远程模板内容信息，如果有站内信编码，再请求一次站内信模板信息+本地的模板参数信息）
     * @param relationBO
     * @return java.util.List<com.oyo.ump.member.service.bo.PushBO.TemplateInfo>
     */
    public PushTemplateDTO.TemplateInfo queryTemplateInfo(PushTemplateRelationBO relationBO){
        PushTemplateDTO.TemplateInfo pushTemplateInfo = new PushTemplateDTO.TemplateInfo();
        ClientBaseResponse<BaseTemplateDTO> response;
        /**
         * 站内信查询参数和别的类型不同，必须传QueryTemplateRequestDTO的子类InternalMsgTemplateQueryDTO
         */
        if(TriggerChannelEnum.INTERNALMSG.getType().equals(relationBO.getTriggerChannel())){
            InternalMsgTemplateQueryDTO internalMsgTemplateQueryDTO = new InternalMsgTemplateQueryDTO();
            internalMsgTemplateQueryDTO.setTemplateNum(relationBO.getTemplateNum());
            response = pushTemplateService.queryTemplate(internalMsgTemplateQueryDTO);
        }else if(TriggerChannelEnum.WECHATAPP.getType().equals(relationBO.getTriggerChannel())){
            WeChatMiniAppQueryTemplateRequestDTO weChatMiniAppQueryTemplateRequestDTO = new WeChatMiniAppQueryTemplateRequestDTO();
            weChatMiniAppQueryTemplateRequestDTO.setTemplateNum(relationBO.getTemplateNum());
            response = pushTemplateService.queryTemplate(weChatMiniAppQueryTemplateRequestDTO);
        }else {
            QueryTemplateRequestDTO queryTemplateRequestDTO = new QueryTemplateRequestDTO();
            queryTemplateRequestDTO.setTemplateNum(relationBO.getTemplateNum());
            response = pushTemplateService.queryTemplate(queryTemplateRequestDTO);
        }

        if(null != response && ResponseCode.SUCCESS.getCode().equals(response.getCode()) && null != response.getData()){
            if(TriggerChannelEnum.SMS.getType().equals(relationBO.getTriggerChannel())){
                // 短信
                SmsPushTemplateDTO baseTemplateDTO = (SmsPushTemplateDTO)response.getData();
                pushTemplateInfo = MapperWrapper.instance().map(baseTemplateDTO, PushTemplateDTO.TemplateInfo.class);
            }else if(TriggerChannelEnum.APPPUSH.getType().equals(relationBO.getTriggerChannel())){
                // APP PUSH
                AppPushTemplateDTO baseTemplateDTO = (AppPushTemplateDTO)response.getData();
                pushTemplateInfo = MapperWrapper.instance().map(baseTemplateDTO, PushTemplateDTO.TemplateInfo.class);
                if(StringUtils.isNotBlank(baseTemplateDTO.getInterTemplateCode())){
                    log.info("APP push 包含站内信：{}，请求站内信信息",baseTemplateDTO.getInterTemplateCode());
                    InternalMsgTemplateQueryDTO internalMsgTemplateQueryDTO = new InternalMsgTemplateQueryDTO();
                    internalMsgTemplateQueryDTO.setTemplateNum(baseTemplateDTO.getInterTemplateCode());
                    ClientBaseResponse<InternalMsgTemplateDTO> internalMsgResponse = pushTemplateService.queryTemplate(internalMsgTemplateQueryDTO);
                    log.info("APP push模板请求站内信返回信息",internalMsgResponse);
                    if(null != internalMsgResponse && ResponseCode.SUCCESS.getCode().equals(internalMsgResponse.getCode()) && null != internalMsgResponse.getData()){
                        pushTemplateInfo.setSendLink(internalMsgResponse.getData().getTemplateLink());
                        pushTemplateInfo.setInternalMsgTitle(internalMsgResponse.getData().getTemplateTitle());
                        pushTemplateInfo.setMsgDescription(internalMsgResponse.getData().getTemplateDescription());
                    }
                    pushTemplateInfo.setIsAttachInternalMsg(true);
                }
            }else if(TriggerChannelEnum.WECHAT.getType().equals(relationBO.getTriggerChannel())){
                // 微信公众号
                WeChatPublicAccountTemplateDTO baseTemplateDTO = (WeChatPublicAccountTemplateDTO)response.getData();
                pushTemplateInfo = MapperWrapper.instance().map(baseTemplateDTO, PushTemplateDTO.TemplateInfo.class);
            }else if(TriggerChannelEnum.WECHATAPP.getType().equals(relationBO.getTriggerChannel())){
                // 微信小程序
                WeChatMiniAppPushTemplateDTO baseTemplateDTO = (WeChatMiniAppPushTemplateDTO)response.getData();
                pushTemplateInfo = MapperWrapper.instance().map(baseTemplateDTO, PushTemplateDTO.TemplateInfo.class);
                if(StringUtils.isNotBlank(baseTemplateDTO.getInternalMsgTemplateCode())){
                    log.info("微信小程序 包含站内信：{}，请求站内信信息",baseTemplateDTO.getInternalMsgTemplateCode());
                    InternalMsgTemplateQueryDTO internalMsgTemplateQueryDTO = new InternalMsgTemplateQueryDTO();
                    internalMsgTemplateQueryDTO.setTemplateNum(baseTemplateDTO.getInternalMsgTemplateCode());
                    ClientBaseResponse<InternalMsgTemplateDTO> internalMsgResponse = pushTemplateService.queryTemplate(internalMsgTemplateQueryDTO);
                    log.info("微信小程序模板请求站内信返回信息",internalMsgResponse);
                    if(null != internalMsgResponse && ResponseCode.SUCCESS.getCode().equals(internalMsgResponse.getCode()) && null != internalMsgResponse.getData()){
                        pushTemplateInfo.setInternalMsgContent(internalMsgResponse.getData().getTemplateContent());
                        pushTemplateInfo.setInternalMsgTitle(internalMsgResponse.getData().getTemplateTitle());
                        pushTemplateInfo.setMsgDescription(internalMsgResponse.getData().getTemplateDescription());
                    }
                    pushTemplateInfo.setIsAttachInternalMsg(true);
                }
            }else if(TriggerChannelEnum.INTERNALMSG.getType().equals(relationBO.getTriggerChannel())){
                // 站内信
                InternalMsgTemplateDTO baseTemplateDTO = (InternalMsgTemplateDTO)response.getData();
                pushTemplateInfo = MapperWrapper.instance().map(baseTemplateDTO, PushTemplateDTO.TemplateInfo.class);
                pushTemplateInfo.setMsgDescription(baseTemplateDTO.getTemplateDescription());
                // 站内信的标题内容
                pushTemplateInfo.setInternalMsgTitle(pushTemplateInfo.getTemplateTitle());
                pushTemplateInfo.setInternalMsgContent(pushTemplateInfo.getTemplateContent());
            }
        }
        pushTemplateInfo.setPercent(relationBO.getPercent());

        pushTemplateInfo.setUrlParams(JSON.parseObject(relationBO.getUrlParams(),List.class));
        pushTemplateInfo.setContentParams(JSON.parseObject(relationBO.getContentParams(),List.class));
        pushTemplateInfo.setTemplateLongLink(null==relationBO.getTemplateUrlId()?"":relationBO.getTemplateUrlId().toString());
        pushTemplateInfo.setExtraParameter(relationBO.getExtraParameter());
        if(null != relationBO.getExtraParameter()){
            JSONObject extParameter = JSON.parseObject(relationBO.getExtraParameter());
            pushTemplateInfo.setUrlType(extParameter.getInteger("urlType"));
            pushTemplateInfo.setMiniAppId(extParameter.getString("miniAppId"));
            pushTemplateInfo.setAppName(extParameter.getString("appName"));
            pushTemplateInfo.setImageUrl(extParameter.getString("imageUrl"));
            pushTemplateInfo.setUpdateJson(extParameter.getString("updateJson"));
            pushTemplateInfo.setAppId(extParameter.getString("appId"));
            pushTemplateInfo.setWechatTemplateId(extParameter.getString("wechatTemplateId"));
            pushTemplateInfo.setInterMsgDetailPageRootPath(extParameter.getString("interMsgDetailPageRootPath"));
            pushTemplateInfo.setActivityId(extParameter.getLong("activityId"));
            pushTemplateInfo.setActivityUtilId(extParameter.getLong("activityUtilId"));
            pushTemplateInfo.setActivityChannelName(extParameter.getString("activityChannelName"));
            pushTemplateInfo.setActivityUrl(extParameter.getString("activityUrl"));
        }
        if(null != relationBO.getTemplateUtmParameter()){
            JSONObject utmParameter = JSON.parseObject(relationBO.getTemplateUtmParameter());
            pushTemplateInfo.setUtmSource(utmParameter.getString("utmSource"));
            pushTemplateInfo.setUtmMedium(utmParameter.getString("utmMedium"));
            pushTemplateInfo.setUtmCampaign(utmParameter.getString("utmCampaign"));
            pushTemplateInfo.setUtmContent(utmParameter.getString("utmContent"));
        }

        return pushTemplateInfo;
    }


    /**
     * PushBO.TemplateInfo 转成 创建appPUSH模板请求
     * @param templateInfo
     * @return com.oyo.cpush.client.dto.request.AppPushTemplateCreateDTO
     */
    private AppPushTemplateCreateDTO convert2APPPushDTO(PushTemplateDTO.TemplateInfo templateInfo){
        AppPushTemplateCreateDTO appPushTemplateCreateDTO = new AppPushTemplateCreateDTO();
        appPushTemplateCreateDTO.setBizChannel(templateInfo.getBizChannel());
        appPushTemplateCreateDTO.setTemplateName("MBAPP"+System.currentTimeMillis());
        appPushTemplateCreateDTO.setTemplateTitle(templateInfo.getTemplateTitle());
        appPushTemplateCreateDTO.setTemplateContent(templateInfo.getTemplateContent());
        appPushTemplateCreateDTO.setTemplateLink(templateInfo.getTemplateLink());
        appPushTemplateCreateDTO.setCreateAccountId(templateInfo.getCreateAccountId());
        appPushTemplateCreateDTO.setCreateAccountName(templateInfo.getCreateAccountName());
        appPushTemplateCreateDTO.setInterTemplateCode(templateInfo.getInternalMsgTemplateCode());
        return appPushTemplateCreateDTO;
    }

    /**
     * PushBO.TemplateInfo 转成 创建短信模板请求
     * @param templateInfo
     * @return com.oyo.cpush.client.dto.request.SmsPushTemplateCreateDTO
     */
    private SmsPushTemplateCreateDTO convert2SmsPushDTO(PushTemplateDTO.TemplateInfo templateInfo){
        SmsPushTemplateCreateDTO smsPushTemplateCreateDTO = new SmsPushTemplateCreateDTO();
        smsPushTemplateCreateDTO.setBizChannel(templateInfo.getBizChannel());
        smsPushTemplateCreateDTO.setTemplateName("MBSMS"+System.currentTimeMillis());
        smsPushTemplateCreateDTO.setTemplateTitle(templateInfo.getTemplateTitle());
        smsPushTemplateCreateDTO.setTemplateContent(templateInfo.getTemplateContent());
        smsPushTemplateCreateDTO.setTemplateLink(templateInfo.getTemplateLink());
        smsPushTemplateCreateDTO.setCreateAccountId(templateInfo.getCreateAccountId());
        smsPushTemplateCreateDTO.setCreateAccountName(templateInfo.getCreateAccountName());
        smsPushTemplateCreateDTO.setOrganizationCode(templateInfo.getOrganizationCode());
        smsPushTemplateCreateDTO.setOrganizationName(templateInfo.getOrganizationName());
        smsPushTemplateCreateDTO.setSmsTemplateType(templateInfo.getSmsTemplateType());
        smsPushTemplateCreateDTO.setSmsSgin(templateInfo.getSmsSgin());

        return smsPushTemplateCreateDTO;
    }

    /**
     * PushBO.TemplateInfo 转成 创建微信公众号模板请求
     * @param templateInfo
     * @return com.oyo.cpush.client.dto.request.WeChatPublicAccountTemplateCreateDTO
     */
    private WeChatPublicAccountTemplateCreateDTO convert2weChatPushDTO(PushTemplateDTO.TemplateInfo templateInfo){
        WeChatPublicAccountTemplateCreateDTO weChatPublicAccountTemplateCreateDTO = new WeChatPublicAccountTemplateCreateDTO();
        weChatPublicAccountTemplateCreateDTO.setBizChannel(templateInfo.getBizChannel());
        weChatPublicAccountTemplateCreateDTO.setTemplateName("MBWC"+System.currentTimeMillis());
        weChatPublicAccountTemplateCreateDTO.setTemplateTitle(templateInfo.getTemplateTitle());
        weChatPublicAccountTemplateCreateDTO.setTemplateContent(templateInfo.getTemplateContent());
        weChatPublicAccountTemplateCreateDTO.setTemplateLink(templateInfo.getTemplateLink());
        weChatPublicAccountTemplateCreateDTO.setCreateAccountId(templateInfo.getCreateAccountId());
        weChatPublicAccountTemplateCreateDTO.setCreateAccountName(templateInfo.getCreateAccountName());
        weChatPublicAccountTemplateCreateDTO.setAppId(templateInfo.getAppId());
        weChatPublicAccountTemplateCreateDTO.setWechatTemplateId(templateInfo.getWechatTemplateId());
        return weChatPublicAccountTemplateCreateDTO;
    }

    /**
     * PushBO.TemplateInfo 转成 创建微信小程序模板请求
     * @param templateInfo
     * @return com.oyo.cpush.client.dto.request.WeChatMiniAppTemplateCreateDTO
     */
    private WeChatMiniAppTemplateCreateDTO convert2weChatMiniAPPPushDTO(PushTemplateDTO.TemplateInfo templateInfo){
        WeChatMiniAppTemplateCreateDTO weChatMiniAppTemplateCreateDTO = new WeChatMiniAppTemplateCreateDTO();
        weChatMiniAppTemplateCreateDTO.setBizChannel(templateInfo.getBizChannel());
        weChatMiniAppTemplateCreateDTO.setTemplateName("WCAPP"+System.currentTimeMillis());
        weChatMiniAppTemplateCreateDTO.setTemplateTitle(templateInfo.getTemplateTitle());
        weChatMiniAppTemplateCreateDTO.setTemplateContent(templateInfo.getTemplateContent());
        weChatMiniAppTemplateCreateDTO.setTemplateLink(templateInfo.getTemplateLink());
        weChatMiniAppTemplateCreateDTO.setCreateAccountId(templateInfo.getCreateAccountId());
        weChatMiniAppTemplateCreateDTO.setCreateAccountName(templateInfo.getCreateAccountName());
        weChatMiniAppTemplateCreateDTO.setAppId(templateInfo.getAppId());
        weChatMiniAppTemplateCreateDTO.setWechatTemplateId(templateInfo.getWechatTemplateId());
        weChatMiniAppTemplateCreateDTO.setInternalMsgTemplateCode(templateInfo.getInternalMsgTemplateCode());
        return weChatMiniAppTemplateCreateDTO;
    }

    /**
     * PushBO.TemplateInfo 转成 站内信模板请求
     * @param templateInfo
     * @return com.oyo.cpush.client.dto.request.WeChatMiniAppTemplateCreateDTO
     */
    private InternalMsgTemplateCreateDTO convert2internalMsgTemplateCreateDTO(PushTemplateDTO.TemplateInfo templateInfo){
        InternalMsgTemplateCreateDTO internalMsgTemplateCreateDTO = new InternalMsgTemplateCreateDTO();
        internalMsgTemplateCreateDTO.setBizChannel(templateInfo.getBizChannel());
        internalMsgTemplateCreateDTO.setTemplateName("ZNX"+System.currentTimeMillis());
        internalMsgTemplateCreateDTO.setTemplateLink(templateInfo.getTemplateLink());
        internalMsgTemplateCreateDTO.setCreateAccountId(templateInfo.getCreateAccountId());
        internalMsgTemplateCreateDTO.setCreateAccountName(templateInfo.getCreateAccountName());
        internalMsgTemplateCreateDTO.setTemplateTitle(templateInfo.getInternalMsgTitle());
        internalMsgTemplateCreateDTO.setMsgDescription(templateInfo.getMsgDescription());
        // 站内信定死酒店英雄0，app写死阿波罗1 todo TriggerChannel细化
        switch (TriggerChannelEnum.getByType(templateInfo.getTriggerChannel())){
            case APPPUSH:
                internalMsgTemplateCreateDTO.setMsgChannel(1);
                internalMsgTemplateCreateDTO.setTemplateContent(templateInfo.getSendLink());
                internalMsgTemplateCreateDTO.setTemplateLink(templateInfo.getSendLink());
                break;
            case WECHATAPP:
                internalMsgTemplateCreateDTO.setMsgChannel(0);
                internalMsgTemplateCreateDTO.setTemplateContent(templateInfo.getInternalMsgContent());
                break;
            case INTERNALMSG:
                internalMsgTemplateCreateDTO.setMsgChannel(0);
                internalMsgTemplateCreateDTO.setTemplateContent(templateInfo.getInternalMsgContent());
                break;
            default:
                log.info("站内信消息模板渠道不是阿波罗和酒店英雄和单独站内信方式");
                break;
        }

        return internalMsgTemplateCreateDTO;
    }

    /**
     * 模板信息转成模板关系BO
     * @param templateInfo
     * @return com.oyo.ump.member.service.bo.PushTemplateRelationBO
     */
    private PushTemplateRelationBO convert2RelationBO(PushTemplateDTO.TemplateInfo templateInfo){
        PushTemplateRelationBO pushTemplateRelationBO = new PushTemplateRelationBO();
        pushTemplateRelationBO.setPushId(templateInfo.getPushId());
        pushTemplateRelationBO.setTemplateNum(templateInfo.getTemplateNum());
        pushTemplateRelationBO.setTriggerChannel(templateInfo.getTriggerChannel());
        pushTemplateRelationBO.setContentParams(null==templateInfo.getContentParams()?null:JSON.toJSON(templateInfo.getContentParams()).toString());
        pushTemplateRelationBO.setTemplateUrlId(StringUtils.isBlank(templateInfo.getTemplateLongLink()) ? null : Long.parseLong(templateInfo.getTemplateLongLink()));
        pushTemplateRelationBO.setUrlParams(null==templateInfo.getUrlParams()?null:JSON.toJSON(templateInfo.getUrlParams()).toString());
        pushTemplateRelationBO.setTemplateUtmParameter(getUtmString(templateInfo.getUrlParams()));
        JSONObject extraParameter = new JSONObject();
        extraParameter.put("urlType",templateInfo.getUrlType());
        extraParameter.put("miniAppId",templateInfo.getMiniAppId());
        extraParameter.put("appId",templateInfo.getAppId());
        extraParameter.put("wechatTemplateId",templateInfo.getWechatTemplateId());
        extraParameter.put("appName",templateInfo.getAppName());
        extraParameter.put("imageUrl", templateInfo.getImageUrl());
        extraParameter.put("updateJson", templateInfo.getUpdateJson());
        extraParameter.put("interMsgDetailPageRootPath", templateInfo.getInterMsgDetailPageRootPath());
        extraParameter.put("activityId", templateInfo.getActivityId());
        extraParameter.put("activityUtilId", templateInfo.getActivityUtilId());
        extraParameter.put("activityChannelName", templateInfo.getActivityChannelName());
        extraParameter.put("activityUrl", templateInfo.getActivityUrl());
        pushTemplateRelationBO.setPercent(templateInfo.getPercent());
        pushTemplateRelationBO.setExtraParameter(extraParameter.toJSONString());
        return pushTemplateRelationBO;
    }

    /**
     * 从 List<PushTemplateParamBo> 中获取utm参数信息
     * @param BOList
     * @return java.lang.String
     */
    private String getUtmString(List<PushTemplateDTO.PushTemplateParamBo> BOList){
        JSONObject utmParameter = new JSONObject();
        utmParameter.put("utmSource","");
        utmParameter.put("utmMedium","");
        utmParameter.put("utmCampaign","");
        utmParameter.put("utmContent","");
        if(CollectionUtils.isNotEmpty(BOList)){
            BOList.forEach(pushTemplateParamBo -> {
                if("utmSource".equals(pushTemplateParamBo.getName())){
                    utmParameter.put("utmSource",pushTemplateParamBo.getValue());
                }
                if("utmMedium".equals(pushTemplateParamBo.getName())){
                    utmParameter.put("utmMedium",pushTemplateParamBo.getValue());
                }
                if("utmCampaign".equals(pushTemplateParamBo.getName())){
                    utmParameter.put("utmCampaign",pushTemplateParamBo.getValue());
                }
                if("utmContent".equals(pushTemplateParamBo.getName())){
                    utmParameter.put("utmContent",pushTemplateParamBo.getValue());
                }
            });
        }

        return utmParameter.toJSONString();
    }

}
