package com.oyo.ump.member.biz.upgradePackage;

import com.alibaba.dubbo.config.annotation.Service;
import com.alibaba.fastjson.JSON;
import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import com.oyo.inventory.client.common.Channel;
import com.oyo.inventory.client.common.SkuWithChannel;
import com.oyo.inventory.client.dto.request.BatchQueryRequest;
import com.oyo.inventory.client.dto.response.BatchQueryResponse;
import com.oyo.ump.member.common.beanutils.MapperWrapper;
import com.oyo.ump.member.common.constants.MemberConstants;
import com.oyo.ump.member.integration.service.product.ProductRemoteService;
import com.oyo.ump.member.integration.service.trade.TradeRemoteService;
import com.oyo.ump.member.service.UpgradePackageService;
import com.oyo.ump.member.service.bo.UpgradePackageBO;
import com.oyo.ump.member.service.bo.UpgradePackagePageBO;
import com.oyo.ump.member.service.dto.UpgradePackageDTO;
import com.oyo.ump.member.service.member.UpgradePackageBizService;
import com.oyo.utp.price.api.dto.GetPriceItemDto;
import com.oyo.utp.price.api.request.GetPriceItem;
import com.oyo.utp.price.api.request.GetPriceReq;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import top.rdfa.product.core.client.response.ClientBaseResponse;
import top.rdfa.product.core.client.response.sku.SkuDto;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author Dong
 * @Classname UpgradePackageBizServiceImpl
 * @Description 给外部系统提供升级包信息
 * @Date 2019-03-22
 */
@Service
@Slf4j
@Component
public class UpgradePackageBizServiceImpl implements UpgradePackageBizService {
    @Value("${V1_V3_COUPON_PRICE}")
    private String V1_V3_COUPON_PRICE;
    @Value("${V2_V3_COUPON_PRICE}")
    private String V2_V3_COUPON_PRICE;

    @Autowired
    UpgradePackageService upgradePackageService;
    @Autowired
    ProductRemoteService productRemoteService;
    @Autowired
    TradeRemoteService tradeRemoteService;

    public UpgradePackagePageBO getUpgradePackageList(Integer pageNum, Integer pageSize) {

        UpgradePackagePageBO upgradePackagePageBO = upgradePackageService.getUpgradePackageList(pageNum, pageSize);
        if(upgradePackagePageBO != null && CollectionUtils.isNotEmpty(upgradePackagePageBO.getUpgradePackageBOList())){
            // 价格RPC
            GetPriceReq getPriceReq = new GetPriceReq();
            List<GetPriceItem> getPriceItemList = Lists.newArrayList();
            upgradePackagePageBO.getUpgradePackageBOList().forEach(upgradePackageBO -> {
                GetPriceItem getPriceItem = new GetPriceItem();
                getPriceItem.setSkuCode(upgradePackageBO.getSkuCode());
                getPriceItem.setChannelCode(MemberConstants.PACKAGE_CHANNEL);
                getPriceItemList.add(getPriceItem);
            });
            getPriceReq.setSkuList(getPriceItemList);
            List<GetPriceItemDto> getPriceItemDtoList = tradeRemoteService.getSkuPrice(getPriceReq);
            if(CollectionUtils.isNotEmpty(getPriceItemDtoList)){
                getPriceItemDtoList.forEach(getPriceItemDto -> {
                    upgradePackagePageBO.getUpgradePackageBOList().forEach(upgradePackageBO -> {
                        if(getPriceItemDto.getSkuCode().equals(upgradePackageBO.getSkuCode())){
                            upgradePackageBO.setPrice(getPriceItemDto.getPrice());
                        }
                    });
                });
            }

            // 库存RPC
            BatchQueryRequest batchQueryRequest = BatchQueryRequest.builder().build();
            List<SkuWithChannel> skuWithChannelList = Lists.newArrayList();
            upgradePackagePageBO.getUpgradePackageBOList().forEach(upgradePackageBO -> {
                Channel channel = Channel.builder().channel(MemberConstants.PACKAGE_CHANNEL).build();
                List<Channel> channelList = Lists.newArrayList();
                channelList.add(channel);

                SkuWithChannel skuWithChannel = new SkuWithChannel();
                skuWithChannel.setChannelList(channelList);
                skuWithChannel.setSkuCode(upgradePackageBO.getSkuCode());

                skuWithChannelList.add(skuWithChannel);
            });
            batchQueryRequest.setSkuList(skuWithChannelList);

            BatchQueryResponse batchQueryResponse = tradeRemoteService.getInventory(batchQueryRequest);
            if(batchQueryResponse != null && CollectionUtils.isNotEmpty(batchQueryResponse.getSkuInventoryList())){
                batchQueryResponse.getSkuInventoryList().forEach(skuInventory -> {
                    upgradePackagePageBO.getUpgradePackageBOList().forEach(upgradePackageBO -> {
                        if(skuInventory.getSkuCode().equals(upgradePackageBO.getSkuCode())){
                            skuInventory.getSaleInventoryList().forEach(saleInventory -> {
                                if(MemberConstants.PACKAGE_CHANNEL.equals(saleInventory.getChannel())){
                                    upgradePackageBO.setStock(saleInventory.getInventory());
                                }
                            });
                        }
                    });
                });
            }


            // 商品RPC，获取商品名
            upgradePackagePageBO.getUpgradePackageBOList().forEach(upgradePackageBO -> {
                String sckCode = upgradePackageBO.getSkuCode();
                ClientBaseResponse<SkuDto> response = productRemoteService.getProductInfo(sckCode);
                if(response != null && response.getData() != null){
                    upgradePackageBO.setPackageName(response.getData().getName());
                }
            });

        }

        return upgradePackagePageBO;
    }



    /**
     * 根据用户gradeId 获取用户可购买的升级包列表（排序）
     * @param gradeId
     * @return com.oyo.common.response.BaseResponse
     */
    @Override
    public BaseResponse getUpgradePackageListByGradeId(Integer gradeId) {
        if(gradeId == null){
            return BaseResponse.fail(ResponseCode.PARAMS_IS_EMPTY);
        }

        List<UpgradePackageDTO> upgradePackageDTOList;
        List<UpgradePackageBO> upgradePackageBOList;
        log.info("可购买升级包的请求入参：{}", gradeId);
        upgradePackageBOList = upgradePackageService.getUpgradePackageListByGradeId(gradeId);
        log.info("get  upgradePackageBOList: {}", JSON.toJSONString(upgradePackageBOList));
        upgradePackageDTOList = assembleUpgradePackageInfo(upgradePackageBOList);
        log.info("get  upgradePackageDTOList: {}", JSON.toJSONString(upgradePackageDTOList));
        return BaseResponse.success(upgradePackageDTOList);
    }


    @Override
    public BaseResponse getUpgradePackageByCode(String skuCode) {
        if(skuCode == null){
            return BaseResponse.fail(ResponseCode.PARAMS_IS_EMPTY);
        }

        UpgradePackageBO upgradePackageBO;
        UpgradePackageDTO upgradePackageDTO;
        log.info("获取升级包信息入参：{}", skuCode);
        upgradePackageBO = upgradePackageService.getUpgradePackageByCode(skuCode);
        log.info("get  upgradePackageBO: {}", JSON.toJSONString(upgradePackageBO));
        if(upgradePackageBO!=null){
            upgradePackageDTO = MapperWrapper.instance().map(upgradePackageBO, UpgradePackageDTO.class);
            if(MemberConstants.V1_ORD.equals(upgradePackageBO.getGradeOrd()) && MemberConstants.V3_ORD.equals(upgradePackageBO.getUpgradeOrd())){
                upgradePackageDTO.setCouponDenomination(BigDecimal.valueOf(Long.parseLong(V1_V3_COUPON_PRICE)));
            }else if(MemberConstants.V2_ORD.equals(upgradePackageBO.getGradeOrd()) && MemberConstants.V3_ORD.equals(upgradePackageBO.getUpgradeOrd())){
                upgradePackageDTO.setCouponDenomination(BigDecimal.valueOf(Long.parseLong(V2_V3_COUPON_PRICE)));
            }
            log.info("get  upgradePackageDTO: {}", JSON.toJSONString(upgradePackageDTO));
            return BaseResponse.success(upgradePackageDTO);
        }else{
            return BaseResponse.fail(ResponseCode.DATA_NOT_EXISTS);
        }
    }


    /**
     * BOList转化为DTOList
     * @param upgradePackageBOList upgradePackageBOList
     * @return
     */
    private List<UpgradePackageDTO> assembleUpgradePackageInfo(List<UpgradePackageBO> upgradePackageBOList) {
        List<UpgradePackageDTO> upgradePackageDTOList = Lists.newArrayList();
        if(CollectionUtils.isNotEmpty(upgradePackageBOList)){
            upgradePackageBOList.forEach(upgradePackageBO -> {
                upgradePackageDTOList.add( MapperWrapper.instance().map(upgradePackageBO, UpgradePackageDTO.class));
            });
        }
        return upgradePackageDTOList;
    }



}
