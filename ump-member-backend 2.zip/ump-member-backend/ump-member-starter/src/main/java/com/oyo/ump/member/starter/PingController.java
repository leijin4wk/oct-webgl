package com.oyo.ump.member.starter;

import com.oyo.ump.member.service.member.ChangeGradeBizService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @description: ping
 * @author: fang
 * @create: 2019-03-14 11:17
 **/
@RestController
@RequestMapping(value = "/ping")
@Api(tags = {"ping"}, value = "ping")
@Slf4j
public class PingController {

    @Autowired
    ChangeGradeBizService changeGradeBizService;

    @Value("${V1_V3_IDENTITY_CODE}")
    private String V1_V3_IDENTITY_CODE ;
    @Value("${V2_V3_IDENTITY_CODE}")
    private String V2_V3_IDENTITY_CODE ;

    @GetMapping(value = "ucm2")
    public String printUCM2(){
        return "V1_V3_IDENTITY_CODE:"+ V1_V3_IDENTITY_CODE + "V2_V3_IDENTITY_CODE:" +V2_V3_IDENTITY_CODE;
    }

    @ApiOperation(value="测试", notes="测试")
    @GetMapping
    public String ping(){
        return "pong";
    }
}
