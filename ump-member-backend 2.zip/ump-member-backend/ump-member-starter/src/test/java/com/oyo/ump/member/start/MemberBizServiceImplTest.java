package com.oyo.ump.member.start;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import com.oyo.ump.member.common.constants.MemberConstants;
import com.oyo.ump.member.common.test.TestApplication;
import com.oyo.ump.member.service.dto.*;
import com.oyo.ump.member.service.member.MemberBizService;
import com.oyo.ump.member.service.utils.RetryUtilService;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.util.Lists;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertTrue;

/**
 * @Author hubin
 * @Description:
 * @Date 2019-04-06
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class MemberBizServiceImplTest {
//    @Autowired
//    MemberBizService memberBizService;
//    @Reference(url = "dubbo://172.20.11.157:5001")
    @Autowired
    MemberBizService memberBizService;
    @Autowired
    private RetryUtilService retryUtilService;
    @Test
    public void getMemberInfoByUserId() {
        Long userId = 19000000L;
        BaseResponse<MemberInfoDTO> response = memberBizService.getMemberInfoByUserId(userId);
        System.out.println(JSON.toJSONString(response, SerializerFeature.PrettyFormat));
        assertTrue(response != null && response.getCode().equals(ResponseCode.SUCCESS.getCode())
                && userId.equals(response.getData().getUserId()));

        userId = 1000L;
        response = memberBizService.getMemberInfoByUserId(userId);
        log.info(JSON.toJSONString(response, SerializerFeature.PrettyFormat));
//        assertTrue(response != null && response.getCode().equals(ResponseCode.DATA_NOT_EXISTS.getCode()));
    }

    @Test
    public void getMemberDiscount() {
        MemberDiscountRequestDTO request = new MemberDiscountRequestDTO();
        /**
         *
         */
        request.setUserId(1943164723L);
        List<Long> hotelList=Lists.newArrayList();
        hotelList.add(666L);
        hotelList.add(6661L);
        request.setPlatform(1);
//        request.setSkuCode("K00098685146");
        request.setHotelIdList(hotelList);
        BaseResponse<List<MemberDiscountDTO>> response = memberBizService.getMemberDiscountV2(request);
        System.out.println(JSON.toJSONString(response, SerializerFeature.PrettyFormat));
        assertTrue(response != null && response.getCode().equals(ResponseCode.SUCCESS.getCode()));
        /**
         *
         */
//        request.setUserId(19431647L);
//        request.setHotelId(155L);
//        response = memberBizService.getMemberDiscount(request);
//        log.info(JSON.toJSONString(response, SerializerFeature.PrettyFormat));
//        assertTrue(response != null && response.getCode().equals(ResponseCode.SUCCESS.getCode())
//                && response.getData().getDiscount() == 95);
//
//        /**
//         *
//         */
//        request.setUserId(100210L);
//        request.setHotelId(155L);
//        response = memberBizService.getMemberDiscount(request);
//        log.info(JSON.toJSONString(response, SerializerFeature.PrettyFormat));
//        assertTrue(response != null && response.getCode().equals(ResponseCode.DATA_NOT_EXISTS.getCode()));
    }
    @Test
    public void getMemberInfoByUserIdList(){
        List<Long> userIds = Lists.newArrayList();
        userIds.add(1906719345L);
        userIds.add(100000283L);
        userIds.add(100043737L);
        userIds.add(100029627L);
        userIds.add(100000001L);
        MemberInfoBatchRequestDTO memberInfoBatchRequestDTO = new MemberInfoBatchRequestDTO();
        memberInfoBatchRequestDTO.setTenant("OYO_JP");
        memberInfoBatchRequestDTO.setUserIds(userIds);
        BaseResponse<List<MemberInfoDTO>> response = memberBizService.getMemberInfoByUserIdList(memberInfoBatchRequestDTO);
        System.out.println(JSON.toJSONString(response, SerializerFeature.PrettyFormat));
    }
    @Test
    public void  regiser(){
        RegisterRequestDTO registerRequestDTO =new RegisterRequestDTO();
        registerRequestDTO.setUserId(290000005L);
        registerRequestDTO.setTenant("OYO");
        registerRequestDTO.setPlatform(MemberConstants.OYO_TENANT);
        registerRequestDTO.setGrade("V1");
        BaseResponse<Boolean> response = memberBizService.registerMemberV2(registerRequestDTO);
        log.info(JSON.toJSONString(response, SerializerFeature.PrettyFormat));
    }
    @Test
    public void  syns(){
        SyncMemberGradeRequestDTO syncMemberGradeRequestDTO =new SyncMemberGradeRequestDTO();
        syncMemberGradeRequestDTO.setPlatform(MemberConstants.OYO_TENANT);
        syncMemberGradeRequestDTO.setGrade("V2");
        syncMemberGradeRequestDTO.setUserId(100000012L);
        syncMemberGradeRequestDTO.setRefreshCode("10012");
        syncMemberGradeRequestDTO.setTenant(MemberConstants.OYO_JP_TENANT);
        syncMemberGradeRequestDTO.setValidTime(new Date());
        BaseResponse<Boolean> response = memberBizService.syncMemberGrade(syncMemberGradeRequestDTO);
        log.info(JSON.toJSONString(response, SerializerFeature.PrettyFormat));
    }

    @Test
    public void registerJp(){
        UserMemberRegisterRequestDTO batchAccountCustomerInfoRequest=new UserMemberRegisterRequestDTO();
        batchAccountCustomerInfoRequest.setMerchantCode("OYO_JP");
        batchAccountCustomerInfoRequest.setIsSend(false);
        List<AccountCustomerDto> accountCustomerDtos = new ArrayList<>();
        AccountCustomerDto accountCustomerDto = new AccountCustomerDto();

        accountCustomerDto.setPhone("158000001318");
        accountCustomerDto.setNickName("15800000000");
        accountCustomerDto.setEmail("15800000000@qq.com");
        NaturalPersonDto naturalPersonDto = new NaturalPersonDto();
        naturalPersonDto.setEmail("15800000000@qq.com");
        naturalPersonDto.setGender(1);
        naturalPersonDto.setUserCode(203199139893215235L);
        naturalPersonDto.setBirthDate(new Date());
        accountCustomerDto.setNaturalPerson(naturalPersonDto);
        accountCustomerDtos.add(accountCustomerDto);
        batchAccountCustomerInfoRequest.setAccountCustomers(accountCustomerDtos);
        batchAccountCustomerInfoRequest.setTenant("OYO_JP");
        batchAccountCustomerInfoRequest.setGrade("V2");
        batchAccountCustomerInfoRequest.setValidTime(new Date());

        BaseResponse<UserMemberRegisterResponseDTO> response = memberBizService.registerUserAndMember(batchAccountCustomerInfoRequest);
        log.info(JSON.toJSONString(response, SerializerFeature.PrettyFormat));
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
    @Test
    public void testJob(){
        retryUtilService.processRetry();
    }
}
