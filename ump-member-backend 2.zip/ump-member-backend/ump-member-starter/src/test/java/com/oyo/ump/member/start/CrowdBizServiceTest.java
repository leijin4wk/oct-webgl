package com.oyo.ump.member.start;

import com.oyo.common.response.BaseResponse;
import com.oyo.common.response.PagedResponse;
import com.oyo.ump.member.service.crowd.CrowdBizService;
import com.oyo.ump.member.service.dto.*;
import com.oyo.ump.member.starter.Application;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashSet;
import java.util.Set;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class)
@Slf4j
public class CrowdBizServiceTest {

    @Autowired
    private CrowdBizService crowdBizService;
    @Test
    public void testAdd(){
        AddCrowdUserDTO addCrowdUserDTO =new AddCrowdUserDTO();
        addCrowdUserDTO.setCrowdId(null);
        addCrowdUserDTO.setName("单元测试");
        Set<Long> userIds=new HashSet<>();
        userIds.add(111L);
        userIds.add(112L);
        addCrowdUserDTO.setUserIds(userIds);
        BaseResponse<Long> baseResponse= crowdBizService.addUserToCrowd(addCrowdUserDTO);
        log.info(baseResponse.toString());
        CrowdUserConditionDTO crowdUserConditionDTO=new CrowdUserConditionDTO();
        Set<Long> crowds=new HashSet<>();
        crowds.add(baseResponse.getData());
        crowdUserConditionDTO.setCrowdIds(crowds);
        crowdUserConditionDTO.setPageNum(1);
        crowdUserConditionDTO.setPageSize(5);
        PagedResponse<CrowdUsersDTO> pagedResponse=crowdBizService.findCrowdUser(crowdUserConditionDTO);
        log.info(pagedResponse.toString());
        DeleteCrowdUserDTO deleteCrowdUserDTO=new DeleteCrowdUserDTO();
        deleteCrowdUserDTO.setCrowdId(baseResponse.getData());
        Set<Long> deleteIds=new HashSet<>();
        deleteIds.add(111L);
        deleteCrowdUserDTO.setUserIds(deleteIds);
        BaseResponse<String> baseResponse1= crowdBizService.deleteCrowdUser(deleteCrowdUserDTO);
        log.info(baseResponse1.toString());
        ExistCrowdUserDTO existCrowdUserDTO1=new ExistCrowdUserDTO();
        existCrowdUserDTO1.setCrowdId(baseResponse.getData());
        existCrowdUserDTO1.setUserId(111L);
        log.info("111L {}",crowdBizService.existCrowdUser(existCrowdUserDTO1));
        ExistCrowdUserDTO existCrowdUserDTO2=new ExistCrowdUserDTO();
        existCrowdUserDTO2.setCrowdId(baseResponse.getData());
        existCrowdUserDTO2.setUserId(112L);
        log.info("112L {}",crowdBizService.existCrowdUser(existCrowdUserDTO2));
    }
}
