package com.oyo.ump.member.start;

import com.oyo.ump.member.integration.service.push.PushTemplateService;
import com.oyo.ump.member.service.MessagePushService;
import com.oyo.ump.member.starter.Application;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class)
@Slf4j
public class MemberPushTest {
    @Autowired
    private MessagePushService messagePushService;
    @Autowired
    PushTemplateService appPushTemplateService;
    @Test
    public void test01(){
    }

    @Test
    public void test02(){


        log.info(appPushTemplateService.getTemplateList().toString());
    }

}
