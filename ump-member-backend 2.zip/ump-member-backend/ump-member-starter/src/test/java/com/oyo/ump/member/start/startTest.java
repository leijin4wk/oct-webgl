package com.oyo.ump.member.start;

import com.aliyun.openservices.ons.api.Message;
import com.oyo.common.response.BaseResponse;
import com.oyo.ump.member.common.constants.MemberConstants;
import com.oyo.ump.member.integration.service.hotel.HotelRemoteService;
import com.oyo.ump.member.integration.service.hotel.LocationRemoteService;
import com.oyo.ump.member.processor.mq.consumer.userOrderChange.UserOrderChangeListener;
import com.oyo.ump.member.service.HotelService;
import com.oyo.ump.member.service.dto.ChangeGradeRequestDTO;
import com.oyo.ump.member.service.member.ChangeGradeBizService;
import com.oyo.ump.member.service.member.HotelBizService;
import com.oyo.ump.member.service.member.UpgradePackageBizService;
import com.oyo.ump.member.starter.Application;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Lists;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

/**
 * @author Dong
 * @Classname startTest
 * @Description 测试对外接口
 * @Date 2019-04-01
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class)
public class startTest {
    @Autowired
    HotelBizService hotelBizService;
    @Autowired
    ChangeGradeBizService changeGradeBizService;
    @Autowired
    UpgradePackageBizService upgradePackageBizService;
    @Autowired
    HotelRemoteService hotelRemoteService;
    @Autowired
    LocationRemoteService locationRemoteService;
    @Autowired
    UserOrderChangeListener userOrderChangeListener;
    @Autowired
    private HotelService hotelService;
    @Test
    public void getSalesHotelTest(){
        List<Long> testList = Lists.newArrayList();
        testList.add(104L);
        testList.add(3L);
        testList.add(5L);
        testList.add(6661L);
        testList.add(1021L);
        testList.add(13456789L);
        testList.add(1345678L);
        BaseResponse<List<Long>> response = hotelBizService.getSalesHotel(testList);
        System.out.print("************************************************************************************************");
        System.out.println(hotelService.isMemberHotel(1345678L));
        System.out.println(hotelService.isMemberHotel(13456789L));
        System.out.println(response);
        hotelService.addMemberHotel(1345678L,1);
        hotelService.addMemberHotel(13456789L,1);
        BaseResponse<List<Long>> response1 = hotelBizService.getSalesHotel(testList);
        System.out.print("************************************************************************************************");
        System.out.println(response1);
        System.out.print("************************************************************************************************");
    }


    @Test
    public void changeGrade(){
        ChangeGradeRequestDTO changeGradeRequestDTO = new ChangeGradeRequestDTO();
        changeGradeRequestDTO.setUserId(27775781L);
        changeGradeRequestDTO.setSkuCode("K00023747378");
        changeGradeRequestDTO.setChangeType(MemberConstants.UPGRADE);


        BaseResponse response = changeGradeBizService.changeGradeByPackage(changeGradeRequestDTO);
        System.out.print("************************************************************************************************");
        System.out.println(response);
        System.out.print("************************************************************************************************");
    }

    @Test
    public void canBuy(){
        Integer gradeId = 2;


        BaseResponse response = upgradePackageBizService.getUpgradePackageListByGradeId(gradeId);
        System.out.print("************************************************************************************************");
        System.out.println(response);
        System.out.print("************************************************************************************************");
    }
    @Test
    public void locationInfo(){

        locationRemoteService.getLocationInfo(120258L,11029L);

    }
    @Test
    public void hotelInfo(){

        hotelRemoteService.getHotelInfo(120258L);

    }
    @Test
    public void messageUpdateInfo(){
        String json="{\"arrivalDate\":1557158400000," +
                "\"bookingGuestName\":\"leijin\"," +
                "\"bookingGuestPhone\":\"18875016131\"," +
                "\"bookingId\":10025530," +
                "\"bookingStatus\":0," +
                "\"centralChannel\":true," +
                "\"channelId\":1," +
                "\"bookingSn\":\"\"," +
                "\"hotelId\":36811," +
                "\"nights\":2," +
                "\"memberId\":20046282,"+
                "\"payStatus\":6," +
                "\"paymentType\":0," +
                "\"publishTime\":1557384848497," +
                "\"retentionDate\":1557417600000," +
                "\"roomNumber\":3," +
                "\"terminal\":\"IOS\","+
                "\"roomType\":\"标准双床房\"" +
                "}";
        Message message=new Message();
        message.setBody(json.getBytes());
        message.setTag("booking_update");
        userOrderChangeListener.processMessage(message);
    }

    @Test
    public void messageNewInfo(){
        String json="{\"arrivalDate\":1558454400000,\"bookingGuestName\":\"OYO会员\",\"bookingGuestPhone\":\"18875016131\",\"bookingId\":559452,\"bookingSn\":\"PBE215832459\",\"bookingStatus\":0,\"centralChannel\":false,\"channelId\":62,\"expectDate\":1558519200000,\"extBookingSn\":\"\",\"hotelId\":100355,\"memberId\":27776149,\"nights\":1,\"paidAmount\":10.90,\"payStatus\":1,\"paymentType\":1,\"publishTime\":1558415847427,\"retentionDate\":1558519200000,\"roomNumber\":1,\"roomType\":\"标准双床房\",\"terminal\":\"IOS\"} ";
        Message message=new Message();
        message.setBody(json.getBytes());
        message.setTag("booking_new");
        userOrderChangeListener.processMessage(message);
    }

    @Test
    public void messageCancelArrive(){
        String json="{\"arrivalDate\":1557158400000," +
                "\"bookingGuestName\":\"leijin\"," +
                "\"bookingGuestPhone\":\"18875016131\"," +
                "\"orderNo\":\"aaaabbbbbb\"," +
                "\"bookingId\":10025530," +
                "\"bookingStatus\":0," +
                "\"centralChannel\":true," +
                "\"channelId\":1," +
                "\"bookingSn\":\"asdasdsadasd\"," +
                "\"hotelId\":36811," +
                "\"nights\":2," +
                "\"memberId\":20046282,"+
                "\"payStatus\":1," +
                "\"paymentType\":0," +
                "\"publishTime\":1557384848497," +
                "\"retentionDate\":1557417600000," +
                "\"roomNumber\":3," +
                "\"terminal\":\"IOS\","+
                "\"roomType\":\"标准双床房\"" +
                "}";
        Message message=new Message();
        message.setBody(json.getBytes());
        message.setTag("booking_cancel");
        userOrderChangeListener.processMessage(message);
    }
    @Test
    public void messageCancelOnline(){
        String json="{\"arrivalDate\":1557158400000," +
                "\"bookingGuestName\":\"leijin\"," +
                "\"bookingGuestPhone\":\"18855719446\"," +
                "\"bookingId\":10025530," +
                "\"bookingStatus\":0," +
                "\"centralChannel\":true," +
                "\"channelId\":1," +
                "\"paidAmount\":100.0," +
                "\"bookingSn\":\"aabbbbbcccc\"," +
                "\"hotelId\":36811," +
                "\"nights\":2," +
                "\"memberId\":20046282,"+
                "\"payStatus\":6," +
                "\"paymentType\":1," +
                "\"publishTime\":1557384848497," +
                "\"retentionDate\":1557417600000," +
                "\"roomNumber\":3," +
                "\"terminal\":\"IOS\","+
                "\"roomType\":\"标准双床房\"" +
                "}";
        Message message=new Message();
        message.setBody(json.getBytes());
        message.setTag("booking_cancel");
        userOrderChangeListener.processMessage(message);
    }

    public static void main(String[] args) {
        System.out.println(StringUtils.isNoneBlank());
    }
}
