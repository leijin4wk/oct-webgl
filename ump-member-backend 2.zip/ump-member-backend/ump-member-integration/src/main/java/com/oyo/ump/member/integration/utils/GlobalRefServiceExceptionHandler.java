package com.oyo.ump.member.integration.utils;

import com.alibaba.dubbo.rpc.RpcException;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.util.concurrent.TimeoutException;

/**
 * @Description: 依赖服务全局异常处理
 * @Author: fang
 * @create: 2019-04-01
 **/
@Slf4j
@Aspect
@Component
public class GlobalRefServiceExceptionHandler {
    @Pointcut("@within(com.oyo.ump.member.integration.utils.RefService)")
    public void logPointCut() {
    }

    @Around("logPointCut()")
    public Object around(ProceedingJoinPoint point) throws Throwable {
        String method = "";
        try {
            point.getSignature();
            Signature signature =  point.getSignature();
            if(signature!=null){
                method = signature.getName();
            }
            Object result = point.proceed();
            return result;
        }catch (RpcException e){
            log.error("ref service,Rpc.code:"+e.getCode()+"-method:"+method, e);
        }catch (Exception e) {
            log.error("ref service error,method:"+(method==null?"方法名异常":method), e);
        }
        return null;

    }
}
