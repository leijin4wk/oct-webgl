package com.oyo.ump.member.integration.utils;

public @interface RefService {
}
