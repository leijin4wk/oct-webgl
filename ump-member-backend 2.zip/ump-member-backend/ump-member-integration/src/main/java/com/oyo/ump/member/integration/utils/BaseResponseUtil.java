package com.oyo.ump.member.integration.utils;

import com.alibaba.fastjson.JSON;
import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import lombok.extern.slf4j.Slf4j;

/**
 * @Description: 对BaseResponse的返回结果处理
 * @Author: fang
 * @create: 2019-04-01
 **/
@Slf4j
public class BaseResponseUtil {
    public static <T> T getBaseResponse(BaseResponse<T> response){

        if(response!=null&& ResponseCode.SUCCESS.getCode().equals(response.getCode())&&response.getData()!=null){
            log.info("外部服务返回：{}",JSON.toJSONString(response));
            return  response.getData();
        }else {
            return null;
        }
    }

}
