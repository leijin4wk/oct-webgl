package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.Map;

/**
 * @Description:
 * @Author: fang
 * @create: 2019-12-11
 **/
@Data
public class UserMemberRegisterResponseDTO implements Serializable {
    private static final long serialVersionUID = -4546141881925374915L;
    private Long userId;
    /**
     * 等级
     */
    private Integer gradeId;
}
