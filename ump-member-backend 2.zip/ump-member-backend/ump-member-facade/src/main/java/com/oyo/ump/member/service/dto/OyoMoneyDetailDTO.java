package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @Description:
 * @Author: fang
 * @create: 2019-10-18
 **/
@Data
public class OyoMoneyDetailDTO implements Serializable {
    private String userName;
    /**
     * 总欧币数目
     */
    private Integer totalPointsNum;

    /**
     * 欧币明细
     */
    private List<OyoMoneySourceDTO> pointsDetails;
    /**
     * 有效期
     */
    private Date expireDate;

    /**
     * 生效时间
     */
    private Date effectDate;
    /**
     * 提供者信息
     */
    private String provideId;
    private String provideType;
    private String provideName;
    private String marketingName;



}
