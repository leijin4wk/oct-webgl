package com.oyo.ump.member.service.member;

import com.oyo.common.response.BaseResponse;
import com.oyo.ump.member.service.dto.UpgradePackageDTO;

import java.util.List;

/**
 * @author Dong
 * @Classname UpgradePackageBizService
 * @Description 给外部系统返回的升级包信息
 * @Date 2019-03-22
 */
public interface UpgradePackageBizService {
    BaseResponse<List<UpgradePackageDTO>> getUpgradePackageListByGradeId(Integer gradeId);

    BaseResponse<UpgradePackageDTO> getUpgradePackageByCode(String skuCode);
}
