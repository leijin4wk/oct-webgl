package com.oyo.ump.member.service.member;

import com.oyo.common.response.BaseResponse;
import com.oyo.ump.member.service.dto.GradeInfoDTO;
import com.oyo.ump.member.service.dto.RefreshRuleDTO;

import java.util.List;

public interface GradeBizService {

    BaseResponse<List<GradeInfoDTO>>  getGradeInfoList();

    BaseResponse<GradeInfoDTO>  getGradeByGradeId(Integer gradeId);

    /**
     * 根据租户查询等级
     * @param tenant
     * @return
     */
    BaseResponse<List<GradeInfoDTO>>  getGradeInfoList(String tenant);

}
