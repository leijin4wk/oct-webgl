package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

/**
 * @author Dong
 * @Classname UpgradePackageDTO
 * @Description 给外部系统返回的升级包信息
 * @Date 2019-03-22
 */
@Data
public class UpgradePackageDTO implements Serializable {
    private static final long serialVersionUID = -477494152617043810L;
    private Integer id;
    private String skuCode;
    private Integer gradeId;
    private Integer upgradeId;
    private BigDecimal frontCommission;
    private BigDecimal ownerCommission;
    private BigDecimal oyoCommission;
    private BigDecimal couponDenomination;

}
