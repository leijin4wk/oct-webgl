package com.oyo.ump.member.service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @Description: todo
 * @Author: fang
 * @create: 2019-12-13
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDto implements Serializable {
    private static final long serialVersionUID = -6839847480086190095L;
    protected String type;

    protected Long code;

    protected Long creatorId;

    protected Long modifierId;
}
