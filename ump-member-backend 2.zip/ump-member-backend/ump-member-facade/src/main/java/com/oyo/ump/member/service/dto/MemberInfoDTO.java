package com.oyo.ump.member.service.dto;

import lombok.Data;
import java.io.Serializable;
import java.util.Date;

/**
 * @Description: 会员
 * @Author: fang
 * @create: 2019-03-22
 **/
@Data
public class MemberInfoDTO implements Serializable {
    private static final long serialVersionUID = -7663648971093529052L;
    private Long userId;
    private Integer gradeId;
    private String grade;
    private String gradeName;
    private Integer roomNight;
    private Integer noshow;
    private Integer upgradeRoomNights;
    private Integer nextGradeId;
    private Date gradeUpdateTime;
    private String tenant;
    private Integer validPeriod;
}
