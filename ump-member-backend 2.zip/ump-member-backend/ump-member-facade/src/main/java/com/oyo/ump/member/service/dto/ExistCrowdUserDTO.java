package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;
@Data
public class ExistCrowdUserDTO implements Serializable {
    private Long crowdId;
    private Long  userId;
}
