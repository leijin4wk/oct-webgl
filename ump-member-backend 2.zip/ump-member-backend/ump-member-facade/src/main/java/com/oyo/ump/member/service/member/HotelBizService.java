package com.oyo.ump.member.service.member;

import com.oyo.common.response.BaseResponse;

import java.util.List;

/**
 * @author Dong
 * @Classname HotelBizService
 * @Description 活动酒店对外接口
 * @Date 2019-04-01
 */
public interface HotelBizService {
    BaseResponse<List<Long>> getSalesHotel(List<Long> hotelIds);
}
