package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * @Description:
 * @Author: fang
 * @create: 2019-12-09
 **/
@Data
public class AddCrowdUserResponseDTO implements Serializable {
    /**
     * 人群包id
     */
    private Long crowdId;
    /**
     * 插入成功的数量
     */
    private Integer count;

}
