package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * @Description: 明细
 * @Author: fang
 * @create: 2019-10-23
 **/
@Data
public class OyoMoneySourceDTO implements Serializable {
    /**
     * 欧币类型编码
     */
    private String pointTypeCode;
    /**
     * 欧币类型名称
     */
    private String pointTypeName;
    /**
     * 成本中心编码
     */
    private String costCode;
    /**
     * 成本中心名称
     */
    private String costName;
    /**
     * 数目
     */
    private Integer pointsNum;
}
