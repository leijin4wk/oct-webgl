package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @Description: 等级信息
 * @Author: fang
 * @create: 2019-03-21
 **/
@Data
public class GradeInfoDTO implements Serializable {
    private static final long serialVersionUID = 6166685938145920608L;
    private Integer gradeId;
    private String grade;
    private Integer gradeOrd;
    private String gradeName;
    private Integer roomNights;
    private Integer noShow;
    /**
     * -1为无天数限制
     */
    private Integer validPeriod;
    private Boolean degradeFlag;
    private Integer relegationNights;
    private Integer relegationNoshow;
    private String icon1;
    private String icon2;
    private String description;
    private Integer previousGradeId;
    private Integer nextGradeId;
    private String text;
    private Boolean memberLimit;
    /**
     * -1为无定级天数限制
     */
    private Integer relegationDays;

}
