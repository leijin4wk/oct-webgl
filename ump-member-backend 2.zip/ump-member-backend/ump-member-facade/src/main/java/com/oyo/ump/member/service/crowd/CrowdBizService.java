package com.oyo.ump.member.service.crowd;

import com.oyo.common.response.BaseResponse;
import com.oyo.common.response.PagedResponse;
import com.oyo.ump.member.service.dto.*;

import java.util.List;

/**
 * 人群包操作对外接口
* @author leijin
* @date 2019-10-29 14:15
**/
public interface CrowdBizService {
    /**
     * 添加用户到人群包，如果人群包id为空，则新增人群包再添加用户到人群包
     * @author leijin
     * @param  addCrowdUserDTO 字段说明见具体定义
     * @return BaseResponse<Long> 返回人群包id
    * @date 2019-10-29 14:36
    **/
    BaseResponse<Long> addUserToCrowd(AddCrowdUserDTO addCrowdUserDTO);


    /**
     * 删除人群包人群
     * @author leijin
     * @param  deleteCrowdUserDTO 字段说明见具体定义
     * @return BaseResponse<String>
     * @date 2019-10-29 14:36
     **/
    BaseResponse<String> deleteCrowdUser(DeleteCrowdUserDTO deleteCrowdUserDTO);


    /**
     * 根据userId进行分组查询
     * @author leijin
     * @param  deleteCrowdUserDTO 字段说明见具体定义
     * @return PagedResponse<CrowdUsersDTO> 字段说明见具体定义
     * @date 2019-10-29 14:36
     **/
    PagedResponse<CrowdUsersDTO> findCrowdUser(CrowdUserConditionDTO deleteCrowdUserDTO);



    /**
     * 查询用户是否存在与人群包中
     * @author leijin
     * @param  existCrowdUserDTO 字段说明见具体定义
     * @return BaseResponse<Boolean> 人群是否存在，true存在
     * @date 2019-10-29 14:36
     **/
    BaseResponse<Boolean> existCrowdUser(ExistCrowdUserDTO existCrowdUserDTO);

    /**
     * 人群包列表查询
     * @param requestDTO
     * @return
     */
    PagedResponse<CrowdDTO> getCrowdList(CrowdListRequestDTO requestDTO);

    /**
     * 获取人群包详情
     * @param requestDTO
     * @return
     */
    BaseResponse<CrowdDetailDTO> getCrowdDetail(CrowdDetailRequestDTO requestDTO);

    /**
     *批量获取用户是否在人群
     * @param requestDTO
     * @return
     */
    BaseResponse<List<ExistCrowdDTO>> batchExistCrowdUser(BatchExistCrowdRequestDTO requestDTO);

    /**
     * 新增人群接口v2 修改返回参数。拆除新建的逻辑
     * @param addCrowdUserDTO
     * @return
     */
    BaseResponse<AddCrowdUserResponseDTO> addUserToCrowdV2(AddCrowdUserDTO addCrowdUserDTO);

    /**
     * 新建人群包
     * @param addCrowdUserDTO
     * @return
     */
    BaseResponse<AddCrowdUserResponseDTO> createUserCrowd(AddCrowdUserDTO addCrowdUserDTO);


}
