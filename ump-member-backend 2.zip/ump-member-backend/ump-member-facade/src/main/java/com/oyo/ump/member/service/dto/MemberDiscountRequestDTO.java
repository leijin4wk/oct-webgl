package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * @Author hubin
 * @Description: 会员折扣请求
 * @Date 2019-04-05
 */
@Data
public class MemberDiscountRequestDTO implements Serializable {
    private static final long serialVersionUID = 6666221211845764479L;
    /**
     * 会员Id
     */
    private Long userId;

    /**
     * 酒店Id
     */
    private List<Long> hotelIdList;

    /**
     * 平台 1 : oyo  渠道id: 目前只处理飞猪 其他按oyo处理
     */
    private Integer platform ;
}
