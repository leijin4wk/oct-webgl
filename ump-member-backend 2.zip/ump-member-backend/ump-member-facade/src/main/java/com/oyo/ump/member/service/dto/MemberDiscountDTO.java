package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * @Description: 会员折扣补贴
 * @Author: fang
 * @create: 2019-03-25
 **/
@Data
public class MemberDiscountDTO implements Serializable {
    private static final long serialVersionUID = -4081266884915085639L;
    private Long userId;
    private Integer gradeId;
    private Integer discount;
    private Integer freightDiscount;
    private Integer subsidy;
    private Integer undertakeOwner;
    private Integer undertakeOyo;
    private Long hotelId;
}
