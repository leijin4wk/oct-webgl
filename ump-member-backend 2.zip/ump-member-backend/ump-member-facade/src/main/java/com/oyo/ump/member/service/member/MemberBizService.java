package com.oyo.ump.member.service.member;

import com.oyo.common.response.BaseResponse;
import com.oyo.ump.member.service.dto.*;

import java.util.List;

/**
 * @author fang
 */
public interface MemberBizService {

    default BaseResponse<MemberInfoDTO> getMemberInfoByUserId(Long userId){
        MemberInfoRequestDTO memberInfoRequestDTO=new MemberInfoRequestDTO();
        memberInfoRequestDTO.setUserId(userId);
        memberInfoRequestDTO.setTenant("OYO");
        return getMemberInfoByUserV2(memberInfoRequestDTO);
    }

    BaseResponse<MemberInfoDTO> getMemberInfoByUserV2(MemberInfoRequestDTO memberInfoRequestDTO);



    BaseResponse<List<MemberDiscountDTO>> getMemberDiscount(MemberDiscountRequestDTO discountRequestDTO);

    /**
     * 会员折扣版本2 增加飞猪
     * @param discountRequestDTO
     * @return
     */
    BaseResponse<List<MemberDiscountDTO>> getMemberDiscountV2(MemberDiscountRequestDTO discountRequestDTO);


    default BaseResponse<List<MemberInfoDTO>> getMemberInfoByUserIdList(List<Long> userIds){
        MemberInfoBatchRequestDTO memberInfoBatchRequestDTO =new MemberInfoBatchRequestDTO();
        memberInfoBatchRequestDTO.setUserIds(userIds);
        memberInfoBatchRequestDTO.setTenant("OYO");
        return getMemberInfoByUserIdList(memberInfoBatchRequestDTO);
    }

    BaseResponse<List<MemberInfoDTO>> getMemberInfoByUserIdList(MemberInfoBatchRequestDTO memberInfoBatchRequestDTO);

    /**
     * 注册会员默认
     * @param userId
     * @return
     */
     BaseResponse<Boolean> registerMember(Long userId);

    /**
     * 注册会员V2
     * @param requestDTO
     * @return
     */
    BaseResponse<Boolean> registerMemberV2(RegisterRequestDTO requestDTO);

    /**
     * 会员同步
     * @param requestDTO
     * @return
     */
    BaseResponse<Boolean> syncMemberGrade(SyncMemberGradeRequestDTO requestDTO);

    /**
     * 日本会员注册->用户注册
     * @param requestDTO
     * @return
     */

    BaseResponse<UserMemberRegisterResponseDTO> registerUserAndMember(UserMemberRegisterRequestDTO requestDTO);



}
