package com.oyo.ump.member.service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * @Description:
 * @Author: fang
 * @create: 2019-12-13
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AccountCustomerDto implements Serializable {
    private static final long serialVersionUID = 6013495203426660667L;
    /**
     * c端账户Id  一个用户usercode  对应多个 账户accountId
     */
    private Long accountId;

    /**
     * 用户code  唯一标志
     */
    private Long userCode;

    /**
     * 姓名
     */
    private String name;

    /**
     * 昵称
     */
    private String nickName;

    /**
     * 邮箱
     */
    private String email;

    /**
     * 手机
     */
    private String phone;

    private String password;

    private String status;

    private String isDelete;

    /**
     * token
     */
    private String accessToken;

    /**
     * 扩展信息
     */
    private Map<String,Object> extra;

    private Long creatorId;

    private Long modifierId;

    /**
     * 自然人信息
     */
    private NaturalPersonDto naturalPerson;

    private String phoneAreaCode;

    /**
     * 头像
     */
    private String avatar;

    /** 操作系统 */
    private String os;

    /**
     * 渠道code
     */
    private String platform;

    /**
     * 渠道名称
     */
    private String platformName;

    /**
     * 第三方账户列表
     */
    private List<ThirdAccountDto> thirdAccounts;
}
