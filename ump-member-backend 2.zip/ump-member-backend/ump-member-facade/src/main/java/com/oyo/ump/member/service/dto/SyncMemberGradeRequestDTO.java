package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @Description:
 * @Author: fang
 * @create: 2019-08-30
 **/
@Data
public class SyncMemberGradeRequestDTO implements Serializable {
    /**
     * 飞猪 ：RM008007_FZ
     */
    private String platform;
    /**
     * V1 V2
     */
    private String grade;
    /**
     * 用户id
     */
    private Long userId;

    /**
     * 租户 ：
     */
    private String tenant;
    /**
     * 有效期
     */
    private Date validTime;
    /**
     * 上一等级
     */
    private String refreshCode;
}
