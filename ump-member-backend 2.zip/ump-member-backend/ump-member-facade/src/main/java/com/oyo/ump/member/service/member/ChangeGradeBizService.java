package com.oyo.ump.member.service.member;

import com.oyo.common.response.BaseResponse;
import com.oyo.ump.member.service.dto.ChangeGradeRequestDTO;

/**
 * @author Dong
 * @Classname ChangeGradeBizService
 * @Description 会员等级变化（升级 降级）
 * @Date 2019-03-25
 */
public interface ChangeGradeBizService {
    BaseResponse changeGradeByPackage(ChangeGradeRequestDTO changeGradeRequestDTO);

}
