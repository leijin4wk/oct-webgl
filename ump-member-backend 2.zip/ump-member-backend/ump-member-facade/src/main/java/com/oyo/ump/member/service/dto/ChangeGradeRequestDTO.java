package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * @author Dong
 * @Classname ChangeGradeRequestDTO
 * @Description 更改用户等级的请求参数对象
 * @Date 2019-03-27
 */
@Data
public class ChangeGradeRequestDTO implements Serializable {
    private static final long serialVersionUID = 3207330045958838522L;
    private Long userId;
    private String skuCode;
    /**
     * 等级变化类型（1 升级；2 降级）
     */
    private Integer changeType;
}
