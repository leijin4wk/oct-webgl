package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

@Data
public class DeleteCrowdUserDTO implements Serializable {

    private Long  crowdId;

    private Set<Long> userIds;

}
