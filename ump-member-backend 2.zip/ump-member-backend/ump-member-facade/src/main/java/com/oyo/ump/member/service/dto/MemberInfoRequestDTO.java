package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * @Description:
 * @Author: fang
 * @create: 2019-08-20
 **/
@Data
public class MemberInfoRequestDTO implements Serializable {
    /**
     * 用户id
     */
    private Long userId;
    /**
     * 租户
     */
    private String tenant;
}
