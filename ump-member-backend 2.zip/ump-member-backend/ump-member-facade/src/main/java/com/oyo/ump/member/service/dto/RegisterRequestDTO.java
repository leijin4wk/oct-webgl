package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * @Description:
 * @Author: fang
 * @create: 2019-08-12
 **/
@Data
public class RegisterRequestDTO implements Serializable {
    /**
     * 用户id
     */
    private Long userId;
    /**
     *  租户  OYO  日本 ：OYO_JP
     *
     */
    private String tenant;

    /**
     * 平台  OYO：OYO  飞猪： RM008007_FZ
     */
    private String platform;
    /**
     * 平台等级id V1 V2 V3 V4
     */
    private String grade;

}
