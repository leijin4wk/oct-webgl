package com.oyo.ump.member.service.dto;

import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Set;

/**
 * 添加用户到人群包
* @author leijin
* @date 2019-10-29 14:34
**/
@Data
public class AddCrowdUserDTO implements Serializable {
    /**
     * 人群包id 非新建必传,
     */

    private Long  crowdId;
    /**
     * 人群包名称 新建必传
     */
    private String name;
    /**
     * userId 集合不能为空
     */

    private Set<Long> userIds;

}
