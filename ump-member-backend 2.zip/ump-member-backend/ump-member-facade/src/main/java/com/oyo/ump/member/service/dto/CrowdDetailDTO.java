package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @Description:
 * @Author: fang
 * @create: 2019-11-08
 **/
@Data
public class CrowdDetailDTO implements Serializable {
    private Long crowdId;
    private List<RuleDTO> ruleList;
    @Data
    public static class RuleDTO implements Serializable{
        private String rule;
        private Integer ruleRelation;
    }
}
