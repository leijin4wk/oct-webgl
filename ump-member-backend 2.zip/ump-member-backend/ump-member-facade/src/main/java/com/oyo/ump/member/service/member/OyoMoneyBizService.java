package com.oyo.ump.member.service.member;

import com.oyo.common.response.BaseResponse;
import com.oyo.ump.member.service.dto.*;

/**
 * @Description: ob对外接口
 * @Author: fang
 * @create: 2019-10-18
 **/
public interface OyoMoneyBizService {
    /**
     * 获取ob 汇率
     * @return
     */
    BaseResponse<ExchangeRateDTO> getOyoMoneyExchangeRate();

    /**
     * 获取签到ob信息
     * @param userId
     * @return
     */
    BaseResponse<MemberSignInMoneyDTO> getMemberSignInMoney(Long userId);

    /**
     * 获取房单ob明细
     * @param requestDTO
     * @return
     */
    BaseResponse<OyoMoneyDetailDTO> getOyoMoneyDetailByOrderSn(OyoMoneyDetailRequestDTO requestDTO);

    /**
     * 鸥币延迟发放
     * @param requestDTO
     * @return
     */
    BaseResponse<OyoMoneyDelayDTO> getOyoMoneyDelay(OyoMoneyDelayRequestDTO requestDTO);
}
