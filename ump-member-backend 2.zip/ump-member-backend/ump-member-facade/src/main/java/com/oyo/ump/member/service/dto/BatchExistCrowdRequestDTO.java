package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @Description:
 * @Author: fang
 * @create: 2019-11-11
 **/
@Data
public class BatchExistCrowdRequestDTO implements Serializable {
    private List<Long> crowdIdList;
    private Long  userId;
    private String distinctId;
}
