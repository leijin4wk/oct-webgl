package com.oyo.ump.member.service.push;

import com.oyo.common.response.BaseResponse;
import com.oyo.ump.member.service.dto.PromotionPushRequestDTO;

/**
 * @author Dong
 * @Description push对外RPC接口
 * @Date 2019-03-25
 */
public interface PushRPCBizService {
    BaseResponse<Boolean> promotionPushOperation(PromotionPushRequestDTO promotionPushRequestDTO);
}
