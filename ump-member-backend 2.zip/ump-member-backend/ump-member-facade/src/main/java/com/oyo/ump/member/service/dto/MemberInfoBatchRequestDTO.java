package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class MemberInfoBatchRequestDTO implements Serializable {
    /**
     * 用户id
     */
    private List<Long> userIds;
    /**
     * 租户
     */
    private String tenant;
}
