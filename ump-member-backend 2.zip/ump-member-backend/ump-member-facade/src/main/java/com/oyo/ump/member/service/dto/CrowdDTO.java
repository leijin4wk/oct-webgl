package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @Description:
 * @Author: fang
 * @create: 2019-11-08
 **/
@Data
public class CrowdDTO implements Serializable {
    private Long id;
    private String crowdName;
    private String crowdStatus;
    /**
     * 数据更新时间
     */
    private Date dataUpdateTime;
    private Integer crowdNum;
    /**
     * 人群创建方式（1 按标签；2 自定义）
     */
    private String crowdCreateType;
    private String crowdTag;
    private Date createTime;
    private Date updateTime;
}
