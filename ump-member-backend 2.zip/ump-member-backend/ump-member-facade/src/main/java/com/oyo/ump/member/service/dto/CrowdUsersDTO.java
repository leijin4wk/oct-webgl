package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;
@Data
public class CrowdUsersDTO implements Serializable {

    private  Long  userId;

    private String crowdIds;

    private Date createTime;
}
