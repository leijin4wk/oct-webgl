package com.oyo.ump.member.service.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @Description:
 * @Author: fang
 * @create: 2019-10-18
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ExchangeRateDTO implements Serializable {
    /**
     * 每一积分可抵扣人民币（元）
     */
    private BigDecimal pricePerUnit;
    /**
     * 单此消耗最少兑换数量
     */
//    private Integer minCostNum;
    /**
     * 业主承担比例
     */
    private Integer undertakeOwner;
    /**
     * oyo承担比例
     */
    private Integer undertakeOyo;
    /**
     * 1元兑换的鸥币价值量
     */
    private BigDecimal costPerUnit;

}
