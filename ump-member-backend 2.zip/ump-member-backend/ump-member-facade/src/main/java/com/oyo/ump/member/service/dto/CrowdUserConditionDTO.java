package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.Set;
@Data
public class CrowdUserConditionDTO implements Serializable {
    private Set<Long> crowdIds;
    private Long  userId;
    private Integer  pageNum=0;
    private Integer  pageSize=5;
}
