package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * @Description:
 * @Author: fang
 * @create: 2020-01-02
 **/
@Data
public class OyoMoneyDelayDTO implements Serializable {
    private Integer delay;
}
