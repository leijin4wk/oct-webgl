package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @Description: 会员签到返回
 * @Author: fang
 * @create: 2019-10-18
 **/
@Data
public class  MemberSignInMoneyDTO implements Serializable {
    /**
     * 等级id
     */
    private Integer gradeId;
    /**
     * 签到总欧币数
     */
    private Integer totalNum;
    /**
     * 积分有效开始日期
     */
    private Date effectDate;
    /**
     * 积分有效截止日期
     */
    private Date  validDate;
    /**
     * 用户id
     */
    private Long userId;

    /**
     * 欧币明细
     */
    private List<OyoMoneySourceDTO> pointsDetails;


}
