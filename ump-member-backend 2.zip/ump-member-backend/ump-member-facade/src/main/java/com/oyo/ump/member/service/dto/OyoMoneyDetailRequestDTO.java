package com.oyo.ump.member.service.dto;

import lombok.Data;
import lombok.NonNull;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @Description:
 * @Author: fang
 * @create: 2019-10-18
 **/
@Data
public class OyoMoneyDetailRequestDTO implements Serializable {
    private Long userId;
    /**
     * 实付金额
     */
    private Double amount;
    /**
     * 身份证号
     */
    private String cardNo;
    /**
     * 酒店id
     */
    private Long hotelId;
    /**
     * 渠道id
     */
    private Integer channelId;
    /**
     *房单状态
     */
    private Integer status;
    /**
     * 时间
     */
    private Date date;
}
