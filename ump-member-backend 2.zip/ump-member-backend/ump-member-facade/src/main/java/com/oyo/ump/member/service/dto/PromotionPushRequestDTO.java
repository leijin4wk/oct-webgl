package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * @author Dong
 * @Description 创建push的RPC请求
 * @Date 2019-03-25
 */
@Data
public class PromotionPushRequestDTO implements Serializable {
    private static final long serialVersionUID = 4194364524262838562L;
    /**
     * 活动工具id
     */
    private String promotionId;
    /**
     * 活动开始时间(yyyy-MM-dd hh:mm:ss)
     */
    private String startTime;
    /**
     * 操作（0-查询；1-关注；2取消关注）
     */
    private String operation;
    /**
     * 用户Id
     */
    private Long userId;

}
