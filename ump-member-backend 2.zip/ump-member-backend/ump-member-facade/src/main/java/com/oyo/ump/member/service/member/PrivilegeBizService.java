package com.oyo.ump.member.service.member;

import com.oyo.common.response.BaseResponse;
import com.oyo.ump.member.service.dto.GradePrivilegeDTO;

import java.util.List;

public interface PrivilegeBizService {

    BaseResponse<List<GradePrivilegeDTO>> getGradePrivilegeList();

    BaseResponse<GradePrivilegeDTO>  getGradePrivilegeByGradeId(Integer gradeId);
}
