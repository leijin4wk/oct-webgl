package com.oyo.ump.member.service.enums;

public enum PushOperationTypeEnum {

    QUERY("0","查询"),
    ADD("1","关注 "),
    CANCEL("2","取消关注");

    private final String type;
    private final String name;

    PushOperationTypeEnum(String type, String name) {
        this.type = type;
        this.name = name;
    }

    public String getType() {
        return type;
    }
    public String getName() {
        return name;
    }
}
