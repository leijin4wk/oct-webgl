package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * @Description:
 * @Author: fang
 * @create: 2019-11-08
 **/
@Data
public class CrowdDetailRequestDTO implements Serializable {
    private Long crowId;
}
