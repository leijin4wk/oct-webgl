package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * @Description: 会员权益类
 * @Author: fang
 * @create: 2019-03-22
 **/
@Data
public class GradePrivilegeDTO implements Serializable {
    private static final long serialVersionUID = 1490963109325557701L;
    private Integer gradeId;
    private String grade;
    private SpecialDiscount specialDiscount;
    private LateCheckout lateCheckout;
    private OptimalPriceGurantee optimalPriceGurantee;
    private ReservationGuarantee reservationGuarantee;
    private FreeWifi freeWifi;
    private BonusConfig bonusConfig;
    @Data
    public static class SpecialDiscount implements Serializable{
        private static final long serialVersionUID = 1490963109325557701L;
        private Integer discount;
        private Boolean memberLimit;
        private Boolean discountLimit;
        private Integer undertakeOwner;
        private Integer undertakeOyo;
        //高亮图片
        private String icon;
        //置灰图片
        private String icon2;
        private Boolean hold;
        private String description;
        private String description2;
        private Integer index;
        private String name;
        private String name2;


    }
    @Data
    public static class LateCheckout implements Serializable{
        private Boolean memberLimit;
        private String detail;
        private Integer timeLimit;
        private String icon;
        private Boolean hold;
        private String icon2;
        private String description;
        private String description2;
        private Integer index;
        private String name;
        private String name2;



    }
    @Data
    public static class OptimalPriceGurantee implements Serializable{
        private Boolean memberLimit;
        private String guranteeType;
        private String icon;
        private String icon2;
        private Boolean hold;
        private String description;
        private String description2;

        private Integer index;
        private String name;
        private String name2;

    }
    @Data
    public static class ReservationGuarantee implements Serializable {
        private Boolean memberLimit;
        private Integer guaranteeHours;
        private String icon;
        private String icon2;
        private Boolean hold;
        private String description;
        private String description2;
        private Integer index;
        private String name;
        private String name2;


    }
    @Data
    public static class FreeWifi implements Serializable{
        private Boolean memberLimit;
        private Integer wifiHours;
        private String icon;
        private String icon2;
        private Boolean hold;
        private String description;
        private String description2;
        private Integer index;
        private String name;
        private String name2;


    }
    @Data
    public static class BonusConfig implements Serializable{
        private Boolean memberLimit;
        private String bonusFactor;
        private String consumeFactor;
        private String icon2;
        private String icon;
        private Boolean hold;
        private String description;
        private String description2;
        private Integer index;
        private String name;
        private String name2;

    }
}
