package com.oyo.ump.member.service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @Description:
 * @Author: fang
 * @create: 2019-12-13
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ThirdAccountDto implements Serializable {

    private static final long serialVersionUID = -5888873199544206247L;
    /** 记录主键id */
    private Long id;

    /** 账号id */
    private Long accountId;

    /**
     * 第三方账号来源,类型不同，存储的关键字段不同
     * 微信:    WX
     * 支付宝:  ALIPAY
     */
    private String type;

    /**
     * 第三方账号类型名称
     */
    private String typeName;

    /**
     * 用户唯一标识，用于搜索
     * type=WX      uk => unionId
     * type=ALIPAY  uk => userId
     */
    private String uk;

    /**
     * 应用唯一标识，用于搜索
     * type=WX     appId => appId
     * type=ALIPAY appId => appId
     */
    private String appId;

    /**
     * 应用下用户唯一标识，用于搜索
     * type=WX  openId => openId
     */
    private String openId;

    /**
     * 手机号，用于搜索
     * type=WX     phone => 微信用户手机号
     * type=ALIPAY phone => 支付宝绑定手机号
     */
    private String phone;

    /**
     * 用户名
     * type=WX     name => 微信昵称
     * type=ALIPAY name => 支付宝昵称
     */
    private String name;

    /**
     * 预留字段1，用于搜索
     * type=WX      index1 预留字段，暂不存值
     * type=ALIPAY  index1 预留字段，暂不存值
     */
    private String index1;

    /**
     * 预留字段2，用于搜索
     * type=WX      index2 预留字段，暂不存值
     * type=ALIPAY  index2 预留字段，暂不存值
     */
    private String index2;

    /**
     * 预留字段3，用于搜索
     * type=WX      index3 预留字段，暂不存值
     * type=ALIPAY  index3 预留字段，暂不存值
     */
    private String index3;

    /**
     * 预留字段4，用于搜索
     * type=WX      index4 预留字段，暂不存值
     * type=ALIPAY  index4 预留字段，暂不存值
     */
    private String index4;

    /** 账号状态，0:有效 1:无效 不传默认是 0 */
    private String status;

    private String full;

    private String createTime;

    private String updateTime;

    /**
     * 用户类型，枚举如下，不传默认是B
     * B  accountId是B端用户
     * C  accountId是C端用户
     */
    private String userType;
}
