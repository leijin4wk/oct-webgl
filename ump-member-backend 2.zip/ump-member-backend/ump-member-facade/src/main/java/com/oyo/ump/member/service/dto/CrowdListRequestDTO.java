package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @Description:
 * @Author: fang
 * @create: 2019-11-08
 **/
@Data
public class CrowdListRequestDTO implements Serializable {
    private String crowdName;
    private Date startTime;
    private Date endTime;
    private Integer crowdStatus;
    private Integer pageNum=1;
    private Integer pageSize=5;

}
