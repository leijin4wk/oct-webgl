package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * @author Dong
 * @Classname HotelDTO
 * @Description 酒店信息DTO
 * @Date 2019-04-01
 */
@Data
public class HotelDTO implements Serializable {
    private static final long serialVersionUID = -8304219981275656455L;
    private Integer id;
    private Long hotelId;
    private Integer cityId;

}
