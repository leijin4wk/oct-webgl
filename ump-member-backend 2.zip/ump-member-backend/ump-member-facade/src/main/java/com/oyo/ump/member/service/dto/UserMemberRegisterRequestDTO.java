package com.oyo.ump.member.service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @Description:
 * @Author: fang
 * @create: 2019-12-11
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserMemberRegisterRequestDTO implements Serializable {
    private static final long serialVersionUID = 2841690111014006446L;

    private List<AccountCustomerDto> accountCustomers;

    private Long creatorId;

    /**
     * 是否需要发送消息
     */
    private Boolean isSend;

    private String merchantCode;
    /**
     * 平台等级id V1 V2 V3 V4
     */
    private String grade;
    /**
     * 租户 ： 日本传OYO_JP 目前仅支持日本租户
     */
    private String tenant;
    /**
     * 有效期
     */
    private Date validTime;

}
