package com.oyo.ump.member.service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * @Description: todo
 * @Author: fang
 * @create: 2019-12-13
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class NaturalPersonDto extends UserDto{
    private static final long serialVersionUID = 2567571590068411152L;
    /**
     * 用户code  唯一标志
     */
    private Long userCode;

    /**
     * 用户类型
     */
    private String type;

    /**
     * 姓名
     */
    private String name;

    /**
     * 名字
     */
    private String firstName;

    /**
     * 姓氏
     */
    private String lastName;


    private String phone;

    private String email;

    /**
     * 性别  0 未知 1 女  2 男
     */
    private Integer gender;

    /**
     * 生日
     */
    private Date birthDate;

    private Long creatorId;

    private Long modifierId;
}
