package com.oyo.ump.member.service.enums;


public enum GradeEnum {

    GRADE_V1(1,"V1"),
    GRADE_V2(2,"V2"),
    GRADE_V3(3,"V3"),
    GRADE_V4(4,"V4");

    private  final int gradeId;
    private final String grade;

    GradeEnum(Integer gradeId, String grade) {
        this.gradeId = gradeId;
        this.grade = grade;
    }

    public Integer getGradeId() {
        return gradeId;
    }

    public String getGrade() {
        return grade;
    }
    public static String getGradeById(Integer gradeId){
        GradeEnum[] values = values();
        GradeEnum[] var2 = values;
        int var3 = values.length;

        for(int var4 = 0; var4 < var3; ++var4) {
            GradeEnum value = var2[var4];
            if (value.gradeId == gradeId) {
                return value.getGrade();
            }
        }
        return null;
    }
}
