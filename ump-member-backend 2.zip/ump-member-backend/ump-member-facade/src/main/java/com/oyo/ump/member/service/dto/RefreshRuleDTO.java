package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * @Description: todo
 * @Author: fang
 * @create: 2019-12-13
 **/
@Data
public class RefreshRuleDTO implements Serializable {
    private String code;
    private String name;
}
