package com.oyo.ump.member.processor.job;

import com.oyo.common.response.BaseResponse;

/**
 * @Author hubin
 * @Description:
 * @Date 2019-03-26
 */
public abstract class BaseChildJob<T> {
    /**
     * execute
     * @return
     */
    public abstract BaseResponse execute(T t);

}
