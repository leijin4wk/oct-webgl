package com.oyo.ump.member.processor.job;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import top.rdfa.timer.client.executor.JobExecutor;

/**
 * @Author hubin
 * @Description:
 * @Date 2019-04-06
 */
@Configuration
@Slf4j
@ConditionalOnProperty(name = "web.job.consume.switch", havingValue = "true")
public class RdfaJobConfiguration {
    @Value("${job.admin.address}")
    private String jobAdminAddress;

    @Value("${job.log.path}")
    private String jobLogPath;

    @Value("${app.name:ump-member-backend}")
    private String appName;

    @Bean(initMethod = "start", destroyMethod = "destroy")
    public JobExecutor jobExecutor() {
        JobExecutor executor = new JobExecutor();
        executor.setAdminAddresses(jobAdminAddress);
        executor.setLogPath(jobLogPath);
        executor.setAppName(appName);
        return executor;
    }
}
