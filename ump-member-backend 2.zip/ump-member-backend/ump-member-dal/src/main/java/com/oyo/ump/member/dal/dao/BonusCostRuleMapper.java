package com.oyo.ump.member.dal.dao;

import com.oyo.ump.member.dal.model.BonusCostRuleEntity;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Classname BonusCostRuleMapper
 * @Description 积分消费规则数据库访问接口
 * @Date 2019-03-15 15:07
 * @author Dong
 */
@Repository
public interface BonusCostRuleMapper {
    /**
     * 获取所有的积分消费规则
     * @return java.util.List<com.oyo.ump.member.dal.model.BonusCostRuleEntity>
     */
    List<BonusCostRuleEntity> getCostRuleList();
}
