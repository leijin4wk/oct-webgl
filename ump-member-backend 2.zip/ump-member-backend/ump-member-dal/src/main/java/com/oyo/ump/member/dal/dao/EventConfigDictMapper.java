package com.oyo.ump.member.dal.dao;

import com.oyo.ump.member.dal.model.EventConfigDictEntity;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Dong
 * @Classname EventConfigDictEntity
 * @Description
 * @Date 2019-08-27
 */
@Repository
public interface EventConfigDictMapper {
    /**
     * 获取所有的事件大类名称
     * @param
     * @return java.util.List<com.oyo.ump.member.dal.dao.EventConfigDictEntity>
     */
    List<EventConfigDictEntity> getAllEventName();

    /**
     * 获取事件大类下的具体事件
     * @param eventName
     * @return java.util.List<com.oyo.ump.member.dal.dao.EventConfigDictEntity>
     */
    List<EventConfigDictEntity> getPropertyName(String eventName);

    /**
     * 根据事件tagColumn获取事件信息
     * @param tagColumn
     * @return com.oyo.ump.member.dal.model.EventConfigDictEntity
     */
    EventConfigDictEntity selectByTagColumn(@Param("eventName") String eventName, @Param("tagColumn") String tagColumn);
}
