package com.oyo.ump.member.dal.model;

import lombok.Data;

import java.io.Serializable;

/**
 * @author Dong
 * @Classname UserProfileDictEntity
 * @Description 人群分类
 * @Date 2019-06-04
 */
@Data
public class UserProfileDictEntity implements Serializable {
    private Integer id;
    private String tagNo;
    private Integer tagStatus;
    private Integer firstClass;
    private Integer secondClass;
    private String tagName;
    private Integer tagType;
    private String tagTable;
    private String tagColumn;
    private String tagDesc;
    private String sampleSql;
    private String valueArea;
    /**
     * B端用户画像字典表用
     */
    private String filter;
}
