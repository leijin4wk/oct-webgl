package com.oyo.ump.member.dal.dao;

import com.oyo.ump.member.dal.model.PushMessageEntity;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;
import java.util.Map;

@Repository
public interface PushMessageMapper {
    /**
     * 统计时间段内某一类型的信息推送次数
    * @author frank
    * @date  11:29
    **/
    Integer countPushMessageByCreateTime(@Param("pushMessageEntity") PushMessageEntity pushMessageEntity,@Param("startTime") Date startTime);

    void  insertPushMessageEntity(PushMessageEntity pushMessageEntity);

    void insertPushMessageEntityList(@Param("list") List<PushMessageEntity> list);


    void updatePushMessageByIdsAndBatchNo(@Param("list") List<Long> list,@Param("batchNo") String batchNo);


    List<PushMessageEntity> findNoPushMessageByStatusAndJobId(@Param("pushJobId") Long pushJobId,@Param("limitNum")Integer limitNum);

    /**
     * 通过jobId templateId 查询待发送的信息
     * @param pushJobId
     * @param templateId
     * @param limitNum
     * @return java.util.List<com.oyo.ump.member.dal.model.PushMessageEntity>
     */
    List<PushMessageEntity> getWaitSendMessage(@Param("pushJobId") Long pushJobId,@Param("templateId") String templateId,@Param("limitNum")Integer limitNum);

    Long countPushMessageByJobId(@Param("pushJobId") Long pushJobId);

    List<Long> getUserIdsByInterval(@Param("userIds") List<Long> userIds, @Param("pushId") Long pushId, @Param("date") String date);
}
