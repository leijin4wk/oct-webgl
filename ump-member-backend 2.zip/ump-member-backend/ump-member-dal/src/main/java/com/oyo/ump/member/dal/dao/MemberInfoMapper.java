package com.oyo.ump.member.dal.dao;

import com.oyo.ump.member.dal.model.MemberInfoEntity;
import org.springframework.stereotype.Repository;

@Repository
public interface MemberInfoMapper {

    /**
     * 查询单个会员的信息
     * @param userId
     * @return
     */
    MemberInfoEntity queryMemberByUserId(Long userId);
}
