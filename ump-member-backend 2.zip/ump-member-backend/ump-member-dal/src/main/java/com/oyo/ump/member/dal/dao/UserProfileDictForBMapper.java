package com.oyo.ump.member.dal.dao;

import com.oyo.ump.member.dal.model.UserProfileDictEntity;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Dong
 * @Classname UserProfileDictMapper
 * @Description 用户标签字典数据库接口
 * @Date 2019-05-06
 */
@Repository
public interface UserProfileDictForBMapper {
    UserProfileDictEntity selectByTagColumn(String tagColumn);
    List<UserProfileDictEntity> selectByFirstId();
}
