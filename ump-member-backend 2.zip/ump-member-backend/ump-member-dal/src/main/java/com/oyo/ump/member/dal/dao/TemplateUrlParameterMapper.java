package com.oyo.ump.member.dal.dao;

import com.oyo.ump.member.dal.model.TemplateUrlParameterEntity;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Description 事件推送模板 长链
* @author dong
* @date 2019-09-05 12:03
**/
@Repository
public interface TemplateUrlParameterMapper {
    /**
     * 根据链接类型查询模板长链信息
     * @param
     * @return java.util.List<com.oyo.ump.member.dal.model.TemplateUrlParameterEntity>
     */
    List<TemplateUrlParameterEntity> getAllUrlParameter(@Param("urlType") Integer urlType);

    /**
     * 通过id获取对象
    * @author leijin
    * @date 2019-09-10 15:12
    **/
    TemplateUrlParameterEntity selectById(@Param("id") Long id);

    /**
     * 根据小程序ID查询模板长链信息
     * @param
     * @return java.util.List<com.oyo.ump.member.dal.model.TemplateUrlParameterEntity>
     */
    List<TemplateUrlParameterEntity> getAllUrlParameterByMiniAppId(@Param("miniAppId") String miniAppId);
}
