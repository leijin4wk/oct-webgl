package com.oyo.ump.member.dal.dao;

import com.oyo.ump.member.dal.model.MemberGradeEntity;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * @Description:会员等级信息
 * @Author: fang
 * @create: 2019-03-20
 **/
@Repository
public interface MemberGradeMapper {

     MemberGradeEntity getMemberGradeByUserId(Long userId,String tenant);

     List<MemberGradeEntity> getMemberGradeByUserIds(List<Long> userIds,String tenant);

     /**
      * 查询会员身份信息列表
      * @param params
      * @return java.util.List<com.oyo.ump.member.dal.model.MemberGradeEntity>
      */
     List<MemberGradeEntity> getMemberIdentityList(Map<String, Object> params);

//     /**
//      * 查询会员身份信息列表,有userID的情况
//      * @param params
//      * @return java.util.List<com.oyo.ump.member.dal.model.MemberGradeEntity>
//      */
//     List<MemberGradeEntity> getMemberIdentityListByUserIdX(Map<String, Object> params);

     /**
      * 升级包后升级和降级
      * @param memberGradeEntity member_grade_info对应的实体类
      * @return void
      */
     void changeGrade(MemberGradeEntity memberGradeEntity);


     /**
      * 插入初始会员数据
      */
     void insert(MemberGradeEntity memberGradeEntity);
}
