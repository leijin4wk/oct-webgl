package com.oyo.ump.member.dal.dao;

import com.oyo.ump.member.dal.model.UmpDataMemberDimRptEntity;
import org.springframework.stereotype.Repository;

/**
 * @Description:
 * @Author: fang
 * @create: 2019-11-12
 **/
@Repository
public interface MemberDimMapper {
    /**
     * 获取用户画像信息
     * @param userId
     * @return
     */
    UmpDataMemberDimRptEntity getMemberInfoById(Long userId);

    /**
     *
     * @param distinctId
     * @return
     */
    UmpDataMemberDimRptEntity getMemberInfoByDistinctId(String distinctId);
}
