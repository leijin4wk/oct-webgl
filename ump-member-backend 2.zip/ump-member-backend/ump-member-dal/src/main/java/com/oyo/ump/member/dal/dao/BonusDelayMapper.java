package com.oyo.ump.member.dal.dao;

import com.oyo.ump.member.dal.model.BonusDelayEntity;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

/**
 * @Description: 鸥币延迟配置
 * @Author: fang
 * @create: 2020-01-02
 **/
@Repository
public interface BonusDelayMapper {
    /**
     * 根据类型获取延迟天数
     * @param type
     * @return
     */
    @Select(" SELECT delay FROM member_bonus_delay_config  where business_type=#{type} ")
    Integer getBonusDelayByType(@Param("type") Integer type);

    /**
     * 改变延迟天数
     * @param type
     * @param delay
     */
    @Update("update member_bonus_delay_config set delay=#{delay} where business_type =#{type}")
    void updateBonusDelayByType(@Param("type") Integer type,@Param("delay") Integer delay);

    /**
     * 插入历史表
     * @param type
     * @param oldValue
     * @param newValue
     * @param userId
     * @param name
     */
    @Update("insert into  member_bonus_delay_config_detail (business_type,old_value,new_value,operate_id,operate_name)  values" +
            "(#{type},#{oldValue},#{newValue},#{userId},#{name})")
    void updateBonusDelayDetail(@Param("type")Integer type,@Param("oldValue") Integer oldValue,@Param("newValue") Integer newValue,@Param("userId")Long userId,@Param("name") String name);
}
