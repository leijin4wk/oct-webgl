package com.oyo.ump.member.dal.dao;

import com.oyo.ump.member.dal.model.MemberOrderEntity;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Author hubin
 * @Description:
 * @Date 2019-04-05
 */
@Repository
public interface MemberOrderMapper {

    /**
     * 会员离线订单同步
     * @param memberOrderEntity
     * @return
     * @throws RuntimeException
     */
    boolean insertMemberOrder(MemberOrderEntity memberOrderEntity);

    /**
     * 获取尚未处理的订单列表
     * @param calcTime
     * @param batchSize
     * @return
     */
    List<MemberOrderEntity> getUnProcessedOrderList(String calcTime, int batchSize);

    /**
     * 更新订单状态
     * @param memberOrderEntity
     * @return
     */
    boolean updateMemberOrder(MemberOrderEntity memberOrderEntity);

    /**
     * 查询用户房单
     */
    List<MemberOrderEntity> queryOrderList(Long userId,List<String> list);

    /**
     * 根据订单号查询订单信息
     * @param orderSn
     * @return
     */

    MemberOrderEntity getOrderByOrderSn(String orderSn);

    /**
     * 一单多人 更新订单
     * @param orderDetail
     */
    void update(MemberOrderEntity orderDetail);
}
