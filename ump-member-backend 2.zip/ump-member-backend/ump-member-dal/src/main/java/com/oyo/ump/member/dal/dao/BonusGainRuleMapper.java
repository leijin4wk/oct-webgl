package com.oyo.ump.member.dal.dao;

import com.oyo.ump.member.dal.model.BonusGainRuleEntity;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Classname BonusGainRuleMapper
 * @Description 积分获取规则数据库访问接口
 * @Date 2019-03-16 09:34
 * @author Dong
 */
@Repository
public interface BonusGainRuleMapper {
    /**
     * 获取所有积分获取规则
     * @return java.util.List<com.oyo.ump.member.dal.model.BonusGainRuleEntity>
     **/
    List<BonusGainRuleEntity> getGainRuleList(@Param("tenant")String tenant);
}
