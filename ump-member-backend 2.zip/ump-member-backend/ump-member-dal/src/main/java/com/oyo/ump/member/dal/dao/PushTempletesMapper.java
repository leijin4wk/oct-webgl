package com.oyo.ump.member.dal.dao;

import com.oyo.ump.member.dal.model.PushTempletesEntity;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Description 事件推送模板数据库接口
* @author frank
* @date 2019-05-13 12:03
**/
@Repository
public interface PushTempletesMapper {
    /**
     * 通过主键来查找
    * @author frank
    * @date 2019-05-13 16:46
    **/
    PushTempletesEntity selectPushTempletesEntityById(Long id);
    /**
     * 通过主键list来查找
    * @author frank
    * @date 2019-05-13 16:47
    **/
    List<PushTempletesEntity> selectPushTempletesEntityByIds(@Param("ids") List<Long> ids);
    /**
     * 根据模板编号list获取模板
    * @author frank
    * @date 2019-07-29 10:21
    **/
    List<PushTempletesEntity> selectPushTempletesEntityByTemplateNo(@Param("ids") List<String> templateNos);


    /**
     * 查询全部模板映射关系
    * @author frank
    * @date 2019-07-29 10:50
     * @return
    **/
    List<PushTempletesEntity> selectPushTemplatesEntityList();
    /**
     * 更新template名称和detail
    * @author frank
    * @date 2019-07-29 11:23
    **/
    void updatePushTemplateMap(@Param("item")PushTempletesEntity pushTempletesEntity);

    /**
     * 添加映射模板
    * @author frank
    * @date 2019-07-29 11:31
    **/
    void insertPushTemplateMap(@Param("item") PushTempletesEntity pushTempletesEntity);


}
