package com.oyo.ump.member.dal.dao;

import com.oyo.ump.member.dal.model.PushEntity;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Dong
 * @Classname PushMapper
 * @Description 事件推送数据库接口
 * @Date 2019-05-06
 */
@Repository
public interface PushMapper {
    void insertPush(PushEntity pushEntity);
    PushEntity selectById(Long id);
    List<PushEntity> selectByIds(@Param("ids") List<Long> ids);
    List<PushEntity> selectByCondition(PushEntity pushEntity);
    void updatePushCrowdInfo(PushEntity pushEntity);
    void updatePushSendRule(PushEntity pushEntity);
    void updateSwitch(PushEntity pushEntity);
    void deletePush(Long id);
    List<PushEntity> selectByRuleIdsAndTriggerType(@Param("ruleIds") List<Long> ruleIds,@Param("triggerType") Integer triggerType);

    /**
     * 选取所有定时任务
     * @return
     */
    List<PushEntity> selectPersonasTimingPush();

    /**
     * 选取所有周期任务
     * @return
     */
    List<PushEntity> selectPersonasCyclePush();

    /**
     * 选取所有自定义事件任务
     * @return
     */
    List<PushEntity> selectEventTriggerPush();

}
