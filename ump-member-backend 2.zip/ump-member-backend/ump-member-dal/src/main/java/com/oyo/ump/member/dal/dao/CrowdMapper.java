package com.oyo.ump.member.dal.dao;

import com.oyo.ump.member.dal.model.CrowdEntity;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * @author Dong
 * @Classname PushMapper
 * @Description 事件推送数据库接口
 * @Date 2019-05-06
 */
@Repository
public interface CrowdMapper {
    void insertCrowd(CrowdEntity crowdEntity);
    CrowdEntity selectById(Long id);
    List<CrowdEntity> selectByIds(@Param("list") List<Long> ids);
    List<CrowdEntity> selectByCondition(Map<String, String> params);
    void updateCrowd(CrowdEntity crowdEntity);
    void deleteCrowd(Long id);
    List<CrowdEntity> selectTagCrowdEntities();

    /**
     * 批量获取
     * @param needQueryDbList
     * @return
     */
    List<CrowdEntity> batchGet(List<Long> needQueryDbList);
}
