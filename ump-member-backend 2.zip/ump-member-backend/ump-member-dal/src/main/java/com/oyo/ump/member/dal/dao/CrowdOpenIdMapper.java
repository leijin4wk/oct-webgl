package com.oyo.ump.member.dal.dao;

import com.oyo.ump.member.dal.model.CrowdOpenIdEntity;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Dong
 * @Classname CrowdCustomMapper
 * @Description
 * @Date 2019-06-06
 */
@Repository
public interface CrowdOpenIdMapper {
    /**
     * 通过人群ID查询
     * @param crowdId
     * @return java.util.List<com.oyo.ump.member.dal.model.CrowdPushIdEntity>
     */
    List<CrowdOpenIdEntity> selectByCrowdId(Long crowdId);
    /**
     * 批量插入
     * @param crowdId
     * @param openInfos
     * @return void
     */
    void insertBatch(@Param("crowdId") Long crowdId, @Param("pushInfos") List<CrowdOpenIdEntity> openInfos);
    /**
     * 通过crowdId删数据
     * @param id
     * @return void
     */
    void deleteByCrowdId(@Param("crowdId")Long id);
    }
