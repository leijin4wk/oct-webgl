package com.oyo.ump.member.dal.model;

import lombok.Data;

import java.util.Date;

/**
 * @Author hubin
 * @Description:
 * @Date 2019-04-05
 */
@Data
public class MemberOrderEntity {
    /**
     * id
     */
    private Long id;
    /**
     * 预订单号
     */
    private String bookingSn;

    /**
     * 订单号
     */
    private String orderSn;

    /**
     * 订单号
     */
    private String orderSource;

    /**
     * 下单时间
     */
    private Date orderTime;

    /**
     * 付款时间
     */
    private Date payTime;

    /**
     * 酒店ID
     */
    private Long hotelId;

    /**
     * 预订人Id
     */
    private Long userId;

    /**
     * 预订人用户名
     */
    private String username;

    /**
     * 是否本人入住
     */
    private boolean memberStay;

    /**
     * 会员等级
     */
    private Integer gradeId;

    /**
     * 付款金额
     */
    private Double paidAmount;

    /**
     * 拆分到每间夜金额
     */
    private Double roomNightsPaidAmount;

    /**
     * 房晚数
     */
    private Integer roomNights;

    /**
     * 是否noShow
     */
    private Boolean noShow;

    /**
     * checkIn时间
     */
    private Date checkInTime;

    /**
     * checkOut时间
     */
    private Date checkOutTime;

    /**
     * 消费积分系数
     */
    private Double consumePointsFactor = 1.0;

    /**
     * 奖励积分系数
     */
    private Double bonusPointsFactor;

    /**
     *
     */
    private Boolean updateFlag;

    /**
     *
     */
    private Date batchSyncTime;

    /**
     * 实际有效消费积分
     */
    private Integer consumePoints;

    /**
     * 实际有效奖励积分
     */
    private Integer bonusPoints;
    /**
     * 实际有效房晚
     */
    private Integer actualRoomNights;
}
