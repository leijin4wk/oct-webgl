package com.oyo.ump.member.dal.model;

import lombok.Data;
import lombok.ToString;
import org.junit.experimental.theories.suppliers.TestedOn;

import java.io.Serializable;
import java.util.Date;

/**
 * @author Dong
 * @Classname PushEntity
 * @Description 事件推送实体类
 * @Date 2019-05-05
 */
@Data
@ToString
public class PushEntity implements Serializable {
    private Long id;
    private String pushName;
    private Integer pushStatus;
    private String description;

    /**
     * 部门
     */
    private Long departmentId;
    private Integer triggerType;
    /**
     * 统一模板ID
     */
    private String uniformTemplateId;
    /**
     * 发送规则 1、立即发送；2、定时发送；3、重复发送
     */
    private Integer sendType;
    /**
     * 发送规则配置信息
     */
    private String sendConfig;

    private Integer validityFlag;
    private Date validityStart;
    private Date validityEnd;
    private String sendFrequency;
    /**
     * 圈定条件
     */
    private Long rule;
    private Integer triggerChannel;
    private Long pushTemplateId;
    private String triggerReward;
    private Long createUserId;
    private String createUserName;
    private Date createTime;
    private Long updateUserId;
    private String updateUserName;
    private Date updateTime;
    private Boolean isDeleted;

    private Date startTime;
    private Date endTime;
    /**
     * 是否创建完成，0-否；1-是
     */
    private Integer isFinish;
    /**
     * push的目标用户类型（1-c端用户，2-b端用户）
     */
    private Integer userType;
}
