package com.oyo.ump.member.dal.model;

import lombok.Data;

import java.io.Serializable;

/**
 * @Description: 会员权益entity
 * @Author: fang
 * @create: 2019-03-14
 **/
@Data
public class MemberPrivilegeEntity implements Serializable {
    private Integer id;
    private String specialDiscount;
    private String lateCheckout;
    private String optimalPriceGurantee;
    private String reservationGuarantee;
    private String freeWifi;
    private String bonusConfig;
    private String grade;


}
