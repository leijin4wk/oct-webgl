package com.oyo.ump.member.dal.model;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author Dong
 * @Classname PushRuleEntity
 * @Description 推送圈定规则
 * @Date 2019-05-07
 */
@Data
public class PushRuleEntity implements Serializable {
    private Long id;
    private String delineationName;
    private Integer eventType;
    private String eventKey;
    private String ruleDetail;
    private Date createTime;
    private Date updateTime;
    private Boolean isDeleted;
}
