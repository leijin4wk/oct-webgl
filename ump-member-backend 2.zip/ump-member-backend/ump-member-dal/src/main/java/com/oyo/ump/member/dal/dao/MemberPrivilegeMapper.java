package com.oyo.ump.member.dal.dao;

import com.oyo.ump.member.dal.model.MemberPrivilegeEntity;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MemberPrivilegeMapper {
    /**
     * 查找所有权益信息
     * @return
     */
    List<MemberPrivilegeEntity> queryAll();
}
