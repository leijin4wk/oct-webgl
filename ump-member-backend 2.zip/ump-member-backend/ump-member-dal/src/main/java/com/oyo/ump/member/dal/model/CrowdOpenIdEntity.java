package com.oyo.ump.member.dal.model;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author Dong
 * @Classname CrowdOpenIdEntity
 * @Description pushId人群
 * @Date 2019-06-04
 */
@Data
public class CrowdOpenIdEntity implements Serializable {
    private Long id;
    private Long crowdId;
    private String openId;
    private Date createTime;
}
