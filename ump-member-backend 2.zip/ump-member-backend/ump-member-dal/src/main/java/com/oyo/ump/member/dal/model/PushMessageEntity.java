package com.oyo.ump.member.dal.model;

import lombok.*;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 推送消息记录实体
* @author frank
* @date 2019-05-14 10:58
**/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PushMessageEntity implements Serializable {

    private Long id;

    private Long memberId;

    private Long templeteId;

    private Long memberPushId;

    private String messageDetail;

    private String eventKey;

    private Date createTime;

    private Boolean isDeleted;

    private String batchNo;

    private String uniformTemplateId;

    private Integer status;

    private Long pushJobRecordId;

    private Integer triggerChannel;

    /**
     * 此字段只为透传参数，不存库字段
     *
    * @author leijin
    * @date 2019-10-22 17:14
    **/
    private List<String> contentKeyList;

//    /**
//     * 非会员推送 pushId
//     */
//    private String pushId;
//    /**
//     * 非会员推送渠道标志（huawei,xiaomi,vivo,oppo,ali,ios等）
//     */
//    private String channelType;
//    /**
//     * 非会员推送 APP跳转链接
//     */
//    private String jumpValue;

}
