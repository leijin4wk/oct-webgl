package com.oyo.ump.member.dal.model;

import lombok.Data;

import java.util.Date;
/**
 * 会员等级映射实体
* @author frank
* @date 2019-08-02 18:26
**/
@Data
public class MemberGradeMapEntity {
    private Long id;
    private Integer platformId;
    private String platformName;
    private Long platformGrade;
    private Integer oyoGrade;
    private Date createTime;
    private Date updateTime;
    private Integer isDeleted;
}
