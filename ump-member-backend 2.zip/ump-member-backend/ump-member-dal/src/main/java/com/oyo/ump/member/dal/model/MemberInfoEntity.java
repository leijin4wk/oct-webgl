package com.oyo.ump.member.dal.model;

import lombok.Data;

/**
 * @Description: 用户信息entity
 * @Author: fang
 * @create: 2019-03-20
 **/
@Data
public class MemberInfoEntity {
    private Long id;
    private Long userId;
    private String subscriptionCode;
    private String nickName;
    private String phone;
}
