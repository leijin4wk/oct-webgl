package com.oyo.ump.member.dal.dao;

import com.oyo.ump.member.dal.model.PushRuleEntity;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Dong
 * @Classname PushMapper
 * @Description 事件推送圈定规则数据库接口
 * @Date 2019-05-06
 */
@Repository
public interface PushRuleMapper {
    PushRuleEntity selectById(Long id);
    List<PushRuleEntity> selectAll();
    List<PushRuleEntity> selectByEventKey(@Param("eventKey")  String eventKey);

    List <PushRuleEntity> selectByDetail(@Param("eventDetail")  String eventDetail);
    void insert(PushRuleEntity pushRuleEntity);
    void update(@Param("item")PushRuleEntity pushRuleEntity,@Param("rule")  Long rule);

    PushRuleEntity selectPersonasRuleById(Long id);
}
