package com.oyo.ump.member.dal.dao;

import com.oyo.ump.member.dal.model.HotelEntity;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Classname HotelsMapper
 * @Description
 * @Date 2019-03-15 10:03
 * @author Dong
 */
@Repository
public interface HotelMapper {
    /**
     * 获取所有的酒店信息
     * @return java.util.List<com.oyo.ump.member.dal.model.HotelEntity>
     */
    List<HotelEntity> getHotelList();

    /**
     * 查询参与或活动的酒店ID
     * @param hotelIds 酒店ID列表
     * @return java.util.List<java.lang.Integer>
     */
    List<HotelEntity> getSalesHotel(List<Long> hotelIds);

    void insert(Long hotelId, Integer cityId);
}
