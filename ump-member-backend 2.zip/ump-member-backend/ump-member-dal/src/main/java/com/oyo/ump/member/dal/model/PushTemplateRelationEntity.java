package com.oyo.ump.member.dal.model;

import lombok.Data;

import java.io.Serializable;

/**
 * @author Dong
 * @Classname PushTemplateRelationEntity
 * @Description 模板推送关系
 * @Date 2019-08-30
 */
@Data
public class PushTemplateRelationEntity implements Serializable {
    private Long id;
    private Long pushId;
    // 1-短信；2-推送；3-微信
    private Integer triggerChannel;
    private String templateNum;
    private String templateContentParameter;
    private String templateUrlParameter;
    private Long templateUrlId;
    private String templateUtmParameter;
    private Integer percent;
    private String extraParameter;
    //url 参数json串
    private String urlParams;
    //内容参数json串
    private String contentParams;
//    /**
//     * 站内信标题
//     */
//    private String internalMsgTitle;
//    /**
//     * 站内信内容
//     */
//    private String internalMsgContent;
}
