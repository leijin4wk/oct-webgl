package com.oyo.ump.member.dal.dao;

import com.oyo.ump.member.dal.model.PushEventMetaEntity;
import com.oyo.ump.member.dal.model.PushRuleEntity;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Dong
 * @Classname PushEventMetaMapper
 * @Description 实时事件元数据库接口
 * @Date 2019-05-06
 */
@Repository
public interface PushEventMetaMapper {
    /**
     * 查询所有实时事件元数据
     * @param
     * @return java.util.List<com.oyo.ump.member.dal.model.PushEventMetaEntity>
     */
    List<PushEventMetaEntity> selectAll();

}
