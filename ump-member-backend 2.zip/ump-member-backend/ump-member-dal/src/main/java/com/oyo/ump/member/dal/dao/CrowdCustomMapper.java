package com.oyo.ump.member.dal.dao;

import com.oyo.ump.member.dal.model.CrowdCustomEntity;
import com.oyo.ump.member.dal.result.CrowdUsersResult;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author Dong
 * @Classname CrowdCustomMapper
 * @Description
 * @Date 2019-06-06
 */
@Repository
public interface CrowdCustomMapper {
    void insertBatch(List<CrowdCustomEntity> crowdCustomEntityList);
    List<CrowdCustomEntity> selectByCrowdId(@Param("crowdId")Long id);
    void deleteByCrowdId(@Param("crowdId")Long id);
    Long countByCrowdIds(@Param("list") List<Long> list);
    List<Long> findCrowdCustomShard(@Param("list") List<Long> crowdIds,@Param("shard") Long shard,@Param("index") Integer index);
    void insertBatchBO(@Param("crowdId")Long crowdId, @Param("list")List<Long> userIds);
    List<Long> findExistUserId(@Param("id") Long id,@Param("userIds") List<Long> userIds);

    void deleteCrowdCustomByCrowdIdAndUserIds(@Param("id") Long id,@Param("userIds") List<Long> userIds);

    List<CrowdUsersResult> findCrowdUsersPageByCondition(@Param("crowdIds") List<Long> crowdIds,
                                                         @Param("userId") Long  userId  , @Param("start") Integer  start  , @Param("offset") Integer  offset );


    long countCrowdUsersPageByCondition(@Param("crowdIds") List<Long> crowdIds,
    @Param("userId") Long  userId);

    /**
     * 通过自定义sql查询
    * @author leijin
    * @date 2019-11-20 14:31
    **/
    List<Map<String, Object>>  findCrowdCustomBySql(@Param("sql") String sql, @Param("start") Integer start, @Param("pageSize") Integer pageSize);




}
