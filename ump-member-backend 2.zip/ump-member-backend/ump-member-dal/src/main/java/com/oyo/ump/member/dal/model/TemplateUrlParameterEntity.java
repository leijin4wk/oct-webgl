package com.oyo.ump.member.dal.model;

import lombok.Data;

import java.io.Serializable;

/**
 * @author Dong
 * @Classname PushTemplateRelationEntity
 * @Description 模板长链信息
 * @Date 2019-08-30
 */
@Data
public class TemplateUrlParameterEntity implements Serializable {
    private Long id;
    private String urlAddress;
    private String urlName;
    private String urlParameter;
    private Integer urlType;
    private String miniAppId;
    private String miniAppName;
    private String defaultParam;
    private String deeplinkUrl;

}
