package com.oyo.ump.member.dal.model;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.Date;

/**
 * @Description:
 * @Author: fang
 * @create: 2019-11-12
 **/
@Data
public class UmpDataMemberDimRptEntity {

    /**
     * 用户ID
     */
    @JSONField(name = "member_id")
    private Long memberId;

    /**
     * 注册渠道
     */
    @JSONField(name = "channel")
    private String channel;

    /**
     * 注册设备类型
     */
    @JSONField(name = "device_type")
    private String deviceType;

    /**
     * 是否有推荐人
     */
    @JSONField(name = "is_reference")
    private Integer isReference;

    /**
     * 推荐人手机
     */
    @JSONField(name = "refer_phone")
    private String referPhone;

    /**
     * 注册时间
     */
    @JSONField(name = "register_time")
    private Date registerTime;

    /**
     * 手机厂商
     */
    @JSONField(name = "phone_manufacturer")
    private String phoneManufacturer;

    /**
     * 手机型号
     */
    @JSONField(name = "phone_model")
    private String phoneModel;

    /**
     * 手机操作系统
     */
    @JSONField(name = "phone_os")
    private String phoneOs;

    /**
     * 手机注册IP
     */
    @JSONField(name = "phone_ip")
    private String phoneIp;

    /**
     * 使用不同手机数量
     */
    @JSONField(name = "count_unique_imei")
    private Integer countUniqueImei;

    /**
     * 推荐他人数量
     */
    @JSONField(name = "count_referothers")
    private Integer countReferothers;

    /**
     * 历史预定次数
     */
    @JSONField(name = "count_reserve")
    private Integer countReserve;

    /**
     * 历史预定酒店数
     */
    @JSONField(name = "count_reservehotel")
    private Integer countReservehotel;

    /**
     * 活动ID为1的参加活动数
     */
    @JSONField(name = "count_act1")
    private Integer countAct1;

    /**
     * 活动ID为2的参加活动数
     */
    @JSONField(name = "count_act2")
    private Integer countAct2;

    /**
     * 活动ID为6的参加活动数
     */
    @JSONField(name = "count_act6")
    private Integer countAct6;

    /**
     * 活动ID为10的参加活动数
     */
    @JSONField(name = "count_act10")
    private Integer countAct10;

    /**
     * 所有参加活动数
     */
    @JSONField(name = "count_act")
    private Integer countAct;

    /**
     * 优惠券总数量
     */
    @JSONField(name = "count_coupons")
    private Integer countCoupons;

    /**
     * 周中入住次数
     */
    @JSONField(name = "count_checkinweekday")
    private Integer countCheckinweekday;

    /**
     * 周末入住次数
     */
    @JSONField(name = "count_checkinweekends")
    private Integer countCheckinweekends;

    /**
     * 历史入住次数
     */
    @JSONField(name = "count_checkin")
    private Integer countCheckin;

    /**
     * 历史入住酒店
     */
    @JSONField(name = "count_checkinhotel")
    private Integer countCheckinhotel;

    /**
     * 半夜退房数
     */
    @JSONField(name = "count_checkoutmidnight")
    private Integer countCheckoutmidnight;

    /**
     * 历史预订最多酒店ID
     */
    @JSONField(name = "hotel_reservemost")
    private Long hotelReservemost;

    /**
     * 历史预定最多酒店次数
     */
    @JSONField(name = "count_reservemosthotel")
    private Integer countReservemosthotel;

    /**
     * 历史入住城市数
     */
    @JSONField(name = "count_checkincity")
    private Integer countCheckincity;

    /**
     * 历史入住最多酒店ID
     */
    @JSONField(name = "hotel_checkinmost")
    private Long hotelCheckinmost;

    /**
     * 历史入住最多酒店次数
     */
    @JSONField(name = "count_checkinmosthotel")
    private Integer countCheckinmosthotel;

    /**
     * APP下单入住次数
     */
    @JSONField(name = "count_appcheckin")
    private Integer countAppcheckin;

    /**
     * APP下单金额
     */
    @JSONField(name = "amount_appcheckin")
    private Double amountAppcheckin;

    /**
     * minAPP下单入住次数
     */
    @JSONField(name = "count_miniappcheckin")
    private Integer countMiniappcheckin;

    /**
     * minAPP下单金额
     */
    @JSONField(name = "amount_miniappcheckin")
    private Double amountMiniappcheckin;

    /**
     * 历史总订单金额
     */
    @JSONField(name = "amount_checkin")
    private Double amountCheckin;

    /**
     * 历史总实际订单金额
     */
    @JSONField(name = "amount_actualcheckin")
    private Double amountActualcheckin;

    /**
     * 历史总支付金额
     */
    @JSONField(name = "amount_paid")
    private Double amountPaid;

    /**
     * 历史平均每次支付金额
     */
    @JSONField(name = "amount_avgpaid")
    private Double amountAvgpaid;

    /**
     * 优惠券使用次数
     */
    @JSONField(name = "count_couponuse")
    private Integer countCouponuse;

    /**
     * 注册预订同一天
     */
    @JSONField(name = "is_date_diffs")
    private Integer isDateDiffs;

    /**
     * 历史最小提前预定天数
     */
    @JSONField(name = "days_reserveadvance_min")
    private Double daysReserveadvanceMin;

    /**
     * 历史最大提前预定天数
     */
    @JSONField(name = "days_reserveadvance_max")
    private Double daysReserveadvanceMax;

    /**
     * 平均提前预定天数
     */
    @JSONField(name = "days_reserveadvance_avg")
    private Double daysReserveadvanceAvg;

    /**
     * 手机号
     */
    @JSONField(name = "phone")
    private String phone;

    /**
     * 运营商
     */
    @JSONField(name = "operator")
    private String operator;

    /**
     * 手机号归属省份
     */
    @JSONField(name = "phone_prov")
    private String phoneProv;

    /**
     * 手机号归属城市
     */
    @JSONField(name = "phone_city")
    private String phoneCity;

    /**
     * 第一次预订时间
     */
    @JSONField(name = "first_booking_time")
    private Date firstBookingTime;

    /**
     * 最近一次预订时间
     */
    @JSONField(name = "last_booking_time")
    private Date lastBookingTime;

    /**
     * 第一次预订且入住时间
     */
    @JSONField(name = "first_booking_checkin_time")
    private Date firstBookingCheckinTime;

    /**
     * 最近一次预订且入住时间
     */
    @JSONField(name = "last_booking_checkin_time")
    private Date lastBookingCheckinTime;

    /**
     * 历史每月入住数
     */
    @JSONField(name = "count_checkin_bymonth")
    private Integer countCheckinBymonth;

    /**
     * 历史每月入住酒店数
     */
    @JSONField(name = "count_checkinhotel_bymonth")
    private Integer countCheckinhotelBymonth;

    /**
     * 历史每月优惠券使用数
     */
    @JSONField(name = "count_couponuse_bymonth")
    private Integer countCouponuseBymonth;

    /**
     * 历史使用优惠券入住酒店数
     */
    @JSONField(name = "count_activity_hotelcoupon")
    private Integer countActivityHotelcoupon;

    /**
     * 历史活动入住酒店数
     */
    @JSONField(name = "count_activity_hotelacts")
    private Integer countActivityHotelacts;

    /**
     * 推荐人与被推荐人入住相同酒店的酒店数
     */
    @JSONField(name = "counts_samehotel")
    private Integer countsSamehotel;

    /**
     * 与推荐人入住过相同酒店的被推荐人数
     */
    @JSONField(name = "counts_referuserforhotel")
    private Integer countsReferuserforhotel;

    /**
     * 入住时长过短次数（小于1小时）
     */
    @JSONField(name = "count_shorttime")
    private Integer countShorttime;

    /**
     * 各优惠券类型总数量
     */
    @JSONField(name = "count_meta_coupons")
    private Integer countMetaCoupons;

    /**
     * 所有优惠券总金额
     */
    @JSONField(name = "amount_allcoupons")
    private Double amountAllcoupons;

    /**
     * 已使用核销优惠券总金额
     */
    @JSONField(name = "amount_usecoupons")
    private Double amountUsecoupons;

    /**
     * 已使用核销优惠券的类别数量
     */
    @JSONField(name = "count_meta_usecoupons")
    private Integer countMetaUsecoupons;

    /**
     * 已使用优惠券总数量
     */
    @JSONField(name = "count_usecoupons")
    private Integer countUsecoupons;

    /**
     * 各类优惠券中用掉最多的数量
     */
    @JSONField(name = "count_couponusemax")
    private Integer countCouponusemax;

    /**
     * 各类优惠券中用掉最多的金额
     */
    @JSONField(name = "amount_couponusemax")
    private Double amountCouponusemax;

    /**
     * 各类优惠券中获取最多的数量
     */
    @JSONField(name = "count_couponmax")
    private Integer countCouponmax;

    /**
     * 各类优惠券中获取最多的金额
     */
    @JSONField(name = "amount_couponmax")
    private Double amountCouponmax;

    /**
     * 用户账户ID 对应神策
     */
    @JSONField(name = "distinct_id")
    private String distinctId;

    /**
     * 用户偏好城市列表
     */
    @JSONField(name = "perfer_citys")
    private String perferCitys;

    /**
     * 是否oyo员工
     */
    @JSONField(name = "is_oyo_corporate")
    private Integer isOyoCorporate;

    /**
     * 是否绑定微信
     */
    @JSONField(name = "wechant_user_flag")
    private Integer wechantUserFlag;

    /**
     * 是否绑定支付宝
     */
    @JSONField(name = "alipay_user_flag")
    private Integer alipayUserFlag;

    /**
     * 用户微信最后登陆时间
     */
    @JSONField(name = "wechat_last_login_time")
    private Date wechatLastLoginTime;

    /**
     * 用户支付宝最后登陆时间
     */
    @JSONField(name = "alipay_last_login_time")
    private Date alipayLastLoginTime;

    /**
     * 三方绑定状态有效性
     */
    @JSONField(name = "auth_status")
    private String authStatus;

    /**
     * Alimp下单入住次数
     */
    @JSONField(name = "count_alimpcheckin")
    private Integer countAlimpcheckin;

    /**
     * Alimp下单金额
     */
    @JSONField(name = "amount_alimpcheckin")
    private Double amountAlimpcheckin;

    /**
     * 首次APP登陆
     */
    @JSONField(name = "first_app_time")
    private Date firstAppTime;

    /**
     * 最近次APP登陆
     */
    @JSONField(name = "last_app_time")
    private Date lastAppTime;

    /**
     * 首次miniApp登陆
     */
    @JSONField(name = "first_mp_time")
    private Date firstMpTime;

    /**
     * 最近次miniApp登陆
     */
    @JSONField(name = "last_mp_time")
    private Date lastMpTime;

    /**
     * 首次alimp登陆
     */
    @JSONField(name = "first_alimp_time")
    private Date firstAlimpTime;

    /**
     * 最近次alimp登陆
     */
    @JSONField(name = "last_alimp_time")
    private Date lastAlimpTime;

    /**
     * 首次web登陆
     */
    @JSONField(name = "first_web_time")
    private Date firstWebTime;

    /**
     * 最近次web登陆
     */
    @JSONField(name = "last_web_time")
    private Date lastWebTime;

    /**
     * 近一个月有正常登陆的天数
     */
    @JSONField(name = "date_count_1madvance")
    private Integer dateCount1madvance;

    /**
     * 近7天有正常登陆的天数
     */
    @JSONField(name = "date_count_7dadvance")
    private Integer dateCount7dadvance;

    /**
     * 历史有正常登陆的天数
     */
    @JSONField(name = "date_count_advance")
    private Integer dateCountAdvance;

    /**
     * 使用优惠券入住时间小于1小时的次数
     */
    @JSONField(name = "count_coupon_shorttime")
    private Integer countCouponShorttime;

    /**
     * 使用优惠券的时间在半夜的次数(24-4点)
     */
    @JSONField(name = "count_coupon_midnight")
    private Integer countCouponMidnight;

    /**
     * 使用优惠券后半小时内入住的次数
     */
    @JSONField(name = "count_coupon_shortbookcheckin")
    private Integer countCouponShortbookcheckin;

    /**
     * 最后一次登陆行为时间
     */
    @JSONField(name = "last_action_time")
    private Date lastActionTime;

    /**
     * 推送接收次数
     */
    @JSONField(name = "receive_stat")
    private Integer receiveStat;

    /**
     * 推送打开次数
     */
    @JSONField(name = "opened_stat")
    private Integer openedStat;

    /**
     * 是否可以接收推送通知
     */
    @JSONField(name = "is_push_flag")
    private Integer isPushFlag;

    /**
     * 用户行为最近30天是否活跃
     */
    @JSONField(name = "is_active_in_latest_month")
    private Integer isActiveInLatestMonth;

    /**
     * 用户未收到推送次数大于3次,0 否 1 是
     */
    @JSONField(name = "is_recevied_push")
    private Integer isReceviedPush;

    /**
     * 用户最近3条推送记录是否全部未收到,0 否 1 是
     */
    @JSONField(name = "is_recevie")
    private Integer isRecevie;

    /**
     * 用户是否删除app，根据最近30天没有app活动，且收到推送次数小于3,且满足最近3条推送记录都是未接收状态
     */
    @JSONField(name = "is_delete_app")
    private Integer isDeleteApp;

    /**
     * 是否既是微信公众号粉丝又是oyo会员 0否1是
     */
    @JSONField(name = "is_oyo_wechat_fans")
    private Integer isOyoWechatFans;

    /**
     * 用户微信的union_id
     */
    @JSONField(name = "wechat_unionid")
    private String wechatUnionid;

    /**
     * 最近活动 3:30天以上,2:7-30天,1:1-7 天有活动,0:代表卸载用户
     */
    @JSONField(name = "recency")
    private Integer recency;

    /**
     * 交易频率 3:代表 无交易,2:代表1次交易,1:代表 多余1次交易
     */
    @JSONField(name = "frequency")
    private Integer frequency;

    /**
     * 价格敏感度 0 较敏感，1中等敏感，2 不甚敏感
     */
    @JSONField(name = "susceptibility")
    private Integer susceptibility;

    /**
     * 用户接收价格均值
     */
    @JSONField(name = "auvp")
    private Double auvp;

    /**
     * 用户接收价格波动范围
     */
    @JSONField(name = "suvp")
    private Double suvp;

    /**
     * 短信推送是否退订 0 否 1是
     */
    @JSONField(name = "sms_enable")
    private Integer smsEnable;

    /**
     * 用户常驻城市名称
     */
    @JSONField(name = "live_city")
    private String liveCity;

    /**
     * 用户常驻城市名称_印度逻辑
     */
    @JSONField(name = "base_city")
    private String baseCity;

    /**
     * 用户积分
     */
    @JSONField(name = "total_points")
    private Double totalPoints;

    /**
     * 用户积分最早过期时间字符串
     */
    @JSONField(name = "expire")
    private Date expire;

    /**
     * 用户当前等级ID
     */
    @JSONField(name = "current_grade_id")
    private Integer currentGradeId;

    /**
     * 用户当前等级名称
     */
    @JSONField(name = "current_grade_name")
    private String currentGradeName;

    /**
     * 用户下一等级ID
     */
    @JSONField(name = "next_grade_id")
    private Integer nextGradeId;

    /**
     * 用户下一等级名称
     */
    @JSONField(name = "next_grade_name")
    private String nextGradeName;

    /**
     * 用户升级到下一级所需的房晚数
     */
    @JSONField(name = "urn_next_level")
    private Integer urnNextLevel;

    /**
     * 推荐城市ID
     */
    @JSONField(name = "perfer_city_id")
    private Integer perferCityId;

    /**
     * 居住城市ID
     */
    @JSONField(name = "live_city_id")
    private Integer liveCityId;

    /**
     * base城市ID
     */
    @JSONField(name = "base_city_id")
    private Integer baseCityId;

    /**
     * 0 否1是，手机号是否合法
     */
    @JSONField(name = "valid_phone")
    private Integer validPhone;

    /**
     * 记录更新时间
     */
    @JSONField(name = "update_time")
    private Date updateTime;
}
