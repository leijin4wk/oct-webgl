package com.oyo.ump.member.dal.config;


import lombok.Data;

/**
 * @author Dong
 * @Classname DruidAdbBase
 * @Description ADB连接属性
 * @Date 2019-06-10
 */
@Data
public class DruidAdbBase {

    /**
     * JDBC url
     */
    private String url;

    /**
     * 用户名
     */
    private String username;

    /**
     * 密码
     */
    private String password;

    /**
     * 驱动类
     */
    private String driverClass;

    /**
     * 初始化连接大小
     */
    private Integer initialSize;

    /**
     * 最小连接池数量
     */
    private Integer minIdle;

    /**
     * 最大连接池数量
     */
    private Integer maxActive;

    /**
     * 必填，记录一个连接使用次数，达到次数连接会被释放
     */
    private Integer phyMaxUseCount;

    /**
     * 获取连接时最大等待时间，单位毫秒
     */
    private Integer maxWait;

    /**
     * 间隔多久检测需要关闭的空闲连接，单位是毫秒
     */
    private Integer timeBetweenEvictionRunsMillis;

    /**
     * 一个连接在池中最小生存的时间，单位是毫秒
     */
    private Integer minEvictableIdleTimeMillis;

    /**
     * 是否保持连接活动
     */
    private Boolean keepAlive;

    /**
     * 用来验证数据库连接的查询语句，查询语句必须是至少返回一条数据的SELECT语句
     */
    private String validationQuery;

    /**
     * 申请连接的时候检测，如果空闲时间大于timeBetweenEvictionRunsMillis，执行validationQuery检测连接是否有效
     */
    private Boolean testWhileIdle;

}
