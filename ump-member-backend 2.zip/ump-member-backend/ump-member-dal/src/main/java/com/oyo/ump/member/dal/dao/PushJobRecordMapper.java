package com.oyo.ump.member.dal.dao;

import com.oyo.ump.member.dal.model.PushJobRecordEntity;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface PushJobRecordMapper {

   // PushJobRecordEntity findPushJobRecord(@Param("pushId") Long pushId, @Param("sendType")Integer sendType,@Param("sendStatus") Integer sendStatus);

//    void insertPushJobRecordEntity(PushJobRecordEntity pushJobRecordEntity);
//
//    void updatePushJobRecordEntity(@Param("id")Long id,@Param("status")Integer status,@Param("resultMessage")String resultMessage);
//
//    PushJobRecordEntity findCyclePushJobRecord(@Param("pushId") Long pushId);

  //  List<PushJobRecordEntity> findExceptionJob();

//    List<PushJobRecordEntity> findByPushId(@Param("memberPushId")Long memberPushId);

  //  void deletePushJobRecordById(@Param("id") Long id);

    void insert(PushJobRecordEntity pushJobRecordEntity);


    void insertList(@Param("list") List<PushJobRecordEntity> list);


    void updateStatus(@Param("id")Long id,@Param("status")Integer status);


    void deleteNotSendByPushId(@Param("pushId")Long pushId);


    List<PushJobRecordEntity> findByPushIdAndStatus(@Param("pushId")Long pushId,@Param("status")Integer status);


    List<PushJobRecordEntity> findByPushId(@Param("pushId")Long pushId);

    List<PushJobRecordEntity> findByTimeInterval(@Param("startTime") Date startTime,@Param("endTime") Date endTime);

    List<PushJobRecordEntity> findTimeOut();



}

