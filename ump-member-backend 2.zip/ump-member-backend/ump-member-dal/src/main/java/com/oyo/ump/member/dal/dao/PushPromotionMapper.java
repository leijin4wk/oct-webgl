package com.oyo.ump.member.dal.dao;

import com.oyo.ump.member.dal.model.PushPromotionEntity;
import com.oyo.ump.member.dal.model.PushRuleEntity;
import org.springframework.stereotype.Repository;

/**
 * @author Dong
 * @Classname PushMapper
 * @Description 事件推送圈定规则数据库接口
 * @Date 2019-05-06
 */
@Repository
public interface PushPromotionMapper {
    PushPromotionEntity selectByCondition(PushPromotionEntity pushPromotionEntity);
    void insert(PushPromotionEntity pushPromotionEntity);
}
