package com.oyo.ump.member.dal.dao;

import com.oyo.ump.member.dal.model.UpgradePackageEntity;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Classname UpgradePackageMapper
 * @Description 升级包数据库访问接口
 * @Date 2019-03-14 14:08
 * @author Dong
 */

@Repository
public interface UpgradePackageMapper {
    /**
     * 获取所有的升级包列表
     * @return java.util.List<com.oyo.ump.member.dal.model.UpgradePackageEntity>
     */
    List<UpgradePackageEntity> getUpgradePackageList();

    /**
     * 根据会员等级获取可购买的升级包列表
     * @param gradeId 会员等级id
     * @return java.util.List<com.oyo.ump.member.dal.model.UpgradePackageEntity>
     */
    List<UpgradePackageEntity> getUpgradePackageListByGradeId(Integer gradeId);

    /**
     * 根据升级包skuCode获取升级包信息
     * @param skuCode  升级包id
     * @return com.oyo.ump.member.dal.model.UpgradePackageEntity
     */
    UpgradePackageEntity getUpgradePackageByCode(String skuCode);





    /**
     * 更新升级包信息
     * @param record 升级包实体类对象
     * @return int
     */
    int updateUpgradePackage(UpgradePackageEntity record);

}
