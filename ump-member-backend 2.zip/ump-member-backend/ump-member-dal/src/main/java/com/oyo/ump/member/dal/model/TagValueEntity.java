package com.oyo.ump.member.dal.model;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author Dong
 * @Classname TagValueEntity
 * @Description ADB中标签枚举值
 * @Date 2019-06-04
 */
@Data
public class TagValueEntity implements Serializable {
    private Long memberId;
    private  String channel;
}
