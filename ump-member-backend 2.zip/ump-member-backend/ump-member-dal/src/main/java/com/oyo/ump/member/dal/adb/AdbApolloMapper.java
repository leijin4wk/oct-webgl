package com.oyo.ump.member.dal.adb;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Description: adb 通过邮箱查询阿波罗用户userId
 * @Author: fang
 * @create: 2019-09-05
 **/
@Repository
public interface AdbApolloMapper {
    /**
     * 通过邮箱查询阿波罗用户userId
     * @param emails
     * @return java.util.List<java.lang.Long>
     */
   List<Long> getUserIdsByEmails(@Param("emails") List<String> emails);


}
