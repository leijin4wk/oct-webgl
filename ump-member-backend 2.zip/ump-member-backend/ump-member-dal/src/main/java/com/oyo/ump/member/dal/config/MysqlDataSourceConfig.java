package com.oyo.ump.member.dal.config;

import com.github.pagehelper.PageHelper;
import com.oyo.ump.member.dal.utils.DataSourceUtils;
import com.oyo.ump.member.dal.utils.MybatisUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import top.rdfa.framework.monitor.cat.mybatis.CatMybatisPlugin;

import javax.sql.DataSource;

/**
 * @author zhangjianjun
 * @date 2018年7月6日
 */
@Slf4j
@Configuration
@EnableConfigurationProperties(DruidMysql.class)
@MapperScan(basePackages = "com.oyo.ump.member.dal.dao", sqlSessionFactoryRef = "mysqlSqlSessionFactory")
@EnableTransactionManagement
public class MysqlDataSourceConfig {

    private static final String MAPPER_MYSQL_XML_PATH = "classpath*:/mapper/*Mapper.xml";
    @Autowired
    private DruidMysql druidMysql;

    @Bean(name = "mysqlDataSource")
    public DataSource mysqlDataSource() {
        log.info("init mysql datasouce");
        DataSource dataSource = DataSourceUtils.getDataSource(druidMysql);
        return dataSource;
    }

    @Bean(name = "mysqlSqlSessionFactory")
    public SqlSessionFactory mysqlSqlSessionFactory() {
        SqlSessionFactoryBean bean = new SqlSessionFactoryBean();
        bean.setDataSource(mysqlDataSource());

        //添加插件
        PageHelper pageHelper = MybatisUtils.getPageHelper();
        bean.setPlugins(new Interceptor[]{new CatMybatisPlugin()});

        //添加XML目录
        ResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        try {
            bean.setMapperLocations(resolver.getResources(MAPPER_MYSQL_XML_PATH));
            return bean.getObject();
        } catch (Exception e) {
            log.error("build mysql SqlSessionFactory has error !");
            throw new RuntimeException(e);
        }
    }

    //配置事务管理器
    @Bean(name = "mysqlTransactionManager")
    public DataSourceTransactionManager mysqlTransactionManager() {
        return new DataSourceTransactionManager(mysqlDataSource());
    }

    //配置模板
    @Bean(name = "mysqlSqlSessionTemplate")
    public SqlSessionTemplate mysqlSqlSessionTemplate(@Qualifier("mysqlSqlSessionFactory") SqlSessionFactory sqlSessionFactory) {
        return new SqlSessionTemplate(sqlSessionFactory);
    }

    @Bean(name = "mysqlJdbcTemplate")
    public JdbcTemplate jdbcTemplate(@Qualifier("mysqlDataSource") DataSource dataSource){
        return new JdbcTemplate(dataSource);
    }
}
