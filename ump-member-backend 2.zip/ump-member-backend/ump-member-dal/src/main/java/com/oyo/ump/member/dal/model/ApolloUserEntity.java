package com.oyo.ump.member.dal.model;

import lombok.Data;

/**
 * @Description: 阿波罗用户的实体
 * @Author: fang
 * @create: 2019-09-05
 **/
@Data
public class ApolloUserEntity {
    private Long userId;
    private String email;
}
