package com.oyo.ump.member.dal.model;

import lombok.Data;

/**
 * @Description: todo
 * @Author: fang
 * @create: 2019-09-05
 **/
@Data
public class UserEventEntity {
    private String event;
    private String dt;
    private String time;
    private String networkType;
    private String manufacturer;
    private String os;
    private String appVersion;
    private String platform;
    private String ip;
    private String city;
    private String hotelId;
    private String hotelName;
    private String roomType;
    private String searchType;
    private String keyword;
    private String checkinDate;
    private String checkoutDate;
    private String nightCount;
    private String maxPrice;
    private String minPrice;
}
