package com.oyo.ump.member.dal.model;

import lombok.Data;

import java.util.Date;

/**
 * @Description:
 * @Author: fang
 * @create: 2019-09-06
 **/
@Data
public class UserTradeEntity {
    private Long id;
    private String orderSn;
    private String bookingSn;
    private Long hotelId;
    private String hotelName;
    private Date orderTime;
    private Date payTime;
    private Date checkinTime;
    private Date checkoutTime;
    private Double actualAmount;
    private Double amount;
    private String terminal;
    private Integer status;
    private Double discountMoney;

}
