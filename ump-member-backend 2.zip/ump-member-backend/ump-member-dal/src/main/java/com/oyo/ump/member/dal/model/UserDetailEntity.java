package com.oyo.ump.member.dal.model;

import lombok.Data;

import java.util.Date;

/**
 * @Description:
 * @Author: fang
 * @create: 2019-09-07
 **/
@Data
public class UserDetailEntity {
    private Long memberId;
    private String registerTime;
    private String firstAppTime;
    private String lastAppTime;
    private String dateCountAdvance;
}
