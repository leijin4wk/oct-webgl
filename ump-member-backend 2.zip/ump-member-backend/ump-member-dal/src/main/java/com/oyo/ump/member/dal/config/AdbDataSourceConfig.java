package com.oyo.ump.member.dal.config;

import com.alibaba.druid.pool.DruidDataSource;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import top.rdfa.framework.datasource.DataSourceContextHolder;
import top.rdfa.framework.datasource.DatasourceManager;
import top.rdfa.framework.datasource.DynamicDatasource;
import top.rdfa.framework.datasource.NacosGlobalDsContextHolder;

import javax.sql.DataSource;

/**
 * @author Dong
 * @Classname AdbDataSourceConfig
 * @Description ADB连接配置
 * @Date 2019-06-10
 */
@Slf4j
@Configuration
@MapperScan(basePackages = "com.oyo.ump.member.dal.adb", sqlSessionFactoryRef = "adbDynamicDsSqlSessionFactory")
public class AdbDataSourceConfig {

    private static final String MAPPER_ADB_XML_PATH = "classpath*:/mapper/adb/*Mapper.xml";

    @Bean(name = "adbMasterDataSource", initMethod = "init", destroyMethod = "close")
    @ConfigurationProperties(prefix = "rdfa.adb.datasource.master")
    public DruidDataSource masterDruidDataSource() {
        log.info("init adb master datasouce");
        DruidDataSource dataSource = new DruidDataSource();
        // 注册主数据源，且主数据源为默认数据源
        DatasourceManager.registerDatasource("master", dataSource, true);
        return dataSource;
    }

    @Bean(name = "adbSlaveDataSource", initMethod = "init", destroyMethod = "close")
    @ConfigurationProperties(prefix = "rdfa.adb.datasource.slave")
    public DruidDataSource slaveDruidDataSource() {
        log.info("init adb slave datasouce");
        DruidDataSource dataSource = new DruidDataSource();
        // 注册从数据源
        DatasourceManager.registerDatasource("slave",dataSource);
        return dataSource;
    }

    @Bean(name = "nacosGlobalDsContextHolder", initMethod = "init")
    @ConfigurationProperties(prefix = "rdfa.dynamic.ds.holder.nacos")
    @DependsOn({"adbMasterDataSource","adbSlaveDataSource"})
    public NacosGlobalDsContextHolder nacosGlobalDsContextHolder(){
        //启动nacos监听数据源切换动作
        return new NacosGlobalDsContextHolder(DatasourceManager.getDefaultDatasource());
    }

    @Bean(name = "adbDynamicDatasource")
    @DependsOn("nacosGlobalDsContextHolder")
    public DynamicDatasource dynamicDatasource(@Qualifier("nacosGlobalDsContextHolder") DataSourceContextHolder dataSourceContextHolder){
        DynamicDatasource dynamicDatasource = new DynamicDatasource(dataSourceContextHolder);
        dynamicDatasource.setTargetDataSources(DatasourceManager.getAllDataSource());
        return dynamicDatasource;
    }

    @Bean(name = "adbDynamicDsSqlSessionFactory")
    @DependsOn("adbDynamicDatasource")
    public SqlSessionFactory sqlSessionFactory(@Qualifier("adbDynamicDatasource") DynamicDatasource datasource) throws Exception {
        SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
        // 设置数据源
        factoryBean.setDataSource(datasource);
        // 添加mapper.xml扫描路径。注：如果是基于@Mapper注解方式，可不用写该段代码
        PathMatchingResourcePatternResolver pathMatchingResourcePatternResolver = new PathMatchingResourcePatternResolver();
        factoryBean.setMapperLocations(pathMatchingResourcePatternResolver.getResources(MAPPER_ADB_XML_PATH));
        return factoryBean.getObject();
    }

    @Bean(name = "adbSqlSessionTemplate")
    public SqlSessionTemplate adbSqlSessionTemplate(@Qualifier("adbDynamicDsSqlSessionFactory") SqlSessionFactory sqlSessionFactory) {
        return new SqlSessionTemplate(sqlSessionFactory);
    }
    @Bean(name = "adbJdbcTemplate")
    public JdbcTemplate jdbcTemplate(@Qualifier("adbDynamicDatasource") DynamicDatasource dynamicDatasource){
        return new JdbcTemplate(dynamicDatasource);
    }
    @Bean(name="adbNamedParameterJdbcTemplate")
    public NamedParameterJdbcTemplate adbNamedParameterJdbcTemplate(@Qualifier("adbDynamicDatasource") DataSource dataSource) {
        return new NamedParameterJdbcTemplate(dataSource);
    }

}
