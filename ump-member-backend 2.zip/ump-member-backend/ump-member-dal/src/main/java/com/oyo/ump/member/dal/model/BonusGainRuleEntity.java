package com.oyo.ump.member.dal.model;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @Classname BonusGainRuleEntity
 * @Description 积分获取规则实体类
 * @Date 2019-03-15 21:52
 * @author Dong
 */
@Data
public class BonusGainRuleEntity implements Serializable {
    private Integer id;
    /**
     * 积分项目（1 消费积分，2 奖励积分，3 活动积分， 4 多倍积分， 5 签到积分）
     */
    private String bonusType;
    /**
     * 各项规则的总开关；0 关，1 开
     */
    private Integer status;
    /**
     * 积分获取开关；0 关，1 开
     */
    private Integer gainFlag;
    /**
     * 积分消耗开关；0 关，1 开
     */
    private Integer costFlag;
    /**
     * 初始积分
     */
    private Integer initalValue;
    /**
     * 积分下限
     */
    private Integer limitValue;
    /**
     * 支持多开标识；0 不支持，1 支持
     */
    private Integer multipleFlag;
    /**
     * 有效期（日本租户在使用这个字段）
     */
    private Date validPeriod;

    private String strValidPeriod;
    /**
     * 有效期（支持多种类型）
     */
    private String validPeriodJson;

    /**
     * 各方承担比例配置
     */
    private String comissionConfig;
    /**
     * 是否删除 0:否，1 是
     */
    private Integer isDeleted;

    private String tenant;
}
