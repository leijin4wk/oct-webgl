package com.oyo.ump.member.dal.result;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class CrowdUsersResult implements Serializable {
    private  Long  userId;

    private String crowdIds;

    private Date createTime;
}
