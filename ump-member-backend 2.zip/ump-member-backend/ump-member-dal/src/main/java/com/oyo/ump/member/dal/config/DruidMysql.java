package com.oyo.ump.member.dal.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * @author zhangjianjun
 * @date 2018年7月6日
 * 映射mysql相关配置
 */
@ConfigurationProperties(prefix = "druid.mysql")
public class DruidMysql extends BaseDruid {


}
