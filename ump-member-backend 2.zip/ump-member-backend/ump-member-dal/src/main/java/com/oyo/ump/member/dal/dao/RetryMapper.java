package com.oyo.ump.member.dal.dao;

import com.oyo.ump.member.dal.model.MemberRetryEntity;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Description: 重试mapper
 * @Author: fang
 * @create: 2019-12-17
 **/
@Repository
public interface RetryMapper {
    /**
     * 插入一条记录
     * @param entity
     */
    void insert (MemberRetryEntity entity);

    /**
     * 获取需要补偿的
     * @return
     */
    List<MemberRetryEntity> getAll(Integer start,Integer num);

    /**
     * 更新
     * @param entity
     */
    void update(MemberRetryEntity entity);
}
