package com.oyo.ump.member.dal.model;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author Dong
 * @Description
 * @Date 2019-12-31
 */
@Data
public class PushPromotionEntity implements Serializable {
    private static final long serialVersionUID = 7936151879922902317L;
    private Long id;
    private String promotionType;
    private String promotionId;
    private String startTime;
    private Long pushId;
    private Long crowdId;
    private Date createTime;
}
