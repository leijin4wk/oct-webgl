package com.oyo.ump.member.dal.config;

import lombok.Data;

/**
 * @author zhangjianjun
 * @date 2018年7月6日
 * 用于映射properties文件中druid的配置数据
 */
@Data
public class BaseDruid {

    private String url;

    private String userName;

    private String password;

    private String driverClass;

    private Integer maxActive;

    private Integer minIdle;

    private Integer initialSize;

    private Boolean testOnBorrow;
}
