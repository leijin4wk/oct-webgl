package com.oyo.ump.member.dal.dao;

import com.oyo.ump.member.dal.model.TemplateParameterEntity;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Description 事件推送模板参数信息
* @author dong
* @date 2019-09-05 12:03
**/
@Repository
public interface TemplateParameterMapper {
    /**
     * 根据参数类型、参数来源 查询参数信息
     * @param parameterName
     * @return java.util.List<com.oyo.ump.member.dal.model.TemplateParameterEntity>
     */
    List<TemplateParameterEntity> getAllParameterByType(@Param("parameterName") String parameterName, @Param("source") Integer source);

    TemplateParameterEntity getParameterById(Long id);

    List<TemplateParameterEntity> selectByIds(@Param("ids") List<Long> ids);

}
