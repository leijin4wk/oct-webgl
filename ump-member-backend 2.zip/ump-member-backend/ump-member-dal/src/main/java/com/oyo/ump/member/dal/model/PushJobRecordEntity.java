package com.oyo.ump.member.dal.model;

import lombok.Data;

import java.util.Date;

/**
 * push定时任务执行记录
* @author frank
* @date 2019-06-12 18:19
**/
@Data
public class PushJobRecordEntity {

    private Long id;

    private Long memberPushId;

    private Date createTime;

    private Date updateTime;

    private Date sendTime;

    private Integer sendType;

    private Integer sendStatus;

    private String resultMessage;

}
