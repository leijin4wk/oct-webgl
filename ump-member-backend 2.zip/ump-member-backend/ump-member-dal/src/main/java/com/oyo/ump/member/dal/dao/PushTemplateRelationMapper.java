package com.oyo.ump.member.dal.dao;

import com.oyo.ump.member.dal.model.PushTemplateRelationEntity;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Dong
 * @Classname PushTemplateRelationMapper
 * @Description
 * @Date 2019-08-30
 */
@Repository
public interface PushTemplateRelationMapper {

    void insertRelation(PushTemplateRelationEntity pushTemplateRelationEntity);

    /**
     * 根据pushId删除模板推送关系
     * @param pushId
     * @return void
     */
    void deleteRelationByPushId(@Param("pushId")Long pushId);

    List<PushTemplateRelationEntity> getRelationsByPushId(@Param("pushId")Long pushId);
}
