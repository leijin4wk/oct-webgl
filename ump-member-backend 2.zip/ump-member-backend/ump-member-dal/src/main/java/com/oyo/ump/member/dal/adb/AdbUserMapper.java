package com.oyo.ump.member.dal.adb;

import com.oyo.ump.member.dal.model.UserDetailEntity;
import com.oyo.ump.member.dal.model.UserEventEntity;
import com.oyo.ump.member.dal.model.UserTradeEntity;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Description: adb 用户信息查询
 * @Author: fang
 * @create: 2019-09-05
 **/
@Repository
public interface AdbUserMapper {
    /**
     * 获取用户时间范围内行为数据
     * @param distinctId
     * @param startTime
     * @param endTime
     * @return
     */
   List<UserEventEntity> queryUserEvent(@Param("distinctId") String distinctId, @Param("startTime") String startTime, @Param("endTime") String endTime);

    /**
     * 获取用户distinctId
     * @param memberId
     * @return
     */
   String getDistinctIdByUserId(@Param("memberId") Long memberId );

    /**
     * 获取用户交易信息
     * @param memberId
     * @param startTime
     * @param endTime
     * @return
     */
   List<UserTradeEntity> getUserTradeInfo(@Param("memberId") Long memberId, @Param("startTime") String startTime, @Param("endTime") String endTime);

    /**
     * 获取用户详情
     * @param userIds
     * @return
     */
   List<UserDetailEntity> getUserDetailList(@Param("userIds") List<Long> userIds);


}
