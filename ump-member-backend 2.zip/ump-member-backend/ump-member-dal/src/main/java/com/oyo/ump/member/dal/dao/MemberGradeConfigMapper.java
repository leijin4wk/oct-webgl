package com.oyo.ump.member.dal.dao;

import com.oyo.ump.member.dal.model.MemberGradeConfigEntity;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MemberGradeConfigMapper {
    /**
     * 查找所有在使用的等级信息
     * @return
     */
    List<MemberGradeConfigEntity> queryAll();

    /**
     * 根据gradeOrd 查等级信息
     * @return
     */
    MemberGradeConfigEntity getMemberGradeConfigByGradeOrd(Integer gradeOrd);
    /**
     * 根据等级id获取等级信息
    * @author leijin
    * @date 2019-08-12 11:01
    **/
    MemberGradeConfigEntity getMemberGradeConfigById(@Param("id") Integer id);


}
