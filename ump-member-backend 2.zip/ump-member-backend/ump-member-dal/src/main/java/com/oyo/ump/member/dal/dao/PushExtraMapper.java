package com.oyo.ump.member.dal.dao;

import com.oyo.ump.member.dal.model.PushExtraEntity;
import org.springframework.stereotype.Repository;

/**
 * @author Dong
 * @Classname CrowdCustomMapper
 * @Description
 * @Date 2019-06-06
 */
@Repository
public interface PushExtraMapper {
    void insert(PushExtraEntity pushExtraEntity);
    PushExtraEntity selectByPushId(Long pushId);
    void deleteByPushId(Long pushId);
}
