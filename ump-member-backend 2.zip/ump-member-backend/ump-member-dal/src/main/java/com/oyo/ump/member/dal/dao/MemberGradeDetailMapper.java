package com.oyo.ump.member.dal.dao;

import com.oyo.ump.member.dal.model.MemberGradeDetailEntity;
import org.springframework.stereotype.Repository;


/**
 * @Description:会员等级变化历史信息
 * @Author: dong
 * @create: 2019-03-29
 **/
@Repository
public interface MemberGradeDetailMapper {
    /**
     * 添加会员等级变更记录
     * @param memberGradeDetailEntity
     * @return void
     */
    void addMemberGradeDetail(MemberGradeDetailEntity memberGradeDetailEntity);

}
