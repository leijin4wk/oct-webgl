package com.oyo.ump.member.dal.dao;

import com.oyo.ump.member.common.test.TestApplication;
import com.oyo.ump.member.dal.model.PushMessageEntity;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.assertj.core.util.Lists;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @Author hubin
 * @Description:
 * @Date 2019/9/24
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class PushMessageMapperTest {
    @Autowired
    PushMessageMapper pushMessageMapper;

    private List<PushMessageEntity> messageEntities = Lists.newArrayList();

    @Before
    public void setUp() {
        PushMessageEntity entity = new PushMessageEntity();
        for (int i = 0; i < 100; i++) {
            entity.setMemberId(20000000L + i);
            entity.setMemberPushId(10L);
            entity.setBatchNo("P200000000");
            entity.setUniformTemplateId("T201909192301139422");
            entity.setStatus(1);
            entity.setPushJobRecordId(200L);
            entity.setIsDeleted(false);
            entity.setMessageDetail(null);
            messageEntities.add(entity);
        }
    }

    @Test
    @Transactional
    public void insertPushMessageEntityList() {
        log.info("entity size: {}", CollectionUtils.size(messageEntities));
        int round = 100;
        long sum = 0;
        for (int i = 0; i < round; ++i) {
            long start = System.currentTimeMillis();
            pushMessageMapper.insertPushMessageEntityList(messageEntities);
            long end = System.currentTimeMillis() - start;
            sum += end;
            log.info("insert finish, cost time: {} ms", end);
        }
        log.warn("avg cost time: {} ms", sum / round);
    }
}