package com.oyo.ump.member.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.oyo.ump.member.common.test.TestApplication;
import com.oyo.ump.member.service.CustomizedEventService;
import com.oyo.ump.member.service.PushRuleService;
import com.oyo.ump.member.service.bo.PushRuleBO;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @Author hubin
 * @Description:
 * @Date 2019/9/10
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class CustomizedEventServiceImplTest {
    @Autowired
    CustomizedEventService customizedEventService;

    @Autowired
    PushRuleService pushRuleService;

    @Autowired
    @Qualifier("adbJdbcTemplate")
    JdbcTemplate jdbcTemplate;

    @Test
    public void getSqlSegmentByConfig() {
        PushRuleBO pushRuleBO = pushRuleService.selectById(77L);
        log.info("push info: {}", JSON.toJSONString(pushRuleBO));
        JSONArray config = JSON.parseArray(pushRuleBO.getRuleDetail());
       // String sql = customizedEventService.getSqlSegmentByConfig(config);
       // log.info("get sql:\n {}", sql);
//        List<Map<String, Object>> list = jdbcTemplate.queryForList(sql);
//        log.info("get result:\n {}", JSON.toJSONString(list));
    }
}
