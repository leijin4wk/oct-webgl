package com.oyo.ump.member.service;

import com.alibaba.fastjson.JSON;
import com.oyo.ump.member.common.test.TestApplication;
import com.oyo.ump.member.service.dto.BonusGainRuleDTO;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author Dong
 * @Classname BonusGainRuleServiceTest
 * @Description 积分获取规则的测试
 * @Date 2019-04-20
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class BonusGainRuleServiceTest {
    @Autowired
    BonusGainRuleService bonusGainRuleService;

    @Test
    public void getGainRuleList(){
        BonusGainRuleDTO bonusGainRuleDTO = bonusGainRuleService.getGainRuleList();
        log.info("bonusGainRuleDTO: {}", JSON.toJSONString(bonusGainRuleDTO));
    }
}

