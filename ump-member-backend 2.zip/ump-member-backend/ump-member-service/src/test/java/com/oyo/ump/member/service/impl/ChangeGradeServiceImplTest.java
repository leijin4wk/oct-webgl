package com.oyo.ump.member.service.impl;

import com.oyo.ump.member.common.test.TestApplication;
import com.oyo.ump.member.service.ChangeGradeService;
import com.oyo.ump.member.service.MemberInfoService;
import com.oyo.ump.member.service.bo.ChangeGradeBO;
import com.oyo.ump.member.service.bo.MemberInfoBO;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;

/**
 * @author Dong
 * @Classname ChangeGradeServiceImplTest
 * @Description
 * @Date 2019-08-01
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class ChangeGradeServiceImplTest {
    @Autowired
    ChangeGradeService changeGradeService;
    @Autowired
    MemberInfoService memberInfoService;

    @Test
    public void changeGrade() {
        ChangeGradeBO changeGradeBO = new ChangeGradeBO();
        changeGradeBO.setUserId(27776640L);
        changeGradeBO.setGradeId(1);
        changeGradeBO.setPreviousGradeId(2);
        changeGradeBO.setUpdateRuleType(2);
        changeGradeService.changeGrade(changeGradeBO);
        MemberInfoBO result = memberInfoService.getMemberInfoFromDB(changeGradeBO.getUserId());
        assertNotNull(result);
        assertTrue(1 == result.getGradeId());
        log.info("插入的数据：{}", result);
    }
}
