package com.oyo.ump.member.service.impl;

import com.oyo.common.response.PagedResponse;
import com.oyo.ump.member.common.test.TestApplication;
import com.oyo.ump.member.service.CrowdService;
import com.oyo.ump.member.service.bo.CrowdBO;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.util.Lists;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;

/**
 * @author Dong
 * @Classname CrowdServiceImplTest
 * @Description
 * @Date 2019-08-01
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class CrowdServiceImplTest {
    @Autowired
    CrowdService crowdService;

    @Test
    public void insertCrowd() {
        CrowdBO crowdBO = new CrowdBO();
        crowdBO.setCrowdName("单元测试人群插入");
        crowdBO.setCrowdCreateType("2");
        crowdBO.setCrowdStatus("1");
        crowdBO.setIsDeleted(0);
        crowdBO.setUserType(1);
        crowdBO.setCrowdType(1);
        List<Long> userList = Lists.newArrayList();
        userList.add(11l);
        userList.add(22l);
        crowdBO.setUserIds(userList);
        crowdService.insertCrowd(crowdBO);
        CrowdBO crowdBO1 = crowdService.selectById(crowdBO.getId());
        assertNotNull(crowdBO1);
    }

    @Test
    public void selectById() {
        CrowdBO crowdBO1 = crowdService.selectById(139L);
        assertNotNull(crowdBO1);
    }

    @Test
    public void selectByCondition() {
        Map<String, String> params = new HashMap<>();
        params.put("startTime", null);
        params.put("endTime", null);
//        params.put("crowdStatus", "0");
        params.put("crowdStatus", "1");
        params.put("crowdName", "单元");
        List<CrowdBO> crowdBOList = crowdService.selectByCondition(params);
        System.out.println(crowdBOList);
    }

    @Test
    public void selectByConditionPaged() {
        Map<String, String> params = new HashMap<>();
        params.put("startTime", null);
        params.put("endTime", null);
//        params.put("crowdStatus", "0");
        params.put("crowdStatus", "1");
        params.put("crowdName", "单元");
        PagedResponse<CrowdBO> response  = crowdService.selectByConditionPaged(params, 1, 5);
        System.out.println(response.getResult());
    }

    @Test
    public void updateCrowd() {
        CrowdBO crowdBO = new CrowdBO();
        crowdBO.setId(36L);
        crowdBO.setCrowdName("单元测试人群修改");
        crowdBO.setCrowdCreateType("2");
        crowdBO.setCrowdStatus("1");
        List<Long> userList = Lists.newArrayList();
        userList.add(11l);
        userList.add(23l);
        crowdBO.setUserIds(userList);
        crowdService.updateCrowd(crowdBO);
        System.out.println(crowdService.selectById(crowdBO.getId()));
    }

    @Test
    public void deleteCrowd() {
        crowdService.deleteCrowd(36L);
        assertNull(crowdService.selectById(36L));
    }

    @Test
    public void findSelectCrowdBoByIds() {
    }

    @Test
    public void jobUpdateCrowdsQty() {
    }
}
