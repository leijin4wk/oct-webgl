package com.oyo.ump.member.service;

import com.oyo.ump.member.common.test.TestApplication;
import com.oyo.ump.member.service.bo.ActivityBasisBo;
import com.oyo.ump.member.service.bo.ChannelLinkBasicBo;
import com.oyo.ump.member.service.bo.PromoteBasisBo;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;
import java.util.Map;

/** 活动url 单元测试
* @author leijin
* @date 2020-01-10 16:49
**/
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class ActivityUrlTest {
    @Autowired
    private PushTemplateRelationService pushTemplateRelationService;
    @Test
    public void  getChanneledActivitiesTest(){
        List<ActivityBasisBo> list= pushTemplateRelationService.getChanneledActivities("");
        System.out.println(list);
    }

    @Test
    public void  getChanneledPromotesTest(){
        List<PromoteBasisBo> list= pushTemplateRelationService.getChanneledPromotes("",1961L);
        System.out.println(list);
    }

    @Test
    public void getTopDepartmentCodeTest(){
        Map<String, String> map=pushTemplateRelationService.getTopDepartmentCode();
        System.out.println(map);
    }

     @Test
    public void getActivityChannelTypesTest(){
        Map<String,String> map=pushTemplateRelationService.getActivityChannelTypes();
         System.out.println(map);
    }

    @Test
    public void createChannelLinkTest(){
        ChannelLinkBasicBo channelLinkBasicBo=new ChannelLinkBasicBo();
        channelLinkBasicBo.setChannelName("test1");
        channelLinkBasicBo.setPromoteBasisId(4112L);
        channelLinkBasicBo.setUtmSource("C_Sup_109998_Le");
        channelLinkBasicBo.setUtmMedium("Sms-CRM");
        channelLinkBasicBo.setUtmCampaign("111");
        channelLinkBasicBo.setUtmContent("22222");
        String a=pushTemplateRelationService.createChannelLink(channelLinkBasicBo);
        System.out.println(a);
    }
}
