package com.oyo.ump.member.service.impl;

import com.oyo.ump.member.common.test.TestApplication;
import com.oyo.ump.member.service.UpgradePackageService;
import com.oyo.ump.member.service.bo.UpgradePackageBO;
import com.oyo.ump.member.service.bo.UpgradePackagePageBO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.junit.Assert.*;

/**
 * @author Dong
 * @Classname UpgradePackageServiceImplTest
 * @Description
 * @Date 2019-08-06
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class UpgradePackageServiceImplTest {
    @Autowired
    UpgradePackageService upgradePackageService;

    @Test
    public void getUpgradePackageList() {
        UpgradePackagePageBO packagePageBO = upgradePackageService.getUpgradePackageList();
        assertNotNull(packagePageBO);
        assertTrue(packagePageBO.getUpgradePackageBOList().size()>0);
    }

    @Test
    public void getUpgradePackageList1() {
        UpgradePackagePageBO packagePageBO = upgradePackageService.getUpgradePackageList(1,5);
        assertNotNull(packagePageBO);
        assertTrue(packagePageBO.getUpgradePackageBOList().size()>0);

        UpgradePackagePageBO packagePageBO2 = upgradePackageService.getUpgradePackageList(2,5);
        assertTrue(packagePageBO2.getUpgradePackageBOList().size()==0);
    }

    @Test
    public void getUpgradePackageListByGradeId() {
        List<UpgradePackageBO> res1 = upgradePackageService.getUpgradePackageListByGradeId(1);
        assertTrue(res1.size()==2);

        List<UpgradePackageBO> res2 = upgradePackageService.getUpgradePackageListByGradeId(2);
        assertTrue(res2.size()==1);

        List<UpgradePackageBO> res3 = upgradePackageService.getUpgradePackageListByGradeId(3);
        assertTrue(CollectionUtils.isEmpty(res3));
    }

    @Test
    public void getUpgradePackageByCode() {
        UpgradePackageBO upgradePackageBO = upgradePackageService.getUpgradePackageByCode("2222");
        assertNull(upgradePackageBO);

        UpgradePackageBO upgradePackageBO2 = upgradePackageService.getUpgradePackageByCode("K00066214025");
        assertNull(upgradePackageBO2);
    }

    @Test
    public void getProductCategoryIds() {
        List<String> res = upgradePackageService.getProductCategoryIds();
        assertTrue(res.size()>0);
        log.info("categoryid集合:{}", res);
    }
}
