package com.oyo.ump.member.service;

import com.oyo.ump.member.common.test.TestApplication;
import com.oyo.ump.member.dal.model.PushMessageEntity;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.util.Lists;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.stereotype.Component;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.junit.Assert.*;

/**
 * @author Dong
 * @Description
 * @Date 2019-10-08
 */
@Component
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class UniformPushServiceTest {
    @Autowired
    UniformPushService uniformPushService;

    /**
     * 带图片的push
     * @param
     * @return void
     */
    @Test
    public void sendAndGetBatchNoImage(){
        List<PushMessageEntity> batchList = Lists.newArrayList();
        PushMessageEntity pushMessageEntity = new PushMessageEntity();
        pushMessageEntity.setMemberId(16780597L);
        pushMessageEntity.setUniformTemplateId("T201909171629238479");
        pushMessageEntity.setMemberPushId(427L);
        pushMessageEntity.setTriggerChannel(2);
        pushMessageEntity.setMessageDetail("{\"imageUrl\":\"https://oyo-common-file-r.oyohotels.cn/cmsimgpath/02C6466612584F1D92D5085AF2B118667446489563937128581.jpg\",\"utmContent\":\"4\",\"utmSource\":\"1\",\"jumpValue\":\"http://www.baidu.com\",\"utmCampaign\":\"3\",\"utmMedia\":\"2\"}");
        batchList.add(pushMessageEntity);
        String result = uniformPushService.sendAndGetBatchNo(batchList, false);
        assertNotNull(result);
    }

    /**
     * 不带图片的push
     * @param
     * @return void
     */
    @Test
    public void sendAndGetBatchNo(){
        List<PushMessageEntity> batchList = Lists.newArrayList();
        PushMessageEntity pushMessageEntity = new PushMessageEntity();
        pushMessageEntity.setMemberId(16780597L);
        pushMessageEntity.setUniformTemplateId("T201909171629238479");
        pushMessageEntity.setMemberPushId(427L);
        pushMessageEntity.setTriggerChannel(2);
        pushMessageEntity.setMessageDetail("{\"imageUrl\":\"https://oyo-common-file-r.oyohotels.cn/cmsimgpath/02C6466612584F1D92D5085AF2B118667446489563937128581.jpg\",\"utmContent\":\"4\",\"utmSource\":\"1\",\"jumpValue\":\"http://www.taoba.com\",\"utmCampaign\":\"3\",\"utmMedia\":\"2\"}");
        batchList.add(pushMessageEntity);
        String result = uniformPushService.sendAndGetBatchNo(batchList, false);
        assertNotNull(result);
    }

    /**
     * 单纯站内信的push
     * @param
     * @return void
     */
    @Test
    public void sendInternalMsg(){
        List<PushMessageEntity> batchList = Lists.newArrayList();
        PushMessageEntity pushMessageEntity = new PushMessageEntity();
        pushMessageEntity.setMemberId(16780597L);
        pushMessageEntity.setUniformTemplateId("T201912041733071199");
        pushMessageEntity.setMemberPushId(427L);
        pushMessageEntity.setTriggerChannel(6);
        pushMessageEntity.setMessageDetail("{\"imageUrl\":\"https://oyo-common-file-r.oyohotels.cn/cmsimgpath/02C6466612584F1D92D5085AF2B118667446489563937128581.jpg\",\"utmContent\":\"4\",\"utmSource\":\"1\",\"jumpValue\":\"http://www.taoba.com\",\"utmCampaign\":\"3\",\"utmMedia\":\"2\"}");
        batchList.add(pushMessageEntity);
        String result = uniformPushService.sendAndGetBatchNo(batchList, false);
        assertNotNull(result);
    }

    /**
     * 阿波罗站内信的push
     * @param
     * @return void
     */
    @Test
    public void sendApolloInternalMsg(){
        List<PushMessageEntity> batchList = Lists.newArrayList();
        PushMessageEntity pushMessageEntity = new PushMessageEntity();
        pushMessageEntity.setMemberId(16780597L);
        pushMessageEntity.setUniformTemplateId("T201912121844175452");
        pushMessageEntity.setMemberPushId(1122L);
        pushMessageEntity.setTriggerChannel(2);
        pushMessageEntity.setMessageDetail("{\"imageUrl\":\"https://oyo-common-file-r.oyohotels.cn/cmsimgpath/02C6466612584F1D92D5085AF2B118667446489563937128581.jpg\",\"utmContent\":\"4\",\"utmSource\":\"1\",\"jumpValue\":\"http://www.taoba.com\",\"utmCampaign\":\"3\",\"utmMedia\":\"2\"}");
        batchList.add(pushMessageEntity);
        String result = uniformPushService.sendAndGetBatchNo(batchList, false);
        assertNotNull(result);
    }

    @Test
    public void sendAndGetBatchNoTest(){
        List<PushMessageEntity> batchList = Lists.newArrayList();
        PushMessageEntity pushMessageEntity = new PushMessageEntity();
        pushMessageEntity.setMemberId(124790L);
        pushMessageEntity.setStatus(0);
        pushMessageEntity.setUniformTemplateId("T201909240038095647");
        pushMessageEntity.setMemberPushId(427L);
        pushMessageEntity.setTriggerChannel(2);
        pushMessageEntity.setMessageDetail("{\"utmContent\":\"4\",\"utmSource\":\"1\",\"jumpValue\":\"http://ali-test.ahotels.tech/ump-qrcode-web/s/lxZljz5B\",\"utmCampaign\":\"3\",\"utmMedia\":\"2\"}");
        batchList.add(pushMessageEntity);
        String result = uniformPushService.sendAndGetBatchNo(batchList, true);
        assertNull(result);
    }
}