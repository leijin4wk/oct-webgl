package com.oyo.ump.member.service;

import com.alibaba.fastjson.JSON;
import com.oyo.ump.member.common.test.TestApplication;
import com.oyo.ump.member.service.bo.UpgradePackageBO;
import com.oyo.ump.member.service.bo.UpgradePackagePageBO;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

/**
 * @author Dong
 * @Classname UpgradePackageServiceTest
 * @Description 升级包接口测试类
 * @Date 2019-04-18
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class UpgradePackageServiceTest {
    @Autowired
    UpgradePackageService upgradePackageService;

    @Test
    public void packageList(){
        UpgradePackagePageBO upgradePackagePageBO = upgradePackageService.getUpgradePackageList();
        log.info("upgradePackagePageBO: {}", JSON.toJSONString(upgradePackagePageBO));
    }

    @Test
    public void canBuy(){
        List<UpgradePackageBO> lis1 = upgradePackageService.getUpgradePackageListByGradeId(1);
        log.info("lis1: {}", JSON.toJSONString(lis1));
        List<UpgradePackageBO> lis2 = upgradePackageService.getUpgradePackageListByGradeId(2);
        log.info("lis2: {}", JSON.toJSONString(lis2));
    }
}
