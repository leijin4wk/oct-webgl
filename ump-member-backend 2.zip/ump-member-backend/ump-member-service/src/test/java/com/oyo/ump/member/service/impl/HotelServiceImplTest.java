package com.oyo.ump.member.service.impl;

import com.oyo.ump.member.common.test.TestApplication;
import com.oyo.ump.member.service.HotelService;
import com.oyo.ump.member.service.bo.HotelBO;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.util.Lists;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;

/**
 * @author Dong
 * @Classname HotelServiceImplTest
 * @Description
 * @Date 2019-08-01
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class HotelServiceImplTest {
    @Autowired
    HotelService hotelService;

    @Test
    public void getHotelList() {
    }

    @Test
    public void getSalesHotel() {
        List<Long> hotelIds = Lists.newArrayList();
        hotelIds.add(123L);
        List<HotelBO> hotelBOList = hotelService.getSalesHotel(hotelIds);
        assertTrue(hotelBOList.size() > 0);
        System.out.println(hotelBOList);
    }

    @Test
    public void isMemberHotel() {
        List<Long> hotelIds = Lists.newArrayList();
        hotelIds.add(123L);
        Map<Long, Boolean> resMap = hotelService.isMemberHotel(hotelIds);
        assertTrue(resMap.get(123L));
        System.out.println(resMap);
    }

    @Test
    public void addMemberHotel() {
        hotelService.addMemberHotel(123L, 456);
        List<Long> hotelIds = Lists.newArrayList();
        hotelIds.add(123L);
        Map<Long, Boolean> resMap = hotelService.isMemberHotel(hotelIds);
        assertTrue(resMap.get(123L));
        System.out.println(resMap);
    }
}
