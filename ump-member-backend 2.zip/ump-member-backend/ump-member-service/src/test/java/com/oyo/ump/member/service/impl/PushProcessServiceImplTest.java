package com.oyo.ump.member.service.impl;

import com.oyo.ump.member.common.test.TestApplication;
import com.oyo.ump.member.service.PushProcessService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class PushProcessServiceImplTest {
    @Autowired
    private PushProcessService pushProcessService;

    /**
     * 测试构建sql
     */
    @Test
    public void testPush(){
        //pushProcessService.getPushInfoAndParams(112L);
    }

    /**
     * 测试自定义事件构建SQL
     */
    @Test
    public void testPush2(){
       // pushProcessService.getPushInfoAndParams(170L);
    }
}
