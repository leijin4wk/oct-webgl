package com.oyo.ump.member.service.impl;

import com.oyo.ump.member.common.test.TestApplication;
import com.oyo.ump.member.service.MessagePushService;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.util.Lists;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

/**
 * @author Dong
 * @Classname MessagePushServiceImplTest
 * @Description
 * @Date 2019-08-02
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class MessagePushServiceImplTest {
    @Autowired
    MessagePushService messagePushService;


    @Test
    public void getUsersQtyByCrowdId() {
       Long num = messagePushService.getUsersQtyByCrowdId(32L);
       System.out.println(num);
    }

    @Test
    public void getUsersQtyByCrowdIds() {
        List<Long> ids = Lists.newArrayList();
        ids.add(32L);
        ids.add(33L);
        Long num = messagePushService.getUsersQtyByCrowdIds(ids, null);
        System.out.println(num);
    }

    @Test
    public void getTagPreviewCrowd() {
        String tag = "[{\"itemId\":1,\"tagClassSelectValue\":\"1\",\"tagType\":1,\"tagSelectValue\":\"channel\",\"tagOperatorValue\":\"in\",\"tagValueSelectValue\":[\"miniapp\"],\"relationValue\":1}]";
        List<Long> result = messagePushService.getTagPreviewCrowd(tag);
        System.out.println(result);

    }

    @Test
    public void saveMemberMessageRecord() {
    }

    @Test
    public void sendAndUpdateMemberMessageRecord() {
    }

    @Test
    public void getUserList() {
    }

    @Test
    public void getAllUserList() {
    }

    @Test
    public void countAllUserList() {
    }

    @Test
    public void processPersonasPush() {
    }

    @Test
    public void getWhereStatement() {
    }

    @Test
    public void getTemplateBoList() {
    }
}
