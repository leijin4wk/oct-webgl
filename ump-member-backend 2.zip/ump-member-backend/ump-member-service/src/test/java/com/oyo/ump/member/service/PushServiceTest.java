package com.oyo.ump.member.service;

import com.google.common.collect.Lists;
import com.oyo.ump.member.common.test.TestApplication;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.stereotype.Component;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.temporal.ChronoUnit;
import java.util.List;

import static org.junit.Assert.assertTrue;

/**
 * @author Dong
 * @Classname PushServiceTest
 * @Description 时间推送接口测试
 * @Date 2019-05-06
 */
@Component
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class PushServiceTest {

    @Autowired
    PushService pushService;
    @Autowired
    CrowdService crowdService;

//    @Test
//    public void getResourceTree() {
//        String resourceTree = "{\"code\":\"crm\",\"resourceTrees\":[{\"code\":\"memberPay\",\"resourceTrees\":[{\"code\":\"memberPay_manage\",\"resourceTrees\":[{\"code\":\"memberPay_manage$button$upgradeQuery\",\"resourceTrees\":null},{\"code\":\"memberPay_manage_page\",\"resourceTrees\":null},{\"code\":\"memberPay_manage$button$editUpgradeRule\",\"resourceTrees\":null},{\"code\":\"memberPay_manage$button$addUpgradeRule\",\"resourceTrees\":null}]}]},{\"code\":\"membershipScore\",\"resourceTrees\":[{\"code\":\"membershipScore_integralRule\",\"resourceTrees\":[{\"code\":\"membershipScore_integralRule$button$updateCreditUseRuel\",\"resourceTrees\":null},{\"code\":\"membershipScore_integralRule_page\",\"resourceTrees\":null},{\"code\":\"membershipScore_integralRule$button$updateCreditGainRule\",\"resourceTrees\":null},{\"code\":\"membershipScore_integralRule$button$addCreditGainRule\",\"resourceTrees\":null}]}]},{\"code\":\"membershipLevel\",\"resourceTrees\":[{\"code\":\"membershipLevel_levelAndRights\",\"resourceTrees\":[{\"code\":\"membershipLevel_levelAndRights$button$updateMemberRights\",\"resourceTrees\":null},{\"code\":\"membershipLevel_levelAndRights_page\",\"resourceTrees\":null},{\"code\":\"membershipLevel_levelAndRights$button$removeMemberLevel\",\"resourceTrees\":null},{\"code\":\"membershipLevel_levelAndRights$button$editMemberLevel\",\"resourceTrees\":null},{\"code\":\"membershipLevel_levelAndRights$button$addMemberlevel\",\"resourceTrees\":null}]}]},{\"code\":\"membershipStatus\",\"resourceTrees\":[{\"code\":\"membershipStatus_membershipStatusList\",\"resourceTrees\":[{\"code\":\"membershipStatus_membershipStatusList$button$memberQuery\",\"resourceTrees\":null},{\"code\":\"membershipStatus_membershipStatusList_page\",\"resourceTrees\":null}]}]},{\"code\":\"eventPush\",\"resourceTrees\":[{\"code\":\"eventPush_eventPushList\",\"resourceTrees\":null},{\"code\":\"eventPush_edit\",\"resourceTrees\":null},{\"code\":\"eventPush_page\",\"resourceTrees\":null},{\"code\":\"eventPush_business_eventPushList\",\"resourceTrees\":null},{\"code\":\"push_department_admin\",\"resourceTrees\":null},{\"code\":\"push_department_member\",\"resourceTrees\":null},{\"code\":\"push_admin\",\"resourceTrees\":null}]},{\"code\":\"membershipPrivilege\",\"resourceTrees\":[{\"code\":\"membershipPrivilege_detail\",\"resourceTrees\":null}]},{\"code\":\"memberGroup\",\"resourceTrees\":[{\"code\":\"memberGroup_list\",\"resourceTrees\":null},{\"code\":\"memberGroup_page\",\"resourceTrees\":null},{\"code\":\"memberGroup_edit\",\"resourceTrees\":null},{\"code\":\"memberGroup_read\",\"resourceTrees\":null},{\"code\":\"memberGroup_crowdMemberList\",\"resourceTrees\":null},{\"code\":\"memberGroup_crowdMemberDetail\",\"resourceTrees\":null}]},{\"code\":\"dataAnalysis\",\"resourceTrees\":[{\"code\":\"dataAnalysis_list\",\"resourceTrees\":null},{\"code\":\"dataAnalysis_funnel\",\"resourceTrees\":null},{\"code\":\"dataAnalysis_coreDataAnalysis\",\"resourceTrees\":null},{\"code\":\"dataAnalysis_preferCityModelAccurency\",\"resourceTrees\":null},{\"code\":\"dataAnalysis_baseCityChinaModelAccurency\",\"resourceTrees\":null},{\"code\":\"dataAnalysis_baseCityIndiaModelAccurency\",\"resourceTrees\":null},{\"code\":\"dataAnalysis_priceModelAccurency\",\"resourceTrees\":null}]},{\"code\":\"memberGradeMap\",\"resourceTrees\":[{\"code\":\"memberGradeMap_aliTripMaps\",\"resourceTrees\":null}]},{\"code\":\"pushManagement\",\"resourceTrees\":[{\"code\":\"pushManagement_editPush\",\"resourceTrees\":null},{\"code\":\"pushManagement_pushBootPage\",\"resourceTrees\":null},{\"code\":\"pushManagement_clientPushEdit\",\"resourceTrees\":null},{\"code\":\"pushManagement_businessPushEdit\",\"resourceTrees\":null}]},{\"code\":\"pushTemplate\",\"resourceTrees\":[{\"code\":\"pushTemplate_templateList\",\"resourceTrees\":null}]}]}";
//        List<String> result = MemberSsoUtil.parseJsonString(resourceTree);
//
//        assertTrue(CollectionUtils.isNotEmpty(result));
//    }

    @Test
    public void selectTest(){
       List<Long> userIds =  pushService.getIntervalUserIds(Lists.newArrayList(27776149L,20578618L),5L, 10L,ChronoUnit.MINUTES);
       if(CollectionUtils.isNotEmpty(userIds)){
           userIds.forEach(System.out::println);
       }
    }

    @Test
    public void employeeNos2UserIdTest(){
        List<String> employeeNos = Lists.newArrayList();
        employeeNos.add("Y00009799");
        List<Long> userIds = crowdService.getUserIdsByEmployeeNos(employeeNos);
        assertTrue(CollectionUtils.isNotEmpty(userIds));
    }

    @Test
    public void createTest(){
        pushService.createPromotionPushByJob();
    }

}
