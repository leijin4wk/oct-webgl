package com.oyo.ump.member.service.impl;

import com.oyo.ump.member.common.test.TestApplication;
import com.oyo.ump.member.service.MemberInfoService;
import com.oyo.ump.member.service.bo.MemberDetailBO;
import com.oyo.ump.member.service.bo.MemberInfoBO;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.util.Lists;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

/**
 * @author Dong
 * @Classname MemberInfoServiceImplTest
 * @Description
 * @Date 2019-08-02
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class MemberInfoServiceImplTest {
    @Autowired
    MemberInfoService memberInfoService;
    @Test
    public void getMemberInfoByUserId() {
        MemberInfoBO memberInfoBO = memberInfoService.getMemberInfoByUserId(19431647L);
        System.out.println(memberInfoBO);
    }

    @Test
    public void getMemberInfoByUserIdList() {
        List<Long> userIds = Lists.newArrayList();
        userIds.add(1943167L);
        userIds.add(647L);
        List<MemberInfoBO> memberInfoBOList = memberInfoService.getMemberInfoByUserIdList(userIds);
        System.out.println(memberInfoBOList);
    }

    @Test
    public void getMemberDetailByUserId() {
        MemberDetailBO memberDetailBO = memberInfoService.getMemberDetailByUserId(19431647L,"OYO");
        System.out.println(memberDetailBO);
    }

    @Test
    public void getMemberInfoFromDB() {
        MemberInfoBO memberInfoBO = memberInfoService.getMemberInfoFromDB(19431647L);
        System.out.println(memberInfoBO);
    }

    @Test
    public void clearMemberInfoCache() {
    }

    @Test
    public void updateUserInfoByUserId() {
        memberInfoService.updateUserInfoByUserId(19431647L, "422401222222222222");
    }

    @Test
    public void registerMember() {
        memberInfoService.registerMember(888888L);
        MemberInfoBO memberInfoBO = memberInfoService.getMemberInfoByUserId(888888L);
        System.out.println(memberInfoBO);
    }

    @Test
    public void getMemberInfoListFromDB() {
    }
}
