package com.oyo.ump.member.service.impl;

import com.alibaba.fastjson.JSON;
import com.oyo.common.response.PagedResponse;
import com.oyo.ump.member.common.enums.GradeRefreshRuleEnum;
import com.oyo.ump.member.common.test.TestApplication;
import com.oyo.ump.member.service.MemberIdentityListService;
import com.oyo.ump.member.service.bo.MemberIdentityBO;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;

import static com.oyo.ump.member.common.constants.MemberConstants.OYO_JP_TENANT;
import static com.oyo.ump.member.common.constants.MemberConstants.OYO_TENANT;
import static org.junit.Assert.*;

/**
 * @author Dong
 * @Classname MemberIdentityListServiceImplTest
 * @Description
 * @Date 2019-08-02
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class MemberIdentityListServiceImplTest {
    @Autowired
    MemberIdentityListService memberIdentityListService;

    @Test
    public void getMemberIdentityList() {
        Map<String, Object> params = new HashMap<>();
        params.put("refreshRule", "");
        params.put("pageNum", 1);
        params.put("pageSize", 10);
        params.put("tenant",OYO_JP_TENANT);
        PagedResponse<MemberIdentityBO> pagedBo = memberIdentityListService.getMemberIdentityList(params);
        log.info("get result: {}", JSON.toJSONString(pagedBo));

        assertTrue(pagedBo != null && pagedBo.getPageSize() == 10);
        assertTrue(pagedBo.getResult().size() == 0 || "V3".equals(pagedBo.getResult().get(0).getGradeName()));
    }

    @Test
    public void getAllGrade() {
        Map gradeMap = memberIdentityListService.getAllGrade(OYO_TENANT);
        log.info("get all tenant list: {}", JSON.toJSONString(gradeMap));
        assertTrue(gradeMap.size() == 11);

        gradeMap = memberIdentityListService.getAllGrade(OYO_JP_TENANT);
        log.info("get all tenant list: {}", JSON.toJSONString(gradeMap));
        assertTrue(gradeMap.size() == 2);

    }

}
