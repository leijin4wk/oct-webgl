package com.oyo.ump.member.service.impl;

import com.oyo.ump.member.common.constants.MemberConstants;
import com.oyo.ump.member.common.test.TestApplication;
import com.oyo.ump.member.service.bo.UserProfileDictBO;
import com.oyo.ump.member.service.schedule.UserProfileDictService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.junit.Assert.*;

/**
 * @author Dong
 * @Classname UserProfileDictServiceImplTest
 * @Description
 * @Date 2019-08-06
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class UserProfileDictServiceImplTest {
    @Autowired
    UserProfileDictService userProfileDictService;

    @Test
    public void selectByFirstId() {
        List<UserProfileDictBO> res1 = userProfileDictService.selectByFirstId("1", MemberConstants.USER_TYPE_FOR_C);
        assertTrue(res1.size()>0);
        List<UserProfileDictBO> res5 = userProfileDictService.selectByFirstId("5", MemberConstants.USER_TYPE_FOR_C);
        assertNull(res5);
    }

    @Test
    public void selectByTagColumn() {
        UserProfileDictBO userProfileDictBO = userProfileDictService.selectByTagColumn("register_time", MemberConstants.USER_TYPE_FOR_C);
        assertNotNull(userProfileDictBO);
        UserProfileDictBO userProfileDictBO2 = userProfileDictService.selectByTagColumn("register_time22222", MemberConstants.USER_TYPE_FOR_C);
        assertNull(userProfileDictBO2);
    }
}
