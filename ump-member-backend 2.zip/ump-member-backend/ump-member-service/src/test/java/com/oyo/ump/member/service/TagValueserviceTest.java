package com.oyo.ump.member.service;

import com.oyo.ump.member.common.test.TestApplication;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.stereotype.Component;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author Dong
 * @Classname TagValueserviceTest
 * @Description TODO
 * @Date 2019-06-11
 */
@Component
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class TagValueserviceTest {
    @Autowired
    TagValueService tagValueService;


    @Test
    public void countTest(){
        String strSql = "channel = 'checked-out' and phone_prov = '河南省' and operator = '中国电信'";

    }
}
