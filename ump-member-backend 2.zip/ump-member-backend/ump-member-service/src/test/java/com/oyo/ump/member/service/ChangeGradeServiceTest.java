package com.oyo.ump.member.service;

import com.oyo.ump.member.common.test.TestApplication;
import com.oyo.ump.member.service.bo.ChangeGradeBO;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author Dong
 * @Classname ChangeGradeServiceTest
 * @Description
 * @Date 2019-08-01
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class ChangeGradeServiceTest {
    @Autowired
    ChangeGradeService changeGradeService;
    @Autowired
    MemberInfoService memberInfoService;

    @Test
    public void changeGradeTest(){
        ChangeGradeBO changeGradeBO = new ChangeGradeBO();
        changeGradeBO.setUserId(27776640L);
        changeGradeBO.setGradeId(3);
        changeGradeBO.setPreviousGradeId(2);
        changeGradeBO.setUpdateRuleType(3);
        changeGradeService.changeGrade(changeGradeBO);
        System.out.println(memberInfoService.getMemberInfoFromDB(changeGradeBO.getUserId()));
    }
}
