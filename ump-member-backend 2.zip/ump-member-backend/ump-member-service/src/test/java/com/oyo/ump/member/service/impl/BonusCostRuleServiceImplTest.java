package com.oyo.ump.member.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.oyo.ump.member.common.test.TestApplication;
import com.oyo.ump.member.service.BonusCostRuleService;
import com.oyo.ump.member.service.dto.BonusCostRuleDTO;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;

/**
 * @author Dong
 * @Classname BonusCostRuleServiceImplTest
 * @Description
 * @Date 2019-08-01
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class BonusCostRuleServiceImplTest {
    @Autowired
    BonusCostRuleService bonusCostRuleService;

    @Test
    public void getCostRuleList() {
        BonusCostRuleDTO bonusCostRuleDTO = bonusCostRuleService.getCostRuleList();
        assertNotNull(bonusCostRuleDTO);
        log.info("鸥币消耗规则：{}", JSON.toJSONString(bonusCostRuleDTO, SerializerFeature.PrettyFormat));
    }
}
