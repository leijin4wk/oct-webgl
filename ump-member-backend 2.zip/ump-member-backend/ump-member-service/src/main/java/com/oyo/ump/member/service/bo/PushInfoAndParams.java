package com.oyo.ump.member.service.bo;

import com.oyo.ump.member.dal.model.PushTemplateRelationEntity;
import lombok.Data;
import org.assertj.core.util.Sets;

import java.util.*;

/**
 * 模板配置类
* @author leijin
* @date 2019-09-08 20:27
**/
@Data
public class PushInfoAndParams{

    //基础参数
    private Long pushId;

    private Integer userType;

    public Integer triggerType;

    private Integer triggerChannel;

    private String  templateNum;

    private Long start;

    private Long end;

    private Integer intervalTime;

    private ColumnAndMqParamBo columnAndMqParamBo;


    //拼接参数
    //view 定义
    private String viewDefine;

    private String modelCondition;

    private String channelCondition;

    private String crowdsCondition;

    private String eventCondition;

    private Integer urlType;


    private String joinCondition;

    private PushBO.TargetCrowdConfig targetCrowdConfig;

    private String generatedSQL;
    /**
     * 用与弹窗显示的sql
    * @author leijin
    * @date 2019-11-20 14:11
    **/
    private String countSQL;


    private String testPushSql;

    /**
     * 用来到mysql中取数的sql
    * @author leijin
    * @date 2019-11-20 11:29
    **/
    private String uploadMysqlCrowdSql;

    private UploadCrowdInfoBo uploadCrowdInfoBo;

    /**
     * 自定义事件中用到的view
    * @author leijin
    * @date 2019-11-20 17:08
    **/
    private Set<String> viewSet;


    public PushInfoAndParams(PushTemplateRelationEntity templateInfo,Integer triggerType,Long start,Long end) {
        this.pushId=templateInfo.getPushId();
        this.templateNum=templateInfo.getTemplateNum();
        this.triggerChannel=templateInfo.getTriggerChannel();
        this.start=start;
        this.end=end;
        this.triggerType=triggerType;
        this.columnAndMqParamBo=new ColumnAndMqParamBo();
    }
}
