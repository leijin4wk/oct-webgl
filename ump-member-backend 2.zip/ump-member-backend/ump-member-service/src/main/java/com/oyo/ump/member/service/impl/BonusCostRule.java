package com.oyo.ump.member.service.impl;

import lombok.Data;

import java.math.BigDecimal;

/**
 * @Classname BonusCostRule
 * @Description 积分消费规则类（内部类用于 接收数据库返回配置字段对应的类对象）
 * @Date 2019-03-15 14:57
 * @author Dong
 */
@Data
public class BonusCostRule {
    /**
     * 积分兑换配置,用于 接收数据库返回配置字段对应的类对象
     */
    @Data
    public static class ExchangeConfig{
        /**
         * 每一积分可抵扣人民币（元）
         */
        private BigDecimal pricePerUnit;
        /**
         * 每次抵扣至少使用多少积分
         */
        private Integer minBonus;
    }


}
