package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;

/**
 * @Description:
 * @Author: fang
 * @create: 2019-11-11
 **/
@Data
public class CrowdTagBO implements Serializable {
    private Integer itemId;
    private String tagClassSelectValue;
    private Integer tagType;
    private String tagSelectValue;
    private String tagOperatorValue;
    private String tagValueSelectValue;
    private Integer relationValue;
}
