package com.oyo.ump.member.service.dto;

import lombok.Data;

/**
 * @Description: todo
 * @Author: fang
 * @create: 2019-04-15
 **/
@Data
public class RefundRequestDTO {
    private String orderSn;
    private Long operatorId;
    private Long userId;
    private String productCode;

}
