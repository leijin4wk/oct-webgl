package com.oyo.ump.member.service.impl;

import com.oyo.ump.member.common.beanutils.MapperWrapper;
import com.oyo.ump.member.dal.dao.PushJobRecordMapper;
import com.oyo.ump.member.dal.model.PushJobRecordEntity;
import com.oyo.ump.member.service.PushJobRecordService;
import com.oyo.ump.member.service.bo.PushJobRecordBO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author Dong
 * @Description
 * @Date 2020-01-03
 */
@Service
@Slf4j
public class PushJobRecordServiceImpl implements PushJobRecordService {
    @Autowired
    PushJobRecordMapper pushJobRecordMapper;

    @Override
    public Long insert(PushJobRecordBO pushJobRecordBO) {
        PushJobRecordEntity pushJobRecordEntity = MapperWrapper.instance().map(pushJobRecordBO,PushJobRecordEntity.class);
        pushJobRecordMapper.insert(pushJobRecordEntity);
        return pushJobRecordEntity.getId();
    }

    @Override
    public void updateStatus(Long jobId, Integer status) {
        pushJobRecordMapper.updateStatus(jobId,status);
    }
}
