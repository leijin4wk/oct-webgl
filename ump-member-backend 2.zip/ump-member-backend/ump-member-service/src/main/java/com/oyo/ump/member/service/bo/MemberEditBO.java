package com.oyo.ump.member.service.bo;

import lombok.Data;

/**
 * @Description: todo
 * @Author: fang
 * @create: 2019-03-28
 **/
@Data
public class MemberEditBO {
    private Boolean success;
    private String msg;
}
