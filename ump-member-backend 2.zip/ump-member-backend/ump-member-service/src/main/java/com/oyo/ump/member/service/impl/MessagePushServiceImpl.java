package com.oyo.ump.member.service.impl;

import com.google.gson.*;
import com.oyo.ump.member.common.constants.MemberConstants;
import com.oyo.ump.member.common.exception.UmpException;
import com.oyo.ump.member.dal.dao.*;
import com.oyo.ump.member.dal.model.CrowdEntity;
import com.oyo.ump.member.dal.model.PushEntity;
import com.oyo.ump.member.dal.model.PushMessageEntity;
import com.oyo.ump.member.dal.model.PushRuleEntity;
import com.oyo.ump.member.integration.service.push.PushMessageService;
import com.oyo.ump.member.integration.service.push.PushTemplateService;
import com.oyo.ump.member.service.MessagePushService;
import com.oyo.ump.member.service.TagValueService;
import com.oyo.ump.member.service.bo.PushBO;
import com.oyo.ump.member.service.bo.TemplateBo;
import com.oyo.ump.member.service.enums.TriggerChannelEnum;
import io.swagger.models.auth.In;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * push 消息发送类
 *
 * @author frank
 * @date 2019-06-11 11:07
 **/
@Service
@Slf4j
public class MessagePushServiceImpl implements MessagePushService {

    @Value("${MEMBER_PUSH_SWITCH}")
    private Integer memberPushSwitch;
    @Autowired
    private CrowdCustomMapper crowdCustomMapper;
    @Autowired
    private CrowdMapper crowdMapper;
    @Autowired
    private PushMessageService appPushMessageService;
    @Autowired
    private PushRuleMapper pushRuleMapper;
    @Autowired
    private PushMessageMapper pushMessageMapper;
    @Autowired

    private TagValueService tagValueService;
    @Autowired
    private PushTemplateService appPushTemplateService;
    @Autowired
    @Qualifier("fromGson")
    private Gson gson;
    @Override
    public Long getUsersQtyByCrowdId(Long crowdId) {
        CrowdEntity crowdEntity = crowdMapper.selectById(crowdId);
        Long countUser = 0L;
        if (crowdEntity == null) {
            return countUser;
        }
        //根据标签
        if (MemberConstants.CREATE_BY_TAG.equals(crowdEntity.getCrowdCreateType())) {
            String tagDetail = crowdEntity.getCrowdTag();
            if (StringUtils.isNotBlank(tagDetail)) {
                JsonArray jsonArray = new JsonParser().parse(tagDetail).getAsJsonArray();
                String sql = paramSqlWhereStatement(jsonArray, jsonArray.size());
                Long countNum = tagValueService.countNum(sql);
                countUser += countNum;
                return countUser;
            }
            //根据自定义
        } else if (MemberConstants.CREATE_BY_CUSTOM.equals(crowdEntity.getCrowdCreateType())) {
            List<Long> customIds = new ArrayList<>();
            customIds.add(crowdEntity.getId());
            Long countNum = crowdCustomMapper.countByCrowdIds(customIds);
            if (countNum != null) {
                countUser += countNum;
                return countUser;
            }
        }
        return countUser;
    }

    @Override
    public Long getUsersQtyByCrowdIds(List<Long> crowdIds,Integer triggerChannel) {
        Long userNum = 0L;
        if (CollectionUtils.isNotEmpty(crowdIds)) {
            List<CrowdEntity> crowdEntities = crowdMapper.selectByIds(crowdIds);
            List<Long> customList = new ArrayList<>();
            List<CrowdEntity> tagList = new ArrayList<>();
            if (CollectionUtils.isNotEmpty(crowdEntities)) {
                for (CrowdEntity item : crowdEntities) {
                    if ("1".equals(item.getCrowdCreateType())) {
                        tagList.add(item);
                    } else {
                        customList.add(item.getId());
                    }
                }
            }
            //先查询自定义类型的数据量
            if (customList.size() > 0) {
                Long countNum = crowdCustomMapper.countByCrowdIds(customList);
                if (countNum != null) {
                    userNum += countNum;
                }
            }
            //再查询按照标签查询的数据量
            if (tagList.size() > 0) {
                String sql=getSqlByTagCrowds(tagList);
                if (triggerChannel!=null){
                    sql=sql+getAllUserSqlByTriggerChannel(triggerChannel);
                }
                long countUser = tagValueService.countNum(sql);
                userNum += countUser;
            }
        }
        return userNum;
    }

    @Override
    public Long getUsersQtyByCrowdIdsDifference(List<Long> crowdIds1, List<Long> crowdIds2) {
        Long userNum = 0L;
        if (CollectionUtils.isNotEmpty(crowdIds1)) {
            List<CrowdEntity> crowdEntities1 = crowdMapper.selectByIds(crowdIds1);
            if (crowdEntities1.size() > 0) {
                String sql=getSqlByTagCrowds(crowdEntities1);

                if(CollectionUtils.isNotEmpty(crowdIds2)){
                    List<CrowdEntity> crowdEntities2 = crowdMapper.selectByIds(crowdIds2);
                    if(crowdEntities2.size() > 0){
                        sql= sql +" and member_dim.member_id NOT in( select member_id  FROM `ump_data_member_dim_dw` as member_dim where " +getSqlByTagCrowds(crowdEntities2) +" )";
                    }
                }
                log.info("并集的查询条件： {}",sql);
                long countUser = tagValueService.countNum(sql);
                userNum += countUser;
            }
        }
        return userNum;
    }

    @Override
    public String getSqlByTagCrowds(List<CrowdEntity> tagCrowds) {
        if (CollectionUtils.isNotEmpty(tagCrowds)) {
            StringBuilder stringBuilder = new StringBuilder();
            int j = 0;
            for (int i = 0; i < tagCrowds.size(); i++) {
                if (StringUtils.isNotBlank(tagCrowds.get(i).getCrowdTag())) {
                    JsonArray jsonArray = new JsonParser().parse(tagCrowds.get(i).getCrowdTag()).getAsJsonArray();
                    String sql = paramSqlWhereStatement(jsonArray, jsonArray.size());
                    if (j != 0) {
                        stringBuilder.append(" or ");
                    }
                    stringBuilder.append("( ");
                    stringBuilder.append(sql);
                    stringBuilder.append(" )");
                    j++;
                }
            }
            return stringBuilder.toString();
        }
        return "";
    }

    @Override
    public List<Long> getTagPreviewCrowd(String tagDetail) {
        JsonArray jsonArray;
        try {
            jsonArray = new JsonParser().parse(tagDetail).getAsJsonArray();
        }catch (JsonSyntaxException e){
            log.info("json参数解析异常!");
            throw new UmpException("参数解析异常");
        }
        List<Long> num = new ArrayList();
        for (int i = 0; i < jsonArray.size(); i++) {
            String whereSql = paramSqlWhereStatement(jsonArray, i + 1);
            Long countNum = tagValueService.countNum(whereSql);
            num.add(countNum);
        }
        return num;
    }
    /**
     * 批量存入将要发送的消息记录
     *
     * @author frank
     * @date 2019-06-12 14:56
     * */
    public void saveMemberMessageRecord(List<Long> userIds, String templateNo, Long memberPushId,Long pushJobId) {
        log.info("保存用户推送消息到表阶段开始！");
        int size = userIds.size();
        //总共要发送的条数
        int batchSize=1000;
        int times = size / batchSize + 1;
        for (int j = 0; j < times; j++) {
            List<PushMessageEntity> pushMessageEntities = new ArrayList<>();
            for (int i = j*batchSize; i < ((j+1) * batchSize)&&i<size; i++) {
                pushMessageEntities.add(PushMessageEntity.builder()
                        .status(0)
                        .isDeleted(false)
                        .memberId(userIds.get(i))
                        .pushJobRecordId(pushJobId)
                        .memberPushId(memberPushId)
                        .uniformTemplateId(templateNo)
                        .build());
            }
            if (CollectionUtils.isNotEmpty(pushMessageEntities)) {
                log.info("本次插入数据量为:{}",pushMessageEntities.size());
                pushMessageMapper.insertPushMessageEntityList(pushMessageEntities);
            }
        }
        log.info("分批保存用户推送消息到表阶段结束！");
    }
    /**
     * 循环发送必更新消息
     *
     * @author frank
     * @date 2019-06-12 14:57
     **/
    @Override
    public void sendAndUpdateMemberMessageRecord(Long pushJobId,Integer triggerChannel) {
        log.info("消息推送阶段开始！");
        List<PushMessageEntity> list;
        do {
            List<Long> userIds=new ArrayList<>();
            List<Long> ids=new ArrayList<>();
            String templateNo="";
            list = pushMessageMapper.findNoPushMessageByStatusAndJobId(pushJobId,1000);
            for (PushMessageEntity pushMessageEntity:list) {
                ids.add(pushMessageEntity.getId());
                templateNo=pushMessageEntity.getUniformTemplateId();
                userIds.add(pushMessageEntity.getMemberId());
            }
            String batchNo;
            if(memberPushSwitch==null){
                log.info("发送开关状态为空，不发送！更新固定批次号！");
                batchNo="123456789";
            }else{
                if (Integer.valueOf(1).equals(memberPushSwitch)){
                    log.info("发送开关状态为开");
                    if (CollectionUtils.isNotEmpty(userIds)) {
                        switch (TriggerChannelEnum.getByType(triggerChannel)){
                            case APPPUSH:
                                batchNo = appPushMessageService.sendAppPushMessage(userIds, templateNo, new ArrayList<>());
                                break;
                            case SMS:
                                batchNo=appPushMessageService.sendSmsPushMessage(userIds,templateNo,new ArrayList<>());
                                break;
                            case WECHAT:
                                batchNo=appPushMessageService.sendWeChatMpPushMessage(userIds,templateNo,new ArrayList<>());
                                break;
                                default:
                                batchNo="无此推送类型";
                                    break;
                        }

                    }else{
                        batchNo="";
                    }
                }else{
                    log.info("发送开关状态为关，不发送！更新固定批次号！");
                    batchNo="123456789";
                }
            }
            if (batchNo==null){
                throw new UmpException("dubbo 消息发送异常！");
            }
            if (CollectionUtils.isNotEmpty(ids)) {
                pushMessageMapper.updatePushMessageByIdsAndBatchNo(ids, batchNo);
            }
        }while (list.size()==1000);
        log.info("消息推送阶段结束！");
    }
    @Override
    public List<Long> getUserList(List<Long> crowdIds, Long shard, Integer index, boolean abTestFlag, double rate,Integer triggerChannel) {
        //考虑到自定义人群包和标签人群包组合之后用户还可以出现重复，所以此处用set去重
        Set<Long> memberSet = new HashSet<>();
        List<Long> memberList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(crowdIds)) {
            List<CrowdEntity> tagList = new ArrayList<>();
            List<Long> customList = new ArrayList<>();
            List<CrowdEntity> crowdEntities = crowdMapper.selectByIds(crowdIds);
            //将自定义人群包和标签人群包区分出来，便于sql查询条件的组装
            if (CollectionUtils.isNotEmpty(crowdEntities)) {
                for (CrowdEntity item : crowdEntities) {
                    if ("1".equals(item.getCrowdCreateType())) {
                        tagList.add(item);
                    } else {
                        customList.add(item.getId());
                    }
                }
            }
            if (CollectionUtils.isNotEmpty(customList)) {
                //分片获取自定义人群
                List<Long> customUsers = crowdCustomMapper.findCrowdCustomShard(customList, shard, index);
                memberSet.addAll(customUsers);
            }
            //分片获取标签人群
            if (CollectionUtils.isNotEmpty(tagList)) {
                String sql = getSqlByTagCrowds(tagList)+getAllUserSqlByTriggerChannel(triggerChannel);
                List<Long>  tagUsers = tagValueService.getUsers("MOD(member_id," + shard + ")=" + index + "  AND " + sql);
                memberSet.addAll(tagUsers);
            }
        }
        //处理灰度
        if (abTestFlag) {
            Double temp = (new Double(memberSet.size())).doubleValue() * rate;
            int max = temp.intValue();
            int j = 0;
            for (Long item : memberSet) {
                if (j < max) {
                    memberList.add(item);
                    j++;
                }
            }
        }else{
            memberList.addAll(memberSet);
        }
        return memberList;
    }

    private String getAllUserSqlByTriggerChannel(Integer triggerChannel){
        String sql;
        switch (TriggerChannelEnum.getByType(triggerChannel)){
            case APPPUSH:
                sql = " and 1=1 and is_push_flag=1 ";
                break;
            case SMS:
                sql = " and 1=1 and phone is not null";
                break;
            case WECHAT:
                sql = " and 1=1 and is_oyo_wechat_fans=1";
                break;
            default:
                sql = " and 1=1";
                break;
        }
        return sql;
    }

    public List<Long> getAllUserList(Long shard, Integer index, boolean abTestFlag, double rate,Integer triggerChannel){
        List<Long> tagUsers = tagValueService.getUsers("MOD(member_id," + shard + ")=" + index + getAllUserSqlByTriggerChannel(triggerChannel));
        List<Long> userIds=new ArrayList<>();
        //处理灰度
        if (abTestFlag) {
            int j = 0;
            Double realTotal = tagUsers.size() * rate;
            int max = realTotal.intValue();
            for (Long item : tagUsers) {
                if (j < max) {
                    userIds.add(item);
                    j++;
                }
            }
        }
        return userIds;
    }
    @Override
    public Long countAllUserList(Integer triggerChannel){
        Long countNum = tagValueService.countNum("1=1 "+getAllUserSqlByTriggerChannel(triggerChannel));
        return countNum;
    }

    @Override
    public void processPersonasPush(PushEntity pushEntity,Long pushJobId,Integer triggerChannel) {
        log.info("push 任务执行开始！");
        PushRuleEntity pushRuleEntity = pushRuleMapper.selectPersonasRuleById(pushEntity.getRule());
        if (pushRuleEntity == null) {
            log.error("没有查询到相应的圈定规则！");
            throw new UmpException("没有查询到相应的圈定规则");
        }
        PushBO.TargetCrowdConfig targetCrowdConfig = gson.fromJson(pushRuleEntity.getRuleDetail(), PushBO.TargetCrowdConfig.class);
        long totalUsers=0;
        boolean abTest=targetCrowdConfig.getGrayFlag().equals(1)?true:false;
        Double rate=new Double(0);
        if (abTest) {
            rate = targetCrowdConfig.getGrayPercent() / 100.0;
        }
        if (targetCrowdConfig.getTargetCrowdType()==1){
            Long messageNum=pushMessageMapper.countPushMessageByJobId(pushJobId);
            if (messageNum>0){
                return;
            }
            totalUsers = countAllUserList(triggerChannel);
            if (totalUsers<1){
                log.info("总人数小于1，直接返回");
                return;
            }
            log.info("全量发送job编号为{},总推送人数为{}", pushJobId, totalUsers);
            long shard = (totalUsers / 20000) + 1;
            for (int i = 0; i < shard; i++) {
                log.info("执行分片id为：{}", i);
                List<Long> shardIds = getAllUserList(shard, i, abTest, rate,triggerChannel);
                log.info("执行插入分片id为：{},插入数据量为:{}", i, shardIds.size());
                saveMemberMessageRecord(shardIds, pushEntity.getUniformTemplateId(), pushEntity.getId(), pushJobId);
            }
            sendAndUpdateMemberMessageRecord(pushJobId,triggerChannel);
        }else{
            Long messageNum=pushMessageMapper.countPushMessageByJobId(pushJobId);
            if (messageNum>0){
                return;
            }
            if (CollectionUtils.isEmpty(targetCrowdConfig.getCrowds())){
                log.error("人群ids为空，不发送！！");
                throw new UmpException("没有查询到相应的圈定规则");
            }
            totalUsers = getUsersQtyByCrowdIds(targetCrowdConfig.getCrowds(),triggerChannel);
            if (totalUsers<1){
                log.info("总人数小于1，直接返回");
                return;
            }
            log.info("标签发送job编号为{},总推送人数为{}", pushJobId, totalUsers);
            long shard = (totalUsers / 20000) + 1;
            for (int i = 0; i < shard; i++) {
                log.info("执行分片id为：{}", i);
                List<Long> shardIds = getUserList(targetCrowdConfig.getCrowds(), shard, i, abTest, rate,triggerChannel);
                log.info("执行插入分片id为：{},插入数据量为:{}", i, shardIds.size());
                saveMemberMessageRecord(shardIds, pushEntity.getUniformTemplateId(), pushEntity.getId(), pushJobId);
            }
            sendAndUpdateMemberMessageRecord(pushJobId,triggerChannel);
        }
    }

    @Override
    public String getWhereStatement(String tagDetail) {
        JsonArray jsonArray;
        try {
            jsonArray = new JsonParser().parse(tagDetail).getAsJsonArray();
        }catch (JsonSyntaxException e){
            log.info("json参数解析异常!");
            throw new UmpException("参数解析异常");
        }
        return paramSqlWhereStatement(jsonArray, jsonArray.size());
    }

    @Override
    public List<TemplateBo> getTemplateBoList(Integer type) {
        List<TemplateBo> list=new ArrayList<>();
        List<PushTemplateService.TemplateInfo> templateInfos=appPushTemplateService.getTemplateList().stream().filter(item->item.getTemplateType().equals(type)).collect(Collectors.toList());
        for (PushTemplateService.TemplateInfo item:templateInfos) {
            TemplateBo templateBo=new TemplateBo();
            BeanUtils.copyProperties(item,templateBo);
            list.add(templateBo);
        }
        return list;
    }


    private String paramSqlWhereStatement(JsonArray jsonArray, Integer num) {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < num; i++) {
            JsonObject item = jsonArray.get(i).getAsJsonObject();
            Integer relationValue = item.get("relationValue").getAsInt();
            String relationValueStr=" AND";
            if (!relationValue.equals(1)) {
                relationValueStr=" OR";
            }
            if (i>0) {
                stringBuilder = new StringBuilder(" (").append(stringBuilder.toString());
                stringBuilder.append(getWhereStatement(item));
                stringBuilder.append(" )");
            }else{
                stringBuilder.append(getWhereStatement(item));
            }
            if (i>=0){
                if (num!=1&&i!=(num-1)){
                    stringBuilder.append(relationValueStr);
                }
            }
        }
        log.info(stringBuilder.toString());
        return stringBuilder.toString();
    }

    private String getWhereStatement(JsonObject item) {
        StringBuilder stringBuilder = new StringBuilder();
        String tagSelectValue = item.get("tagSelectValue").getAsString();
        String tagOperatorValue = item.get("tagOperatorValue").getAsString();
        stringBuilder.append(" ");
        stringBuilder.append("member_dim.");
        stringBuilder.append(tagSelectValue);
        stringBuilder.append(" ");
        stringBuilder.append(tagOperatorValue);
        Integer tagType = item.get("tagType").getAsInt();
        switch (tagType) {
            case 1:
                JsonArray jsonElements=item.get("tagValueSelectValue").getAsJsonArray();
                stringBuilder.append("(");
                Iterator<JsonElement> iterator=jsonElements.iterator();
                List<String> strList=new ArrayList<>();
                while (iterator.hasNext()){
                    strList.add("\'"+iterator.next().getAsString()+"\'");
                }
                stringBuilder.append(StringUtils.join(strList,","));
                stringBuilder.append(")");
                break;
            case 2:
            case 4:
            case 6:
                String tagValueSelectValueStr = item.get("tagValueSelectValue").getAsString();
                stringBuilder.append("\'" + tagValueSelectValueStr + "\'");
                break;
            case 3:
            case 5:
                String tagValueSelectValueNum = item.get("tagValueSelectValue").getAsString();
                stringBuilder.append(tagValueSelectValueNum);
                break;
            default:
                break;
        }
        return stringBuilder.toString();
    }

}
