package com.oyo.ump.member.service.impl;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.oyo.ump.member.common.constants.RedisConstants;
import com.oyo.ump.member.dal.dao.HotelMapper;
import com.oyo.ump.member.dal.model.HotelEntity;
import com.oyo.ump.member.service.HotelService;
import com.oyo.ump.member.service.RedisService;
import com.oyo.ump.member.service.bo.HotelBO;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @Author Dong
 * @Classname HotelServiceImpl
 * @Description 酒店接口实现类
 * @Date 2019-03-15 11:35
 */
@Service
@Slf4j
public class HotelServiceImpl implements HotelService {
    public static List<HotelBO> HOTEL_CACHE_LIST = Lists.newArrayList();
    @Autowired
    private HotelMapper hotelMapper;
    @Autowired
    private RedisService redisService;
    private static final int LIVE_TIME = 60 * 60 * 3;

    @Override
    public List<HotelBO> getHotelList() {

        return HOTEL_CACHE_LIST;
    }

    /**
     * 查询参与活动的酒店列表
     *
     * @param hotelIds
     * @return java.util.List<com.oyo.ump.member.service.bo.HotelBO>
     */
    @Override
    public List<HotelBO> getSalesHotel(List<Long> hotelIds) {
        List<HotelBO> result = Lists.newArrayList();
        Map<Long, Boolean> hotelMap = isMemberHotel(hotelIds);
        hotelMap.forEach((hotelId, isMember) -> {
            if (isMember) {
                HotelBO hotelBO = new HotelBO();
                hotelBO.setHotelId(hotelId);
                result.add(hotelBO);
            }
        });

        return result;

    }

    /**
     * @param hotelList
     * @return
     */
    @Override
    public Map<Long, Boolean> isMemberHotel(List<Long> hotelList) {
        Map<Long, Boolean> result = Maps.newHashMap();
        List<Long> cacheList = Lists.newArrayList();
        List<Long> needDbQueryList = Lists.newArrayList();
        List<String> keyList = hotelList.stream().map(hotelId -> RedisConstants.MEMBER_HOTEL + hotelId).collect(Collectors.toList());
        List<Object> objectList = redisService.mGet(keyList);
        if (CollectionUtils.isNotEmpty(objectList)) {
            objectList.stream().filter(hotelVoStr -> hotelVoStr != null).forEach(hotelVoStr -> {
                HotelCacheVO hotelCacheVO = JSON.parseObject(hotelVoStr.toString(), HotelCacheVO.class);
                if (hotelCacheVO != null) {
                    cacheList.add(hotelCacheVO.getHotelId());
                    result.put(hotelCacheVO.getHotelId(), hotelCacheVO.isMember());
                }
            });
        }
        hotelList.forEach(hotelId -> {
            if (!cacheList.contains(hotelId)) {
                needDbQueryList.add(hotelId);
            }
        });
        if (CollectionUtils.isNotEmpty(needDbQueryList)) {
            List<HotelEntity> hotelEntityList = hotelMapper.getSalesHotel(Lists.newArrayList(needDbQueryList));
            Map<Long, HotelEntity> entityMap = convert2EntityMap(hotelEntityList);
            needDbQueryList.forEach(hotelId -> {
                result.put(hotelId, entityMap.containsKey(hotelId));
                redisService.setNXValue(RedisConstants.MEMBER_HOTEL + hotelId, generateCache(hotelId, entityMap.containsKey(hotelId)), LIVE_TIME);
            });
        }
        return result;
    }

    /**
     * hotelId与entity的map映射
     *
     * @param hotelEntityList
     * @return
     */
    private Map<Long, HotelEntity> convert2EntityMap(List<HotelEntity> hotelEntityList) {
        Map<Long, HotelEntity> map = Maps.newHashMap();
        if (CollectionUtils.isNotEmpty(hotelEntityList)) {
            hotelEntityList.forEach(hotelEntity -> {
                if (hotelEntity != null) {
                    map.put(hotelEntity.getHotelId(), hotelEntity);
                }
            });
        }
        return map;
    }

    /**
     * 增加会员酒店
     *
     * @param hotelId
     * @param cityId
     */
    @Override
    public void addMemberHotel(Long hotelId, Integer cityId) {
        try {
            if (isMemberHotel(hotelId)) {
                return;
            }
            hotelMapper.insert(hotelId, cityId);
            redisService.setNXValue(RedisConstants.MEMBER_HOTEL + hotelId, generateCache(hotelId, true), LIVE_TIME);
        } catch (Exception e) {
            log.error("增加会员酒店异常hotelId:{}", hotelId, e);
        }
    }


    private String generateCache(Long hotelId, Boolean isMember) {
        HotelCacheVO hotelCacheVO = new HotelCacheVO();
        hotelCacheVO.setHotelId(hotelId);
        hotelCacheVO.setMember(isMember);
        return JSON.toJSONString(hotelCacheVO);

    }

    @Data
    public static class HotelCacheVO implements Serializable {
        private static final long serialVersionUID = 1406219191296852841L;
        private Long hotelId;
        private boolean member;
    }

}
