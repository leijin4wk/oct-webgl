package com.oyo.ump.member.service.enums;

/**
 * 人群类型
* @author leijin
* @date 2019-10-30 10:45
**/
public enum TargetCrowdTypeEnum {

    AllUser(1,"全部用户"),

    DefineCrowd(3,"自定义人群"),

    SelectCrowd(5,"已有人群包"),

    UploadCrowd(4,"上传人群"),

    MuseCrowd(6,"apollo用户"),

    NoRegisterCrowd(7,"未注册人群");

    private Integer type;
    private String name;

    public Integer getType() {
        return type;
    }
    public String getName() {
        return name;
    }
    TargetCrowdTypeEnum(Integer type, String name){
        this.name=name;
        this.type=type;
    }
}
