package com.oyo.ump.member.service.enums;

public enum PointTypeEnum {
    CONSUME_POINT("1","消费鸥币"),
    AWARD_POINT("2","奖励鸥币"),
    ACTIVITY_POINT("3","活动鸥币");

    private final String type;
    private final String name;

    public String getType() {
        return type;
    }
    public String getName() {
        return name;
    }
    PointTypeEnum(String type, String name){
     this.name=name;
     this.type=type;
    }
}
