package com.oyo.ump.member.service.impl;

import com.alibaba.fastjson.JSON;
import com.dianping.cat.Cat;
import com.google.common.collect.Maps;
import com.oyo.common.response.BaseResponse;
import com.oyo.ledger.client.response.CostDataVO;
import com.oyo.ump.member.common.constants.MemberConstants;
import com.oyo.ump.member.dal.dao.MemberGradeDetailMapper;
import com.oyo.ump.member.dal.dao.MemberGradeMapper;
import com.oyo.ump.member.dal.model.MemberGradeDetailEntity;
import com.oyo.ump.member.dal.model.MemberGradeEntity;
import com.oyo.ump.member.integration.service.costcenter.CostCenterRemoteService;
import com.oyo.ump.member.integration.service.user.OyoUser;
import com.oyo.ump.member.integration.service.wallet.PointsRemoteService;
import com.oyo.ump.member.service.BonusGainRuleService;
import com.oyo.ump.member.service.ChangeGradeService;
import com.oyo.ump.member.service.MemberInfoService;
import com.oyo.ump.member.service.bo.ChangeGradeBO;
import com.oyo.ump.member.service.bo.MemberInfoBO;
import com.oyo.ump.member.service.dto.BonusGainRuleDTO;
import com.oyo.ump.member.service.dto.MemberRegisterDTO;
import com.oyo.ump.member.service.utils.BusinessRetry;
import com.oyo.wallet.client.req.PointsAddDTO;
import com.oyo.wallet.client.req.PointsDetailDTO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import static com.oyo.ump.member.common.constants.DateformateConstants.DATE_FORMAT;
import static com.oyo.ump.member.common.constants.DateformateConstants.SHORT_DATE_FORMAT;

/**
 * @Description:业务重试类,加上需要重试的方法
 * @Author: fang
 * @create: 2019-12-18
 **/
@Component
@Slf4j
public class RetryBusinessService {
    @Autowired
    private PointsRemoteService pointsRemoteService;
    @Autowired
    private MemberGradeMapper memberGradeMapper;
    @Autowired
    private MemberGradeDetailMapper memberGradeDetailMapper;
    @Autowired
    private MemberInfoService memberInfoService;
    @Autowired
    private ChangeGradeService changeGradeService;

    public BaseResponse<Boolean> sendPoint(PointsAddDTO pointsAddDTO){
        return sendPointRetry(pointsAddDTO);
    }

    /**
     * 积分发放 重试
     * @param pointsAddDTO
     * @return
     */
    @BusinessRetry(type = 1,field = "code",result = {"000","100001"},retryMethod = "sendPoint")
    public BaseResponse<Boolean> sendPointRetry(PointsAddDTO pointsAddDTO){
        return pointsRemoteService.addPoints(pointsAddDTO);
    }
    public Boolean register(MemberRegisterDTO memberRegisterDTO){
        return registerRetry(memberRegisterDTO);
    }
    @BusinessRetry(type = 2,retryMethod = "register")
    @Transactional(rollbackFor = Exception.class)
    public Boolean registerRetry(MemberRegisterDTO memberRegisterDTO){
        int initGradeId=1;
        if(MemberConstants.OYO_JP_TENANT.equals(memberRegisterDTO.getTenant())){
            MemberGradeEntity entity = memberGradeMapper.getMemberGradeByUserId(memberRegisterDTO.getUserId(),memberRegisterDTO.getTenant());
            if(entity!=null){
                log.info("用户id{}已经存在",entity.getUserId());
                Cat.logMetricForCount("OYO_JP_USER_REPEAT_REGISTER");
                return true;
            }
            initGradeId=memberRegisterDTO.getGradeId();
        }
        if(memberRegisterDTO.getPlatform()!=null&&MemberConstants.FEIZHU_PLATEFORM.equals(memberRegisterDTO.getPlatform())){
            initGradeId =memberRegisterDTO.getGradeId();
            MemberInfoBO memberInfoBO = memberInfoService.getMemberInfoFromDB(memberRegisterDTO.getUserId(),MemberConstants.OYO_TENANT);
            //如果已经是会员则进行同步
            if(memberInfoBO!=null&&memberInfoBO.getUserId()!=null){
                if(memberInfoBO.getGradeId()<memberRegisterDTO.getGradeId()){
                    changeGrade(memberRegisterDTO.getGradeId(),memberInfoBO.getGradeId(),memberRegisterDTO.getUserId(),MemberConstants.OYO_TENANT,null,MemberConstants.UPDATE_GRADE_BY_NATURE);
                }
                return true;
            }
        }
        MemberGradeEntity memberGradeEntity = new MemberGradeEntity();
        memberGradeEntity.setUserId(memberRegisterDTO.getUserId());
        memberGradeEntity.setPreviousGradeId(0);
        memberGradeEntity.setGradeId(initGradeId);
        memberGradeEntity.setUpdateRuleType(MemberConstants.UPDATE_GRADE_BY_NATURE);
        memberGradeEntity.setTenant(memberRegisterDTO.getTenant());
        memberGradeEntity.setValidTime(memberRegisterDTO.getValidTime());
        memberGradeMapper.insert(memberGradeEntity);
        MemberGradeDetailEntity memberGradeDetailEntity = new MemberGradeDetailEntity();
        memberGradeDetailEntity.setUserId(memberRegisterDTO.getUserId());
        memberGradeDetailEntity.setPreviousGradeId(0);
        memberGradeDetailEntity.setCurrentGradeId(initGradeId);
        memberGradeDetailEntity.setChangeType(MemberConstants.UPDATE_GRADE_BY_NATURE);
        memberGradeDetailEntity.setCreateTime(new Date());
        memberGradeDetailEntity.setTenant(memberRegisterDTO.getTenant());
        memberGradeDetailMapper.addMemberGradeDetail(memberGradeDetailEntity);
        memberInfoService.asynProess(memberRegisterDTO.getUserId(),memberRegisterDTO.getTenant());
        return true;
    }
    private void changeGrade(Integer gradeId, Integer preGradeId,Long userId,String tenant,Date validTime,Integer rule) {
        ChangeGradeBO changeGradeBO =new ChangeGradeBO();
        changeGradeBO.setGradeId(gradeId);
        changeGradeBO.setPreviousGradeId(preGradeId);
        changeGradeBO.setUserId(userId);
        changeGradeBO.setChangeType(rule);
        changeGradeBO.setTenant(tenant);
        changeGradeBO.setValidTime(validTime);
        changeGradeService.changeGrade(changeGradeBO);
    }
}
