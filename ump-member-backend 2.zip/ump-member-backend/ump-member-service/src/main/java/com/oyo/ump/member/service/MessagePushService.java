package com.oyo.ump.member.service;

import com.oyo.ump.member.dal.model.CrowdEntity;
import com.oyo.ump.member.dal.model.PushEntity;
import com.oyo.ump.member.service.bo.TemplateBo;

import java.util.List;

public interface MessagePushService {

    /**
     * 通过人群id获取人数
    * @author frank
    * @date 2019-06-11 10:45
    **/
    Long getUsersQtyByCrowdId(Long crowdId);

    /**
     * 根据人群id 列表获取用户总数
    * @author frank
    * @date 2019-06-11 12:00
    **/
    Long getUsersQtyByCrowdIds(List<Long> crowdIds,Integer triggerChannel);
    /**
     * 根据两个人群id列表的差集获取用户总数
     * @param crowdIds1
     * @param crowdIds2
     * @return java.lang.Long
     */
    Long getUsersQtyByCrowdIdsDifference(List<Long> crowdIds1, List<Long> crowdIds2);
    /**
     * 获取预览人群的数量list
     * @Param tagDetail json字符串
    * @author frank
    * @date 2019-06-11 10:45
    **/
    List<Long> getTagPreviewCrowd(String tagDetail);

    /**
     * 通过 crowdIds 查询分块查询用户
    * @author frank
    * @date 2019-06-11 21:04
    **/
    List<Long> getUserList(List<Long> crowdIds, Long shared, Integer index,boolean abTestFlag,double rate,Integer triggerChannel);

    /**
     * 获取模板list
    * @author frank
    * @date 2019-06-12 19:34
    **/
    List<TemplateBo>  getTemplateBoList(Integer type);

    /**
     *  对于单个用户画像类型的push做处理
     * @author frank
     * @param triggerChannel 发送渠道（微信，push，短信等）
     * @date 2019-06-13 11:31
     **/
     void processPersonasPush(PushEntity pushEntity,Long pushJobId,Integer triggerChannel);


     /**
      * 通过tagjson 获取where sql
     * @author frank
     * @date 2019-06-15 13:51
     **/
     String getWhereStatement(String tagDetail);



    Long countAllUserList(Integer triggerChannel);


    void  sendAndUpdateMemberMessageRecord(Long jobId,Integer triggerChanne);

    /**
     * 通过人群id获取人群sql
    * @author leijin
    * @date 2019-09-16 10:36
    **/
   String getSqlByTagCrowds(List<CrowdEntity> tagCrowds);

}
