package com.oyo.ump.member.service.push;

public class PushSender {
}
