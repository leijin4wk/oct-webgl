package com.oyo.ump.member.service;

import com.oyo.ump.member.service.bo.PushEventDefineBo;
import com.oyo.ump.member.service.bo.PushTemplateMapBo;

import java.util.List;

/**
 * push模板和对应的映射字段配置service
* @author frank
* @date 2019-07-29 10:43
**/
public interface PushTemplateMapService {
    /**
     * 获取模板映射list
    * @author frank
    * @date 2019-07-30 10:57
    **/
    List<PushTemplateMapBo> getPushTemplateMapBoList();
    /**
     * 通过id获取模板映射
    * @author frank
    * @date 2019-07-30 10:58
    **/
    PushTemplateMapBo getPushTemplateById(Long id);
    /**
     * 修改模板映射
    * @author frank
    * @date 2019-07-30 10:58
    **/
    void updatePushTemplateMap(PushTemplateMapBo pushTemplateMapBo);
    /**
     *  插入模板映射
    * @author frank
    * @date 2019-07-30 10:59
    **/
    void insertPushTemplateMap(PushTemplateMapBo pushTemplateMapBo);

    /**
     * 获取事件定义list
    * @author frank
    * @date 2019-07-30 10:59
    **/
    List<PushEventDefineBo> getPushEventDefineBoList();
    /**
     * 新增事件定义
    * @author frank
    * @date 2019-07-30 10:59
    **/
    void insertPushEventDefine(PushEventDefineBo pushEventDefineBo);
    /**
     * 更新事件定义
    * @author frank
    * @date 2019-07-30 11:00
    **/
    void updatePushEventDefine(PushEventDefineBo pushEventDefineBo);


    PushEventDefineBo findPushEventDefineById(Long id);
}
