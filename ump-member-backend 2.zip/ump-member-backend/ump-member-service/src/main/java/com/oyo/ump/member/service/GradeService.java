package com.oyo.ump.member.service;

import com.oyo.ump.member.service.bo.GradeInfoBO;
import java.util.List;

import static com.oyo.ump.member.common.constants.MemberConstants.OYO_TENANT;

/**
 * @Description: 会员等级接口
 * @Author: fang
 * @create: 2019-03-13
 **/
public interface GradeService {
     default List<GradeInfoBO> getGradeInfoList(){
          return getGradeInfoList(OYO_TENANT);
     }
     GradeInfoBO getGradeByGradeId(Integer gradeId);

     List<GradeInfoBO> getGradeInfoList(String tenant);

}
