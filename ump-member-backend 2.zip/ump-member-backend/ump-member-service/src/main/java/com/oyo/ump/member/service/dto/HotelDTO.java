package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @Classname HotelDTO
 * @Description 酒店返回信息
 * @Date 2019-03-15 11:29
 * @author Dong
 */
@Data
public class HotelDTO implements Serializable {
    private List<HotelInfo> hotelInfoList;
    @Data
    public static class HotelInfo{
        private Integer id;
        private Long hotelId;
        private Integer cityId;
    }
}
