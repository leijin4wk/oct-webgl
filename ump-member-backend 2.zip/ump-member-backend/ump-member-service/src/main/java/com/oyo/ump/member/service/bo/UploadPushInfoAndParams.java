package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 上传人群配置类
* @author leijin
* @date 2019-11-20 09:54
**/
@Data
public class UploadPushInfoAndParams  {

    //基础参数
    private Long pushId;

    public Integer triggerType;

    private Integer triggerChannel;

    private PushBO.TargetCrowdConfig targetCrowdConfig;

    private String  templateNum;

    private Long  templateLongLink;

    private String extraParameter;

    private Long start;

    private Long end;

    private Integer intervalTime;

    //url 参数json串
    private List<PushTemplateParamBo> urlParamList;
    //内容参数json串
    private List<PushTemplateParamBo> contentParamList;

    //拼接参数

    private String modelCondition;

    private String channelCondition;

    private Set<String> columns;

    private Set<String> mqKeys;

    private Map<String,String> extraMap;

    private String crowdsCondition;

    private Integer urlType;

    private String baseUrl;

    private String deeplinkUrl;

    private String generatedSQL;

    private String countSQL;



}
