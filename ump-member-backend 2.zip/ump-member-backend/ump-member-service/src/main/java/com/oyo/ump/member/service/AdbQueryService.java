package com.oyo.ump.member.service;

import com.oyo.ump.member.service.dto.UserDetailPageResponseDTO;
import com.oyo.ump.member.service.dto.UserEventPageResponseDTO;
import com.oyo.ump.member.service.dto.UserTradePageResponseDTO;

import java.util.Map;

/**
 * adb 查询接口
 * @author fang
 */
public interface AdbQueryService {
    /**
     * 查询用户基础信息
     * @param userId
     * @return
     */
    Map<String,Object> queryUserBasicInfo(Long userId);

    /**
     * 查询用户事件信息
     * @param userId
     * @param startTime
     * @param endTime
     * @param page
     * @param num
     * @return
     */
    UserEventPageResponseDTO queryUserEvent(Long userId, String startTime, String endTime, Integer page, Integer num);

    /**
     * 获取交易信息
     * @param userId
     * @param startTime
     * @param endTime
     * @param page
     * @param num
     * @return
     */
    UserTradePageResponseDTO queryTradeEvent(Long userId, String startTime, String endTime, Integer page, Integer num);

    /**
     * 获取人群列表
     * @param crowdId
     * @param pageSize
     * @param pageNum
     * @return
     */
    UserDetailPageResponseDTO queryUserList(Long crowdId, Integer pageSize, Integer pageNum);
}
