package com.oyo.ump.member.service;

import com.oyo.ump.member.service.bo.GradePrivilegeBO;

import java.util.List;

/**
 * @Description: 等级权益接口
 * @Author: fang
 * @create: 2019-03-22
 **/
public interface PrivilegeService {
    List<GradePrivilegeBO> getGradePrivilegeList();
    GradePrivilegeBO  getGradePrivilegeByGradeId(Integer gradeId);

}
