package com.oyo.ump.member.service;

import com.oyo.ump.member.service.bo.PushJobRecordBO;

/**
 * @author Dong
 * @Description
 * @Date 2020-01-03
 */
public interface PushJobRecordService {
    Long insert(PushJobRecordBO pushJobRecordBO);
    void updateStatus(Long jobId, Integer status);
}
