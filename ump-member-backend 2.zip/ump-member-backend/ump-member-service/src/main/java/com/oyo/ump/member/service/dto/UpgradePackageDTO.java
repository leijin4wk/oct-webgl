package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @Classname UpgradePackageDTO
 * @Description 升级包信息返回对象
 * @Date 2019-03-14 17:56
 * @author Dong
 */
@Data
public class UpgradePackageDTO implements Serializable {
    private List<UpgradePackageInfo> upgradePackageInfoList;
    @Data
    public static class UpgradePackageInfo{
        private Integer id;
        /**
         * 升级包id(商品中心维护)
         */
        private String packageCode;
        /**
         * 升级前的等级id
         */
        private Integer gradeId;
        /**
         * 升级后的等级名
         */
        private String gradeName;
        /**
         * 升级后的等级id
         */
        private Integer upgradeId;
        /**
         * 升级后的等级名
         */
        private String upgradeName;
        /**
         * 前台分佣
         */
        private BigDecimal frontCommission;
        /**
         * 业主分佣
         */
        private BigDecimal ownerCommission;
        /**
         * oyo分佣
         */
        private BigDecimal oyoCommission;
        /**
         * 升级包状态，1 已启用；0 未启用
         */
        private Boolean status;
        /**
         * 升级包类型，0 购买升级包；1 房晚数自然升级
         */
        private Integer packageType;
    }
}
