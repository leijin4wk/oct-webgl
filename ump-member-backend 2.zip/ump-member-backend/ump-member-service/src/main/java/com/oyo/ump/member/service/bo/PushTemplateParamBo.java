package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;

/**
 *
 * push模板参数实体
* @author leijin
* @date 2019-10-12 20:42
**/
@Data
public class PushTemplateParamBo implements Serializable {

    private String name;
    //参数来源类型  1：固定文本 2：系统参数
    private Integer type;
    //参数值
    private String value;

}
