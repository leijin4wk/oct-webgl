package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;
import java.util.*;

/**
 * 模板中参数相关的Bo
* @author leijin
* @date 2019-12-04 11:56
**/
@Data
public class ColumnAndMqParamBo implements Serializable {

    //url 参数json串
    private List<PushTemplateParamBo> urlParamList=new ArrayList<>();
    //内容参数json串
    private List<PushTemplateParamBo> contentParamList=new ArrayList<>();

    private List<KeyModelBo> contentKeysList=new ArrayList<>();

    private List<KeyModelBo> urlKeysList=new ArrayList<>();

    private Map<String,String> extraMap=new HashMap<>();

    private Long  templateLongLink;

    //最终的结果
    private Set<String> columns=new HashSet<>();

    private Set<String> mqKeys=new HashSet<>();

    private String baseUrl;

    private String deeplinkUrl;
}
