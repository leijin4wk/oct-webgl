package com.oyo.ump.member.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Maps;
import com.oyo.common.response.PagedResponse;
import com.oyo.ump.member.common.constants.MemberConstants;
import com.oyo.ump.member.common.enums.GradeRefreshRuleEnum;
import com.oyo.ump.member.dal.dao.MemberGradeConfigMapper;
import com.oyo.ump.member.dal.dao.MemberGradeMapper;
import com.oyo.ump.member.dal.model.MemberGradeEntity;
import com.oyo.ump.member.service.GradeService;
import com.oyo.ump.member.service.MemberIdentityListService;
import com.oyo.ump.member.service.UpgradePackageService;
import com.oyo.ump.member.service.bo.GradeInfoBO;
import com.oyo.ump.member.service.bo.MemberIdentityBO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;
import java.util.Map;

/**
 * @author Dong
 * @Classname MemberIdentityListServiceImpl
 * @Description 获取会员身份信息列表的实现类
 * @Date 2019-03-20
 */
@Service
@Slf4j
public class MemberIdentityListServiceImpl implements MemberIdentityListService {
    @Autowired
    private MemberGradeMapper memberGradeMapper;
    @Autowired
    private MemberGradeConfigMapper memberGradeConfigMapper;
    @Autowired
    private UpgradePackageService upgradePackageService;
    @Autowired
    private GradeService gradeService;
    private Map<String,Map<String,String>> REFRESH_RULE_MAP_MAP =Maps.newHashMap();


    /**
     * 身份列表有条件查询
     * @param params
     * @return com.oyo.ump.member.service.bo.MemberIdentityPageBO
     */
    @Override
    public PagedResponse<MemberIdentityBO> getMemberIdentityList(Map<String, Object> params) {
        List<MemberIdentityBO> memberIdentityBOList = Lists.newArrayList();
        PagedResponse<MemberIdentityBO> pagedResponse = new PagedResponse<>();
        int pageNum = Integer.parseInt(params.get("pageNum").toString());
        int pageSize = Integer.parseInt(params.get("pageSize").toString());

        // 如果刷新规则字段不空，解析刷新规则
        String refreshRule = params.get("refreshRule").toString();
        if(StringUtils.isNotBlank(refreshRule)) {
            GradeRefreshRuleEnum ruleEnum = GradeRefreshRuleEnum.getByCode(refreshRule);
            if (ruleEnum != null) {
                params.put("updateRuleType", ruleEnum.getUpdateRuleType());
                params.put("previousGradeId", ruleEnum.getPreviousId());
                params.put("gradeId", ruleEnum.getGradeId());
            }
        }

        PageHelper.startPage(pageNum, pageSize);
        try {
            List<MemberGradeEntity> memberGradeEntityList = memberGradeMapper.getMemberIdentityList(params);
            PageInfo<MemberGradeEntity> entityPageInfo = PageInfo.of(memberGradeEntityList);
            if(CollectionUtils.isNotEmpty(memberGradeEntityList)){
                convert2BOList(memberGradeEntityList, memberIdentityBOList);
            }
            pagedResponse.setPageSize(pageSize);
            pagedResponse.setTotalCount(entityPageInfo.getTotal());
            pagedResponse.setPageNum(pageNum);
            pagedResponse.setResult(memberIdentityBOList);
        }catch (Exception e){
            log.error("会员身份信息查询sql异常：MemberIdentityListServiceImpl",e);
        }

        return pagedResponse;

    }


    /**
     * 组合所有的等级刷新规则
     * @param
     * @return java.util.Map<java.lang.String,java.lang.String>
     */
    @Override
    public Map<String, String> getAllGrade(String tenant) {
        Map<String, String> gradeMap = Maps.newHashMap();
        GradeRefreshRuleEnum.getListByTenant(tenant).forEach(gradeRefreshRuleEnum -> {
            gradeMap.put(gradeRefreshRuleEnum.getCode(), gradeRefreshRuleEnum.getMsg());
        });
        return gradeMap;
    }

    /**
     * EntityList转化为BOList
     * @param entityList
     * @param memberIdentityBOList
     * @return void
     */
    private void convert2BOList(List<MemberGradeEntity> entityList, List<MemberIdentityBO> memberIdentityBOList) {

        if(CollectionUtils.isNotEmpty(entityList)){
            entityList.forEach(memberGradeEntity -> {

                MemberIdentityBO memberIdentityBO = new MemberIdentityBO();
                convert2BO(memberGradeEntity, memberIdentityBO);


                memberIdentityBOList.add(memberIdentityBO);
            });
        }
    }

    /**
     * Entity 转 BO
     * @param memberGradeEntity
     * @param memberIdentityBO
     * @return void
     */
    private void convert2BO(MemberGradeEntity memberGradeEntity, MemberIdentityBO memberIdentityBO) {
        GradeInfoBO gradeInfoBO = gradeService.getGradeByGradeId(memberGradeEntity.getGradeId());

        memberIdentityBO.setId(memberGradeEntity.getId());
        memberIdentityBO.setUserId(memberGradeEntity.getUserId());
        memberIdentityBO.setGradeId(memberGradeEntity.getGradeId());
        memberIdentityBO.setGradeName(gradeInfoBO.getGrade());
        // 拼装等级刷新规则
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(memberGradeEntity.getUpdateRuleType());
        if(MemberConstants.OYO_JP_TENANT.equals(memberGradeEntity.getTenant())&&memberGradeEntity.getPreviousGradeId()==0){
            stringBuilder.append("00");
        }else {
            stringBuilder.append(memberGradeEntity.getPreviousGradeId());
        }
        stringBuilder.append(memberGradeEntity.getGradeId());
        memberIdentityBO.setRefreshRule(stringBuilder.toString());
        memberIdentityBO.setRefreshTime(memberGradeEntity.getGradeUpdateTime());
        memberIdentityBO.setValidTime(memberGradeEntity.getValidTime());
        if(memberGradeEntity.getValidTime()==null){
            memberIdentityBO.setValidDays(-1);
        }else {
            memberIdentityBO.setValidDays(Long.valueOf(memberGradeEntity.getValidTime().toInstant().atZone(ZoneId.systemDefault()).toLocalDate().toEpochDay()-LocalDate.now().toEpochDay()).intValue());
        }
        memberIdentityBO.setUpgradeTotal(memberGradeEntity.getRoomNights());
        memberIdentityBO.setKeepTotal(memberGradeEntity.getRoomNights());

        if(gradeInfoBO.getNextGradeId() != null){
            // 存在下一等级，有升级目标无保级目标
            Integer upgradeTarget = gradeService.getGradeByGradeId(gradeInfoBO.getNextGradeId()).getRoomNights();
            memberIdentityBO.setUpgradeTarget(upgradeTarget);

            memberIdentityBO.setKeepTarget(0);
        }else {
            // 不存在下一等级，无升级目标有保级目标
            memberIdentityBO.setUpgradeTarget(0);
            Integer keepTarget = gradeInfoBO.getRelegationNights();
            memberIdentityBO.setKeepTarget(keepTarget);
        }

        memberIdentityBO.setRoomNights(memberGradeEntity.getRoomNights());
        memberIdentityBO.setNoshowNum(memberGradeEntity.getNoShow());
        memberIdentityBO.setUpdateTime(memberGradeEntity.getUpdateTime());
    }

}
