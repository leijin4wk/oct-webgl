package com.oyo.ump.member.service.impl;

import com.oyo.ump.member.common.beanutils.MapperWrapper;
import com.oyo.ump.member.dal.dao.TemplateParameterMapper;
import com.oyo.ump.member.dal.dao.TemplateUrlParameterMapper;
import com.oyo.ump.member.dal.model.TemplateParameterEntity;
import com.oyo.ump.member.dal.model.TemplateUrlParameterEntity;
import com.oyo.ump.member.service.PushTemplateParameterService;
import com.oyo.ump.member.service.bo.TemplateParameterBO;
import com.oyo.ump.member.service.bo.TemplateUrlParameterBO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Dong
 * @Classname PushTemplateParameterServiceImpl
 * @Description
 * @Date 2019-09-05
 */
@Service
@Slf4j
public class PushTemplateParameterServiceImpl implements PushTemplateParameterService {
    @Autowired
    TemplateUrlParameterMapper templateUrlParameterMapper;
    @Autowired
    TemplateParameterMapper templateParameterMapper;

    @Override
    public List<TemplateParameterBO> getAllParameterByType(String parameterName, Integer source) {
        List<TemplateParameterBO> resList = Lists.newArrayList();
        List<TemplateParameterEntity> entityList = templateParameterMapper.getAllParameterByType(parameterName, source);
        if(CollectionUtils.isNotEmpty(entityList)){
            resList = MapperWrapper.instance().mapList(entityList, TemplateParameterBO.class);
        }
        return resList;
    }


    @Override
    public List<TemplateUrlParameterBO> getAllUrlParameter(Integer urlType) {
        List<TemplateUrlParameterEntity> entityList = templateUrlParameterMapper.getAllUrlParameter(urlType);
        List<TemplateUrlParameterBO> bOList = Lists.newArrayList();
        if(CollectionUtils.isNotEmpty(entityList)){
            bOList = MapperWrapper.instance().mapList(entityList, TemplateUrlParameterBO.class);
        }
        return bOList;
    }

    @Override
    public List<TemplateUrlParameterBO> getAllUrlParameterByMiniAppId(String miniAppId) {
        List<TemplateUrlParameterEntity> entityList = templateUrlParameterMapper.getAllUrlParameterByMiniAppId(miniAppId);
        List<TemplateUrlParameterBO> bOList = Lists.newArrayList();
        if(CollectionUtils.isNotEmpty(entityList)){
            bOList = MapperWrapper.instance().mapList(entityList, TemplateUrlParameterBO.class);
        }
        return bOList;
    }


}
