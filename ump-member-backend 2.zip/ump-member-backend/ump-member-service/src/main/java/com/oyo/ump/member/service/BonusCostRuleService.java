package com.oyo.ump.member.service;

import com.oyo.ump.member.service.dto.BonusCostRuleDTO;

/**
 * @Classname BonusCostRuleService
 * @Description 积分消费规则业务接口
 * @Date 2019-03-15 16:08
 * @author Dong
 */
public interface BonusCostRuleService {
    /**
     * 获取所有的积分消耗规则DTO
     * @return com.oyo.ump.member.service.dto.BonusCostRuleDTO
     */
    BonusCostRuleDTO getCostRuleList();
}
