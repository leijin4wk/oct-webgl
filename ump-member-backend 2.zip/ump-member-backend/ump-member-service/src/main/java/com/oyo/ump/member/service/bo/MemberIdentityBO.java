package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author Dong
 * @Classname MemberIdentityBO
 * @Description 会员身份信息BO
 * @Date 2019-03-26
 */
@Data
public class MemberIdentityBO implements Serializable {
    private Long id;
    private Long userId;
    private String nickName;
    private String phone;
    private Integer gradeId;
    private String gradeName;
    private Date refreshTime;
    private Integer updateRuleType;
    private String refreshRule;
    /**
     * 会员等级有效期时间,null为无时间限制.
     */
    private Date validTime;
    private Integer validDays;

    private Integer roomNights;
    private Integer upgradeTotal;
    private Integer upgradeTarget;
    private Integer keepTotal;
    private Integer keepTarget;
    private Integer noshowNum;
    private Integer bonus;
    private String recentExpirationDate;
    private Date updateTime;
    private String platform;
    private String platformName;
    private String email;

}
