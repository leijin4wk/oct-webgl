package com.oyo.ump.member.service.bo;

import lombok.Data;
import java.io.Serializable;
import java.util.Date;

/**
 * @author Dong
 * @Classname CrowdPushIdBO
 * @Description
 * @Date 2019-06-04
 */
@Data
public class CrowdPushIdBO implements Serializable {
    private Long id;
    private Long crowdId;
    private String pushId;
    private String channelType;
    private Date createTime;
}
