package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.util.Date;

/**
 * @Description: 会员积分请求dto
 * @Author: fang
 * @create: 2019-04-04
 **/
@Data
public class MemberPointRequestDTO {
    private Long  userId;
    private String tenant;
    private Date fromDate;
    private Date toDate;
    private String	orderNo;
    private Integer pageNum;
    private Integer pageSize;
    private String queryType;

}
