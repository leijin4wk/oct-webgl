package com.oyo.ump.member.service.bo;

import lombok.Data;
import lombok.ToString;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author Dong
 * @Classname CrowdBO
 * @Description 人群BO
 * @Date 2019-06-04
 */
@Data
@ToString
public class PushJobRecordBO implements Serializable {
    private Long id;

    private Long memberPushId;

    private Date createTime;

    private Date updateTime;

    private Date sendTime;

    private Integer sendType;

    private Integer sendStatus;

    private String resultMessage;
}
