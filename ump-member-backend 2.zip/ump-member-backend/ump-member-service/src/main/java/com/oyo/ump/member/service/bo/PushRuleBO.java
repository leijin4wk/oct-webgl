package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author Dong
 * @Classname PushBO
 * @Description 事件推送BO
 * @Date 2019-05-06
 */
@Data
public class PushRuleBO implements Serializable {
    private Long id;
    private String delineationName;
    private Date createTime;
    private Date updateTime;
    private String ruleDetail;
    private Boolean isDeleted;
}
