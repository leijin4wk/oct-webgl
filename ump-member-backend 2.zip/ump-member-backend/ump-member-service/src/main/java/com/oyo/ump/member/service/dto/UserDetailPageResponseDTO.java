package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @Description: 人群列表
 * @Author: fang
 * @create: 2019-09-07
 **/
@Data
public class UserDetailPageResponseDTO implements Serializable {
    private List<UserInfo> memberInfoList;
    private Long total;
    private Integer pageNum;
    private Integer pageSize;

    @Data
    public static class UserInfo implements Serializable{
          private Long memberId;
          private String registerTime;
          private String firstAppTime;
          private String lastAppTime;
          private String dateCountAdvance;

    }

}
