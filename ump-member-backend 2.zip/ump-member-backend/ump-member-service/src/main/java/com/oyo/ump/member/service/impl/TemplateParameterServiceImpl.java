package com.oyo.ump.member.service.impl;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import com.oyo.ump.member.common.exception.UmpException;
import com.oyo.ump.member.dal.dao.TemplateParameterMapper;
import com.oyo.ump.member.dal.dao.TemplateUrlParameterMapper;
import com.oyo.ump.member.dal.model.TemplateParameterEntity;
import com.oyo.ump.member.dal.model.TemplateUrlParameterEntity;
import com.oyo.ump.member.service.TemplateParameterService;
import com.oyo.ump.member.service.bo.ColumnAndMqParamBo;
import com.oyo.ump.member.service.bo.KeyModelBo;
import com.oyo.ump.member.service.bo.PushInfoAndParams;
import com.oyo.ump.member.service.bo.PushTemplateParamBo;
import com.oyo.ump.member.service.enums.TemplateParamTypeEnum;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class TemplateParameterServiceImpl implements TemplateParameterService {
    @Autowired
    private TemplateParameterMapper templateParameterMapper;
    @Autowired
    private TemplateUrlParameterMapper templateUrlParameterMapper;
    @Override
    public ColumnAndMqParamBo buildColumnAndMqKeyParam(ColumnAndMqParamBo columnAndMqParamBo) {
        //内容参数获取
        if (CollectionUtils.isNotEmpty(columnAndMqParamBo.getContentParamList())) {
            List<Long> contentParamsIds = new ArrayList<>();
            for (PushTemplateParamBo item : columnAndMqParamBo.getContentParamList()) {
                if (TemplateParamTypeEnum.SYS_KEY.getType().equals(item.getType())) {
                    contentParamsIds.add(Long.valueOf(item.getValue()));
                }
            }
            if (CollectionUtils.isNotEmpty(contentParamsIds)) {
                Map<Long, String> valueMap = getKeyWordMap(columnAndMqParamBo, contentParamsIds);
                for (PushTemplateParamBo item : columnAndMqParamBo.getContentParamList()) {
                    if (TemplateParamTypeEnum.SYS_KEY.getType().equals(item.getType())) {
                        String value = valueMap.get(Long.parseLong(item.getValue()));
                        columnAndMqParamBo.getContentKeysList().add(new KeyModelBo(item.getName(), TemplateParamTypeEnum.SYS_KEY.getType(), value));
                    } else if (TemplateParamTypeEnum.TEXT.getType().equals(item.getType())) {
                        columnAndMqParamBo.getContentKeysList().add(new KeyModelBo(item.getName(), TemplateParamTypeEnum.TEXT.getType(), item.getValue()));
                    }
                }
            } else {
                for (PushTemplateParamBo item : columnAndMqParamBo.getContentParamList()) {
                    columnAndMqParamBo.getContentKeysList().add(new KeyModelBo(item.getName(), TemplateParamTypeEnum.TEXT.getType(), item.getValue()));
                }
            }
        }
        //url 参数获取
        Long linkId = columnAndMqParamBo.getTemplateLongLink();
        if (linkId != null) {
            //获取url长链接
            TemplateUrlParameterEntity templateUrlParameterEntity = templateUrlParameterMapper.selectById(linkId);
            columnAndMqParamBo.setBaseUrl(templateUrlParameterEntity.getUrlAddress());
            columnAndMqParamBo.setDeeplinkUrl(templateUrlParameterEntity.getDeeplinkUrl());
            //获取配置的url参数
            List<Long> linkParamsIds = new ArrayList<>();
            if (CollectionUtils.isNotEmpty(columnAndMqParamBo.getUrlParamList())) {
                for (PushTemplateParamBo item : columnAndMqParamBo.getUrlParamList()) {
                    if (TemplateParamTypeEnum.SYS_KEY.getType().equals(item.getType())) {
                        linkParamsIds.add(Long.valueOf(item.getValue()));
                    }
                }
            }
            if (CollectionUtils.isNotEmpty(linkParamsIds)) {
                Map<Long, String> valueMap = getKeyWordMap(columnAndMqParamBo, linkParamsIds);
                for (PushTemplateParamBo item : columnAndMqParamBo.getUrlParamList()) {
                    if (TemplateParamTypeEnum.SYS_KEY.getType().equals(item.getType())) {
                        String value = valueMap.get(Long.parseLong(item.getValue()));
                        columnAndMqParamBo.getUrlKeysList().add(new KeyModelBo(item.getName(), TemplateParamTypeEnum.SYS_KEY.getType(), value));
                    } else if (TemplateParamTypeEnum.TEXT.getType().equals(item.getType())) {
                        columnAndMqParamBo.getUrlKeysList().add(new KeyModelBo(item.getName(), TemplateParamTypeEnum.TEXT.getType(), item.getValue()));
                    }
                }
            } else {
                for (PushTemplateParamBo item : columnAndMqParamBo.getUrlParamList()) {
                    columnAndMqParamBo.getUrlKeysList().add(new KeyModelBo(item.getName(), TemplateParamTypeEnum.TEXT.getType(), item.getValue()));
                }
            }
        }
        return columnAndMqParamBo;
    }

    /**
     * 区分mq参数和表参数并添加到具体list
     *
     * @author leijin
     * @date 2019-09-10 16:56
     **/
    private Map<Long, String> getKeyWordMap(ColumnAndMqParamBo columnAndMqParamBo, List<Long> paramsIds) {
        List<TemplateParameterEntity> templateParameterEntities = templateParameterMapper.selectByIds(paramsIds);
        Map<Long, String> valueMap = new HashMap<>();
        for (TemplateParameterEntity item : templateParameterEntities) {
            if (item.getSource().equals(1)) {
                columnAndMqParamBo.getColumns().add(item.getDictTab() + '.' + item.getDictCol());
            } else {
                columnAndMqParamBo.getMqKeys().add(item.getDictCol());
            }
            valueMap.put(item.getId(), item.getDictCol());
        }
        return valueMap;
    }

}
