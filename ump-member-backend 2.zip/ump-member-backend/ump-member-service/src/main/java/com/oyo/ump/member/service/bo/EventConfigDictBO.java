package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;

/**
 * @author Dong
 * @Classname EventConfigDictBO
 * @Description
 * @Date 2019-06-04
 */
@Data
public class EventConfigDictBO implements Serializable {
    private Integer id;
    private Integer tagStatus;
    private String eventName;
    private String eventPropertyName;
    private Integer tagType;
    private String tagTable;
    private String tagColumn;
    private String tagDesc;
    private String sampleSql;
    private String valueArea;
    private String viewName;
    private String viewColumn;
    private String viewFilter;
}
