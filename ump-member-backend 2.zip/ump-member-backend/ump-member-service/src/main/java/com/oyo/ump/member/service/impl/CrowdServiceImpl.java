package com.oyo.ump.member.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
import com.google.gson.Gson;
import com.oyo.common.response.PagedResponse;
import com.oyo.ump.member.common.beanutils.MapperWrapper;
import com.oyo.ump.member.common.constants.MemberConstants;
import com.oyo.ump.member.common.constants.RedisConstants;
import com.oyo.ump.member.common.enums.CrowdTypeEnum;
import com.oyo.ump.member.dal.adb.AdbApolloMapper;
import com.oyo.ump.member.dal.dao.*;
import com.oyo.ump.member.dal.model.*;
import com.oyo.ump.member.dal.result.CrowdUsersResult;
import com.oyo.ump.member.integration.service.user.BUserInfoRemoteService;
import com.oyo.ump.member.service.CrowdService;
import com.oyo.ump.member.service.MessagePushService;
import com.oyo.ump.member.service.RedisService;
import com.oyo.ump.member.service.TagValueService;
import com.oyo.ump.member.service.bo.*;
import com.oyo.ump.member.service.enums.TagFirstClassEnum;
import com.oyo.ump.member.service.enums.TagOperatorEnum;
import com.oyo.ump.member.service.schedule.UserProfileDictService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import top.rdfa.biz.actor.business.client.dto.AccountDto;
import top.rdfa.biz.actor.business.client.dto.EmployeeDto;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;
import static com.oyo.ump.member.common.constants.MemberConstants.CREATE_BY_CUSTOM;

/**
 * @author Dong
 * @Classname CrowdServiceImpl
 * @Description
 * @Date 2019-06-04
 */
@Service
@Slf4j
public class CrowdServiceImpl implements CrowdService {
    @Autowired
    CrowdMapper crowdMapper;
    @Autowired
    CrowdCustomMapper crowdCustomMapper;
    @Autowired
    CrowdPushIdMapper crowdPushIdMapper;
    @Autowired
    CrowdOpenIdMapper crowdOpenIdMapper;
    @Autowired
    MessagePushService messagePushService;
    @Autowired
    TagValueService tagValueService;
    @Autowired
    BUserInfoRemoteService bUserInfoRemoteService;

    @Autowired
    RedisService redisService;
    @Autowired
    private UserProfileDictService userProfileDictService;
    @Autowired
    private MemberDimMapper memberDimMapper;
    @Autowired
    private AdbApolloMapper adbApolloMapper;

    private String keyPrefix = "ump-member-backend:crowd:";
    private List<String> CONTAIN_LIST = Lists.newArrayList("in", "not in");
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");


    @Transactional(rollbackFor = Exception.class)
    @Override
    public Long insertCrowd(CrowdBO crowdBO) {
        CrowdEntity crowdEntity = convert2Entity(crowdBO);
        if(StringUtils.isNotBlank(crowdBO.getCrowdCreateType()) && MemberConstants.CREATE_BY_TAG.equals(crowdBO.getCrowdCreateType())){
            String whereSql = messagePushService.getWhereStatement(crowdBO.getCrowdTag());
            Integer crowdNum = (int)tagValueService.countNum(whereSql);
            crowdEntity.setCrowdNum(crowdNum);
        }
        crowdMapper.insertCrowd(crowdEntity);
        if(MemberConstants.CREATE_BY_CUSTOM.equals(crowdBO.getCrowdCreateType())){
            if(CrowdTypeEnum.USER_ID.getType().equals(crowdBO.getCrowdType())){
                crowdBO.setId(crowdEntity.getId());
                insertCrowdCustom(crowdBO);
            }else if (CrowdTypeEnum.PUSH_ID.getType().equals(crowdBO.getCrowdType())){
                crowdBO.setId(crowdEntity.getId());
                insertCrowdPushId(crowdBO);
            }else if (CrowdTypeEnum.OPEN_ID.getType().equals(crowdBO.getCrowdType())){
                crowdBO.setId(crowdEntity.getId());
                insertCrowdOpenId(crowdBO);
            }
        }
        return crowdEntity.getId();
    }

    @Override
    public CrowdBO selectById(Long id) {
        Object object = redisService.getValue(RedisConstants.MEMBER_CROWD_PREFIX + id);
        if (object == null) {
            CrowdEntity crowdEntity = crowdMapper.selectById(id);
            if (crowdEntity != null) {
                CrowdBO crowdBO = convert2BO(crowdEntity);
                redisService.setValue(RedisConstants.MEMBER_CROWD_PREFIX + id, JSON.toJSONString(crowdBO), RedisConstants.MEMBER_DIM_EXPIRE);
                return crowdBO;
            }
        } else {
            return JSON.parseObject(object.toString(), CrowdBO.class);
        }
        return null;
    }

    @Override
    public List<CrowdBO> selectByCondition(Map<String, String> params) {
        List<CrowdBO> crowdBOList = Lists.newArrayList();
        List<CrowdEntity> crowdEntityList = crowdMapper.selectByCondition(params);
        if (CollectionUtils.isNotEmpty(crowdEntityList)) {
            crowdEntityList.forEach(crowdEntity -> {
                crowdBOList.add(convert2BO(crowdEntity));
            });
            return crowdBOList;
        }
        return null;
    }

    @Override
    public PagedResponse<CrowdBO> selectByConditionPaged(Map<String, String> params, Integer pageNum, Integer pageSize) {
        PagedResponse<CrowdBO> pagedResponse = new PagedResponse<>();
        pagedResponse.setPageSize(pageSize);

        List<CrowdBO> crowdBOList = Lists.newArrayList();
        PageHelper.startPage(pageNum, pageSize);
        List<CrowdEntity> crowdEntityList = crowdMapper.selectByCondition(params);
        PageInfo<CrowdEntity> entityPageInfo = PageInfo.of(crowdEntityList);
        if (CollectionUtils.isNotEmpty(crowdEntityList)) {
            crowdEntityList.forEach(crowdEntity -> {
                crowdBOList.add(convert2BO(crowdEntity));
            });
        }
        pagedResponse.setTotalCount(entityPageInfo.getTotal());
        pagedResponse.setPageNum(pageNum);
        pagedResponse.setResult(crowdBOList);
        return pagedResponse;
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void updateCrowd(CrowdBO crowdBO) {
        CrowdEntity crowdEntity = convert2Entity(crowdBO);
        if (StringUtils.isNotBlank(crowdBO.getCrowdCreateType()) && MemberConstants.CREATE_BY_TAG.equals(crowdBO.getCrowdCreateType())) {
            String whereSql = messagePushService.getWhereStatement(crowdBO.getCrowdTag());
            Integer crowdNum = (int) tagValueService.countNum(whereSql);
            crowdEntity.setCrowdNum(crowdNum);
        }

        if(MemberConstants.CREATE_BY_CUSTOM.equals(crowdBO.getCrowdCreateType())){
            if(CrowdTypeEnum.USER_ID.getType().equals(crowdBO.getCrowdType())){
                // 删老数据
                crowdCustomMapper.deleteByCrowdId(crowdBO.getId());
                // 插新数据
                insertCrowdCustom(crowdBO);
            }else if (CrowdTypeEnum.PUSH_ID.getType().equals(crowdBO.getCrowdType())){
                crowdPushIdMapper.deleteByCrowdId(crowdBO.getId());
                insertCrowdPushId(crowdBO);
            }else if (CrowdTypeEnum.OPEN_ID.getType().equals(crowdBO.getCrowdType())){
                crowdOpenIdMapper.deleteByCrowdId(crowdBO.getId());
                insertCrowdOpenId(crowdBO);
            }
        }
        crowdEntity.setDataUpdateTime(new Date());
        crowdMapper.updateCrowd(crowdEntity);
        redisService.removeKey(RedisConstants.MEMBER_CROWD_PREFIX + crowdBO.getId());
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteCrowd(Long id) {
        CrowdEntity crowdEntity = crowdMapper.selectById(id);
        if (null != crowdEntity) {
            crowdMapper.deleteCrowd(id);
            if(MemberConstants.CREATE_BY_CUSTOM.equals(crowdEntity.getCrowdCreateType())){
                if(CrowdTypeEnum.USER_ID.getType().equals(crowdEntity.getCrowdType())){
                    crowdCustomMapper.deleteByCrowdId(id);
                }else if (CrowdTypeEnum.PUSH_ID.getType().equals(crowdEntity.getCrowdType())){
                    crowdPushIdMapper.deleteByCrowdId(id);
                }else if (CrowdTypeEnum.OPEN_ID.getType().equals(crowdEntity.getCrowdType())){
                    crowdOpenIdMapper.deleteByCrowdId(id);
                }
            }
        }
        redisService.removeKey(RedisConstants.MEMBER_CROWD_PREFIX + id);
    }

    private CrowdEntity convert2Entity(CrowdBO crowdBO) {
        CrowdEntity crowdEntity = new CrowdEntity();
        crowdEntity.setId(crowdBO.getId());
        crowdEntity.setCrowdName(crowdBO.getCrowdName());
        crowdEntity.setCrowdStatus(crowdBO.getCrowdStatus());
        crowdEntity.setDataUpdateTime(crowdBO.getDataUpdateTime());
        crowdEntity.setCrowdNum(crowdBO.getCrowdNum());
        crowdEntity.setIsDeleted(crowdBO.getIsDeleted());
        crowdEntity.setCrowdCreateType(crowdBO.getCrowdCreateType());
        crowdEntity.setCrowdTag(crowdBO.getCrowdTag());
        crowdEntity.setIsDeleted(crowdBO.getIsDeleted());
        crowdEntity.setUserType(crowdBO.getUserType());
        crowdEntity.setCrowdType(crowdBO.getCrowdType());

        return crowdEntity;
    }

    private CrowdBO convert2BO(CrowdEntity crowdEntity) {
        CrowdBO crowdBO = new CrowdBO();
        crowdBO.setId(crowdEntity.getId());
        crowdBO.setCrowdName(crowdEntity.getCrowdName());
        crowdBO.setCrowdStatus(crowdEntity.getCrowdStatus());
        crowdBO.setCrowdNum(crowdEntity.getCrowdNum());
        crowdBO.setCrowdCreateType(crowdEntity.getCrowdCreateType());
        crowdBO.setCrowdTag(crowdEntity.getCrowdTag());
        // 自定义的时候，取列表

        crowdBO.setCreateTime(crowdEntity.getCreateTime());
        crowdBO.setUpdateTime(crowdEntity.getUpdateTime());
        crowdBO.setDataUpdateTime(crowdEntity.getDataUpdateTime());
        crowdBO.setUserType(crowdEntity.getUserType());
        crowdBO.setCrowdType(crowdEntity.getCrowdType());

        return crowdBO;
    }
    /**
     * 插入member_crowd_custom
     * @param crowdBO
     * @return void
     */
    private void insertCrowdCustom(CrowdBO crowdBO) {
        log.info("要插入的自定义人群数量：{}",crowdBO.getUserIds().size());
        if(CollectionUtils.isNotEmpty(crowdBO.getUserIds())){
            List<List<Long>> userIdLists = Lists.partition(crowdBO.getUserIds(),MemberConstants.INSERT_CROWD_SIZE);
            if(CollectionUtils.isNotEmpty(userIdLists)){
                userIdLists.forEach(userIds->{
                    crowdCustomMapper.insertBatchBO(crowdBO.getId(), userIds);
                });
            }
        }
    }

    /**
     * 插入member_crowd_pushId
     * @param crowdBO
     * @return void
     */
    private void insertCrowdPushId(CrowdBO crowdBO) {
        List<CrowdPushIdEntity> entityList = MapperWrapper.instance().mapList(crowdBO.getPushIdInfos(),CrowdPushIdEntity.class);
        List<List<CrowdPushIdEntity>> lists = Lists.partition(entityList,MemberConstants.INSERT_CROWD_SIZE);
        if(CollectionUtils.isNotEmpty(lists)){
            lists.forEach(list->{
                crowdPushIdMapper.insertBatch(crowdBO.getId(),list);
            });
        }
    }

    /**
     * 插入member_crowd_openId
     * @param crowdBO
     * @return void
     */
    private void insertCrowdOpenId(CrowdBO crowdBO) {
        List<CrowdOpenIdEntity> entityList = MapperWrapper.instance().mapList(crowdBO.getOpenIdInfos(),CrowdOpenIdEntity.class);
        List<List<CrowdOpenIdEntity>> lists = Lists.partition(entityList,MemberConstants.INSERT_CROWD_SIZE);
        if(CollectionUtils.isNotEmpty(lists)){
            lists.forEach(list->{
                crowdOpenIdMapper.insertBatch(crowdBO.getId(),list);
            });
        }
    }

    @Override
    public List<SelectCrowdBo> findSelectCrowdBoByIds(List<Long> crowdList) {
        List<SelectCrowdBo> result = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(crowdList)) {
            List<CrowdEntity> list = crowdMapper.selectByIds(crowdList);
            for (CrowdEntity crowdEntity : list) {
                SelectCrowdBo selectCrowdBo = new SelectCrowdBo();
                selectCrowdBo.setCountTime(new Date());
                selectCrowdBo.setCrowdName(crowdEntity.getCrowdName());
                Long qty = messagePushService.getUsersQtyByCrowdId(crowdEntity.getId());
                selectCrowdBo.setCrowdQty(qty);
                result.add(selectCrowdBo);
            }
        }
        Long qty = messagePushService.getUsersQtyByCrowdIds(crowdList, null);
        SelectCrowdBo selectCrowdBo = new SelectCrowdBo();
        selectCrowdBo.setCountTime(new Date());
        selectCrowdBo.setCrowdName("总计");
        selectCrowdBo.setCrowdQty(qty);
        result.add(selectCrowdBo);

        return result;
    }

    @Override
    public void jobUpdateCrowdsQty() {
        List<CrowdEntity> list = crowdMapper.selectTagCrowdEntities();
        for (CrowdEntity crowdEntity : list) {
            Long qty = messagePushService.getUsersQtyByCrowdId(crowdEntity.getId());
            crowdEntity.setCrowdNum(qty.intValue());
            crowdMapper.updateCrowd(crowdEntity);
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public AddUserToCrowdBO addUserToCrowd(Long id, Set<Long> userIds, String name) {
        CrowdEntity crowdEntity = null;
        List<Long> exsitUsers = new ArrayList<>();
        if (id == null) {
            crowdEntity = new CrowdEntity();
            crowdEntity.setCrowdName(name);
            crowdEntity.setCrowdStatus("0");
            crowdEntity.setIsDeleted(0);
            crowdEntity.setCrowdNum(userIds.size());
            crowdEntity.setCrowdCreateType(CREATE_BY_CUSTOM);
            crowdEntity.setUserType(1);
            crowdMapper.insertCrowd(crowdEntity);

        } else {
            crowdEntity = crowdMapper.selectById(id);
            if (crowdEntity != null) {
                exsitUsers = crowdCustomMapper.findExistUserId(id, new ArrayList<>(userIds));
                if (exsitUsers == null) {
                    exsitUsers = new ArrayList<>();
                }
                crowdEntity.setCrowdNum(crowdEntity.getCrowdNum() + userIds.size() - exsitUsers.size());
                crowdMapper.updateCrowd(crowdEntity);
            } else {
                crowdEntity = new CrowdEntity();
                crowdEntity.setCrowdName(name);
                crowdEntity.setCrowdNum(userIds.size());
                crowdEntity.setCrowdStatus("0");
                crowdEntity.setIsDeleted(0);
                crowdEntity.setCrowdCreateType(CREATE_BY_CUSTOM);
                crowdEntity.setUserType(1);
                crowdMapper.insertCrowd(crowdEntity);
            }
        }
        List<List<Long>> arrays = com.google.common.collect.Lists.partition(new ArrayList<>(userIds), 500);
        for (List<Long> item : arrays) {
            List<CrowdCustomEntity> list = new ArrayList<>();
            for (Long i : item) {
                if (!exsitUsers.contains(i)) {
                    CrowdCustomEntity crowdCustomEntity = new CrowdCustomEntity();
                    crowdCustomEntity.setCrowdId(crowdEntity.getId());
                    crowdCustomEntity.setUserId(i);
                    list.add(crowdCustomEntity);
                }
            }
            if(CollectionUtils.isNotEmpty(list)){
                crowdCustomMapper.insertBatch(list);
            }
        }
        redisService.batchAddSet(keyPrefix + crowdEntity.getId(), userIds.toArray());
        AddUserToCrowdBO addUserToCrowdBO =new AddUserToCrowdBO();
        addUserToCrowdBO.setCrowdId(crowdEntity.getId());
        addUserToCrowdBO.setCount(userIds.size() - exsitUsers.size());
        return addUserToCrowdBO;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteCrowdUser(Long crowdId, Set<Long> userIds) {
        if (CollectionUtils.isNotEmpty(userIds)) {
            redisService.batchRemoveSet(keyPrefix + crowdId, userIds.toArray());
            crowdCustomMapper.deleteCrowdCustomByCrowdIdAndUserIds(crowdId, new ArrayList<>(userIds));
        } else {
            redisService.removeKey(keyPrefix + crowdId);
            crowdMapper.deleteCrowd(crowdId);
            crowdCustomMapper.deleteByCrowdId(crowdId);
        }
    }

    @Override
    public PagedResponse<CrowdUsersBo> findCrowdUser(Set<Long> crowdIds, Long userId, Integer pageNum, Integer pageSize) {
        List<Long> users = new ArrayList<>(crowdIds);
        long num = crowdCustomMapper.countCrowdUsersPageByCondition(users, userId);
        List<CrowdUsersResult> list = crowdCustomMapper.findCrowdUsersPageByCondition(users, userId, (pageNum - 1) * pageSize, pageSize);
        List<CrowdUsersBo> result = new ArrayList<>();
        for (CrowdUsersResult crowdUsersResult : list) {
            CrowdUsersBo crowdUsersBo = new CrowdUsersBo();
            crowdUsersBo.setCreateTime(crowdUsersResult.getCreateTime());
            crowdUsersBo.setCrowdIds(crowdUsersResult.getCrowdIds());
            crowdUsersBo.setUserId(crowdUsersResult.getUserId());
            result.add(crowdUsersBo);
        }
        PagedResponse<CrowdUsersBo> page = new PagedResponse<>(pageNum, pageSize, num);
        page.setResult(result);
        return page;
    }

    @Override
    public Boolean existCrowdUser(Long crowdId, Long userId) {
        return redisService.isMemberOfSet(keyPrefix + crowdId, userId);
    }

    @Override
    public List<RuleBO> getCrowdDetailById(Long crowdId) {
        CrowdBO crowdBO = selectById(crowdId);
        if (crowdBO == null || StringUtils.isEmpty(crowdBO.getCrowdTag())) {
            return Lists.newArrayList();
        }
        List<CrowdTagBO> crowdTagBOList = JSONArray.parseArray(crowdBO.getCrowdTag(), CrowdTagBO.class);
        return crowdTagBOList.stream().map(crowdTagBO -> {
            RuleBO ruleBO = new RuleBO();
            String rule = TagFirstClassEnum.getNameByCode(crowdTagBO.getTagClassSelectValue()) + ":";
            UserProfileDictBO userProfileDictBO = userProfileDictService.selectByTagColumn(crowdTagBO.getTagSelectValue(),MemberConstants.USER_TYPE_FOR_C);
            rule += userProfileDictBO.getTagName();
            rule += TagOperatorEnum.getNameByCode(crowdTagBO.getTagOperatorValue());
            rule += crowdTagBO.getTagValueSelectValue();
            ruleBO.setRule(rule);
            ruleBO.setRuleRelation(crowdTagBO.getRelationValue());
            return ruleBO;
        }).collect(Collectors.toList());
    }

    @Override
    public UmpDataMemberDimRptEntity getMemberDimInfo(Long userId,String distinctId) {
        if(userId==null&&StringUtils.isEmpty(distinctId)){
            return null;
        }
        UmpDataMemberDimRptEntity entity;
        Object object;
        if(userId!=null){
            object = redisService.getValue(RedisConstants.MEMBER_DIM_PREFIX + userId);
        }else {
            object=redisService.getValue(RedisConstants.MEMBER_DISTINCT_DIM_PREFIX + distinctId);
        }
        if (object == null) {
            if(userId!=null){
                entity = memberDimMapper.getMemberInfoById(userId);
                if (entity != null) {
                    redisService.setValue(RedisConstants.MEMBER_DIM_PREFIX + userId, JSON.toJSONString(entity), RedisConstants.MEMBER_DIM_EXPIRE);
                }
            }else {
                entity = memberDimMapper.getMemberInfoByDistinctId(distinctId);
                if (entity != null) {
                    redisService.setValue(RedisConstants.MEMBER_DISTINCT_DIM_PREFIX + distinctId, JSON.toJSONString(entity), RedisConstants.MEMBER_DIM_EXPIRE);
                }
            }

        } else {
            entity = JSON.parseObject(object.toString(), UmpDataMemberDimRptEntity.class);
        }
        return entity;
    }

    /**
     * A x B -> A B 结果，再看且与或，是否满足中止条件->不满足则继续A 拆分 A=axb 循环
     *
     * @param crowdBO
     * @param entity
     * @return
     */
    @Override
    public Boolean userFitCrowdRule(CrowdBO crowdBO, UmpDataMemberDimRptEntity entity) {
        if (entity == null || crowdBO == null || StringUtils.isEmpty(crowdBO.getCrowdTag())) {
            return false;
        }
        List<CrowdTagBO> crowdTagBOList = JSONArray.parseArray(crowdBO.getCrowdTag(), CrowdTagBO.class);
        boolean result2 = true;
        boolean result1;
        boolean result = false;
        try {
            for (int i = crowdTagBOList.size() - 1; i >= 0; i--) {
                CrowdTagBO crowdTagBO = crowdTagBOList.get(i);
                if (crowdTagBO.getTagSelectValue() != null) {
                    JSONObject jsonObject = JSONObject.parseObject(JSON.toJSONString(entity));
                    Object object = jsonObject.get(crowdTagBO.getTagSelectValue());
                    String value = crowdTagBO.getTagValueSelectValue();
                    if (object != null && value != null) {
                        if (CONTAIN_LIST.contains(crowdTagBO.getTagOperatorValue())) {
                            List<String> stringList = JSON.parseArray(value, String.class);
                            result1 = TagOperatorEnum.getCompareListByCode(crowdTagBO.getTagOperatorValue()).contains(Boolean.compare(stringList.contains(object), true));
                        } else {
                            int j = 0;
                            if (object instanceof Double) {
                                j = Double.compare((double) object, Double.valueOf(value));
                            } else if (object instanceof Long) {
                                if (value.contains("-")) {
                                    try {
                                        j = Long.compare((long) object, DATE_FORMAT.parse(value).getTime());
                                    } catch (Exception e) {
                                        log.error("时间转换异常:{}", value, e);
                                    }
                                } else {
                                    j = Long.compare((long) object, Long.valueOf(value));
                                }
                            } else if (object instanceof Integer) {
                                j = Integer.compare((int) object, Integer.valueOf(value));
                            } else if (object instanceof String) {
                                if (!object.equals(value)) {
                                    j = -1;
                                }
                            }
                            result1 = TagOperatorEnum.getCompareListByCode(crowdTagBO.getTagOperatorValue()).contains(j);
                        }
                        if (i == 0) {
                            if (1 == crowdTagBO.getRelationValue()) {
                                return result1 && result2;
                            } else {
                                return result1 || result2;
                            }
                        }
                        boolean stopCondition1 = (result1 == true && 2 == crowdTagBOList.get(i - 1).getRelationValue());
                        boolean stopCondition2 = (result1 == false) && 1 == crowdTagBOList.get(i - 1).getRelationValue();
                        if (stopCondition1) {
                            return true;
                        }
                        if (stopCondition2) {
                            return false;
                        }
                    } else {
                        result1 = false;
                    }
                    if (1 == crowdTagBO.getRelationValue()) {
                        result = result1 && result2;
                    } else if (2 == crowdTagBO.getRelationValue()) {
                        result = result1 || result2;
                    } else {
                        result = false;
                    }
                    result2 = result1;
                }
            }
        } catch (Exception e) {
            log.error("解析用户是否在人群异常", e);
        }
        log.info("走进异常兜底结果 人群信息:{},用户画像信息:{}", JSON.toJSONString(crowdBO), JSON.toJSONString(entity));
        return result;
    }

    @Override
    public Long getCrowdCount(Long crowdId) {
        return redisService.getSizeOfSet(keyPrefix + crowdId);
    }

    @Override
    public List<CrowdBO> batchGetCrowd(List<Long> crowdIdList) {
        List<CrowdBO> crowdBOList =Lists.newArrayList();
        List<Long> cacheList = Lists.newArrayList();
        List<Object> objectList = redisService.mGet(crowdIdList.stream().map(crowdId->RedisConstants.MEMBER_CROWD_PREFIX + crowdId).collect(Collectors.toList()));
        if(CollectionUtils.isNotEmpty(objectList)){
            crowdBOList = objectList.stream().filter(Objects::nonNull).map(object -> {
                CrowdBO crowdBO = JSON.parseObject(object.toString(), CrowdBO.class);
                cacheList.add(crowdBO.getId());
                return crowdBO;
            } ).collect(Collectors.toList());
        }
        if(crowdBOList.size()==crowdIdList.size()){
            return crowdBOList;
        }
        List<Long> needQueryDbList=Lists.newArrayList();
        crowdIdList.stream().forEach(id->{
            if(!cacheList.contains(id)){
                needQueryDbList.add(id);
            }
        });
        if(CollectionUtils.isNotEmpty(needQueryDbList)){
          List<CrowdEntity> crowdEntityList =  crowdMapper.batchGet(needQueryDbList);
          if(CollectionUtils.isNotEmpty(crowdEntityList)){
              for (CrowdEntity crowdEntity : crowdEntityList) {
                  CrowdBO crowdBO = convert2BO(crowdEntity);
                  crowdBOList.add(crowdBO);
                  redisService.setValue(RedisConstants.MEMBER_CROWD_PREFIX + crowdBO.getId(), JSON.toJSONString(crowdBO), RedisConstants.MEMBER_DIM_EXPIRE);
              }
          }
        }
        return crowdBOList;
    }

    @Override
    public List<Long> getUserIdsByEmails(List<String> emails) {
        List<Long> userIds = Lists.newArrayList();
        if(CollectionUtils.isEmpty(emails)){
            return userIds;
        }
        List<List<String>> listList = Lists.partition(emails,MemberConstants.EMAIL_TO_USERID_SIZE);
        if(CollectionUtils.isNotEmpty(listList)){
            listList.forEach(list->{
                userIds.addAll(adbApolloMapper.getUserIdsByEmails(list));
            });
        }
        log.info("邮箱转userId成功数量：{}",userIds.size());
        return userIds;
    }

    @Override
    public List<Long> getUserIdsByEmployeeNos(List<String> employeeNos) {
        List<Long> userIds = Lists.newArrayList();
        if(CollectionUtils.isEmpty(employeeNos)){
            return userIds;
        }
        List<List<String>> listList = Lists.partition(employeeNos,MemberConstants.EMPLOYEE_TO_USERID_SIZE);
        if(CollectionUtils.isNotEmpty(listList)){
            listList.forEach(list->{
                List<AccountDto> accountDtoList = bUserInfoRemoteService.getBUserByEmployeeNos(list);
                userIds.addAll(getUserIdsByAccountDtoList(accountDtoList));
            });
        }
        log.info("工号转userId成功数量：{}",userIds.size());
        return userIds;
    }

    private List<Long> getUserIdsByAccountDtoList(List<AccountDto> accountDtoList){
        List<Long> userIds = Lists.newArrayList();
        if(CollectionUtils.isNotEmpty(accountDtoList)){
            accountDtoList.forEach(accountDto -> {
                if(null != accountDto.getUser() && CollectionUtils.isNotEmpty(accountDto.getUser().getEmployees())){
                    userIds.add(accountDto.getUser().getEmployees().get(0).getUserId());
                }
            });
        }
        return userIds;
    }
}
