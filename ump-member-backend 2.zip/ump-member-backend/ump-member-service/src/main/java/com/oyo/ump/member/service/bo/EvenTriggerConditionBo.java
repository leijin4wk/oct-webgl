package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;
import java.util.Map;

@Data
public class EvenTriggerConditionBo implements Serializable {

    private Integer itemId;

    private boolean existFlag;

    private String triggerType;

    private String viewName;

    private String viewFilter;

    private Map<Integer,TriggerEventItemBo> subTriggerEventMap;

}
