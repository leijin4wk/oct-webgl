package com.oyo.ump.member.service;

import com.oyo.ump.member.service.bo.EventConfigDictBO;

import java.util.List;

/**
 * @author Dong
 * @Classname EventConfigDictService
 * @Description
 * @Date 2019-08-27
 */
public interface EventConfigDictService {
    /**
     * 获取大类事件名
     * @param
     * @return java.util.List<com.oyo.ump.member.service.bo.EventConfigDictBO>
     */
    List<EventConfigDictBO> getAllEventName();

    /**
     * 根据大类事件名获取事件列表信息
     * @param eventName
     * @return java.util.List<com.oyo.ump.member.service.bo.EventConfigDictBO>
     */
    List<EventConfigDictBO> getPropertyName(String eventName);

    /**
     * 根据事件tagColumn获取事件信息
     * @param tagColumn
     * @return com.oyo.ump.member.service.bo.EventConfigDictBO
     */
    EventConfigDictBO selectByTagColumn(String eventName,String tagColumn);
}
