package com.oyo.ump.member.service;

import com.alibaba.fastjson.JSONArray;
import com.oyo.ump.member.service.bo.DynamicSqlBo;

/**
 * @Author hubin
 * @Description: 自定义事件服务
 * @Date 2019/9/10
 */
public interface CustomizedEventService {
    /**
     * 自定义事件配置json转换为sql片段
     * @param configs
     * @return
     */
//    String getSqlSegmentByConfig(JSONArray configs);

    /**
     * 获取自定义事件构建view
     * @return
     */
    String getEventViewSql();


    /**
     * 动态组装sql
    * @author leijin
    * @date 2019-11-15 15:44
    **/
    DynamicSqlBo dynamicBuildSql(String json);
}
