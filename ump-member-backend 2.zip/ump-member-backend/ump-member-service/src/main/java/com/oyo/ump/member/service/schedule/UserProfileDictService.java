package com.oyo.ump.member.service.schedule;

import com.oyo.ump.member.service.bo.UserProfileDictBO;

import java.util.List;

/**
 * @author Dong
 * @Classname UserProfileDictService
 * @Description 用户标签字典接口
 * @Date 2019-05-06
 */
public interface UserProfileDictService {
    List<UserProfileDictBO> selectByFirstId(String firstId, Integer userType);
    UserProfileDictBO selectByTagColumn(String tagColumn, Integer userType);
}
