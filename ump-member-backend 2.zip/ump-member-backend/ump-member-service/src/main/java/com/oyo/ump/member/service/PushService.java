package com.oyo.ump.member.service;

import com.oyo.common.response.PagedResponse;
import com.oyo.ump.member.service.bo.PushBO;
import com.oyo.ump.member.service.bo.PushPromotionBO;

import java.time.temporal.TemporalUnit;
import java.util.List;

/**
 * @author Dong
 * @Classname PushService
 * @Description 事件推送业务接口
 * @Date 2019-05-06
 */
public interface PushService {
    /**
     * 插入push
     * @param pushBO
     * @return java.lang.Long
     */
    Long insertPush(PushBO pushBO);
    /**
     * 通过id查push信息
     * @param id
     * @return com.oyo.ump.member.service.bo.PushBO
     */
    PushBO selectById(Long id);
    /**
     * 通过条件分页查push列表
     * @param pushBO
     * @param pageNum
     * @param pageSize
     * @return com.oyo.common.response.PagedResponse<com.oyo.ump.member.service.bo.PushBO>
     */
    PagedResponse<PushBO> selectByConditionPaged(PushBO pushBO, Integer pageNum, Integer pageSize);
    /**
     * 通过条件查列表不分页
     * @param pushBO
     * @return java.util.List<com.oyo.ump.member.service.bo.PushBO>
     */
    List<PushBO> selectByCondition(PushBO pushBO);
    /**
     * 更新push第一页内容
     * @param pushBO
     * @return java.lang.Boolean
     */
    Boolean updatePushCrowdInfo(PushBO pushBO);
    /**
     * 更新push第三页内容
     * @param pushBO
     * @return java.lang.Boolean
     */
    Boolean updatePushSendRule(PushBO pushBO);
    /**
     * 更新push开关状态
     * @param pushBO
     * @return void
     */
    void updateSwitch(PushBO pushBO);
    /**
     * 删除push
     * @param id
     * @return void
     */
    void deletePush(Long id);

    /**
     * 获取时间间隔内的
     * @param userIds 用户ids
     * @param pushId  pushId
     * @param interval 时间大小
     * @param temporalUnit  时间单位
     * @return
     */
   List<Long> getIntervalUserIds(List<Long> userIds, Long pushId, Long interval, TemporalUnit temporalUnit);

   /**
    * JOB创建活动推送的push
    * @param
    * @return void
    */
   void createPromotionPushByJob();

    /**
     * 创建活动推送的push
     * @param
     * @return void
     */
    Long createPromotionPush(PushPromotionBO pushPromotionBO);

}
