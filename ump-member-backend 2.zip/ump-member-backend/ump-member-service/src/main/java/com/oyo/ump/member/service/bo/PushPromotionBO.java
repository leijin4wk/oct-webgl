package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @author Dong
 * @Classname PushPromotionBO
 * @Description 活动push
 * @Date 2019-05-06
 */
@Data
public class PushPromotionBO implements Serializable {
    private Long id;
    private String promotionType;
    private String promotionId;
    private String startTime;
    private Long pushId;
    private Long crowdId;
    private Date createTime;
}
