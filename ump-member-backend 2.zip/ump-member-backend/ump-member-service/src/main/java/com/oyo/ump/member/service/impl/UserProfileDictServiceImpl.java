package com.oyo.ump.member.service.impl;

import com.oyo.ump.member.common.beanutils.MapperWrapper;
import com.oyo.ump.member.common.constants.MemberConstants;
import com.oyo.ump.member.dal.dao.UserProfileDictForBMapper;
import com.oyo.ump.member.dal.dao.UserProfileDictMapper;
import com.oyo.ump.member.dal.model.UserProfileDictEntity;
import com.oyo.ump.member.service.bo.UserProfileDictBO;
import com.oyo.ump.member.service.schedule.UserProfileDictService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Dong
 * @Classname UserProfileDictServiceImpl
 * @Description
 * @Date 2019-06-05
 */
@Service
@Slf4j
public class UserProfileDictServiceImpl implements UserProfileDictService {
    @Autowired
    UserProfileDictMapper userProfileDictMapper;
    @Autowired
    UserProfileDictForBMapper userProfileDictForBMapper;

    @Override
    public List<UserProfileDictBO> selectByFirstId(String firstId, Integer userType){
        List<UserProfileDictBO> userProfileDictBOList =Lists.newArrayList();
        List<UserProfileDictEntity> userProfileDictEntityList = Lists.newArrayList();
        if(MemberConstants.USER_TYPE_FOR_B.equals(userType)){
            userProfileDictEntityList = userProfileDictForBMapper.selectByFirstId();
        }else {
            userProfileDictEntityList = userProfileDictMapper.selectByFirstId(firstId);
        }
        if(CollectionUtils.isNotEmpty(userProfileDictEntityList)){
            userProfileDictEntityList.forEach(userProfileDictEntity -> {
                UserProfileDictBO userProfileDictBO =  MapperWrapper.instance().map(userProfileDictEntity, UserProfileDictBO.class);
                userProfileDictBOList.add(userProfileDictBO);
            });
            return userProfileDictBOList;
        }

        return null;
    }

    @Override
    public UserProfileDictBO selectByTagColumn(String tagColumn, Integer userType) {
        UserProfileDictEntity userProfileDictEntity = new UserProfileDictEntity();
        if(MemberConstants.USER_TYPE_FOR_B.equals(userType)){
            userProfileDictEntity = userProfileDictForBMapper.selectByTagColumn(tagColumn);
        }else {
            userProfileDictEntity = userProfileDictMapper.selectByTagColumn(tagColumn);
        }
        if(null != userProfileDictEntity){
            UserProfileDictBO userProfileDictBO =  MapperWrapper.instance().map(userProfileDictEntity, UserProfileDictBO.class);
            return userProfileDictBO;
        }
        return null;
    }

}
