package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.util.Date;

@Data
public class PushTempleteBo {
    private Long id;
    private String pushName;
    private Integer pushStatus;
    private String description;
    /**
     * 部门
     */
    private Long departmentId;
    private Integer triggerType;
    private Integer validityFlag;
    private Date validityStart;
    private Date validityEnd;
    private String sendFrequency;
    /**
     * 圈定条件
     */
    private Long rule;
    private Integer triggerChannel;
    private Long pushTemplateId;
    private String triggerReward;
    private Long createUserId;
    private String createUserName;
    private Date createTime;
    private Long updateUserId;
    private String updateUserName;
    private Date updateTime;
    private Boolean isDeleted;
    /*
    *短信pushid
    **/
    private String smsTempleteId;
    /**
     * 统一模板ID
     */
    private String uniformTemplateId;

    /**
    *短信其他字段
    **/
    private String pushDetail;

}
