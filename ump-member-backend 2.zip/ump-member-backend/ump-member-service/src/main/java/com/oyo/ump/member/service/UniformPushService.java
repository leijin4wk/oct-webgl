package com.oyo.ump.member.service;

import com.oyo.ump.member.dal.model.PushMessageEntity;
import com.oyo.ump.member.service.producer.memberPush.MemberPushMessage;

import java.util.List;

/**
 * @author Dong
 * @Description
 * @Date 2019-09-17
 */
public interface UniformPushService {

    /**
     * 发送push
     * @param batchList
     * @param testFlag
     * @return java.lang.String
     */
    String sendAndGetBatchNo(List<PushMessageEntity> batchList, Boolean testFlag);

    /**
     * MQ出队解析、发送、异步入库
     * @param memberPushMessage
     * @return java.lang.Integer
     */
    void sendAndInsertPush(MemberPushMessage memberPushMessage);
}
