package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author Dong
 * @Classname CrowdCustomBO
 * @Description
 * @Date 2019-06-04
 */
@Data
public class CrowdCustomBO implements Serializable {
    private Long id;
    private Long crowdId;
    private Long userId;
    private Date createTime;
}
