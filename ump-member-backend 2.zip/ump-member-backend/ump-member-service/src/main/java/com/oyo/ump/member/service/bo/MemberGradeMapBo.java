package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.util.Date;

@Data
public class MemberGradeMapBo {
    private Long id;
    private Integer platformId;
    private String platformName;
    private Long platformGrade;
    private Integer oyoGrade;
    private Date createTime;
    private Date updateTime;
}
