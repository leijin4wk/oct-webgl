package com.oyo.ump.member.service.bo;


import lombok.Data;

import java.io.Serializable;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Data
public class DynamicSqlBo implements Serializable {

    private String joinFragment;

    private String  whereFragment;

    private Set<String> viewSet=new HashSet<>();

}
