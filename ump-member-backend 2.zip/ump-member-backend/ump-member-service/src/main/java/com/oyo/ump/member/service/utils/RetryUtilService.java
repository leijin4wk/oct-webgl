package com.oyo.ump.member.service.utils;

import com.alibaba.fastjson.JSON;
import com.oyo.ump.member.dal.dao.RetryMapper;
import com.oyo.ump.member.dal.model.MemberRetryEntity;
import com.oyo.ump.member.integration.service.wallet.PointsRemoteService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

/**
 * @Description: 重试方法工具类
 * @Author: fang
 * @create: 2019-11-01
 **/
@Slf4j
@Component
public class RetryUtilService implements ApplicationContextAware {
    @Autowired
    private RetryMapper retryMapper;


    private final String SYMBOL = "--";
    private static ApplicationContext applicationContext;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        RetryUtilService.applicationContext = applicationContext;
    }

    /**
     * 插入重试表
     */
    public void insertDb(ProceedingJoinPoint point, int retry, Object result, String[] targetResult, String field, int type, String retryMethod) {
        MemberRetryEntity entity = new MemberRetryEntity();
        entity.setProcessResult(result == null ? null : JSON.toJSONString(result));
        entity.setTargetCount(retry);
        entity.setStatus(0);
        entity.setBusinessType(type);
        if (targetResult != null && targetResult.length > 0) {
            StringBuffer stringBuffer = new StringBuffer();
            Arrays.stream(targetResult).forEach(s -> stringBuffer.append(s).append(SYMBOL));
            String target = stringBuffer.toString();
            entity.setTargetResult(target.substring(0, target.length() - 2));

        }
        entity.setField(field);
        entity.setRetryCount(0);
        if (point.getArgs() != null && point.getArgs().length > 0) {
            StringBuffer stringBuffer = new StringBuffer();
            Arrays.stream(point.getArgs()).forEach(s -> stringBuffer.append(s == null ? "" : JSON.toJSONString(s)).append(SYMBOL));
            String target = stringBuffer.toString();
            entity.setBusinessParams(target.substring(0, target.length() - 2));
        }
        entity.setTargetMethod(retryMethod);
        entity.setTargetClass(point.getSignature().getDeclaringType().getName());
        retryMapper.insert(entity);
    }

    /**
     * 执retry补偿方法
     */
    public void processRetry() {
        boolean needRetry = true;
        int offset = 0;
        int num = 500;
        int index = 0;
        while (needRetry) {
            List<MemberRetryEntity> entityList = retryMapper.getAll(offset, num);
            index = index + 1;
            offset = index * num;
            if (CollectionUtils.isNotEmpty(entityList)) {
                entityList.forEach(entity -> {
                    entity.setRetryCount((entity.getRetryCount() + 1));
                    if (entity.getRetryCount() <= entity.getTargetCount()) {
                        processCommon(entity);
                    } else {
                        log.info("id为{}重试多次仍旧异常", entity.getId());
                    }
                });
            } else {
                needRetry = false;
            }
        }

    }

    /**
     * 执行通用部分
     *
     * @param entity
     */
    private void processCommon(MemberRetryEntity entity) {
        try {
            final Object[] result = new Object[1];
            Class targetClass = Class.forName(entity.getTargetClass());
            Arrays.stream(targetClass.getMethods()).forEach(method -> {
                if (entity.getTargetMethod().equals(method.getName())) {
                    try {
                        Type[] parameterTypes = method.getGenericParameterTypes();
                        String[] paramArray = entity.getBusinessParams().split(SYMBOL);
                        Object[] paramObject = new Object[parameterTypes.length];
                        for (int i = 0; i < parameterTypes.length; i++) {
                            if (paramArray.length > i && StringUtils.isNotEmpty(paramArray[i])) {
                                paramObject[i] = JSON.parseObject(paramArray[i], parameterTypes[i]);
                            }
                        }
                        result[0] = method.invoke(applicationContext.getBean(targetClass), paramObject);
                    } catch (Exception e) {
                        log.error("重试发生异常{}", method.getName(), e);
                    }
                }
            });
            boolean success = isProcessSuccess(result[0], entity.getField(), entity.getTargetResult().split(SYMBOL));
            if (success) {
                entity.setStatus(1);
            }
            entity.setProcessResult(result[0] == null ? null : JSON.toJSONString(result[0]));
        } catch (Throwable e) {
            log.error("重试发生异常{}", entity.getId(), e);
        } finally {
            retryMapper.update(entity);
        }
    }

    /**
     * 执行不同业务类型请求 增加业务类型需要增加这块的代码
     *
     * @param entity
     */
//    private void processBusiness(MemberRetryEntity entity) {
//        if (entity.getBusinessType().intValue() == 1) {
//            if (pointsRemoteService.addPoints(JSON.parseObject(entity.getBusinessParams(), PointsAddDTO.class))) {
//                entity.setStatus(1);
//                entity.setProcessResult("true");
//            } else {
//                entity.setProcessResult("false");
//            }
//            retryMapper.update(entity);
//        }
//    }

    /**
     * 查看执行结果是否正确
     *
     * @param result
     * @param resultArray
     * @param fieldStr
     * @return
     */
    public boolean isProcessSuccess(Object result, String fieldStr, String[] resultArray) {
        if (resultArray.length > 0 && result != null) {
            if (StringUtils.isEmpty(fieldStr)) {
                if (Arrays.stream(resultArray).filter(Objects::nonNull).anyMatch(object -> object.equals(result.toString()))) {
                    return true;
                }
            } else {
                try {
                    Field field = result.getClass().getDeclaredField(fieldStr);
                    field.setAccessible(true);
                    Object fieldValue = field.get(result);
                    if (fieldValue != null) {
                        if (Arrays.stream(resultArray).filter(Objects::nonNull).anyMatch(object -> object.equals(fieldValue.toString()))) {
                            return true;
                        }
                    }
                } catch (Exception e) {
                    log.error("retry util reflect error", e);
                }
            }

        }
        return false;
    }


}
