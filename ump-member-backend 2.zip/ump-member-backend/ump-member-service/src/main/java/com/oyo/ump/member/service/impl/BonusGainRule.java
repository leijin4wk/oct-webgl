package com.oyo.ump.member.service.impl;

import lombok.Data;

/**
 * @Classname BonusGainRule
 * @Description 积分获取规则类（内部类用于 接收数据库返回配置字段对应的类对象）
 * @Date 2019-03-16 12:29
 * @author Dong
 */
@Data
public class BonusGainRule {
    /**
     * 积分获取规则配置项
     */
    @Data
    public static class ComissionConfig{
        private String undertake1;
        private Integer undertake1Ratio;
        private String undertake2;
        private Integer undertake2Ratio;
        private String undertake3;
        private Integer undertake3Ratio;
        private String undertake4;
        private Integer undertake4Ratio;
        private String undertake5;
        private Integer undertake5Ratio;
    }
}
