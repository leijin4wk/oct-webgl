package com.oyo.ump.member.service.bo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PushTemplateMapBo {
    private Long id;
    private String templeteName;
    private String aliTempleteId;
    private String detail;
    private Date createTime;
    private Date updateTime;
    private Boolean isDeleted;
}
