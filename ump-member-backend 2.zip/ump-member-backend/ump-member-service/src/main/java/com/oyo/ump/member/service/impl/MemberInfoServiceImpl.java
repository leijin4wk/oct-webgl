package com.oyo.ump.member.service.impl;

import com.alibaba.fastjson.JSON;
import com.ctrip.framework.apollo.spring.annotation.ApolloJsonValue;
import com.dianping.cat.Cat;
import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.oyo.ledger.client.response.CostDataVO;
import com.oyo.ump.member.common.constants.MemberConstants;
import com.oyo.ump.member.common.constants.RedisConstants;
import com.oyo.ump.member.common.enums.GradeEnum;
import com.oyo.ump.member.common.utils.Retry;
import com.oyo.ump.member.dal.dao.MemberGradeDetailMapper;
import com.oyo.ump.member.dal.dao.MemberGradeMapper;
import com.oyo.ump.member.dal.model.MemberGradeDetailEntity;
import com.oyo.ump.member.dal.model.MemberGradeEntity;
import com.oyo.ump.member.integration.service.costcenter.CostCenterRemoteService;
import com.oyo.ump.member.integration.service.coupon.CouponHttpService;
import com.oyo.ump.member.integration.service.sms.SmsRequest;
import com.oyo.ump.member.integration.service.sms.SmsService;
import com.oyo.ump.member.integration.service.user.JpUserInfoRemoteService;
import com.oyo.ump.member.integration.service.user.MemberEditDTO;
import com.oyo.ump.member.integration.service.user.OyoUser;
import com.oyo.ump.member.integration.service.user.UserInfoRemoteService;
import com.oyo.ump.member.integration.service.wallet.PointsRemoteService;
import com.oyo.ump.member.service.*;
import com.oyo.ump.member.service.bo.*;
import com.oyo.ump.member.service.dto.BonusGainRuleDTO;
import com.oyo.ump.member.service.dto.MemberRegisterDTO;
import com.oyo.uum.api.user.request.user.QueryUserRequest;
import com.oyo.uum.api.user.request.user.UpdateUserRequest;
import com.oyo.wallet.client.req.PointsAddDTO;
import com.oyo.wallet.client.req.PointsDetailDTO;
import com.oyo.wallet.client.req.PointsQueryBalanceDTO;
import com.oyo.wallet.client.resp.PointsQueryBalanceVO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import javax.annotation.PostConstruct;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.oyo.ump.member.common.constants.DateformateConstants.DATE_FORMAT;
import static com.oyo.ump.member.common.constants.DateformateConstants.SHORT_DATE_FORMAT;

/**
 * @Description: 会员信息一些基础信息实现类
 * @Author: fang
 * @create: 2019-03-22
 **/
@Service
@Slf4j
public class MemberInfoServiceImpl implements MemberInfoService {
    @Autowired
    private MemberGradeMapper memberGradeMapper;
    @Autowired
    private MemberGradeDetailMapper memberGradeDetailMapper;
    @Autowired
    private RedisService redisService;
    @Autowired
    private UserInfoRemoteService userInfoRemoteService;
    @Autowired
    private GradeService gradeService;
    @Autowired
    private PointsRemoteService pointsRemoteService;
    @Autowired
    @Qualifier("fromGson")
    private Gson gson;
    @Autowired
    private ThreadPoolTaskExecutor threadPoolTaskExecutor;
    @Autowired
    private CouponHttpService couponHttpService;
    @Autowired
    private JpUserInfoRemoteService jpUserInfoRemoteService;
    @Value("${SEND_MESSAGE}")
    private String SEND_MESSAGE;
    @Value("${REGISTER_COUPON}")
    private String REGISTER_COUPON;
    private static final String MESSAGE_SWITCH = "1";
    private static final String REGISTER_COUPON_SWITCH = "1";
    @Autowired
    private SmsService smsService;
    @Value("${User_Register_TemplateId}")
    private String TemplateId;
    @ApolloJsonValue("${REGISTER_ACTION}")
    private Map<String, List<Integer>> REGISTER_ACTION;
    private final int SEND_COUPON_ACTION=1;
    private final int SEND_MESSAGE_ACTION=2;
    private final int SEND_POINT_ACTION=3;
    @Value("${REGISTER_JP_POINT}")
    private String REGISTER_JP_POINT;
    @Value("${ump.newcomer.register.switch}")
    private Integer NEWCOMER_SWITCH;
    @Autowired
    private BonusGainRuleService bonusGainRuleService;
    @Autowired
    private CostCenterRemoteService costCenterRemoteService;
    private Map<String, BonusGainRuleDTO.BonusGainRuleInfo> bonusGainRuleInfoMap = Maps.newHashMap();

    private Map<String, CostDataVO> costCenterMap = Maps.newHashMap();
    @Autowired
    private ChangeGradeService changeGradeService;
    @Autowired
    private RetryBusinessService retryBusinessService;


    @PostConstruct
    private void buildInitialMap() {
        List<BonusGainRuleDTO.BonusGainRuleInfo> bonusGainRuleInfoList = bonusGainRuleService.getGainRuleList(MemberConstants.OYO_JP_TENANT).getBonusGainRuleInfoList();
        if (CollectionUtils.isNotEmpty(bonusGainRuleInfoList)) {
            bonusGainRuleInfoList.forEach(bonusGainRuleInfo -> {
                bonusGainRuleInfoMap.put(bonusGainRuleInfo.getBonusType(), bonusGainRuleInfo);
            });
        }
        List<CostDataVO> costCenterList = costCenterRemoteService.getCostCenterList();
        log.info("成本中心列表: {}", JSON.toJSONString(costCenterList));
        if (CollectionUtils.isNotEmpty(costCenterList)) {
            costCenterList.forEach(costDataVO -> {
                costCenterMap.put(costDataVO.getCostCode(), costDataVO);
            });
        }else {
            log.error("成本中心服务异常,加载数据异常");
        }
    }





    private static final int LIVE_TIME = 60 * 60 * 3;
    private static final SimpleDateFormat DATE_FORMATE = new SimpleDateFormat("yyyy-MM-dd");

    @Override
    public MemberInfoBO getMemberInfoByUserId(Long userId, String tenant) {
        String key = buildMemberCacheKey(userId,tenant);
        Object memberInfoStr=null;
        try {
            memberInfoStr = redisService.getValue(key);
        }catch (Exception e){
            log.error("获取用户信息缓存异常",e);
            Cat.logMetricForCount("OYO_USER_CACHE_READ_ERROR");
        }
        if (memberInfoStr != null) {
            return gson.fromJson(memberInfoStr.toString(), MemberInfoBO.class);
        }
        MemberInfoBO memberInfoBO = getMemberInfoFromDB(userId,tenant);
        //20191204 增加兜底
        if (memberInfoBO != null && memberInfoBO.getUserId() != null) {
            try {
                redisService.setNXValue(key, gson.toJson(memberInfoBO), LIVE_TIME);
            }catch (Exception e){
                log.error("写入用户信息缓存异常",e);
                Cat.logMetricForCount("OYO_USER_CACHE_WRITE_ERROR");
            }
        }else {
            log.info("用户id{},租户{}走进兜底逻辑",userId,tenant);
            Cat.logMetricForCount("OYO_USER_NO_EXIST");
            memberInfoBO=new MemberInfoBO();
            memberInfoBO.setUserId(userId);
            memberInfoBO.setTenant(tenant);
            memberInfoBO.setFictitious(true);
            if(MemberConstants.OYO_TENANT.equals(tenant)){
                memberInfoBO.setGradeId(GradeEnum.GRADE_V1.getGradeId());
                memberInfoBO.setNextGradeId(GradeEnum.GRADE_V2.getGradeId());
            }else {
                memberInfoBO.setGradeId(GradeEnum.GRADE_JP_V1.getGradeId());
                memberInfoBO.setNextGradeId(GradeEnum.GRADE_JP_V2.getGradeId());
            }

        }
        return memberInfoBO;
    }

    @Override
    public List<MemberInfoBO> getMemberInfoByUserIdList(List<Long> userIds, String tenant) {
        if (CollectionUtils.isEmpty(userIds) || userIds.size() > 40) {
            return null;
        }
        log.info("getMemberInfoByUserIdList入参集合：" + userIds.toString());
        List<MemberInfoBO> memberInfoBOList = Lists.newArrayList();
        List<String> keys = userIds.stream().filter(userId -> userId != null).map(userId -> buildMemberCacheKey(userId,tenant)).collect(Collectors.toList());
        List<Object> objectList = redisService.mGet(keys);
        List<MemberInfoBO> memberInfoBOS = objectList.stream().filter(object -> object != null).map(object -> gson.fromJson(object.toString(), MemberInfoBO.class)).collect(Collectors.toList());
        memberInfoBOList.addAll(memberInfoBOS);
        List<Long> redisUserIdList = memberInfoBOS.stream().filter(memberInfoBO -> memberInfoBO != null && memberInfoBO.getUserId() != null).map(memberInfoBO -> memberInfoBO.getUserId()).collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(redisUserIdList)) {
            log.info("getMemberInfoByUserIdList redis集合：" + redisUserIdList.toString());
            userIds.removeAll(redisUserIdList);
        }
        List<MemberInfoBO> dbBoList = Lists.newArrayList();
        if (CollectionUtils.isNotEmpty(userIds)) {
            dbBoList = getMemberInfoListFromDB(userIds,tenant);
        }
        if (CollectionUtils.isNotEmpty(dbBoList)) {
            memberInfoBOList.addAll(dbBoList);
            dbBoList.forEach(memberInfoBO -> redisService.setNXValue(buildMemberCacheKey(memberInfoBO.getUserId(),tenant), gson.toJson(memberInfoBO), LIVE_TIME));
        }
        return memberInfoBOList;    }

    @Override
    public MemberDetailBO getMemberDetailByUserId(Long userId,String tenant) {
        MemberDetailBO memberDetailBO = new MemberDetailBO();
        OyoUser user;
        PointsQueryBalanceVO pointsQueryBalanceVO;
        MemberInfoBO memberInfoBO = getMemberInfoByUserId(userId);
        memberDetailBO.setUserId(userId);
        try {
            user = getOyoUserByTeant(userId,tenant);
            PointsQueryBalanceDTO pointsQueryBalanceDTO = new PointsQueryBalanceDTO();
            pointsQueryBalanceDTO.setUserId(userId.toString());
            pointsQueryBalanceDTO.setTenantId(tenant);
            pointsQueryBalanceVO = pointsRemoteService.queryBalance(pointsQueryBalanceDTO);
            assembleMemberDetail(user, memberDetailBO, memberInfoBO, pointsQueryBalanceVO);
        } catch (Exception e) {
            log.error("调用用户中心服务异常getUserByUserId：" + userId, e);
        }
        return memberDetailBO;
    }


    private String buildMemberCacheKey(Long userId,String tenant) {
        return RedisConstants.MEMBERGRADE + tenant+":"+userId % 100 + ":" + userId;
    }

    /**
     * 会员信息转化
     *
     * @param user
     * @param memberDetailBO
     * @param memberInfoBO
     * @param pointsQueryBalanceVO
     */
    private void assembleMemberDetail(OyoUser user, MemberDetailBO memberDetailBO, MemberInfoBO memberInfoBO, PointsQueryBalanceVO pointsQueryBalanceVO) {
        if (user != null) {
            memberDetailBO.setAddress(user.getAddress());
            memberDetailBO.setCertificateNo(user.getCertificationNo());
            memberDetailBO.setPhone(user.getPhone());
            memberDetailBO.setUserName(user.getUserName());
            memberDetailBO.setCertificateType("身份证");
        }
        if (memberInfoBO != null && memberInfoBO.getUserId() != null) {
            memberDetailBO.setValidTime(memberInfoBO.getValidTime() == null ? "" : DATE_FORMATE.format(memberInfoBO.getGradeUpdateTime()) + "-" + DATE_FORMATE.format(memberInfoBO.getValidTime()));
            GradeInfoBO gradeInfoBO = gradeService.getGradeByGradeId(memberInfoBO.getGradeId());
            if (gradeInfoBO != null) {
                memberDetailBO.setIcon(gradeInfoBO.getIcon1());
            }
            memberDetailBO.setTenant(memberInfoBO.getTenant());
            memberDetailBO.setGrade(memberInfoBO.getGrade());
        }
        if (pointsQueryBalanceVO != null) {
            memberDetailBO.setBonus(pointsQueryBalanceVO.getTotalPointsNum());
            memberDetailBO.setBonusLimitTime(pointsQueryBalanceVO.getPointsLastExpireTime() == null ? "" : pointsQueryBalanceVO.getPointsLastExpireTime());
        }

    }

    /**
     * 从db获取会员等级信息
     *
     * @param userId
     * @return
     */
    @Override
    public MemberInfoBO getMemberInfoFromDB(Long userId,String tenant) {
        MemberInfoBO memberInfoBO = new MemberInfoBO();
        try {
            MemberGradeEntity memberGradeEntity = memberGradeMapper.getMemberGradeByUserId(userId,tenant);
            // 若会员不存在，则尝试进行注册补偿 //20191204 去除兜底
//            if (memberGradeEntity == null) {
//                OyoUser oyoUser = getOyoUser(userId,tenant);
//                if (oyoUser != null && oyoUser.getUserId()!= null) {
//                    MemberRegisterDTO memberRegisterDTO =new MemberRegisterDTO();
//                    memberRegisterDTO.setUserId(userId);
//                    memberRegisterDTO.setPlatform(MemberConstants.OYO_TENANT);
//                    memberRegisterDTO.setTenant(tenant);
//                    registerMemberV2(memberRegisterDTO);
//                    memberGradeEntity = memberGradeMapper.getMemberGradeByUserId(userId,tenant);
//                }
//            }
            if(memberGradeEntity==null){
                return null;
            }
            GradeInfoBO gradeInfoBO = gradeService.getGradeByGradeId(memberGradeEntity.getGradeId());
            memberInfoBO = convert2BO(memberGradeEntity, gradeInfoBO,tenant);
        } catch (Exception e) {
            log.error("getMemberInfoByUserId error:userId:" + userId, e);
        }
        return memberInfoBO;
    }

    @Override
    public void clearMemberInfoCache(Long userId, String tenant) {
        redisService.removeKey(buildMemberCacheKey(userId,tenant));

    }



    @Override
    public MemberEditBO updateUserInfoByUserId(Long userId, String certificateNo) {
        UpdateUserRequest request = new UpdateUserRequest();
        request.setUserId(userId);
        request.setCredentialNumber(certificateNo);
        MemberEditDTO memberEditDTO = userInfoRemoteService.updateUserByUserId(request);
        MemberEditBO memberEditBO = new MemberEditBO();
        memberEditBO.setSuccess(memberEditDTO.getSuccess());
        memberEditBO.setMsg(memberEditDTO.getMsg());
        return memberEditBO;

    }
    /**
     * 注册会员v2
     * @param memberRegisterDTO
     */
    @Override
    public void registerMemberV2(MemberRegisterDTO memberRegisterDTO) {
        retryBusinessService.registerRetry(memberRegisterDTO);
//        asynProess(memberRegisterDTO.getUserId(),memberRegisterDTO.getTenant());
    }

    /**
     * 新用户异步发券等行为
     * @param userId
     * @param tenant
     */
    public void asynProess(Long userId,String tenant) {
        threadPoolTaskExecutor.execute(() -> {
            List<Integer> actionList =REGISTER_ACTION.get(tenant);
            if(CollectionUtils.isEmpty(actionList)){
                return ;
            }
            OyoUser user = getOyoUser(userId,tenant);
            if(actionList.contains(SEND_COUPON_ACTION)&&NEWCOMER_SWITCH==0){
                log.info("走老逻辑,发券");
                sendCoupon(userId, user);
            }
            if(actionList.contains(SEND_MESSAGE_ACTION)){
                sendMessage(user);
            }
            if(actionList.contains(SEND_POINT_ACTION)){
                sendPoint(user);
            }

        });
    }

    /**
     * 改变等级
     * @param gradeId
     * @param preGradeId
     * @param userId
     */
    private void changeGrade(Integer gradeId, Integer preGradeId,Long userId,String tenant,Date validTime,Integer rule) {
        ChangeGradeBO changeGradeBO =new ChangeGradeBO();
        changeGradeBO.setGradeId(gradeId);
        changeGradeBO.setPreviousGradeId(preGradeId);
        changeGradeBO.setUserId(userId);
        changeGradeBO.setChangeType(rule);
        changeGradeBO.setTenant(tenant);
        changeGradeBO.setValidTime(validTime);
        changeGradeService.changeGrade(changeGradeBO);
    }

    @Override
    @Retry
    public Boolean syncMemberGrade(SyncMemberGradeRequestBO requestBO) {
        log.info("等级同步入参:{}",JSON.toJSONString(requestBO));
        if(requestBO.getGradeId()==null){
            return false;
        }
        MemberInfoBO memberInfoBO = getMemberInfoFromDB(requestBO.getUserId(),requestBO.getTenant());
        //如果没有则进行同步
        if(memberInfoBO==null){
            //201912 去掉兜底注册
//            int initGradeId=1;
//            if(MemberConstants.OYO_JP_TENANT.equals(requestBO.getTenant())){
//                initGradeId=11;
//            }
//            MemberGradeEntity memberGradeEntity = new MemberGradeEntity();
//            memberGradeEntity.setUserId(requestBO.getUserId());
//            memberGradeEntity.setPreviousGradeId(0);
//            memberGradeEntity.setGradeId(initGradeId);
//            memberGradeEntity.setUpdateRuleType(MemberConstants.UPDATE_GRADE_BY_NATURE);
//            memberGradeEntity.setTenant(requestBO.getTenant());
//            memberGradeMapper.insert(memberGradeEntity);
//            memberInfoBO = getMemberInfoFromDB(requestBO.getUserId(),requestBO.getTenant());
//            asynProess(requestBO.getUserId(),requestBO.getTenant());
            return false;
        }
        if(memberInfoBO!=null&&memberInfoBO.getUserId()!=null){
            Integer preGradeId=memberInfoBO.getGradeId();
            if(MemberConstants.OYO_JP_TENANT.equals(requestBO.getTenant())){
                if(requestBO.getPreGradeId()!=null){
                    preGradeId=requestBO.getPreGradeId();
                }
                changeGrade(requestBO.getGradeId(),preGradeId,requestBO.getUserId(),requestBO.getTenant(),requestBO.getValidTime(),requestBO.getRule());
            }
            if(MemberConstants.OYO_TENANT.equals(requestBO.getTenant())&&memberInfoBO.getGradeId()<requestBO.getGradeId()){
                changeGrade(requestBO.getGradeId(),preGradeId,requestBO.getUserId(),requestBO.getTenant(),requestBO.getValidTime(),requestBO.getRule());
            }
        }
        return true;
    }

    /**
     * 发放积分
     * @param
     */
    public void sendPoint(OyoUser user) {
        PointsAddDTO pointsAddDTO = new PointsAddDTO();
        pointsAddDTO.setBusinessNo(user.getUserId()+"japan");
        pointsAddDTO.setUserId(String.valueOf(user.getUserId()));
        pointsAddDTO.setUserName(user==null?"日本租户":user.getUserName());
        pointsAddDTO.setAmount(new BigDecimal(0));
        pointsAddDTO.setTotalPointsNum(Integer.valueOf(REGISTER_JP_POINT));
        pointsAddDTO.setOrderTime(DATE_FORMAT.format(new Date()));
        pointsAddDTO.setPayTime(DATE_FORMAT.format(new Date()));
        pointsAddDTO.setActivityId("register");
        pointsAddDTO.setMarketingName("注册奖励积分");
        pointsAddDTO.setEffectDate(SHORT_DATE_FORMAT.format(new Date()));
        if(MapUtils.isNotEmpty(bonusGainRuleInfoMap)&&bonusGainRuleInfoMap.get(MemberConstants.BONUS_POINTS_TYPE)!=null){
            pointsAddDTO.setExpireDate(SHORT_DATE_FORMAT.format(bonusGainRuleInfoMap.get(MemberConstants.BONUS_POINTS_TYPE).getValidPeriod()));
        }
        pointsAddDTO.setProvideId("OYO_JP");
        pointsAddDTO.setProvideName("OYO日本");
        pointsAddDTO.setProvideType("OYO");
        List<PointsDetailDTO> pointsDetails = Lists.newArrayList();
        PointsDetailDTO pointsDetailDTO =new PointsDetailDTO();
        pointsDetailDTO.setPointsNum(Integer.valueOf(REGISTER_JP_POINT));
        pointsDetailDTO.setPointTypeCode(MemberConstants.BONUS_POINTS_TYPE);
        BonusGainRuleDTO.BonusGainRuleInfo ruleInfo = bonusGainRuleInfoMap.get(MemberConstants.BONUS_POINTS_TYPE);
        pointsDetailDTO.setCostCode(ruleInfo==null?MemberConstants.OYO_JP_TENANT:ruleInfo.getComissionConfig().getUndertake1());
        pointsDetailDTO.setCostName(costCenterMap.get(ruleInfo.getComissionConfig().getUndertake1())==null?MemberConstants.OYO_JP_TENANT:costCenterMap.get(ruleInfo.getComissionConfig().getUndertake1()).getCostName());
        pointsDetailDTO.setPointTypeName("奖励积分");
        pointsAddDTO.setBusinessType("REGISTER");
        pointsAddDTO.setTenantId(MemberConstants.OYO_JP_TENANT);
        pointsDetails.add(pointsDetailDTO);
        pointsAddDTO.setPointsDetails(pointsDetails);
        retryBusinessService.sendPointRetry(pointsAddDTO);
    }

    /**
     * 查询用户信息，如果第一次未查到，sleep 100ms 再去查
     * @param userId
     * @param
     * @return
     */
    private OyoUser getOyoUser(Long userId,  String tenant) {
        OyoUser user = getOyoUserByTeant(userId, tenant);
        if(user==null||user.getUserId()==null){
            try {
                Thread.sleep(100L);
                user = getOyoUserByTeant(userId, tenant);
            } catch (InterruptedException e) {
                log.error("注册异步线程异常",e);
            }
        }
        log.info("查询用户信息:{}", JSON.toJSONString(user));
        return user;
    }

    private OyoUser getOyoUserByTeant(Long userId,  String tenant) {
        OyoUser user=null;
        if(MemberConstants.OYO_TENANT.equals(tenant)){
            QueryUserRequest request = new QueryUserRequest();
            request.setUserId(userId);
            user = userInfoRemoteService.getUserByUserId(request);
        }
        if(MemberConstants.OYO_JP_TENANT.equals(tenant)){
            List<OyoUser> oyoUserList=  jpUserInfoRemoteService.getAccountCustomersByBatch(Lists.newArrayList(userId));
            if(CollectionUtils.isNotEmpty(oyoUserList)){
                user =oyoUserList.get(0);
            }
        }
        return user;
    }

    /**
     * 发送券
     * @param userId
     * @param user
     */
    private void sendCoupon(Long userId, OyoUser user) {
        try {
            if (REGISTER_COUPON_SWITCH.equals(REGISTER_COUPON) && user != null && StringUtils.isNotEmpty(user.getPhone())) {
                couponHttpService.SendCoupon(userId, user.getPhone());
            }
        } catch (Exception e) {
            log.error("发送注册异常", e);
        }
    }

    /**
     * 发送短信
     * @param user
     */
    private void sendMessage(OyoUser user) {
        try {
            if (MESSAGE_SWITCH.equals(SEND_MESSAGE) && user != null && StringUtils.isNotEmpty(user.getPhone())) {
                smsService.send(buildeMsgRequest(user));
            }
        } catch (Exception e) {
            log.error("发送短信异常", e);
        }
    }

    /**
     * 构建发短信请求
     *
     * @param user
     * @return
     */
    private SmsRequest buildeMsgRequest(OyoUser user) {
        SmsRequest smsRequest = new SmsRequest();
        smsRequest.setMobile(user.getPhone());
        smsRequest.setTemplateId(TemplateId);
        return smsRequest;
    }

    /**
     * entity转化为BO
     *
     * @param memberGradeEntity
     * @param gradeInfoBO
     * @return
     */
    private MemberInfoBO convert2BO(MemberGradeEntity memberGradeEntity, GradeInfoBO gradeInfoBO,String tenant) {
        MemberInfoBO memberInfoBO = new MemberInfoBO();
        if (memberGradeEntity != null) {
            memberInfoBO.setUserId(memberGradeEntity.getUserId());
            memberInfoBO.setGradeId(memberGradeEntity.getGradeId());
            memberInfoBO.setNoshow(memberGradeEntity.getNoShow());
            memberInfoBO.setRoomNight(memberGradeEntity.getRoomNights());
            memberInfoBO.setTenant(memberGradeEntity.getTenant());
            Optional<GradeInfoBO> optional = gradeService.getGradeInfoList(tenant).stream().filter(gradeBO -> gradeBO.getGradeOrd() > memberGradeEntity.getGradeId()).findFirst();
            if (optional != null && optional.isPresent() && optional.get() != null) {
                GradeInfoBO nextgradeInfoBO = optional.get();
                memberInfoBO.setUpgradeRoomNights(nextgradeInfoBO.getRoomNights() - memberGradeEntity.getRoomNights());
            }
            memberInfoBO.setUpdateTime(memberGradeEntity.getUpdateTime());
            memberInfoBO.setValidTime(memberGradeEntity.getValidTime());
            memberInfoBO.setGradeUpdateTime(memberGradeEntity.getGradeUpdateTime());
            if (gradeInfoBO != null) {
                memberInfoBO.setGrade(gradeInfoBO.getGrade());
                memberInfoBO.setGradeName(gradeInfoBO.getGradeName());
                memberInfoBO.setNextGradeId(gradeInfoBO.getNextGradeId());
                memberInfoBO.setValidPeriod(gradeInfoBO.getValidPeriod());

            }
        }
        return memberInfoBO;
    }

    public List<MemberInfoBO> getMemberInfoListFromDB(List<Long> userIds,String tenant) {
        List<MemberInfoBO> result = Lists.newArrayList();
        try {
            List<MemberGradeEntity> entities = memberGradeMapper.getMemberGradeByUserIds(userIds,tenant);
            if (CollectionUtils.isEmpty(entities)) {
                return null;
            }
            entities.forEach(memberGradeEntity -> {
                try {
                    GradeInfoBO gradeInfoBO = gradeService.getGradeByGradeId(memberGradeEntity.getGradeId());
                    result.add(convert2BO(memberGradeEntity, gradeInfoBO,tenant));
                } catch (Exception e) {
                    log.error("getMemberInfoByUserIdList convert 2 Bo error:" + memberGradeEntity.toString(), e);
                }
            });
        } catch (Exception e) {
            log.error("getMemberInfoByUserIdList error:userId:" + userIds.toString(), e);
        }
        return result;
    }

}
