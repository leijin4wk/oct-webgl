package com.oyo.ump.member.service.bo;

import lombok.Data;
import lombok.ToString;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author Dong
 * @Classname CrowdBO
 * @Description 人群BO
 * @Date 2019-06-04
 */
@Data
@ToString
public class CrowdBO implements Serializable {
    private Long id;
    private String crowdName;
    private String crowdStatus;
    /**
     * 数据更新时间
     */
    private Date dataUpdateTime;
    private Integer crowdNum;
    /**
     * 人群创建方式（1 按标签；2 自定义）
     */
    private String crowdCreateType;
    private String crowdTag;
    /**
     * 自定义人群创建方式传入的user列表
     */
    private List<Long> userIds;
    private Date createTime;
    private Date updateTime;
    private Integer isDeleted;

    /**
     * 目标用户类型（1-c端用户；2-b端用户）
     */
    private Integer userType;
    /**
     * 人群类型（1-userid人群；2-pushid人群；3-openid人群）
     */
    private Integer crowdType;
    /**
     * 自定义人群创建方式传入的pushid信息列表
     */
    private List<CrowdPushIdBO> pushIdInfos;
    /**
     * 自定义人群创建方式传入的openid信息列表
     */
    private List<CrowdOpenIdBO> openIdInfos;
}
