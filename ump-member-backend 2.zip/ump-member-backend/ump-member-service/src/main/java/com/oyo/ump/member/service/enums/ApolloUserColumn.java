package com.oyo.ump.member.service.enums;

/**
 * apollo 用户表字段映射
* @author leijin
* @date 2019-12-21 16:04
**/
public enum ApolloUserColumn {
    REGION("region","region_id"),
    ZONE("zone","zone_id"),
    HUB("hub","hub_id"),
    CLC("clc","clc_id"),
    STREET("street","street_id"),
    CLUSTER("cluster","cluster_id"),
    CITY("city","city_id"),
    STATE("state","state_id");

    public String getName() {
        return name;
    }

    public String getColumn() {
        return column;
    }

    private String name;

    private String column;

    ApolloUserColumn(String name, String column) {
        this.name = name;
        this.column = column;
    }
    public static ApolloUserColumn getColumnByName(String name){
        for (ApolloUserColumn item:ApolloUserColumn.values()) {
           if (item.name.equals(name)){
               return item;
           }
        }
       return null;
    }

}
