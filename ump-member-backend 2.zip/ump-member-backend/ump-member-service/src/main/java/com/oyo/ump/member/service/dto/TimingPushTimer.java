package com.oyo.ump.member.service.dto;

import com.oyo.ump.member.dal.dao.PushJobRecordMapper;
import com.oyo.ump.member.dal.dao.PushMapper;
import com.oyo.ump.member.dal.model.PushEntity;
import com.oyo.ump.member.dal.model.PushJobRecordEntity;
import com.oyo.ump.member.service.PushProcessService;
import com.oyo.ump.member.service.enums.PushRecordStatusEnum;
import io.netty.util.Timeout;
import lombok.extern.slf4j.Slf4j;


/**
 * 处理定时任务的时间轮任务
 *
 * @author frank
 * @date 2019-06-13 15:40
 **/
@Slf4j
public class TimingPushTimer extends BasePushTimer {

    private PushJobRecordMapper pushJobRecordMapper;

    private PushProcessService pushProcessService;

    private PushJobRecordEntity pushJobRecordEntity;

    public TimingPushTimer(PushProcessService pushProcessService, PushJobRecordMapper pushJobRecordMapper, PushJobRecordEntity pushJobRecordEntity, Long delayTime) {
        super(delayTime);
        this.pushJobRecordMapper = pushJobRecordMapper;
        this.pushProcessService = pushProcessService;
        this.pushJobRecordEntity = pushJobRecordEntity;
    }

    @Override
    public void run(Timeout timeout) {
        try {
            pushJobRecordMapper.updateStatus(pushJobRecordEntity.getId(), PushRecordStatusEnum.Sending.getStatus());
            log.info("发送id：{} record 任务！",pushJobRecordEntity.getId());
            pushProcessService.sendMessageByPushId(pushJobRecordEntity.getMemberPushId(), pushJobRecordEntity.getId());
            pushJobRecordMapper.updateStatus(pushJobRecordEntity.getId(), PushRecordStatusEnum.SendFinish.getStatus());
        } catch (Exception e) {
            e.printStackTrace();
            log.error("消息推送异常,{}", e.getMessage());
            pushJobRecordMapper.updateStatus(pushJobRecordEntity.getId(), PushRecordStatusEnum.Error.getStatus());
        }
    }
}
