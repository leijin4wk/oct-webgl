package com.oyo.ump.member.service;

import com.oyo.common.response.PagedResponse;
import com.oyo.ump.member.dal.model.UmpDataMemberDimRptEntity;
import com.oyo.ump.member.service.bo.*;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author Dong
 * @Classname CrowdService
 * @Description 人群业务接口
 * @Date 2019-05-06
 */
public interface CrowdService {
    Long insertCrowd(CrowdBO crowdBO);
    CrowdBO selectById(Long id);
    List<CrowdBO> selectByCondition(Map<String, String> params);
    PagedResponse<CrowdBO> selectByConditionPaged(Map<String, String> params, Integer pageNum, Integer pageSize);
    void updateCrowd(CrowdBO crowdBO);
    void deleteCrowd(Long id);
    List<SelectCrowdBo> findSelectCrowdBoByIds(List<Long> crowdList);
    //定时任务刷新人群包数量
    void jobUpdateCrowdsQty();
    /**
     * 添加用户到人群包
    * @author leijin
    * @date 2019-10-29 16:08
    **/
    AddUserToCrowdBO addUserToCrowd(Long id, Set<Long>userIds, String name);

    /**
     * 删除人群包用户
     * @param crowdId 人群包id
     * @param userIds 需要删除的用户id
    *  @author leijin
    *  @date 2019-10-29 16:53
    **/
    void deleteCrowdUser(Long crowdId,Set<Long> userIds);

    /**
     * 根据用户id分组获取用户数据列表
    * @author leijin
    * @date 2019-10-29 17:01
    **/
    PagedResponse<CrowdUsersBo> findCrowdUser(Set<Long> crowdIds,Long  userId,Integer  pageNum, Integer  pageSize);
    /**
     * 用户是否存在于人群包中
    * @author leijin
    * @date 2019-10-29 17:03
    **/
    Boolean existCrowdUser( Long crowdId, Long  userId);

    /**
     * 根据id获取类型
     * @param crowdId
     * @return
     */
    List<RuleBO> getCrowdDetailById(Long crowdId);

    /**
     * 获取用户画像
     * @param userId
     * @return
     */
    UmpDataMemberDimRptEntity getMemberDimInfo(Long userId,String distinctId);

    /**
     * 判断用户画像是否符合人群判断
     * @param crowdBO
     * @param entity
     * @return
     */
    Boolean userFitCrowdRule(CrowdBO crowdBO, UmpDataMemberDimRptEntity entity);

    /**
     * 获取某个自定义人群的数量
     * @param crowdId
     * @return
     */
    Long getCrowdCount(Long crowdId);

    /**
     *批量获取人群
     * @param crowdIdList
     * @return
     */
    List<CrowdBO> batchGetCrowd(List<Long> crowdIdList);

    /**
     * B端阿波罗用户，邮箱转userId
     * @param emails
     * @return java.util.List<java.lang.Long>
     */
    List<Long> getUserIdsByEmails(List<String> emails);

    /**
     * B端用户，工号转userId
     * @param employeeNos
     * @return java.util.List<java.lang.Long>
     */
    List<Long> getUserIdsByEmployeeNos(List<String> employeeNos);
}
