package com.oyo.ump.member.service;


import com.google.common.collect.Lists;
import com.oyo.ump.member.service.bo.HotelBO;

import java.util.List;
import java.util.Map;

/**
 * @Classname HotelService
 * @Description 酒店接口
 * @Date 2019-03-15 11:34
 * @Author Dong
 */

public interface HotelService {

   /**
    * 查询所有的酒店信息
    * @return com.oyo.ump.member.service.dto.HotelDTO
    */
   @Deprecated
    List<HotelBO> getHotelList();

    /**
     * 查询参与或活动的酒店ID
     * @param hotelIds 酒店ID列表
     * @return java.util.List<java.lang.Long>
     */
    List<HotelBO> getSalesHotel(List<Long> hotelIds);

    /**
     * 查询是否活动酒店Id
     * @param hotelId 酒店ID
     * @return java.lang.Long
     */
    default boolean isMemberHotel(Long hotelId){
        return isMemberHotel(Lists.newArrayList(hotelId)).get(hotelId);
    }

    /**
     *
     * @param hotelList
     * @return
     */
    Map<Long,Boolean> isMemberHotel(List<Long> hotelList);

    void addMemberHotel(Long hotelId,Integer cityId);
}
