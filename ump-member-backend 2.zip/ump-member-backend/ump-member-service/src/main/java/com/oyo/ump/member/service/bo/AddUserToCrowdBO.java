package com.oyo.ump.member.service.bo;

import lombok.Data;

/**
 * @Description: todo
 * @Author: fang
 * @create: 2019-12-09
 **/
@Data
public class AddUserToCrowdBO {
    /**
     * 人群包id
     */
    private Long crowdId;
    /**
     * 插入成功的数量
     */
    private Integer count;
}
