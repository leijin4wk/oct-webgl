package com.oyo.ump.member.service.schedule;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @Description: 等级本地缓存定时刷新
 * @Author: fang
 * @create: 2019-03-25
 **/
@Component
@Slf4j
public class GradeShecduleService {

}
