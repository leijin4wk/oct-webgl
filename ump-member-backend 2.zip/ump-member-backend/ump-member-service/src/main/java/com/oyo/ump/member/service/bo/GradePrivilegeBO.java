package com.oyo.ump.member.service.bo;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

/**
 * @Description: 等级权益BO
 * @Author: fang
 * @create: 2019-03-22
 **/
@Data
public class GradePrivilegeBO implements Serializable{
    private Integer gradeId;
    private String grade;
    private SpecialDiscount specialDiscount;
    private LateCheckout lateCheckout;
    private OptimalPriceGurantee optimalPriceGurantee;
    private ReservationGuarantee reservationGuarantee;
    private FreeWifi freeWifi;
    private BonusConfig bonusConfig;
    @Data
    public static class SpecialDiscount implements Serializable{
        private Integer discount;
        private Boolean memberLimit;
        private Boolean discountLimit;
        private Integer undertakeOwner;
        private Integer undertakeOyo;
        private String icon;
        private String icon2;
        private Boolean hold;
        private String description;
        private String description2;
        private Integer index;
        private String name="预付折扣";
        private String name2="预付折扣";

    }
    @Data
    public static class LateCheckout implements Serializable{
        private Boolean memberLimit;
        private String detail;
        private Integer timeLimit;
        private String icon;
        private String icon2;
        private Boolean hold;
        private String description;
        private String description2;
        private Integer index;
        private String name="延迟退房";
        private String name2="延迟退房";


    }
    @Data
    public static class OptimalPriceGurantee implements Serializable{
        private Boolean memberLimit;
        private String guaranteeType;
        private String icon;
        private String icon2;
        private Boolean hold;
        private String description;
        private String description2;
        private Integer index;
        private String name="积分抵扣";
        private String name2="鸥币抵扣";


    }
    @Data
    public static class ReservationGuarantee implements Serializable {
        private Boolean memberLimit;
        private Integer guaranteeHours;
        private String icon;
        private String icon2;
        private Boolean hold;
        private String description;
        private String description2;
        private Integer index;
        private String name="预订保障";
        private String name2="预订保障";

    }
    @Data
    public static class FreeWifi implements Serializable{
        private Boolean memberLimit;
        private Integer wifiHours;
        private String icon;
        private String icon2;
        private Boolean hold;
        private String description;
        private String description2;
        private Integer index;
        private String name="极速wifi";
        private String name2="极速wifi";



    }
    @Data
    public static class BonusConfig implements Serializable{
        private Boolean memberLimit;
        private String bonusFactor;
        private String consumeFactor;
        private String icon;
        private String icon2;
        private Boolean hold;
        private String description;
        private String description2;
        private Integer index;
        private SignPoint signPoint;
        private String name="积分奖励";
        private String name2="鸥币奖励";
    }
    @Data
    public static class SignPoint{
        private Integer pointNum;
        private Integer delay;
        private Integer gainUndertakeOyo;
        private Integer gainUndertakeOwner;
        private Integer costUndertakeOyo;
        private Integer costUndertakeOwner;
    }
}
