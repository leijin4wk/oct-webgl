package com.oyo.ump.member.service.enums;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import java.util.List;
import java.util.Map;

public enum TagOperatorEnum {
    TagOperatorEnum1("in","包含",Lists.newArrayList(0)),
    TagOperatorEnum2("not in","不包含",Lists.newArrayList(1,-1)),
    TagOperatorEnum3(">","大于", Lists.newArrayList(1)),
    TagOperatorEnum4("<","小于",Lists.newArrayList(-1)),
    TagOperatorEnum5(">=","大于等于",Lists.newArrayList(1,0)),
    TagOperatorEnum6("<=","小于等于",Lists.newArrayList(-1,0)),
    TagOperatorEnum7("=","等于",Lists.newArrayList(0)),
    TagOperatorEnum8("!=","不等于",Lists.newArrayList(-1,1));


    private final String code;
    private final String name;
    private final List<Integer> compareList;
    private static Map<String,String> initMap= Maps.newHashMap();
    private static Map<String,List<Integer>> initCompareMap= Maps.newHashMap();

    static  {
        TagOperatorEnum[] values = values();
        for (int i = 0; i <values.length ; i++) {
            initMap.put(values[i].code,values[i].name);
            initCompareMap.put(values[i].code,values[i].compareList);
        }

    }

    public String getCode() {
        return code;
    }
    public String getName() {
        return name;
    }
    TagOperatorEnum(String code, String name,List<Integer> compareList){
        this.name=name;
        this.code=code;
        this.compareList=compareList;
    }
    public static String getNameByCode(String code){
        return initMap.containsKey(code)?initMap.get(code):"";
    }
    public static List<Integer> getCompareListByCode(String code){
        return initCompareMap.containsKey(code)?initCompareMap.get(code):Lists.newArrayList();
    }


    }
