package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;

/**
 * @author Dong
 * @Classname PushExtraBO
 * @Description
 * @Date 2019-06-12
 */
@Data
public class PushExtraBO implements Serializable {
    private Long id;
    private Long pushId;
    private String actUserType;
    private String actType;
    private String actTypeDetail;
    private String couponCode;
    private String couponAmount;
    private String couponType;
}
