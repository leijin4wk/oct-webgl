package com.oyo.ump.member.service;

import com.oyo.ump.member.service.bo.PushEventMetaBO;
import com.oyo.ump.member.service.bo.PushRuleBO;

import java.util.List;

/**
 * @author Dong
 * @Classname PushRuleService
 * @Description 事件推送圈定条件业务接口
 * @Date 2019-05-07
 */
public interface PushRuleService {
    PushRuleBO selectById(Long id);
    List<PushEventMetaBO> selectAll();

}
