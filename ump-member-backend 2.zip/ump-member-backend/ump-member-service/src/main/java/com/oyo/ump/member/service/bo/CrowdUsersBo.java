package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class CrowdUsersBo implements Serializable {

    private  Long  userId;

    private String crowdIds;

    private Date createTime;
}
