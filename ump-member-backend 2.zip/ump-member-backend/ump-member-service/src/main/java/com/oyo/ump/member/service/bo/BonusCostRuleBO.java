package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author Dong
 * @Classname BonusCostRuleBO
 * @Description 积分消耗规则BO
 * @Date 2019-03-25
 */
@Data
public class BonusCostRuleBO implements Serializable {
    private Integer id;

    private Integer deductionRatio;
    /**
     * 每一积分可抵扣人民币（元）
     */
    private BigDecimal pricePerUnit;
    /**
     * 每次抵扣至少使用多少积分
     */
    private Integer minBonus;

    private Boolean isDeleted;
}
