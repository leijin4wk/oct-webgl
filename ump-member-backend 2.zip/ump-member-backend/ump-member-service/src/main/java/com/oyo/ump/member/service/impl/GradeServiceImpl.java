package com.oyo.ump.member.service.impl;

import com.google.common.collect.Maps;
import com.oyo.ump.member.common.constants.MemberConstants;
import com.oyo.ump.member.dal.dao.MemberGradeConfigMapper;
import com.oyo.ump.member.dal.model.MemberGradeConfigEntity;
import com.oyo.ump.member.service.GradeService;
import com.oyo.ump.member.service.bo.GradeInfoBO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * @Description: 会员等级信息实现类
 * @Author: fang
 * @create: 2019-03-13
 **/

@Service
@Slf4j
public class GradeServiceImpl implements GradeService {
    private Map<String,List<GradeInfoBO>> GRADE_CACHE_LIST_MAP = Maps.newHashMap();
    private Map<Integer,GradeInfoBO> GRADE_CACHE_MAP= Maps.newHashMap();
    @Autowired
    private MemberGradeConfigMapper memberGradeConfigMapper;
    @Override
    public List<GradeInfoBO> getGradeInfoList(String tenant) {
        if(MapUtils.isEmpty(GRADE_CACHE_LIST_MAP)){
            refreshGradeFromDB();
        }
        return GRADE_CACHE_LIST_MAP.get(tenant);
    }

    @Override
    public GradeInfoBO getGradeByGradeId(Integer gradeId) {
        if(MapUtils.isEmpty(GRADE_CACHE_MAP)){
            refreshGradeFromDB();
        }
        return GRADE_CACHE_MAP.get(gradeId);
    }


    /**
     * inti时读取数据库数据并塞入GRADE_CACHE_LIST
     *
     * @return
     */
    @PostConstruct
    private void refreshGradeFromDB() {
             List<MemberGradeConfigEntity> entityList = memberGradeConfigMapper.queryAll();
             convert2BO(entityList);
    }

    /**
     * entityList转化为BO
     *
     * @param entityList
     */
    private void convert2BO(List<MemberGradeConfigEntity> entityList) {
        List<GradeInfoBO> oyoGradeList = Lists.newArrayList();
        List<GradeInfoBO> japanGradeList = Lists.newArrayList();

        if (CollectionUtils.isNotEmpty(entityList)) {
            entityList .forEach(memberGradeConfigEntity -> {
                GradeInfoBO gradeInfoBO = convertEntity2GradeInfoBO(memberGradeConfigEntity);
                // 是否有上一等级
                MemberGradeConfigEntity previousGrade = memberGradeConfigMapper.getMemberGradeConfigByGradeOrd(gradeInfoBO.getGradeOrd() - 1);
                if (previousGrade != null) {
                    gradeInfoBO.setPreviousGradeId(previousGrade.getId());
                }
                // 是否有下一等级
                MemberGradeConfigEntity nextGrade = memberGradeConfigMapper.getMemberGradeConfigByGradeOrd(gradeInfoBO.getGradeOrd() + 1);
                if (nextGrade != null) {
                    gradeInfoBO.setNextGradeId(nextGrade.getId());
                }
                GRADE_CACHE_MAP.put(gradeInfoBO.getGradeId(),gradeInfoBO);
                switch (gradeInfoBO.getTenant()){
                    case MemberConstants.OYO_TENANT:
                        oyoGradeList.add(gradeInfoBO);
                        break;
                    case MemberConstants.OYO_JP_TENANT :
                        japanGradeList.add(gradeInfoBO);
                        break;
                        default:break;
                }
            });
            Collections.reverse(oyoGradeList);
            Collections.reverse(japanGradeList);
            GRADE_CACHE_LIST_MAP.put(MemberConstants.OYO_TENANT,oyoGradeList);
            GRADE_CACHE_LIST_MAP.put(MemberConstants.OYO_JP_TENANT,japanGradeList);
        }
    }


    /**
     * 转化entity为memberinfo
     *
     * @param memberGradeConfigEntity
     * @return
     */
    private GradeInfoBO convertEntity2GradeInfoBO(MemberGradeConfigEntity memberGradeConfigEntity) {
        GradeInfoBO gradeInfoBO = new GradeInfoBO();
        gradeInfoBO.setGradeId(memberGradeConfigEntity.getId());
        gradeInfoBO.setGrade(memberGradeConfigEntity.getGrade());
        gradeInfoBO.setGradeOrd(memberGradeConfigEntity.getGradeOrd());
        gradeInfoBO.setGradeName(memberGradeConfigEntity.getGradeName());
        gradeInfoBO.setRoomNights(memberGradeConfigEntity.getRoomNights());
        gradeInfoBO.setNoShow(memberGradeConfigEntity.getNoShow());
        gradeInfoBO.setValidPeriod(memberGradeConfigEntity.getValidPeriod());
        gradeInfoBO.setDegradeFlag(memberGradeConfigEntity.getDegradeFlag().intValue() == 1);
        gradeInfoBO.setDescription(memberGradeConfigEntity.getDescription());
        gradeInfoBO.setIcon1(memberGradeConfigEntity.getGradeIcon());
        gradeInfoBO.setIcon2(memberGradeConfigEntity.getGradeIcon2());
        gradeInfoBO.setRelegationNights(memberGradeConfigEntity.getRelegationNights());
        gradeInfoBO.setRelegationNoshow(memberGradeConfigEntity.getRelegationNoShow());
        gradeInfoBO.setText(memberGradeConfigEntity.getText());
        gradeInfoBO.setMemberLimit(memberGradeConfigEntity.getMemberLimit().intValue()==1);
        gradeInfoBO.setRelegationDays(memberGradeConfigEntity.getRelegationDays());
        gradeInfoBO.setTenant(memberGradeConfigEntity.getTenant());
        return gradeInfoBO;
    }
}
