package com.oyo.ump.member.service.utils;


import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 方法重试组件
 * @author fang
 */
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface BusinessRetry {

    int retry() default 2;

    Class<? extends Throwable>[] exception() default {Exception.class};

    String[] result() default {"true"};

    String field() default "";

    int type() default -1;

    String retryMethod() default "";


}
