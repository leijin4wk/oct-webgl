package com.oyo.ump.member.service;

import com.oyo.ump.member.service.bo.ColumnAndMqParamBo;

/**
 *用于组装系统参数和自定义参数
* @author leijin
* @date 2019-12-04 11:47
**/
public interface TemplateParameterService {
      /*组装参数
      * @author leijin
      * @date 2019-12-04 11:58
      **/
      ColumnAndMqParamBo buildColumnAndMqKeyParam(ColumnAndMqParamBo columnAndMqParamBo);
}
