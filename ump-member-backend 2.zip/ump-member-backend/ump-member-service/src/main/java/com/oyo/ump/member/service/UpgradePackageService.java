package com.oyo.ump.member.service;

import com.oyo.ump.member.service.bo.UpgradePackageBO;
import com.oyo.ump.member.service.bo.UpgradePackagePageBO;

import java.util.List;


/**
 * @Classname UpgradePackageService
 * @Description 会员升级包接口
 * @Date 2019-03-14 16:37
 * @author Dong
 */
public interface UpgradePackageService {
    /**
     *
     * @param
     * @return com.oyo.ump.member.service.bo.UpgradePackagePageBO
     */
    UpgradePackagePageBO getUpgradePackageList();

    /**
     * 获取所有的升级包
     * @param pageNum 页码
     * @param pageSize 每页数量
     * @return java.util.List<com.oyo.ump.member.service.bo.UpgradePackageBO>
     */
    UpgradePackagePageBO getUpgradePackageList(Integer pageNum, Integer pageSize);

    /**
     * 通过会员等级id 获取能购买的升级包(对外)
     * @param gradeId 会员等级id
     * @return java.util.List<com.oyo.ump.member.service.bo.UpgradePackageBO>
     */
    List<UpgradePackageBO> getUpgradePackageListByGradeId(int gradeId);

    /**
     * 通过升级包code获取升级包信息
     * @param skuCode 升级包code
     * @return com.oyo.ump.member.service.bo.UpgradePackageBO
     */
    UpgradePackageBO getUpgradePackageByCode(String skuCode);

    List<String>  getProductCategoryIds();
}
