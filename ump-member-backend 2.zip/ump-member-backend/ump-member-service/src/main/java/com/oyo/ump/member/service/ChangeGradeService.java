package com.oyo.ump.member.service;

import com.oyo.ump.member.service.bo.ChangeGradeBO;

/**
 * @author Dong
 * @Classname ChangeGradeService
 * @Description 等级变更接口
 * @Date 2019-04-02
 */
public interface ChangeGradeService {

    void changeGrade (ChangeGradeBO changeGradeBO);
}
