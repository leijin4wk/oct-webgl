package com.oyo.ump.member.service.impl;

import com.alibaba.dubbo.rpc.RpcException;
import com.alibaba.fastjson.JSON;
import com.oyo.cpush.client.dto.request.*;
import com.oyo.ump.member.common.constants.MemberConstants;
import com.oyo.ump.member.common.enums.PushAppTypeEnum;
import com.oyo.ump.member.dal.dao.PushJobRecordMapper;
import com.oyo.ump.member.dal.dao.PushMapper;
import com.oyo.ump.member.dal.dao.PushMessageMapper;
import com.oyo.ump.member.dal.model.PushEntity;
import com.oyo.ump.member.dal.model.PushMessageEntity;
import com.oyo.ump.member.integration.service.push.UniformPushRpcService;
import com.oyo.ump.member.service.PushTemplateRelationService;
import com.oyo.ump.member.service.UniformPushService;
import com.oyo.ump.member.service.enums.TriggerChannelEnum;
import com.oyo.ump.member.service.enums.UserTypeEnum;
import com.oyo.ump.member.service.producer.memberPush.MemberPushMessage;
import com.oyo.ump.member.service.producer.memberPush.MemberPushPublisher;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Dong
 * @Description 统一推送接口
 * @Date 2019-09-17
 */
@Service
@Slf4j
public class UniformPushServiceImpl implements UniformPushService {
    @Autowired
    UniformPushRpcService uniformPushRpcService;
    @Autowired
    PushMessageMapper pushMessageMapper;
    @Autowired
    PushJobRecordMapper pushJobRecordMapper;
    @Autowired
    @Qualifier("insertPushThreadPoolTaskExecutor")
    ThreadPoolTaskExecutor threadPoolTaskExecutor;
    @Autowired
    PushTemplateRelationService pushTemplateRelationService;
    @Autowired
    PushMapper pushMapper;
    @Autowired
    MemberPushPublisher memberPushPublisher;

    @Override
    public String sendAndGetBatchNo(List<PushMessageEntity> batchList, Boolean testFlag) {
        if(CollectionUtils.isEmpty(batchList)){
            log.info("要发送的信息为空！");
            return null;
        }
        if(testFlag){
            log.info("这是一条测试发送！");
        }
        Long memberPushId = batchList.get(0).getMemberPushId();
        PushEntity pushEntity =  pushMapper.selectById(memberPushId);
        Integer pushStatus = pushEntity.getPushStatus();
        Integer triggerChannel = pushEntity.getTriggerChannel();
        String pushName = pushEntity.getPushName();

        String batchNo;

        if (Integer.valueOf(1).equals(pushStatus) || testFlag){
            log.info("发送开关状态为开");
            if(null == triggerChannel || null == TriggerChannelEnum.getByType(triggerChannel)){
                log.info("发送方式为空，或者发送方式非法！");
                return null;
            }
            switch (TriggerChannelEnum.getByType(triggerChannel)){
                case APPPUSH:
                    if(UserTypeEnum.BUSINESS_TYPE.getType().equals(pushEntity.getUserType())){
                        log.info("阿波罗推送:{}",batchList.get(0).getMemberPushId());
                        batchNo = sendAppPush(PushAppTypeEnum.APOLLO_APP.getType(),batchList,triggerChannel,pushName);
                        break;
                    }else {
                        if(!MemberConstants.NOT_MEMBER_MEMBER_ID.equals(batchList.get(0).getMemberId())){
                            log.info("会员AppPUSH推送:{}",batchList.get(0).getMemberPushId());
                            batchNo = sendAppPush(PushAppTypeEnum.OYO_APP.getType(),batchList,triggerChannel,pushName);
                            break;
                        }else {
                            log.info("非会员APPPUSH推送:{}",batchList.get(0).getMemberId());
                            AppPushWithPushIdAndChannelTypeRequestDTO appPushWithPushIdAndChannelTypeRequestDTO = new AppPushWithPushIdAndChannelTypeRequestDTO();
                            appPushWithPushIdAndChannelTypeRequestDTO.setTargetType(6);
                            appPushWithPushIdAndChannelTypeRequestDTO.setPushName(pushName);
                            appPushWithPushIdAndChannelTypeRequestDTO.setAppType(PushAppTypeEnum.OYO_APP.getType());
                            appPushWithPushIdAndChannelTypeRequestDTO.setJumpValue(JSON.parseObject(batchList.get(0).getMessageDetail(), Map.class).get("jumpValue").toString());
                            PushCommonParams NONMEMBERAPPPUSHCommonParams =  getPushCommonParams(batchList,triggerChannel);
                            appPushWithPushIdAndChannelTypeRequestDTO.setTemplateCode(NONMEMBERAPPPUSHCommonParams.getTemplateCode());
                            appPushWithPushIdAndChannelTypeRequestDTO.setExtra(NONMEMBERAPPPUSHCommonParams.getExtra());
                            appPushWithPushIdAndChannelTypeRequestDTO.setPushList(NONMEMBERAPPPUSHCommonParams.getPushList());
                            batchNo = uniformPushRpcService.sentPush(appPushWithPushIdAndChannelTypeRequestDTO);
                            break;
                        }
                    }
                case SMS:
                    SmsPushWithParamsRequestDTO smsPushWithParamsRequestDTO = new SmsPushWithParamsRequestDTO();
                    smsPushWithParamsRequestDTO.setTargetType(2);
                    PushCommonParams SMSCommonParams =  getPushCommonParams(batchList,triggerChannel);
                    smsPushWithParamsRequestDTO.setTemplateCode(SMSCommonParams.getTemplateCode());
                    smsPushWithParamsRequestDTO.setExtra(SMSCommonParams.getExtra());
                    smsPushWithParamsRequestDTO.setTemplateParams(SMSCommonParams.getTemplateParams());
                    batchNo = uniformPushRpcService.sentPush(smsPushWithParamsRequestDTO);
                    break;
                case WECHAT:
                    WeChatOfficialAccountWithParamsPushRequestDTO weChatOfficialAccountWithParamsPushRequestDTO = new WeChatOfficialAccountWithParamsPushRequestDTO();
                    weChatOfficialAccountWithParamsPushRequestDTO.setTargetType(2);
                    PushCommonParams WECHATCommonParams =  getPushCommonParams(batchList,triggerChannel);
                    weChatOfficialAccountWithParamsPushRequestDTO.setTemplateParams(WECHATCommonParams.getWeChatTemplateParams());
                    weChatOfficialAccountWithParamsPushRequestDTO.setIndividualParams(WECHATCommonParams.getIndividualParams());
                    weChatOfficialAccountWithParamsPushRequestDTO.setTemplateCode(WECHATCommonParams.getTemplateCode());
                    weChatOfficialAccountWithParamsPushRequestDTO.setExtra(WECHATCommonParams.getExtra());
                    batchNo = uniformPushRpcService.sentPush(weChatOfficialAccountWithParamsPushRequestDTO);
                    break;
                case WECHATAPP:
                    WeChatMiniAppWithParamsPushRequestDTO weChatMiniAppWithParamsPushRequestDTO = new WeChatMiniAppWithParamsPushRequestDTO();
                    weChatMiniAppWithParamsPushRequestDTO.setTargetType(2);
                    PushCommonParams WECHATAPPCommonParams =  getPushCommonParams(batchList,triggerChannel);
                    weChatMiniAppWithParamsPushRequestDTO.setTemplateParams(WECHATAPPCommonParams.getWeChatTemplateParams());
                    weChatMiniAppWithParamsPushRequestDTO.setIndividualParams(WECHATAPPCommonParams.getIndividualParams());
                    weChatMiniAppWithParamsPushRequestDTO.setTemplateCode(WECHATAPPCommonParams.getTemplateCode());
                    weChatMiniAppWithParamsPushRequestDTO.setExtra(WECHATAPPCommonParams.getExtra());
                    batchNo = uniformPushRpcService.sentPush(weChatMiniAppWithParamsPushRequestDTO);
                    break;
                case INTERNALMSG:
                    InterMsgWithoutParamsRequestDTO interMsgWithoutParamsRequestDTO = new InterMsgWithoutParamsRequestDTO();
                    interMsgWithoutParamsRequestDTO.setTargetType(2);
                    PushCommonParams INTERNALMSGCommonParams =  getPushCommonParams(batchList,triggerChannel);
                    interMsgWithoutParamsRequestDTO.setTemplateCode(INTERNALMSGCommonParams.getTemplateCode());
                    interMsgWithoutParamsRequestDTO.setTargetList(INTERNALMSGCommonParams.getTargetList());
                    batchNo = uniformPushRpcService.sentPush(interMsgWithoutParamsRequestDTO);
                    break;
                default:
                    batchNo="无此推送类型";
                    break;
            }
        }else{
            log.info("发送开关状态为关或空，不发送！更新固定批次号！");
            batchNo="123456789";
        }

        if (batchNo==null){
            log.info("发送失败，没有返回批次号！");
        }

        return batchNo;
    }

    @Override
    public void sendAndInsertPush(MemberPushMessage memberPushMessage) {
        if(CollectionUtils.isNotEmpty(memberPushMessage.getPushMessageEntities()) && memberPushMessage.getTimes()< MemberConstants.PUSH_RETRY_TIME){
            // 1、发送
            try{
                String batchNo = sendAndGetBatchNo(memberPushMessage.getPushMessageEntities(),memberPushMessage.getTestFlag());
                if(null != batchNo){
                    memberPushMessage.getPushMessageEntities().forEach(pushMessageEntity -> {
                        pushMessageEntity.setBatchNo(batchNo);
                        pushMessageEntity.setStatus(1);
                    });
                }
                threadPoolTaskExecutor.execute(()->{
                    // 2、异步插库
                    pushMessageMapper.insertPushMessageEntityList(memberPushMessage.getPushMessageEntities());
                });
            }catch (RpcException e){
                log.error("调用PUSH dubbo服务异常，重试次数加1，重新放入队列:   "+e.getCode(), e);
                // 调用PUSH dubbo服务异常，重试次数加1，重新放入队列
                memberPushMessage.setTimes(memberPushMessage.getTimes()+1);
                memberPushPublisher.execute(memberPushMessage);
            }catch (Exception e){
                log.info("发送push出现业务异常",e);
            }
        }
    }

    private String sendAppPush(Integer appType,List<PushMessageEntity> batchList,Integer triggerChannel,String pushName){
        AppPushWithParamsRequestDTO appPushWithParamsRequestDTO = new AppPushWithParamsRequestDTO();
        appPushWithParamsRequestDTO.setTargetType(2);
        appPushWithParamsRequestDTO.setPushName(pushName);
        appPushWithParamsRequestDTO.setAppType(appType);
        PushCommonParams APPCommonParams =  getPushCommonParams(batchList,triggerChannel);
        appPushWithParamsRequestDTO.setTemplateCode(APPCommonParams.getTemplateCode());
        appPushWithParamsRequestDTO.setExtra(APPCommonParams.getExtra());
        appPushWithParamsRequestDTO.setTemplateParams(APPCommonParams.getTemplateParams());
        String batchNo = uniformPushRpcService.sentPush(appPushWithParamsRequestDTO);
        return batchNo;
    }

    private PushCommonParams getPushCommonParams(List<PushMessageEntity> batchList,Integer triggerChannel){
        PushCommonParams pushCommonParams = new PushCommonParams();
        Map<String,String> extra = new HashMap<>();
        Map<String,Map<String,String>> templateParams = new HashMap<>();
        Map<String,Map<String,Map<String,String>>> weChatTemplateParams = new HashMap<>();
        Map<String,Map<String,String>> individualParams = new HashMap<>();
        Map<String, String> indi = new HashMap<>();
        List<PushDTO> pushList = Lists.newArrayList();
        List<Long> targetList = Lists.newArrayList();

        pushCommonParams.setTemplateCode(batchList.get(0).getUniformTemplateId());
        Map<String, String> firstMessageDetail = JSON.parseObject(batchList.get(0).getMessageDetail(), Map.class);
        extra.put("utm_source",firstMessageDetail.get("utmSource"));
        extra.put("utm_medium",firstMessageDetail.get("utmMedium"));
        extra.put("utm_campaign",firstMessageDetail.get("utmCampaign"));
        extra.put("utm_content",firstMessageDetail.get("utmContent"));
        extra.put("interMsgDetailPageRootPath",firstMessageDetail.get("interMsgDetailPageRootPath"));
        extra.put("isShowAlert",firstMessageDetail.get("isShowAlert"));

        if(TriggerChannelEnum.WECHAT.getType().equals(triggerChannel) || TriggerChannelEnum.WECHATAPP.getType().equals(triggerChannel)){
            for (PushMessageEntity pushMessageEntity:batchList) {
                Map<String, String> messageDetail = JSON.parseObject(pushMessageEntity.getMessageDetail(), Map.class);
                Map<String, Map<String, String>> templateData = new HashMap<>();
                for (String key:pushMessageEntity.getContentKeyList()) {
                    Map<String, String> remarkValue = new HashMap<>();
                    remarkValue.put("value",messageDetail.get(key));
                    templateData.put(key, remarkValue);
                }
                weChatTemplateParams.put(pushMessageEntity.getMemberId().toString(), templateData);
                if(TriggerChannelEnum.WECHAT.getType().equals(triggerChannel)){
                    if ("1".equals(messageDetail.get("urlType"))){
                        indi.put("url",messageDetail.get("url"));
                    }else{
                        indi.put("appid",messageDetail.get("appId"));
                        indi.put("pagepath",messageDetail.get("url"));
                    }
                }else if(TriggerChannelEnum.WECHATAPP.getType().equals(triggerChannel)){
                    indi.put("page",messageDetail.get("url"));
                }

                individualParams.put(pushMessageEntity.getMemberId().toString(), indi);

            }
        }else if(TriggerChannelEnum.INTERNALMSG.getType().equals(triggerChannel)){
            for (PushMessageEntity pushMessageEntity:batchList) {
                targetList.add(pushMessageEntity.getMemberId());
            }
        }else {
            for (PushMessageEntity pushMessageEntity:batchList) {
                Map<String, String> messageDetail = JSON.parseObject(pushMessageEntity.getMessageDetail(), Map.class);
                if(MemberConstants.NOT_MEMBER_MEMBER_ID.equals(batchList.get(0).getMemberId())){
                    // 非会员APPPUSH
                    log.info("非会员APPPUSH组装信息");
                    PushDTO pushDTO = new PushDTO();
                    pushDTO.setPushId(messageDetail.get("pushId"));
                    pushDTO.setChannelType(messageDetail.get("channelType"));
                    pushList.add(pushDTO);
                    // 图片信息
                    if (StringUtils.isNotBlank(messageDetail.get("imageUrl"))){
                        extra.put("attachment",messageDetail.get("imageUrl"));
                    }
                }else {
                    templateParams.put(pushMessageEntity.getMemberId().toString(), messageDetail);
                    if(TriggerChannelEnum.APPPUSH.getType().equals(triggerChannel)){
                        if (StringUtils.isNotBlank(messageDetail.get("imageUrl"))){
                            extra.put("attachment",messageDetail.get("imageUrl"));
                        }
                    }
                }
            }
        }

        pushCommonParams.setTemplateParams(templateParams);
        pushCommonParams.setWeChatTemplateParams(weChatTemplateParams);
        pushCommonParams.setIndividualParams(individualParams);
        pushCommonParams.setExtra(extra);
        pushCommonParams.setPushList(pushList);
        pushCommonParams.setTargetList(targetList);
        return pushCommonParams;
    }

    @Data
    public class PushCommonParams{
        private String templateCode;
        private Map<String,Map<String,String>> templateParams;
        private Map<String,Map<String,Map<String,String>>> weChatTemplateParams;
        private Map<String,Map<String,String>> individualParams;
        private Map<String,String> extra;
        private List<PushDTO> pushList;
        private List<Long> targetList;
    }

}
