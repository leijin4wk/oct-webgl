package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author Dong
 * @Classname PushBO
 * @Description 事件推送BO
 * @Date 2019-05-06
 */
@Data
public class PushBO implements Serializable {
    private Long id;
    private String pushName;
    private Integer pushStatus;
    private String description;

    /**
     * 活动信息
     */
    private String actUserType;
    private String actType;
    private String actTypeDetail;
    /**
     * 优惠券信息
     */
    private String couponCode;
    private BigDecimal couponAmount;
    private String couponType;

    /**
     * 部门
     */
    private Long departmentId;
    private Integer triggerType;

    private TargetCrowdConfig targetCrowdConfig;
    @Data
    public static class TargetCrowdConfig implements Serializable{
        /**
         * 目标人群 1-所有用户（不含未注册）; 2-定向人群(carbon废弃); 3-定制人群; 4-上传人群; 5-已有标签人群; 6-muse人群; 7-未注册人群
         */
        private Integer targetCrowdType;
        private List<Long> crowds; // carbon 弃用
        private Integer grayFlag;
        private Integer grayPercent;
        /**
         * 支持人群包集合的交叉并补
         */
        private String crowdsGather;

        /**
         * targetCrowdType定制人群时，定制人群的信息（crowdCreateType:人群创建方式（1 按标签；2 自定义）;crowdTag:标签）
         */
        private String customCrowdInfo;
        /**
         * 自定义事件触发类型的触发条件选项
         */
        private String triggerCondition;
    }

    /**
     * 发送规则 1、立即发送；2、定时发送；3、重复发送
     */
    private Integer sendType;

    private  SendConfig sendConfig;
    @Data
    public static class SendConfig implements Serializable{
        private Date sendStartTime;
        private Date sendEndTime;
        private Integer sendInterval;
    }

    private Integer validityFlag;
    private Date validityStart;
    private Date validityEnd;
    private SendFrequency sendFrequency;
    @Data
    public static class SendFrequency implements Serializable{
        private Integer sendFrequencySwitch;
        private Integer sendFrequencyDay;
        private Integer sendFrequencyTimes;
    }

    /**
     * 圈定条件
     */
    private Long rule;
    private String ruleDetail;
    private Integer triggerChannel;
//    /**
//     * 模板信息
//     */
//    private List<TemplateInfo> templateInfos;
//    @Data
//    public static class TemplateInfo implements Serializable{
//
//    }



    private Long pushTemplateId;
    private TriggerReward triggerReward;
    @Data
    public static class TriggerReward implements Serializable{
        private Integer triggerRewardSwitch;
        private String triggerRewardURL;
    }


    private Long createUserId;
    private String createUserName;
    private Date createTime;
    private Long updateUserId;
    private String updateUserName;
    private Date updateTime;
    private Boolean isDeleted;

    private Date startTime;
    private Date endTime;

    /**
     * 是否更新模板信息（0-否；1-是）
     */
    private Integer isUpdateTemplate;
    /**
     * 是否创建完成，0-否；1-是
     */
    private Integer isFinish;
    /**
     * push的目标用户类型（1-c端用户，2-b端用户）
     */
    private Integer userType;
}
