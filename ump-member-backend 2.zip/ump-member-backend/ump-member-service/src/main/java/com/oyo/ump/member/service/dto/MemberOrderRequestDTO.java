package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.util.Date;

/**
 * @Description: todo
 * @Author: fang
 * @create: 2019-03-29
 **/
@Data
public class MemberOrderRequestDTO {
  private Long  userId;
    private Date fromDate;
    private Date toDate;
    private String	orderNo;

}
