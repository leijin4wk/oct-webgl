package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author Dong
 * @Classname CrowdOpenIdBO
 * @Description
 * @Date 2019-06-04
 */
@Data
public class CrowdOpenIdBO implements Serializable {
    private Long id;
    private Long crowdId;
    private String openId;
    private Date createTime;
}
