package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @Classname BonusGainRuleDTO
 * @Description 积分获取规则返回信息
 * @Date 2019-03-16 11:29
 * @author Dong
 */
@Data
public class BonusGainRuleDTO implements Serializable {

    private List<BonusGainRuleInfo> bonusGainRuleInfoList;

    @Data
    public static class BonusGainRuleInfo{
        /**
         * 规则
         */
        private Integer id;
        /**
         * 积分项目（1 消费积分，2 奖励积分，3 活动积分， 4 多倍积分， 5 签到积分）
         */
        private String bonusType;
        /**
         * 开关；0 关，1 开
         */
        private Boolean status;
        /**
         * 积分获取开关；0 关，1 开
         */
        private Boolean gainFlag;
        /**
         * 积分消耗开关；0 关，1 开
         */
        private Boolean costFlag;
        /**
         * 初始积分
         */
        private Integer initalValue;
        /**
         * 积分下限
         */
        private Integer limitValue;
        /**
         * 支持多开标识；0 不支持，1 支持
         */
        private Boolean multipleFlag;
        /**
         * 有效期（日本租户在使用这个字段）
         */
        private Date validPeriod;

        /**
         * 有效期str 给前端展示
         */
        private String validity;
        /**
         * 有效期str 给job
         */
        private String strValidPeriod;
        /**
         * 有效期（支持多种类型）
         */
        private ValidPeriod validPeriodJson;
        @Data
        public static class ValidPeriod implements Serializable{
            private Integer type;
            private String strValidPeriod;
        }

        /**
         * 各方承担比例配置
         */
        private ComissionConfig comissionConfig;
        @Data
        public static class ComissionConfig implements Serializable{
            private String undertake1;
            private Integer undertake1Ratio;
            private String undertake2;
            private Integer undertake2Ratio;
            private String undertake3;
            private Integer undertake3Ratio;
            private String undertake4;
            private Integer undertake4Ratio;
            private String undertake5;
            private Integer undertake5Ratio;
        }

    }
}
