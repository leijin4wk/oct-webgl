package com.oyo.ump.member.service.impl;

import com.oyo.ump.member.common.beanutils.MapperWrapper;
import com.oyo.ump.member.dal.dao.PushTemplateRelationMapper;
import com.oyo.ump.member.dal.model.PushTemplateRelationEntity;
import com.oyo.ump.member.integration.service.push.PushActivityLinkService;
import com.oyo.ump.member.service.PushTemplateRelationService;
import com.oyo.ump.member.service.bo.ActivityBasisBo;
import com.oyo.ump.member.service.bo.ChannelLinkBasicBo;
import com.oyo.ump.member.service.bo.PromoteBasisBo;
import com.oyo.ump.member.service.bo.PushTemplateRelationBO;
import com.oyo.ump.platform.service.activity.dto.ActivityBasisBizDTO;
import com.oyo.ump.platform.service.activity.dto.ChannelLinkBasicDTO;
import com.oyo.ump.platform.service.activity.dto.PromoteBasisBizDTO;
import com.oyo.ump.platform.service.definition.ChannelTypeEnum;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author Dong
 * @Classname PushTemplateRelationServiceImpl
 * @Description
 * @Date 2019-08-31
 */
@Service
@Slf4j
public class PushTemplateRelationServiceImpl implements PushTemplateRelationService{
    @Autowired
    PushTemplateRelationMapper pushTemplateRelationMapper;

    @Autowired
    private PushActivityLinkService pushActivityLinkService;

    @Override
    public void insertRelation(PushTemplateRelationBO pushTemplateRelationBO) {
        PushTemplateRelationEntity pushTemplateRelationEntity = MapperWrapper.instance().map(pushTemplateRelationBO, PushTemplateRelationEntity.class);
        pushTemplateRelationMapper.insertRelation(pushTemplateRelationEntity);
    }

    @Override
    public void deleteRelationByPushId(Long pushId) {
        pushTemplateRelationMapper.deleteRelationByPushId(pushId);
    }

    @Override
    public List<PushTemplateRelationBO> getRelationBOsByPushId(Long pushId) {
        List<PushTemplateRelationBO> relationBOList = Lists.newArrayList();
        List<PushTemplateRelationEntity> relationEntityList = pushTemplateRelationMapper.getRelationsByPushId(pushId);
        if(CollectionUtils.isNotEmpty(relationEntityList)){
            relationBOList = MapperWrapper.instance().mapList(relationEntityList, PushTemplateRelationBO.class);
        }
        return relationBOList;
    }

    @Override
    public List<String> getTemplateNumList(Long pushId) {
        List<PushTemplateRelationEntity> relationEntityList = pushTemplateRelationMapper.getRelationsByPushId(pushId);
        return relationEntityList.stream().map(item->item.getTemplateNum()).collect(Collectors.toList());
    }

    @Override
    public List<ActivityBasisBo> getChanneledActivities(String keyWords) {
        List<ActivityBasisBo> result=new ArrayList<>();
        List<ActivityBasisBizDTO> list=pushActivityLinkService.getChanneledActivities(keyWords);
        list.stream().forEach(item->{
            ActivityBasisBo activityBasisBo=new ActivityBasisBo();
            activityBasisBo.setId(item.getId());
            activityBasisBo.setActivityName(item.getActivityName());
            result.add(activityBasisBo);
        });
        return result;
    }

    @Override
    public List<PromoteBasisBo> getChanneledPromotes(String promoteName, Long activityId) {
        List<PromoteBasisBo> result=new ArrayList<>();
        List<PromoteBasisBizDTO> list= pushActivityLinkService.getChanneledPromotes(promoteName,activityId);
        list.stream().forEach(item->{
            PromoteBasisBo promoteBasisBo=new PromoteBasisBo();
            promoteBasisBo.setId(item.getId());
            promoteBasisBo.setActivityId(item.getActivityId());
            promoteBasisBo.setPromoteName(item.getPromoteName());
            result.add(promoteBasisBo);
        });
        return result;
    }

    @Override
    public Map<String, String> getTopDepartmentCode() {
        return pushActivityLinkService.getTopDepartmentCode();
    }

    @Override
    public Map<String, String> getActivityChannelTypes() {
        Map<String,String> map=new HashMap<>();
        List<ChannelTypeEnum> list= pushActivityLinkService.getChannelTypes();
        list.stream().forEach(item->{
            map.put(item.getCode(),item.getDescription());
        });
        return map;
    }

    @Override
    public String createChannelLink(ChannelLinkBasicBo channelLinkBasicBo) {
        ChannelLinkBasicDTO channelLinkBasicDTO= new ChannelLinkBasicDTO();
        channelLinkBasicDTO.setChannelName(channelLinkBasicBo.getChannelName());
        channelLinkBasicDTO.setPromoteBasisId(channelLinkBasicBo.getPromoteBasisId());
        channelLinkBasicDTO.setUtmSource(channelLinkBasicBo.getUtmSource());
        channelLinkBasicDTO.setUtmMedium(channelLinkBasicBo.getUtmMedium());
        channelLinkBasicDTO.setUtmCampaign(channelLinkBasicBo.getUtmCampaign());
        channelLinkBasicDTO.setUtmContent(channelLinkBasicBo.getUtmContent());
        return pushActivityLinkService.createChannelLink(channelLinkBasicDTO);
    }


}
