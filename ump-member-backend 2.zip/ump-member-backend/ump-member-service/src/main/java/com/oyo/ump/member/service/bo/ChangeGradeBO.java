package com.oyo.ump.member.service.bo;

import com.oyo.ump.member.common.constants.MemberConstants;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author Dong
 * @Classname ChangeGradeBO
 * @Description 变更用户等级BO
 * @Date 2019-04-02
 */
@Data
public class ChangeGradeBO implements Serializable {
    private Long userId;
    private Integer gradeId;
    private Integer PreviousGradeId;
    /**
     * 等级更新规则 1.自然  2.升级包
     */
    // todo fix 可以加个枚举类吗？
    private Integer updateRuleType;
    /**
     * 等级变更类型 1.升级  2.降级  3.保级  4.间夜数清零
     */
    // todo fix 这个字段有用吗？
    private Integer changeType;
    /**
     * 等级有效时间（只有V4存在有效期，其他的无有效限期制）
     */
    private Date validTime;

    /**
     * 间夜数
     */
    private Integer roomNights;

    /**
     * 更新noShow数
     */
    private Integer noShow;

    /**
     * 等级更新描述
     */
    private String description;
    /**
     * 租户
     */
    private String tenant= MemberConstants.OYO_TENANT;
}
