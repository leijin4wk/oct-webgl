package com.oyo.ump.member.service.dto;

import io.netty.util.TimerTask;

public abstract class BasePushTimer implements TimerTask {
    private Long delayTime;

    public BasePushTimer(Long delayTime) {
        this.delayTime = delayTime;
    }

    public Long getDelayTime() {
        return delayTime;
    }
}
