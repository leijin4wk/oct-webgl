package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author Dong
 * @Classname UpgradePackagePageBO
 * @Description 升级包信息带分页
 * @Date 2019-03-27
 */
@Data
public class UpgradePackagePageBO implements Serializable {
    private List<UpgradePackageBO> upgradePackageBOList;
    private Long total;
    private Integer pageNum;
    private Integer pageSize;
}
