package com.oyo.ump.member.service.enums;

/** 用户类型枚举
* @author leijin
* @date 2019-11-15 14:54
**/
public enum UserTypeEnum {
    /**
     *c端用户
    **/
    CLIENT_TYPE(1,"c端用户"),
    /**
     *b端用户
     **/
    BUSINESS_TYPE(2,"b端用户");


    private final Integer type;
    private final String name;

    public Integer getType() {
        return type;
    }
    public String getName() {
        return name;
    }
    UserTypeEnum(Integer type, String name){
        this.name=name;
        this.type=type;
    }
}

