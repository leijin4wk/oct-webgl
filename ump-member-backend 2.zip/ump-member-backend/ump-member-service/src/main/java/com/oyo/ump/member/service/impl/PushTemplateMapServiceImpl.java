package com.oyo.ump.member.service.impl;

import com.oyo.ump.member.common.exception.UmpException;
import com.oyo.ump.member.dal.dao.PushEventMetaMapper;
import com.oyo.ump.member.dal.dao.PushRuleMapper;
import com.oyo.ump.member.dal.dao.PushTempletesMapper;
import com.oyo.ump.member.dal.model.PushEventMetaEntity;
import com.oyo.ump.member.dal.model.PushRuleEntity;
import com.oyo.ump.member.dal.model.PushTempletesEntity;
import com.oyo.ump.member.service.PushTemplateMapService;
import com.oyo.ump.member.service.bo.PushEventDefineBo;
import com.oyo.ump.member.service.bo.PushTemplateMapBo;
import com.oyo.ump.member.service.enums.TriggerTypeEnum;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**ØØØ
 * push模板和对应的映射字段配置service实现
* @author frank
* @date 2019-07-29 10:48
**/
@Service
@Slf4j
public class PushTemplateMapServiceImpl  implements PushTemplateMapService {
    @Autowired
    private PushTempletesMapper pushTempletesMapper;
    @Autowired
    private PushRuleMapper pushRuleMapper;
    @Autowired
    private PushEventMetaMapper pushEventMetaMapper;

    @Override
    public List<PushTemplateMapBo> getPushTemplateMapBoList() {
        List<PushTempletesEntity> results=pushTempletesMapper.selectPushTemplatesEntityList();
        return results.stream().map(item->{
            PushTemplateMapBo bo= PushTemplateMapBo.builder()
                   .id(item.getId())
                    .createTime(item.getCreateTime())
                    .detail(item.getDetail())
                    .templeteName(item.getTempleteName())
                    .updateTime(item.getUpdateTime())
                    .isDeleted(item.getIsDeleted())
                   .aliTempleteId(item.getAliTempleteId()
                   )
                    .build();
            return bo;

        }).collect(Collectors.toList());
    }

    @Override
    public PushTemplateMapBo getPushTemplateById(Long id) {
        PushTempletesEntity pushTempletesEntity=pushTempletesMapper.selectPushTempletesEntityById(id);
        PushTemplateMapBo bo= PushTemplateMapBo.builder()
                .id(pushTempletesEntity.getId())
                .createTime(pushTempletesEntity.getCreateTime())
                .detail(pushTempletesEntity.getDetail())
                .templeteName(pushTempletesEntity.getTempleteName())
                .updateTime(pushTempletesEntity.getUpdateTime())
                .isDeleted(pushTempletesEntity.getIsDeleted())
                .aliTempleteId(pushTempletesEntity.getAliTempleteId()
                )
                .build();
        return bo;
    }

    @Override
    public void updatePushTemplateMap(PushTemplateMapBo pushTemplateMapBo) {
        PushTempletesEntity pushTempletesEntity = new PushTempletesEntity();
        pushTempletesEntity.setId(pushTemplateMapBo.getId());
        pushTempletesEntity.setTempleteName(pushTemplateMapBo.getTempleteName());
        pushTempletesEntity.setDetail(pushTemplateMapBo.getDetail());
        pushTempletesEntity.setAliTempleteId(pushTemplateMapBo.getAliTempleteId());
        pushTempletesMapper.updatePushTemplateMap(pushTempletesEntity);
    }

    @Override
    public void insertPushTemplateMap(PushTemplateMapBo pushTemplateMapBo) {
        PushTempletesEntity pushTempletesEntity = new PushTempletesEntity();
        pushTempletesEntity.setId(pushTemplateMapBo.getId());
        pushTempletesEntity.setTempleteName(pushTemplateMapBo.getTempleteName());
        pushTempletesEntity.setDetail(pushTemplateMapBo.getDetail());
        pushTempletesEntity.setAliTempleteId(pushTemplateMapBo.getAliTempleteId());
        pushTempletesMapper.insertPushTemplateMap(pushTempletesEntity);
    }

    @Override
    public List<PushEventDefineBo> getPushEventDefineBoList() {
       List<PushEventMetaEntity> list=pushEventMetaMapper.selectAll();
       return list.stream().map(item->{
            PushEventDefineBo pushEventDefineBo=new PushEventDefineBo();
            pushEventDefineBo.setDelineationName(item.getEventName());
            pushEventDefineBo.setEventKey(item.getEventKey());
            pushEventDefineBo.setId(item.getId());
            return pushEventDefineBo;
        }).collect(Collectors.toList());
    }

    @Override
    public void insertPushEventDefine(PushEventDefineBo pushEventDefineBo) {
        List<PushRuleEntity> old=pushRuleMapper.selectByEventKey(pushEventDefineBo.getEventKey());
        if (CollectionUtils.isNotEmpty(old)){
            throw new UmpException("eventKey已经存在!");
        }
        PushRuleEntity pushRuleEntity=new PushRuleEntity();
        pushRuleEntity.setEventType(TriggerTypeEnum.EVENT_TYPE.getType());
        pushRuleEntity.setDelineationName(pushEventDefineBo.getDelineationName());
        pushRuleEntity.setEventKey(pushEventDefineBo.getEventKey());
        pushRuleMapper.insert(pushRuleEntity);
    }

    @Override
    public void updatePushEventDefine(PushEventDefineBo pushEventDefineBo) {
        List<PushRuleEntity> old=pushRuleMapper.selectByEventKey(pushEventDefineBo.getEventKey());
        if (CollectionUtils.isNotEmpty(old)){
            throw new UmpException("eventKey重复!");
        }
        PushRuleEntity pushRuleEntity=new PushRuleEntity();
        pushRuleEntity.setEventType(TriggerTypeEnum.EVENT_TYPE.getType());
        pushRuleEntity.setDelineationName(pushEventDefineBo.getDelineationName());
        pushRuleEntity.setEventKey(pushEventDefineBo.getEventKey());
        pushRuleMapper.update(pushRuleEntity,pushEventDefineBo.getId());
    }

    @Override
    public PushEventDefineBo findPushEventDefineById(Long id) {
        PushRuleEntity pushRuleEntity= pushRuleMapper.selectById(id);
        PushEventDefineBo pushEventDefineBo=new PushEventDefineBo();
        pushEventDefineBo.setId(pushRuleEntity.getId());
        pushEventDefineBo.setDelineationName(pushRuleEntity.getDelineationName());
        pushEventDefineBo.setEventKey(pushRuleEntity.getEventKey());
        return pushEventDefineBo;
    }
}
