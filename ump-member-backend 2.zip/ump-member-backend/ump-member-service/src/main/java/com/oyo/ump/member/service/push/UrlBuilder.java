package com.oyo.ump.member.service.push;

import com.oyo.ump.member.integration.service.push.QrCodeService;
import com.oyo.ump.member.service.bo.KeyModelBo;
import com.oyo.ump.member.service.bo.PushInfoAndParams;
import com.oyo.ump.member.service.enums.TemplateParamTypeEnum;
import com.oyo.ump.member.service.enums.TriggerChannelEnum;
import freemarker.cache.StringTemplateLoader;
import freemarker.template.Configuration;
import freemarker.template.Template;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.List;
import java.util.Map;
@Slf4j
public class UrlBuilder {
    public UrlBuilder(QrCodeService qrCodeService) {
        this.qrCodeService = qrCodeService;
    }

    private QrCodeService qrCodeService;

    public boolean buildAndValidator(List<KeyModelBo> models, Map<String, Object> dbMap, Map<String, String> mqKeysParams, int source, Map<String, String> result) {
        for (KeyModelBo item : models) {
            if (TemplateParamTypeEnum.SYS_KEY.getType().equals(item.getType())) {
                if (source == 1) {
                    if (dbMap.get(item.getValue()) == null) {
                        log.info("参数：{}为空，消息组装失败！", item);
                        return false;
                    }
                    String str = dbMap.get(item.getValue()).toString();
                    if (StringUtils.isBlank(str)) {
                        log.info("参数：{}为空，消息组装失败！", item);
                        return false;
                    }
                    result.put(item.getName(), str);
                } else {
                    String str = mqKeysParams.get(item.getValue());
                    if (StringUtils.isBlank(str)) {
                        log.info("参数：{}为空，消息组装失败！", item);
                        return false;
                    }
                    result.put(item.getName(), str);
                }
            } else if (TemplateParamTypeEnum.TEXT.getType().equals(item.getType())) {
                result.put(item.getName(), item.getValue());
            }
        }
        return true;
    }

    private String freemarkerProcess(Map input, String templateStr) {
        StringTemplateLoader stringLoader = new StringTemplateLoader();
        String template = "content";
        stringLoader.putTemplate(template, templateStr);
        Configuration cfg = new Configuration();
        cfg.setTemplateLoader(stringLoader);
        try {
            Template templateCon = cfg.getTemplate(template);
            StringWriter writer = new StringWriter();
            templateCon.process(input, writer);
            return writer.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }


    //构造url
    public String buildUrl(SqlModel pushSqlModel, Map<String, String> urlParamMap) {
        String baseUrl = pushSqlModel.getBaseUrl();
        if (StringUtils.isBlank(baseUrl)) {
            return "";
        }
        String deepLinkUrl = pushSqlModel.getDeeplinkUrl();
        if (StringUtils.isBlank(deepLinkUrl)) {
            return baseUrl;
        } else {
            String res = freemarkerProcess(urlParamMap, deepLinkUrl);
            if (StringUtils.isBlank(res)) {
                return "";
            }
            if (pushSqlModel.getTriggerChannel().equals(TriggerChannelEnum.SMS.getType())) {
                String encodeUrl;
                try {
                    encodeUrl = URLEncoder.encode(res, "utf-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                    encodeUrl = "";
                }
                if (StringUtils.isBlank(encodeUrl)) {
                    return "";
                }
                String shortUrl = qrCodeService.getShortUrl(baseUrl + encodeUrl);
                if (StringUtils.isBlank(shortUrl)) {
                    return "";
                } else {
                    return shortUrl;
                }
            } else {
                return baseUrl + res;
            }
        }
    }
}
