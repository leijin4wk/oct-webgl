package com.oyo.ump.member.service;

import com.oyo.ump.member.service.bo.ActivityBasisBo;
import com.oyo.ump.member.service.bo.ChannelLinkBasicBo;
import com.oyo.ump.member.service.bo.PromoteBasisBo;
import com.oyo.ump.member.service.bo.PushTemplateRelationBO;
import com.oyo.ump.platform.service.activity.dto.ActivityBasisBizDTO;
import com.oyo.ump.platform.service.activity.dto.ChannelLinkBasicDTO;
import com.oyo.ump.platform.service.activity.dto.PromoteBasisBizDTO;
import com.oyo.ump.platform.service.definition.ChannelTypeEnum;

import java.util.List;
import java.util.Map;

/**
 * @author Dong
 * @Classname PushTemplateRelationService
 * @Description
 * @Date 2019-08-31
 */
public interface PushTemplateRelationService {

    void insertRelation(PushTemplateRelationBO pushTemplateRelationBO);

    void deleteRelationByPushId(Long pushId);

    /**
     * 根据pushId获取模板推送关系信息
     * @param pushId
     * @return java.util.List<com.oyo.ump.member.service.bo.PushTemplateRelationBO>
     */
    List<PushTemplateRelationBO> getRelationBOsByPushId(Long pushId);
    /**
     * 获取模板idlist
    * @author leijin
    * @date 2019-09-18 11:37
    **/
    List<String> getTemplateNumList(Long pushId);


    /**
     * 获取活动渠道
    * @author leijin
    * @date 2020-01-10 16:27
    **/
    List<ActivityBasisBo> getChanneledActivities(String keyWords);

    /** 获取活动工具
    * @author leijin
    * @date 2020-01-10 16:31
    **/
    List<PromoteBasisBo> getChanneledPromotes(String promoteName, Long activityId);

    /** utmsource部门接口
     * @author leijin
     * @date 2020-01-10 12:01
     **/
    Map<String,String> getTopDepartmentCode();



    /** utmmedium 枚举接口
     * @author leijin
     * @date 2020-01-10 12:01
     **/
    Map<String,String>  getActivityChannelTypes();

    /**
     * 创建渠道
    * @author leijin
    * @date 2020-01-10 16:41
    **/
    String createChannelLink(ChannelLinkBasicBo channelLinkBasicBo);

}
