package com.oyo.ump.member.service.bo;

import com.github.pagehelper.PageInfo;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author Dong
 * @Classname MemberIdentityPageBO
 * @Description 前端返回带有分页信息的列表数据
 * @Date 2019-03-27
 */
@Data
public class MemberIdentityPageBO implements Serializable {
    private List<MemberIdentityBO> memberIdentityBOList;
    private Long total;
    private Integer pageNum;
    private Integer pageSize;
}
