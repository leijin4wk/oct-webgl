package com.oyo.ump.member.service.bo;

import io.swagger.models.auth.In;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @Description: todo
 * @Author: fang
 * @create: 2019-08-30
 **/
@Data
public class SyncMemberGradeRequestBO implements Serializable {
    /**
     * 平台 OYO 飞猪 ：RM008007_FZ
     */
    private String platform;
    /**
     * V1 V2
     */
    private Integer gradeId;
    /**
     * 用户id
     */
    private Long userId;
    /**
     * 租户 ：
     */
    private String tenant;
    /**
     * 有效期
     */
    private Date validTime;
    /**
     * 上一等级
     */
    private Integer preGradeId;
    /**
     * refreshrule
     */
    private Integer rule=1;
}
