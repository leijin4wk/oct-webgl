package com.oyo.ump.member.service.dto;

import lombok.Data;

/**
 * @Description: 退定返回
 * @Author: fang
 * @create: 2019-04-15
 **/
@Data
public class RefundResponseDTO {
    private Boolean isSuccess;
    private String msg;
}
