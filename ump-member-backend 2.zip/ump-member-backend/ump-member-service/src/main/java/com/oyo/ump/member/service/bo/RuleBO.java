package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;

/**
 * @Description:
 * @Author: fang
 * @create: 2019-11-11
 **/
@Data
public class RuleBO implements Serializable {
    private String rule;
    private Integer ruleRelation;
}
