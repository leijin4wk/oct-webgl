package com.oyo.ump.member.service;

/**
 * @Description:
 * @Author: fang
 * @create: 2020-01-02
 **/
public interface BonusDelayService {
    /**
     * 获取延迟天数
     * @param type
     * @return
     */
   Integer  getDelayByType(Integer type);

    /**
     * 更新延迟天数
     * @param type
     * @param delay
     * @param userId
     * @param name
     * @return
     */
   Boolean updateDelayByType(Integer type,Integer delay,Long userId,String name);
}
