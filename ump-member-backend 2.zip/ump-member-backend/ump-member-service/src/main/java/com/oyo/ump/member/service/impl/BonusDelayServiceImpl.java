package com.oyo.ump.member.service.impl;

import com.oyo.ump.member.common.constants.MemberConstants;
import com.oyo.ump.member.common.constants.RedisConstants;
import com.oyo.ump.member.dal.dao.BonusDelayMapper;
import com.oyo.ump.member.service.BonusDelayService;
import com.oyo.ump.member.service.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @Description:
 * @Author: fang
 * @create: 2020-01-02
 **/
@Component
@Slf4j
public class BonusDelayServiceImpl implements BonusDelayService {
    @Autowired
    private BonusDelayMapper bonusDelayMapper;

    @Autowired
    private RedisService redisService;

    @Override
    public Integer getDelayByType(Integer type) {
        Integer result;
        Object cacheObject = redisService.getValue(RedisConstants.BONUS_DELAY_PREFIX + type);
          if(cacheObject!=null){
              result=(Integer) cacheObject;
          }else {
              result = bonusDelayMapper.getBonusDelayByType(type);
              redisService.setValue(RedisConstants.BONUS_DELAY_PREFIX + type,result);
          }
        return result;
    }

    @Override
    public Boolean updateDelayByType(Integer type, Integer delay,Long userId,String name) {
        Integer oldValue = getDelayByType(type);
        bonusDelayMapper.updateBonusDelayByType(type,delay);
        redisService.setValue(RedisConstants.BONUS_DELAY_PREFIX + type,delay);
        bonusDelayMapper.updateBonusDelayDetail(type,oldValue,delay,userId,name);
        return true;
    }
}
