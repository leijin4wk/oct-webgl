package com.oyo.ump.member.service.impl;


import com.alibaba.fastjson.JSON;
import com.oyo.ump.coupon.facade.dto.request.FailureCouponRequest;
import com.oyo.ump.coupon.facade.dto.request.MetadataInfoRequest;
import com.oyo.ump.coupon.facade.dto.request.SendCouponRequest;
import com.oyo.ump.coupon.facade.dto.request.SendMetadataInfo;
import com.oyo.ump.coupon.facade.dto.response.FailureCouponResponse;
import com.oyo.ump.coupon.facade.dto.response.SendCouponResponseDTO;
import com.oyo.ump.coupon.facade.util.GeneralResponse;
import com.oyo.ump.member.common.constants.MemberConstants;
import com.oyo.ump.member.integration.service.coupon.CouponRemoteService;
import com.oyo.ump.member.service.RedisService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.MapUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.Map;


/**
 * @author Dong
 * @Classname RetryService
 * @Description 优惠券RPC接口的重试
 * @Date 2019-04-11
 */
@Service
@Configuration
@EnableScheduling
@Slf4j
public class RetryService {
    @Autowired
    RedisService redisService;
    @Autowired
    CouponRemoteService couponRemoteService;

    @Scheduled(fixedRate=300000)
    private void retry() {

        Map<Object, Object> sendMap = redisService.getMapEntries(MemberConstants.SEND_COUPON_REDIS);
        if(MapUtils.isNotEmpty(sendMap)){
            log.info("--------------------------------------------进入 重试 发券异常---------------------------------------");
            SendCouponRequest request = new SendCouponRequest();
            SendMetadataInfo metadataInfo = new SendMetadataInfo();
            metadataInfo.setNum(MemberConstants.COUPON_NUM);

            for (Map.Entry<Object, Object> entry : sendMap.entrySet()) {
                String reqString = entry.getKey().toString();
                int times = Integer.parseInt(entry.getValue().toString());

                if(times < MemberConstants.RETRY_TIMES){
                    // 取key 解析出request
                    String[] strArray = reqString.split("\\*");
                    String userId = strArray[0];
                    String activityId = strArray[1];
                    String identifyCode = strArray[2];
                    request.setUserId(Long.parseLong(userId));
                    request.setActivityId(Long.parseLong(activityId));
                    metadataInfo.setIdentifyCode(identifyCode);
                    request.setCouponInfo(Lists.newArrayList(metadataInfo));
                    try{
                        log.info("发券请求信息，request:{} ", JSON.toJSONString(request));
                        GeneralResponse<SendCouponResponseDTO> response = couponRemoteService.sendCouponByIdentifyCode(request);
                        log.info("发券请求返回信息，response:{} ", JSON.toJSONString(response));
                        log.info("重试成功，删除---{}---请求-----------------", reqString);
                        redisService.deleteMapEntry(MemberConstants.SEND_COUPON_REDIS, reqString);
                    }catch (Exception e){
                        log.info("重试失败，---{}---重试次数加1-----------------", userId);
                        redisService.putMapEntry(MemberConstants.SEND_COUPON_REDIS, reqString, times+1);
                    }
                }else {
                    log.info("重试次数超限，丢弃请求");
                    redisService.deleteMapEntry(MemberConstants.SEND_COUPON_REDIS, reqString);
                }

            }

        }

        Map<Object, Object> failureMap = redisService.getMapEntries(MemberConstants.FAIL_COUPON_REDIS);
        if(MapUtils.isNotEmpty(failureMap)){
            log.info("--------------------------------------------进入 重试 废券异常---------------------------------------");
            FailureCouponRequest request = new FailureCouponRequest();
            MetadataInfoRequest metadataInfo = new MetadataInfoRequest();
            metadataInfo.setNum(MemberConstants.COUPON_NUM);

            for (Map.Entry<Object, Object> entry : failureMap.entrySet()) {
                String reqString = entry.getKey().toString();
                int times = Integer.parseInt(entry.getValue().toString());

                if(times < MemberConstants.RETRY_TIMES){
                    // 取key 解析出request
                    String[] strArray = reqString.split("\\*");
                    String userId = strArray[0];
                    String activityId = strArray[1];
                    String identifyCode = strArray[2];
                    request.setUserId(Long.parseLong(userId));
                    request.setActivityId(Long.parseLong(activityId));
                    metadataInfo.setIdentifyCode(identifyCode);
                    request.setCouponInfo(Lists.newArrayList(metadataInfo));
                    try{
                        log.info("废券重试请求信息，request:{} ", JSON.toJSONString(request));
                        GeneralResponse<FailureCouponResponse> response = couponRemoteService.failureUseCoupon(request);
                        log.info("废券重试返回信息，response:{} ", JSON.toJSONString(response));
                        log.info("重试成功，删除---{}---请求-----------------", userId);
                        redisService.deleteMapEntry(MemberConstants.FAIL_COUPON_REDIS, reqString);
                    }catch (Exception e){
                        log.info("重试失败，{}---重试次数加1-----------------", userId);
                        redisService.putMapEntry(MemberConstants.FAIL_COUPON_REDIS, reqString, times+1);
                    }
                }else {
                    log.info("重试次数超限，丢弃请求");
                    redisService.deleteMapEntry(MemberConstants.FAIL_COUPON_REDIS, reqString);
                }

            }
        }

    }

}
