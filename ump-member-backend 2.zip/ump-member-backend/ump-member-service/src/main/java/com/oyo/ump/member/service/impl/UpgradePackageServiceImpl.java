package com.oyo.ump.member.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Maps;
import com.oyo.common.enums.ResponseCode;
import com.oyo.ump.member.dal.dao.UpgradePackageMapper;
import com.oyo.ump.member.dal.model.UpgradePackageEntity;
import com.oyo.ump.member.integration.service.product.ProductRemoteService;
import com.oyo.ump.member.service.UpgradePackageService;
import com.oyo.ump.member.service.bo.UpgradePackageBO;
import com.oyo.ump.member.service.bo.UpgradePackagePageBO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import top.rdfa.product.core.client.response.ClientBaseResponse;
import top.rdfa.product.core.client.response.sku.SkuDto;

import javax.annotation.PostConstruct;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

/**
 * @Classname UpgradePackageServiceImpl
 * @Description 升级包接口实现类
 * @Date 2019-03-14 16:46
 * @author Dong
 */

@Service
@Slf4j
public class UpgradePackageServiceImpl implements UpgradePackageService {
    public static List<UpgradePackageBO> PACKAGE_CACHE_LIST = Lists.newArrayList();
    public static Map<String,UpgradePackageBO> PACKAGE_CACHE_MAP= Maps.newHashMap();
    public static Map<Integer,List<UpgradePackageBO>> CAN_BUY_PACKAGE_CACHE_MAP = Maps.newHashMap();
    @Autowired
    private UpgradePackageMapper upgradePackageMapper;
    @Autowired
    private ProductRemoteService productRemoteService;
    /**
     * 所有升级包，无分页
     * @param
     * @return com.oyo.ump.member.service.bo.UpgradePackagePageBO
     */
    @Override
    public UpgradePackagePageBO getUpgradePackageList() {
        UpgradePackagePageBO upgradePackagePageBO = new UpgradePackagePageBO();
        List<UpgradePackageEntity> upgradePackageEntityList = Lists.newArrayList();
        List<UpgradePackageBO> upgradePackageBOList = Lists.newArrayList();

        try {
            upgradePackageEntityList =  upgradePackageMapper.getUpgradePackageList();
        }catch (Exception e){
            log.error("升级包查询sql异常：UpgradePackageServiceImpl.getUpgradePackageList",e);
        }

        convert2BOList(upgradePackageEntityList,upgradePackageBOList);
        upgradePackagePageBO.setUpgradePackageBOList(upgradePackageBOList);

        return upgradePackagePageBO;
    }

    /**
     * 查询所有升级包,传分页参数
     * @param
     * @return java.util.List<com.oyo.ump.member.service.bo.UpgradePackageBO>
     */
    @Override
    public UpgradePackagePageBO getUpgradePackageList(Integer pageNum, Integer pageSize) {

        UpgradePackagePageBO upgradePackagePageBO = new UpgradePackagePageBO();
        List<UpgradePackageEntity> upgradePackageEntityList = Lists.newArrayList();
        List<UpgradePackageBO> upgradePackageBOList = Lists.newArrayList();

        PageHelper.startPage(pageNum, pageSize);
        try {
            upgradePackageEntityList =  upgradePackageMapper.getUpgradePackageList();
            PageInfo pageInfo = PageInfo.of(upgradePackageEntityList);
            upgradePackagePageBO.setTotal(pageInfo.getTotal());
            upgradePackagePageBO.setPageNum(pageInfo.getPageNum());
            upgradePackagePageBO.setPageSize(pageInfo.getPageSize());
        }catch (Exception e){
            log.error("升级包查询sql异常：UpgradePackageServiceImpl.getUpgradePackageList",e);
        }

        convert2BOList(upgradePackageEntityList,upgradePackageBOList);
        upgradePackagePageBO.setUpgradePackageBOList(upgradePackageBOList);

        return upgradePackagePageBO;
    }

    /**
     * 根据用户等级id查询可购买的升级包
     * @param gradeId
     * @return java.util.List<com.oyo.ump.member.service.bo.UpgradePackageBO>
     */
    @Override
    public List<UpgradePackageBO> getUpgradePackageListByGradeId(int gradeId) {

        return CAN_BUY_PACKAGE_CACHE_MAP.get(gradeId);

    }

    /**
     * 通过skuCode获取升级包信息
     * @param skuCode
     * @return com.oyo.ump.member.service.bo.UpgradePackageBO
     */
    @Override
    public UpgradePackageBO getUpgradePackageByCode(String skuCode) {

        return PACKAGE_CACHE_MAP.get(skuCode);
    }

    /**
     * 获取categoryid集合
     * @return
     */
    @Override
    public List<String> getProductCategoryIds() {
        List<String> result =Lists.newArrayList();
        UpgradePackagePageBO upgradePackagePageBO = getUpgradePackageList();
        if(upgradePackagePageBO!=null&&CollectionUtils.isNotEmpty(upgradePackagePageBO.getUpgradePackageBOList())){
            upgradePackagePageBO.getUpgradePackageBOList().forEach(upgradePackageBO -> {
                ClientBaseResponse<SkuDto> response=  productRemoteService.getProductInfo(upgradePackageBO.getSkuCode());
                if(response!=null&&ResponseCode.SUCCESS.getCode().equals(response.getCode())&&response.getData()!=null){
                    result.add(response.getData().getBackendCategoryId().toString());
                }
            });
        }
        return result;
    }


    /**
     * inti时读取数据库数据并塞入缓存
     * @return
     */
    @PostConstruct
    private void refreshFromDB() {
        List<UpgradePackageEntity> entityList = upgradePackageMapper.getUpgradePackageList();
        initCache(entityList);
    }


    private void convert2BO(UpgradePackageEntity upgradePackageEntity, UpgradePackageBO upgradePackageBO) {
        upgradePackageBO.setId(upgradePackageEntity.getId());
        upgradePackageBO.setSkuCode(upgradePackageEntity.getSkuCode());
        upgradePackageBO.setGradeId(upgradePackageEntity.getGradeId());
        upgradePackageBO.setGradeOrd(upgradePackageEntity.getGradeOrd());
        upgradePackageBO.setGradeName(upgradePackageEntity.getGradeName());
        upgradePackageBO.setUpgradeId(upgradePackageEntity.getUpgradeId());
        upgradePackageBO.setUpgradeOrd(upgradePackageEntity.getUpgradeOrd());
        upgradePackageBO.setUpgradeName(upgradePackageEntity.getUpgradeName());
        upgradePackageBO.setFrontCommission(upgradePackageEntity.getFrontCommission());
        upgradePackageBO.setOwnerCommission(upgradePackageEntity.getOwnerCommission());
        upgradePackageBO.setOyoCommission(upgradePackageEntity.getOyoCommission());
        upgradePackageBO.setStatus(upgradePackageEntity.getStatus()==1);

    }


    /**
     * EntityList转化为BO
     * @param entityList 升级包实体类列表
     * @param upgradePackageBOList 升级包BO列表
     */
    private void convert2BOList(List<UpgradePackageEntity> entityList, List<UpgradePackageBO> upgradePackageBOList) {
        if(CollectionUtils.isNotEmpty(entityList)){

            entityList.forEach(upgradePackageEntity -> {
                UpgradePackageBO upgradePackageBO = new UpgradePackageBO();
                convert2BO(upgradePackageEntity, upgradePackageBO);
                upgradePackageBOList.add(upgradePackageBO);
            });
        }
    }


    private void initCache(List<UpgradePackageEntity> entityList){
        if(CollectionUtils.isNotEmpty(entityList)){
            entityList.forEach(upgradePackageEntity -> {
                UpgradePackageBO upgradePackageBO = new UpgradePackageBO();
                List<UpgradePackageBO> upgradePackageBOList = Lists.newArrayList();

                convert2BO(upgradePackageEntity, upgradePackageBO);
                PACKAGE_CACHE_LIST.add(upgradePackageBO);
                PACKAGE_CACHE_MAP.put(upgradePackageBO.getSkuCode(), upgradePackageBO);

                if(CAN_BUY_PACKAGE_CACHE_MAP.get(upgradePackageBO.getGradeId()) != null && upgradePackageBO.getStatus()){
                    CAN_BUY_PACKAGE_CACHE_MAP.get(upgradePackageBO.getGradeId()).add(upgradePackageBO);
                }else {
                    if(upgradePackageBO.getStatus()){
                        upgradePackageBOList.add(upgradePackageBO);
                    }
                    CAN_BUY_PACKAGE_CACHE_MAP.put(upgradePackageBO.getGradeId(), upgradePackageBOList);

                }

            });
        }
    }

}
