package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author Dong
 * @Description push模板信息的实体承载类
 * @Date 2019-10-16
 */
@Data
public class PushTemplateDTO implements Serializable {
    private Long pushId;
    /**
     * 推送类型（1-短信；2-push；3-微信公众号；4-微信小程序；5-支付宝小程序；6-站内信）
     */
    private Integer triggerChannel;
    private Long departmentId;

    /**
     * 模板信息
     */
    private List<TemplateInfo> templateInfos;
    @Data
    public static class TemplateInfo implements Serializable{
        private Long pushId;
        /**
         * 推送类型（1-短信；2-push；3-微信公众号；4-微信小程序；5-支付宝小程序；6-站内信）
         */
        private Integer triggerChannel;

        // 公共参数
        private Integer bizChannel; // 会员中心固定为 1
        private String templateName;
        private String templateTitle;
        private String templateContent;
        private String templateLink;
        private String templateLongLink;  // 长链的ID
        private Long createAccountId;
        private String createAccountName;
        private Long updateAccountId;
        private String updateAccountName;

        // 短信模板增加参数
        private String organizationCode;
        private String organizationName;
        private Integer smsTemplateType;
        private Integer smsSgin;

        // 微信模板增加参数
        private String appId;
        private String wechatTemplateId;
        // 站内信模板编码
        private String internalMsgTemplateCode;
        // 点击模板卡片后的跳转页面，仅限本小程序内的页面
        private String page;

        // 后端需要的参数
        private String templateNum;
        private List<PushTemplateParamBo> contentParams;
        private String templatePhoto;
        private List<PushTemplateParamBo> urlParams;
        private String utmParameter;
        private Integer percent;
        private String extraParameter;

        // 额外参数，方便前端回显
        private Integer urlType;
        private String miniAppId;
        private String appName;  // 公众号名称
        /**
         * 图片参数
         */
        private String imageUrl;
        /**
         * 是否附加站内信，默认不附加站内信
         */
        private Boolean isAttachInternalMsg = false;
        /**
         * 站内信标题
         */
        private String internalMsgTitle;
        /**
         * apollo站内信发送链接
         */
        private String sendLink;
        /**
         * apollo站内信修改和回显需要的JSON
         */
        private String updateJson;
        /**
         * 站内信描述部分
         */
        private String msgDescription;
        /**
         * 站内信内容
         */
        private String internalMsgContent;
        /**
         * 站内信消息模板渠道
         */
        private Integer internalMsgChannel;
        /**
         * 站内信详情页面根路径
         */
        private String interMsgDetailPageRootPath;

        /**
         * 解析后单独的utm参数。创建模板时候前端不用传，仅返回时供前端显示使用（打通活动工具的需求）
         */
        private String utmSource;
        private String utmMedium;
        private String utmCampaign;
        private String utmContent;

        /**
         * 活动相关参数（打通活动工具的需求）
         */
        private Long activityId;
        private Long activityUtilId;
        private String activityChannelName;
        private String activityUrl;

    }
    @Data
    public static class PushTemplateParamBo implements Serializable {

        private String name;
        /**
         * 参数来源类型  1：固定文本 2：系统参数
         */
        private Integer type;
        /**
         * 参数值
         */
        private String value;

    }
}
