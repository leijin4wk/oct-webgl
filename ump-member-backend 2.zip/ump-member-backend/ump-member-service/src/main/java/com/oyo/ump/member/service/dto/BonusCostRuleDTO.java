package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

/**
 * @Classname BonusCostRuleDTO
 * @Description 积分消费规则返回信息
 * @Date 2019-03-15 11:29
 * @author Dong
 */
@Data
public class BonusCostRuleDTO implements Serializable {

    private List<BonusCostRuleInfo> bonusCostRuleInfoList;

    @Data
    public static class BonusCostRuleInfo{
        private Integer id;

        private Integer deductionRatio;
        /**
         * 每一积分可抵扣人民币（元）
         */
        private BigDecimal pricePerUnit;
        /**
         * 每次抵扣至少使用多少积分
         */
        private Integer minBonus;

        private Boolean isDeleted;
    }
}
