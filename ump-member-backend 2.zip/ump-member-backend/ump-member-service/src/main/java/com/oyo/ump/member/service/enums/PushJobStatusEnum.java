package com.oyo.ump.member.service.enums;
/**
 *
* @author frank
* @date  17:32
**/
public enum  PushJobStatusEnum {

    Sending("1","正在发送"),
    Finish("2","发送完成");

    private final String type;
    private final String name;

    public String getType() {
        return type;
    }
    public String getName() {
        return name;
    }
    PushJobStatusEnum(String type, String name){
        this.name=name;
        this.type=type;
    }
}
