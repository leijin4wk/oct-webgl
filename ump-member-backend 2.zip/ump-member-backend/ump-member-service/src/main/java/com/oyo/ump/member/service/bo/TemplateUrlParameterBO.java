package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;

/**
 * @author Dong
 * @Classname TemplateUrlParameterBO
 * @Description
 * @Date 2019-09-05
 */
@Data
public class TemplateUrlParameterBO implements Serializable {
    private Long id;
    private String urlAddress;
    private String urlName;
    private String urlParameter;
    private Integer urlType;
    private String miniAppId;
    private String miniAppName;
    private String deeplinkUrl;
}
