package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;

@Data
public class ChannelLinkBasicBo implements Serializable {

    private String channelName;

    private Long promoteBasisId;

    private String utmMedium;

    private String utmSource;

    private String utmCampaign;

    private String utmContent;

}
