package com.oyo.ump.member.service.enums;
/**
 *
 * push 任务推送状态
* @author leijin
* @date 2020-01-02 15:06
**/
public enum PushRecordStatusEnum {
    /**
    * 初始状态
    **/
    Init(1),
    /**
     * 绑定时间轮处于就绪状态
     **/
    Ready(4),

    /**
     * 执行时间轮任务发送状态
     **/
    Sending(5),

    /**
    *发送错误
    **/
    Error(3),
    /**
     * 发送结束
     **/
    SendFinish(2);





    private Integer status;

    PushRecordStatusEnum(Integer status) {
        this.status = status;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
