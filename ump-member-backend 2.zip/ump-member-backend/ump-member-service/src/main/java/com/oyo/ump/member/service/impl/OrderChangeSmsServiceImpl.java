package com.oyo.ump.member.service.impl;

import com.google.gson.Gson;
import com.oyo.ump.member.dal.dao.PushMapper;
import com.oyo.ump.member.dal.dao.PushMessageMapper;
import com.oyo.ump.member.dal.dao.PushRuleMapper;
import com.oyo.ump.member.dal.dao.PushTempletesMapper;
import com.oyo.ump.member.dal.model.PushEntity;
import com.oyo.ump.member.dal.model.PushMessageEntity;
import com.oyo.ump.member.dal.model.PushRuleEntity;
import com.oyo.ump.member.dal.model.PushTempletesEntity;
import com.oyo.ump.member.integration.service.hotel.HotelRemoteService;
import com.oyo.ump.member.integration.service.hotel.LocationRemoteService;
import com.oyo.ump.member.integration.service.push.PushMessageService;
import com.oyo.ump.member.integration.service.sms.SmsService;
import com.oyo.ump.member.service.OrderChangeSmsService;
import com.oyo.ump.member.service.PushProcessService;
import com.oyo.ump.member.service.bo.PushTempleteBo;
import com.oyo.ump.member.service.enums.TriggerChannelEnum;
import com.oyo.ump.member.service.enums.TriggerTypeEnum;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/***
 *根据队列消息和事件发送不同的消息
 * @author frank
* @date 2019-05-09 17:29
**/
@Service
@Slf4j
public class OrderChangeSmsServiceImpl implements OrderChangeSmsService {
    @Value("${SMS_PUSH_USER_WHITE_LIST}")
    private String whiteList;
    @Value("${SMS_PUSH_SWITCH}")
    private boolean sMsPushSwitch;
    @Autowired
    private PushTempletesMapper pushTempletesMapper;
    @Autowired
    private PushRuleMapper pushRuleMapper;
    @Autowired
    private PushMapper pushMapper;
    @Autowired
    private PushMessageMapper pushMessageMapper;
    @Autowired
    private SmsService smsService;
    @Autowired
    private PushMessageService pushMessageService;
    @Autowired
    @Qualifier("fromGson")
    private Gson gson;
    @Autowired
    private HotelRemoteService hotelRemoteService;
    @Autowired
    private LocationRemoteService locationRemoteService;
    @Autowired
    private PushProcessService pushProcessService;
    @Override
    public void sendOrderChangeSmsMessage(Map<String,String> messageMap) {
        if (StringUtils.isNotBlank(whiteList)){
            List<String> list=new ArrayList<>(Arrays.asList(whiteList.split(",")));
            if(!list.contains(messageMap.get("bookingGuestPhone"))){
                log.info("白名单：{}，当前手机号为:{}",whiteList,messageMap.get("bookingGuestPhone"));
                return;
            }
        }
        //获取酒店相关信息
        HotelRemoteService.HotelInfo hotelInfo = hotelRemoteService.getHotelInfo(Long.parseLong(messageMap.get("hotelId")));
        if (hotelInfo==null){
            log.info("酒店信息为空！");
            return;
        }
        messageMap.put("hotelName",hotelInfo.getName());
        messageMap.put("hotelPhone",hotelInfo.getPhone());
        //获取酒店地址相关信息
        LocationRemoteService.LocationInfo locationInfo=locationRemoteService.getLocationInfo(Long.parseLong(messageMap.get("hotelId")),hotelInfo.getClusterId());
        if(locationInfo==null){
            log.info("酒店地址信息为空！");
            return;
        }
        locationInfo.setCnStateName(locationInfo.getCnStateName());
        String street=StringUtils.isBlank(hotelInfo.getStreet())?"":hotelInfo.getStreet();
        String hotelAddress=String.format("%s %s%s%s", locationInfo.getCnStateName(),locationInfo.getCnCityName(),locationInfo.getCnClusterName(),street);
        messageMap.put("hotelAddress",hotelAddress);

        log.info("推送开关状态：{}",sMsPushSwitch);
        //通过pushRuleId 集合 获取符合条件的推送模板相关配置
        if (sMsPushSwitch) {
            //通过eventeys获取符合发送条件的pushRuleId 集合il
            List<Long> ruleIds=getPushRuleByDetail(messageMap);
            if (CollectionUtils.isEmpty(ruleIds)){
                log.info("查询圈定条件ids为空！");
                return;
            }
            List<PushEntity> entities=getPushTempleteEntity(ruleIds);
            if (CollectionUtils.isEmpty(entities)){
                log.info("查询消息推送模板为空！");
                return;
            }
            log.info("可发送消息的模板数量为：{}",entities.size());
            //遍历每个模板，发送信息
            log.info("消息参数内容为：{}", messageMap);
            for (PushEntity item : entities) {
                pushProcessService.sendMqPushMessageByPushId(item.getId(), messageMap, Long.valueOf(messageMap.get("memberId")));
            }
        }else{
            //通过eventeys获取符合发送条件的pushRuleId 集合
            List<Long> ruleIds=getPushRuleByEventKey(messageMap);
            if (CollectionUtils.isEmpty(ruleIds)){
                log.info("查询圈定条件ids为空！");
                return;
            }
            //通过pushRuleId 集合 获取符合条件的推送模板相关配置
            List<PushTempleteBo> pushTempleteBos=getPushTempleteBo(ruleIds);
            if (CollectionUtils.isEmpty(pushTempleteBos)){
                log.info("查询消息推送模板为空！");
                return;
            }
            log.info("可发送消息的模板数量为：{}",pushTempleteBos.size());
            //遍历每个模板，发送信息
            for (PushTempleteBo item:pushTempleteBos) {
                PushMessageEntity pushMessageEntity = PushMessageEntity.builder()
                        .memberId(Long.parseLong(messageMap.get("memberId")))
                        .templeteId(item.getId())
                        .eventKey(messageMap.get("eventKey"))
                        .uniformTemplateId(item.getUniformTemplateId())
                        .isDeleted(false)
                        .memberPushId(item.getId())
                        .build();
                //##判断发送频率取消
                Map<String, String> map = gson.fromJson(item.getPushDetail(), Map.class);
                String[] keyList = map.get("keyList").split(",");
                List<String> keys = new ArrayList<>(Arrays.asList(keyList));
                List<String> paramValues=new ArrayList<>();
                log.info("messageMap:"+messageMap);
                for (String key : keys) {
                    //如果传入的信息中有值那就拿传入的值
                    if (messageMap.get(key) != null) {
                        paramValues.add(messageMap.get(key));
                        //如果传入的信息中有值那就拿数据库中保存在json字段中的值
                    } else {
                        paramValues.add(map.get(key));
                    }
                }
                log.info("uniformTemplateId is {},sms message :{}",item.getUniformTemplateId(),gson.toJson(paramValues));
                String resultNo=pushMessageService.sendEventSMSPushMessage(messageMap.get("bookingGuestPhone"),item.getUniformTemplateId(),paramValues);
                pushMessageEntity.setBatchNo(resultNo);
                pushMessageMapper.insertPushMessageEntity(pushMessageEntity);
            }
        }
    }
    //通过rule 详情来查询rule
    public List<Long> getPushRuleByDetail(Map<String,String> messageMap){
        StringBuffer stringBuffer=new StringBuffer();
        stringBuffer.append("{\"crowdsGather\":\"{\\\"event\\\":\\\"").append(messageMap.get("eventKey")).append("\\\"}\"}");
        log.info("ruleDetail:{}",stringBuffer.toString());
        List<PushRuleEntity> list=pushRuleMapper.selectByDetail(stringBuffer.toString());
        return list.stream().map(PushRuleEntity::getId).collect(Collectors.toList());
    }


    /**
     * 获取消息对应的pushRuleId通过事件名称
    * @author frank
    * @date 2019-05-13 14:49
    **/
    public List<Long> getPushRuleByEventKey(Map<String,String> messageMap){
        List<PushRuleEntity> list=pushRuleMapper.selectByEventKey(messageMap.get("eventKey"));
        return list.stream().map(PushRuleEntity::getId).collect(Collectors.toList());
    }
    /**
     * 根据 pushRuleIds 获取对应的推送
    * @author frank
    * @date 2019-05-13 15:43
    **/
    public List<PushEntity> getPushTempleteEntity(List<Long> pushRuleIds){
        List<PushEntity> list=pushMapper.selectByRuleIdsAndTriggerType(pushRuleIds, TriggerTypeEnum.EVENT_TYPE.getType());
        log.info("查询到可发送模板数：{}",list.size());
        return list;
    }
    /**
     * 根据 pushRuleIds 获取对应的推送
     * @author frank
     * @date 2019-05-13 15:43
     **/
    public List<PushTempleteBo> getPushTempleteBo(List<Long> pushRuleIds){
        List<PushEntity> list=pushMapper.selectByRuleIdsAndTriggerType(pushRuleIds, TriggerTypeEnum.EVENT_TYPE.getType());
        List<PushEntity> pushEntities=new ArrayList<>();
        pushEntities.addAll(
                list.stream()
                        .filter(item->item.getTriggerChannel().equals(TriggerChannelEnum.SMS.getType()))
                        .filter(item-> item.getValidityFlag().equals(1))
                        .collect(Collectors.toList())
        );
        pushEntities.addAll(
                list.stream()
                        .filter(item->item.getTriggerChannel().equals(TriggerChannelEnum.SMS.getType()))
                        .filter(item-> item.getValidityFlag().equals(0))
                        .filter(item->
                                item.getValidityStart().before(new Date())
                                        &&item.getValidityEnd().after(new Date()))
                        .collect(Collectors.toList())
        );
        List<String> templeteIds=pushEntities.stream().map(PushEntity::getUniformTemplateId).collect(Collectors.toList());
        if(CollectionUtils.isEmpty(templeteIds)){
            log.info("推送对应的模板id为空！");
            return null;
        }
        List<PushTempletesEntity> pushTempletesEntities=pushTempletesMapper.selectPushTempletesEntityByTemplateNo(templeteIds);
        if (CollectionUtils.isEmpty(pushTempletesEntities)){
            log.info("模板对应的配置映射为空！");
            return null;
        }
        Map<String,PushTempletesEntity> templetesEntityMap=pushTempletesEntities.stream()
                .collect(Collectors.toMap(PushTempletesEntity::getAliTempleteId, entity -> entity));
        List<PushTempleteBo> boList=new ArrayList<>();

        for (PushEntity item :pushEntities) {
            PushTempleteBo pushTempleteBo=new PushTempleteBo();
            BeanUtils.copyProperties(item,pushTempleteBo);
            PushTempletesEntity temp=templetesEntityMap.get(item.getUniformTemplateId());
            if (temp==null){
                continue;
            }
            pushTempleteBo.setUniformTemplateId(temp.getAliTempleteId());
            pushTempleteBo.setPushDetail(temp.getDetail());
            boList.add(pushTempleteBo);
        }
        return boList;
    }
}
