package com.oyo.ump.member.service;

import com.oyo.ump.member.dal.model.PushMessageEntity;
import com.oyo.ump.member.service.bo.PushInfoAndParams;

import java.util.Map;

/**
 * 人群筛选操作类
* @author leijin
* @date 2019-09-06 17:15
**/
public interface PushProcessService {

    void sendMessageByPushId(Long pushId,Long jobId);


    void sendMqPushMessageByPushId(Long pushId,Map<String,String> mqKeysParams,Long memberId);


    void testPushMessage(Long pushId,String templateNum,String phone);



    void testBusinessMessage(Long pushId,String userId);

    /**
     *
     * source 1为db参数，2为mq参数
    * @author leijin
    * @date 2019-09-24 15:29
    **/
    PushMessageEntity buildPushMessageEntity(PushInfoAndParams pushInfoAndParams,
                                                    Map<String,Object> dbMap, Map<String,String> mqKeysParams, Long jobId,int source);

    /**
     * 统计push用户的总数
    * @author leijin
    * @date 2019-11-01 11:23
    **/
    long countPushUsersByPushId(Long pushId);
}
