package com.oyo.ump.member.service.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @Description: 交易信息
 * @Author: fang
 * @create: 2019-09-06
 **/
@Data
public class UserTradePageResponseDTO implements Serializable {
    private List<UserTradeInfo> memberIdentityBOList;
    private Long total =0L;
    private Integer pageNum;
    private Integer pageSize;
    @Data
    public static class UserTradeInfo implements Serializable {
        private Long id;
        private String orderSn;
        private String bookingSn;
        private Long hotelId;
        private String hotelName;
        private String orderTime;
        private String payTime;
        private String checkinTime;
        private String checkoutTime;
        private Double actualAmount;
        private Double amount;
        private String terminal;
        //0-待入住;1-在住;2-离店;3-取消;4-noShow
        private String status;
        private Double discountMoney;

    }
}
