package com.oyo.ump.member.service;

import java.util.Map;

/**
* @author frank
* @date 2019-05-09 17:23
**/
public interface OrderChangeSmsService {
    /**
     * 发送事件消息
     * @author frank
    * @date 2019-05-09 17:25
    **/
    void sendOrderChangeSmsMessage(Map<String,String> messageMap);

}
