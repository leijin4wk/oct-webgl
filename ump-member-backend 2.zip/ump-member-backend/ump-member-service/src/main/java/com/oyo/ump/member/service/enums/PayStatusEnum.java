package com.oyo.ump.member.service.enums;

public enum  PayStatusEnum {

    PAYING(0, "支付中"),
    PAY_SUCCESS(1, "支付成功"),
    PAY_FAILURE(2, "支付失败"),
    PAY_WAIT(3, "待支付"),


    //c端订单支付状态扩展
    PAY_WAIT_SIGNATURE(4, "待支付，未生成支付签名"),
    PAY_TIME_OUT(5, "订单在线支付超时"),
    NO_NEED_ONLINE_PAY(6, "不需要在线支付"),

    REFUND_WAIT(7, "待退款"),
    REFUNDING(8, "退款中"),
    REFUND_SUCCESS(9, "退款成功"),
    REFUND_FAILURE(10, "退款失败"),

    //B端标记为异常
    EXCEPTION(11, "异常");

    
    private final Integer type;
    private final String name;

    public Integer getType() {
        return type;
    }
    public String getName() {
        return name;
    }
    PayStatusEnum(Integer type, String name){
        this.name=name;
        this.type=type;
    }
}
