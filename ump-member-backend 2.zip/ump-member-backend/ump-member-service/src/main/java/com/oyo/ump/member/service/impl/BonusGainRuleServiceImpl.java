package com.oyo.ump.member.service.impl;

import com.alibaba.fastjson.JSON;
import com.google.gson.Gson;
import com.oyo.ump.member.common.constants.MemberConstants;
import com.oyo.ump.member.dal.dao.BonusGainRuleMapper;
import com.oyo.ump.member.dal.model.BonusGainRuleEntity;
import com.oyo.ump.member.service.BonusGainRuleService;
import com.oyo.ump.member.service.RedisService;
import com.oyo.ump.member.service.dto.BonusGainRuleDTO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * @Classname BounsGainRuleServiceImpl
 * @Description 积分获取规则实现类
 * @Date 2019-03-16 11:30
 * @author Dong
 */
@Service
@Slf4j
public class BonusGainRuleServiceImpl implements BonusGainRuleService {

    @Autowired
    private BonusGainRuleMapper bonusGainRuleMapper;

    @Autowired
    @Qualifier("fromGson")
    private Gson gson;

    @Autowired
    private RedisService redisService;

    @Override
    public BonusGainRuleDTO getGainRuleList(String tenant) {
        Object gainRule= redisService.getValue(MemberConstants.POINT_GAIN_RULE+tenant);
        if(gainRule!=null){
            return JSON.parseObject(gainRule.toString(),BonusGainRuleDTO.class) ;

        }
        BonusGainRuleDTO bonusGainRuleDTO = new BonusGainRuleDTO();
        List<BonusGainRuleEntity> bonusGainRuleEntityList = Lists.newArrayList();

        try{
            bonusGainRuleEntityList = bonusGainRuleMapper.getGainRuleList(tenant);
        }catch (Exception e){
            log.error("查询鸥币获取规则sql异常", e);
        }

        convert2DTO(bonusGainRuleEntityList, bonusGainRuleDTO);
        redisService.setValue(MemberConstants.POINT_GAIN_RULE+tenant,JSON.toJSONString(bonusGainRuleDTO),MemberConstants.POINT_EXCHANGER_EXPIRED);
        return bonusGainRuleDTO;
    }

    /**
     * EntityList转换为DTO
     * @param bonusGainRuleEntityList 积分获取规则实体列表
     * @param bonusGainRuleDTO 积分规则DTO
     * @return void
     */
    private void convert2DTO(List<BonusGainRuleEntity> bonusGainRuleEntityList, BonusGainRuleDTO bonusGainRuleDTO){

        List<BonusGainRuleDTO.BonusGainRuleInfo> bonusGainRuleInfoList = Lists.newArrayList();

        if(CollectionUtils.isNotEmpty(bonusGainRuleEntityList)){
            bonusGainRuleEntityList.forEach(entity ->{
                BonusGainRuleDTO.BonusGainRuleInfo bonusGainRuleInfo = convert2Info(entity);
                bonusGainRuleInfoList.add(bonusGainRuleInfo);
            });
        }

        bonusGainRuleDTO.setBonusGainRuleInfoList(bonusGainRuleInfoList);
    }

    /**
     * Entity 转换成 Info
     * @param entity 积分获取规则实体类
     * @return com.oyo.ump.member.service.dto.BonusGainRuleDTO.BonusGainRuleInfo
     */
    private BonusGainRuleDTO.BonusGainRuleInfo convert2Info(BonusGainRuleEntity entity) {
        BonusGainRuleDTO.BonusGainRuleInfo bonusGainRuleInfo = new BonusGainRuleDTO.BonusGainRuleInfo();
        try{
            bonusGainRuleInfo.setId(entity.getId());
            bonusGainRuleInfo.setBonusType(entity.getBonusType());
            bonusGainRuleInfo.setStatus(entity.getStatus().intValue()==1);
            bonusGainRuleInfo.setGainFlag(entity.getGainFlag().intValue()==1);
            bonusGainRuleInfo.setCostFlag(entity.getCostFlag().intValue()==1);
            bonusGainRuleInfo.setInitalValue(entity.getInitalValue());
            bonusGainRuleInfo.setLimitValue(entity.getLimitValue());
            bonusGainRuleInfo.setMultipleFlag(entity.getMultipleFlag().intValue()==1);
            bonusGainRuleInfo.setValidPeriod(entity.getValidPeriod());
            bonusGainRuleInfo.setValidity(entity.getStrValidPeriod());

            if(entity.getValidPeriodJson() != null){
                BonusGainRuleDTO.BonusGainRuleInfo.ValidPeriod validPeriodJson = gson.fromJson(entity.getValidPeriodJson(), BonusGainRuleDTO.BonusGainRuleInfo.ValidPeriod.class);
                bonusGainRuleInfo.setValidPeriodJson(validPeriodJson);

                if(validPeriodJson != null && validPeriodJson.getType() != null && StringUtils.isNotBlank(validPeriodJson.getStrValidPeriod())){
                    Integer type = validPeriodJson.getType();
                    String strValidPeriod = validPeriodJson.getStrValidPeriod();
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    Date date = new Date();
                    if(MemberConstants.FIXED_TYPE.equals(type) && strValidPeriod.length() == MemberConstants.FIXED_TYPE_LENGTH){
                        // 次年12月31日, 月份和日期的格式必须两位数
                        String year = strValidPeriod.substring(0,2);
                        String month = strValidPeriod.substring(2,4);
                        String day = strValidPeriod.substring(5,7);
                        System.out.println(year);
                        if("次年".equals(year)){
                            String strDate = sdf.format(date);
                            String strYear = strDate.substring(0,4);
                            Integer nextYear = Integer.parseInt(strYear) + 1;
                            String strNextYear = nextYear.toString();
                            String validPeriod = strNextYear +"-"+ month +"-"+ day;
                            bonusGainRuleInfo.setStrValidPeriod(validPeriod);
                        }else if("当年".equals(year)){
                            String strDate = sdf.format(date);
                            String strYear = strDate.substring(0,4);
                            String validPeriod = strYear +"-"+ month +"-"+ day;
                            bonusGainRuleInfo.setStrValidPeriod(validPeriod);
                        }
                    } else if(MemberConstants.UNFIXED_TYPE.equals(type)){
                        String unit = strValidPeriod.substring(strValidPeriod.length()-1);
                        Integer num = Integer.parseInt(strValidPeriod.substring(0, strValidPeriod.length()-1));
                        Calendar cal = Calendar.getInstance();
                        cal.setTime(date);
                        if("年".equals(unit)){
                            cal.add(Calendar.YEAR, num);
                        }else if("月".equals(unit)){
                            cal.add(Calendar.MONTH, num);
                        }else if("日".equals(unit)){
                            cal.add(Calendar.DATE, num);
                        }
                        date = cal.getTime();
                        bonusGainRuleInfo.setStrValidPeriod(sdf.format(date));
                    }
                }
            }

            BonusGainRuleDTO.BonusGainRuleInfo.ComissionConfig comissionConfig = gson.fromJson(entity.getComissionConfig(), BonusGainRuleDTO.BonusGainRuleInfo.ComissionConfig.class);
            bonusGainRuleInfo.setComissionConfig(comissionConfig);
        }catch (Exception e){
            log.info("BonusGainRuleServiceImpl.convert2BO:", e);
        }

        return bonusGainRuleInfo;
    }


}
