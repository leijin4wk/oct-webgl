package com.oyo.ump.member.service.impl;

import com.alibaba.fastjson.JSON;
import com.ctrip.framework.apollo.spring.annotation.ApolloJsonValue;
import com.google.common.collect.Maps;
import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import com.oyo.common.response.PagedResponse;
import com.oyo.ump.member.dal.dao.MemberOrderMapper;
import com.oyo.ump.member.dal.model.MemberOrderEntity;
import com.oyo.ump.member.integration.service.trade.TradeRemoteService;
import com.oyo.ump.member.integration.service.wallet.PointsRemoteService;
import com.oyo.ump.member.service.GradeService;
import com.oyo.ump.member.service.TradeService;
import com.oyo.ump.member.service.UpgradePackageService;
import com.oyo.ump.member.service.bo.GradeInfoBO;
import com.oyo.ump.member.service.dto.*;
import com.oyo.ump.member.service.enums.PointTypeEnum;
import com.oyo.utp.pa.client.dto.OrderDto;
import com.oyo.utp.pa.client.req.OrdersQueryReq;
import com.oyo.utp.pa.client.req.RefundReq;
import com.oyo.utp.pa.client.req.SubOrdersReq;
import com.oyo.utp.pa.common.enums.BizId;
import com.oyo.utp.pa.common.enums.OrderStatus;
import com.oyo.utp.pa.common.enums.PaymentChannelType;
import com.oyo.utp.pa.common.enums.RefundTypeEnum;
import com.oyo.wallet.client.req.PointsDetailDTO;
import com.oyo.wallet.client.req.PointsQueryFlowsDTO;
import com.oyo.wallet.client.resp.PointsQueryFlowsVO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

/**
 * @Description: 查询用户交易数据实现类
 * @Author: fang
 * @create: 2019-03-29
 **/
@Service
@Slf4j
public class TradeServiceImpl implements TradeService {
    private static final SimpleDateFormat DATE_FORMATE = new SimpleDateFormat("yyyy-MM-dd");
    private static final SimpleDateFormat BONUS_CREAT_FORMATE = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    @Autowired
    private TradeRemoteService tradeRemoteService;
    @Autowired
    private PointsRemoteService pointsRemoteService;
    @Autowired
    private GradeService gradeService;
    @Autowired
    private UpgradePackageService upgradePackageService;
    @Autowired
    private MemberOrderMapper memberOrderMapper;
    private Long REFUND_TIMEOUT=1000*60*60*24*7L;

    @ApolloJsonValue("${OYO_MONEY_BUSINESS_TYPE_MAP}")
    Map<String,String> OYO_MONEY_BUSINESS_TYPE_MAP;


    @Override
    public MemberOrderResponseDTO queryUserTradeList(MemberOrderRequestDTO requestDTO) {
        MemberOrderResponseDTO memberOrderResponseDTO = new MemberOrderResponseDTO();
        memberOrderResponseDTO.setUserId(requestDTO.getUserId());
        OrdersQueryReq ordersQueryReq = buildeTradeRequestDTO(requestDTO);
        PagedResponse<OrderDto> response = tradeRemoteService.findAllOrder(ordersQueryReq);
        if (response != null && CollectionUtils.isNotEmpty(response.getResult())) {
            response.getResult().stream().forEach(orderDto -> {
                memberOrderResponseDTO.getResult().add(convert2MemberOrder(orderDto));
            });
        }
        return memberOrderResponseDTO;
    }

    @Override
    public MemberPointResponseDTO queryPointsList(MemberPointRequestDTO requestDTO) {
        MemberPointResponseDTO responseDTO =new MemberPointResponseDTO();
        responseDTO.setUserId(requestDTO.getUserId());
        List<PointsQueryFlowsVO> pointsQueryFlowsVOList =Lists.newArrayList();
        PagedResponse<PointsQueryFlowsVO>  response= pointsRemoteService.queryFlows(bulidePointsRequestDTO(requestDTO));
        if(response!=null){
            pointsQueryFlowsVOList =response.getResult();
            responseDTO.setPageNum(requestDTO.getPageNum());
            responseDTO.setPageSize(requestDTO.getPageSize());
            responseDTO.setTotalCount(response.getTotalCount());
            responseDTO.setTotalPages(response.getTotalPages());
        }
        if(CollectionUtils.isNotEmpty(pointsQueryFlowsVOList)){
            List<String> orderNo=Lists.newArrayList();
            pointsQueryFlowsVOList.forEach(pointsQueryFlowsVO->{
                orderNo.add(getOrderSn(pointsQueryFlowsVO.getBusinessNo()));
            });
            Map<String, MemberOrderEntity> orderEntityMap=convert2EntityMap(requestDTO.getUserId(),orderNo);
            pointsQueryFlowsVOList.forEach(pointsQueryFlowsVO -> {
                MemberPointResponseDTO.MemberBonusInfo memberBonusInfo =new MemberPointResponseDTO.MemberBonusInfo();
                memberBonusInfo.setTotalPointsNum(pointsQueryFlowsVO.getTotalPointsNum());
                memberBonusInfo.setOrderSn(pointsQueryFlowsVO.getBusinessNo());
                memberBonusInfo.setPointNum(pointsQueryFlowsVO.getPointNum());
                memberBonusInfo.setMarketingName(pointsQueryFlowsVO.getMarketingName());
                memberBonusInfo.setPointNum(pointsQueryFlowsVO.getPointNum());
                calculateUserPoint(pointsQueryFlowsVO, memberBonusInfo);
                if(OYO_MONEY_BUSINESS_TYPE_MAP.containsKey(pointsQueryFlowsVO.getBusinessType())){
                    memberBonusInfo.setBusinessType(OYO_MONEY_BUSINESS_TYPE_MAP.get(pointsQueryFlowsVO.getBusinessType()));
                }else {
                    memberBonusInfo.setBusinessType("未知业务类型");
                }
                try {
                    memberBonusInfo.setBonusAddTime(BONUS_CREAT_FORMATE.parse(pointsQueryFlowsVO.getCreateTime()));
                } catch (Exception e) {
                    log.error("获取积分时间转化异常"+pointsQueryFlowsVO.getCreateTime(),e);
                }
                if(orderEntityMap.get(getOrderSn(pointsQueryFlowsVO.getBusinessNo()))!=null){
                    MemberOrderEntity entity =orderEntityMap.get(getOrderSn(pointsQueryFlowsVO.getBusinessNo()));
                    memberBonusInfo.setCreateTime(entity.getOrderTime());
                    memberBonusInfo.setPayTime(entity.getPayTime());
                    memberBonusInfo.setActualAmount(BigDecimal.valueOf(entity.getPaidAmount()));
                    memberBonusInfo.setOrderStatus("已完成");
                    Integer gradeId = entity.getGradeId();
                    GradeInfoBO gradeInfoBO =gradeService.getGradeByGradeId(gradeId);
                    if(gradeInfoBO!=null){
                        memberBonusInfo.setGrade(gradeInfoBO.getGrade());
                    }
                }
                responseDTO.getResult().add(memberBonusInfo);

            });
        }

        return responseDTO;
    }

    /**
     * 获取房单号和房单数据的map
     * @param userId
     * @param orderNo
     * @return
     */
    private Map<String, MemberOrderEntity> convert2EntityMap(Long userId, List<String> orderNo) {
        Map<String, MemberOrderEntity> result = Maps.newHashMap();
        try{
            if(CollectionUtils.isNotEmpty(orderNo)||userId==null){
                List<MemberOrderEntity> entityList=  memberOrderMapper.queryOrderList(userId,orderNo);
                if(CollectionUtils.isNotEmpty(entityList)){
                    entityList.stream().filter(memberOrderEntity -> memberOrderEntity!=null).forEach(memberOrderEntity -> {
                        result.put(memberOrderEntity.getOrderSn(),memberOrderEntity);
                    });
                }

            }

        }catch (Exception e){
            log.error("房单map数据转化异常"+ JSON.toJSONString(orderNo),e);
        }
        return result;

    }

    @Override
    public RefundResponseDTO refund(RefundRequestDTO requestDTO) {
        RefundResponseDTO responseDTO =new RefundResponseDTO();
        BaseResponse<Void> response = tradeRemoteService.refund(bulideRefundReq(requestDTO));
        if(response!=null&&ResponseCode.SUCCESS.getCode().equals(response.getCode())){
            responseDTO.setIsSuccess(true);
            responseDTO.setMsg(response.getMsg());
        }else {
            responseDTO.setIsSuccess(false);
            responseDTO.setMsg(response==null?"退订异常":response.getMsg());
        }
        return responseDTO;
    }

    /**
     * 构建退订接口请求dto
     * @param requestDTO
     * @return
     */
    private RefundReq bulideRefundReq(RefundRequestDTO requestDTO) {
        RefundReq tradeReq =new RefundReq();
        tradeReq.setBizId(BizId.PMS_001.name());
//        tradeReq.setUserId(requestDTO.getUserId());
        tradeReq.setOperatorId(requestDTO.getOperatorId());
        tradeReq.setOrderSn(requestDTO.getOrderSn());
        tradeReq.setOperatorRefGroupId("CRM");
        tradeReq.setRefundType(RefundTypeEnum.REFUND.getCode());
        List<SubOrdersReq> subOrdersReqList=Lists.newArrayList();
        SubOrdersReq subOrdersReq =new SubOrdersReq();
        subOrdersReq.setSkuCode(requestDTO.getProductCode());
        subOrdersReq.setSaleNumber(1);
        subOrdersReqList.add(subOrdersReq);
        tradeReq.setSubOrdersReq(subOrdersReqList);
        return tradeReq;
    }

    /**
     * 计算积分
     * @param pointsQueryFlowsVO
     * @param memberBonusInfo
     */
    private void calculateUserPoint(PointsQueryFlowsVO pointsQueryFlowsVO, MemberPointResponseDTO.MemberBonusInfo memberBonusInfo) {
        List<PointsDetailDTO> pointsDetailDTOList = pointsQueryFlowsVO.getPointsDetails();
        if(CollectionUtils.isNotEmpty(pointsDetailDTOList)){
            pointsDetailDTOList.stream().filter(pointsDetailDTO -> pointsDetailDTO!=null&&pointsDetailDTO.getPointsNum()!=null).forEach(pointsDetailDTO -> {
                if(PointTypeEnum.CONSUME_POINT.getType().equals(pointsDetailDTO.getPointTypeCode())){
                    memberBonusInfo.setConsumePoints(memberBonusInfo.getConsumePoints()+pointsDetailDTO.getPointsNum());
                }
                if(PointTypeEnum.AWARD_POINT.getType().equals(pointsDetailDTO.getPointTypeCode())){
                    memberBonusInfo.setAwardPoints(memberBonusInfo.getAwardPoints()+pointsDetailDTO.getPointsNum());
                }
                if(PointTypeEnum.ACTIVITY_POINT.getType().equals(pointsDetailDTO.getPointTypeCode())){
                    memberBonusInfo.setActivityPoints(memberBonusInfo.getActivityPoints()+pointsDetailDTO.getPointsNum());
                }
            });
        }
    }

    /**
     * 获取k为orderNo value为PromotionVo 的map
     * @param orderNo
     * @param userId
     * @return
     */
//    private Map<String, PromotionVo> convert2PromotionVoMap(List<String> orderNo, Long userId) {
//        Map<String, PromotionVo> promotionVoMap=Maps.newHashMap();
//        List<PromotionVo> promotionVoList = tradeRemoteService.findLivingInfo(orderNo,userId);
//        if(CollectionUtils.isNotEmpty(promotionVoList)){
//            promotionVoList.forEach(promotionVo -> {
//                promotionVoMap.put(promotionVo.getOrderSn(),promotionVo);
//            });
//        }
//          return promotionVoMap;
//    }

    /**
     * 构建积分请求dto
     * @param requestDTO
     * @return
     */
    private PointsQueryFlowsDTO bulidePointsRequestDTO(MemberPointRequestDTO requestDTO) {
        PointsQueryFlowsDTO pointsQueryFlowsDTO =new PointsQueryFlowsDTO();
        pointsQueryFlowsDTO.setUserId(requestDTO.getUserId().toString());
        pointsQueryFlowsDTO.setTenantId(requestDTO.getTenant());
        if(StringUtils.isNotEmpty(requestDTO.getOrderNo())){
            pointsQueryFlowsDTO.setBusinessNo(requestDTO.getOrderNo());
        }
        pointsQueryFlowsDTO.setQueryType(requestDTO.getQueryType());
        if(requestDTO.getFromDate()!=null){
            pointsQueryFlowsDTO.setBeginDate(DATE_FORMATE.format(requestDTO.getFromDate()));
        }
        if(requestDTO.getToDate()!=null){
            pointsQueryFlowsDTO.setEndDate(DATE_FORMATE.format(requestDTO.getToDate()));
        }
        pointsQueryFlowsDTO.setPageNum(requestDTO.getPageNum());
        pointsQueryFlowsDTO.setPageSize(requestDTO.getPageSize());
        return pointsQueryFlowsDTO;
    }

    /**
     * 转化为会员信息dto
     *
     * @param orderDto
     * @return
     */
    private MemberOrderResponseDTO.MemberOrderInfo convert2MemberOrder(OrderDto orderDto) {
        MemberOrderResponseDTO.MemberOrderInfo memberOrderInfo = new MemberOrderResponseDTO.MemberOrderInfo();
        memberOrderInfo.setActualAmount(orderDto.getActualAmount());
        memberOrderInfo.setCreateTime(orderDto.getCreateTime());
        memberOrderInfo.setOrderSn(orderDto.getOrderSn());
        memberOrderInfo.setOrderType(orderDto.getOrderType());
        memberOrderInfo.setOrderStatus(OrderStatus.getMessage(orderDto.getOrderStatus()));
        if(OrderStatus.TRANS_COMPLETE.getCode()==orderDto.getOrderStatus()){
            memberOrderInfo.setRefund(true);
        }else {
            memberOrderInfo.setRefund(false);
        }
        if(orderDto.getOrderBuyerVipinfoDto()!=null&&orderDto.getOrderBuyerVipinfoDto().getMemberLevel()!=null){
            memberOrderInfo.setGrade(orderDto.getOrderBuyerVipinfoDto().getMemberLevel());
        }
        if(CollectionUtils.isNotEmpty(orderDto.getOrdersItemDtos())){
            memberOrderInfo.setProductName(orderDto.getOrdersItemDtos().get(0).getProductName());
            memberOrderInfo.setProductCode(orderDto.getOrdersItemDtos().get(0).getProductCode());
        }
        if(orderDto.getOrdersPaymentDto()!=null){
            memberOrderInfo.setPayTime(orderDto.getOrdersPaymentDto().getFinishTime());
            memberOrderInfo.setPaymentChannel(PaymentChannelType.getName(orderDto.getOrdersPaymentDto().getPayChannel()));
            //超过7天不给退订
            if(orderDto.getOrdersPaymentDto().getFinishTime()!=null) {
                Long payTime = orderDto.getOrdersPaymentDto().getFinishTime().getTime();
                Long nowTime = System.currentTimeMillis();
                if ((nowTime - payTime) > REFUND_TIMEOUT) {
                    memberOrderInfo.setRefund(false);
                }
            }
        }
        return memberOrderInfo;
    }

    /**
     * 构建交易升级包请求dto
     *
     * @param requestDTO
     * @return
     */
    private OrdersQueryReq buildeTradeRequestDTO(MemberOrderRequestDTO requestDTO) {
        OrdersQueryReq ordersQueryReq = new OrdersQueryReq();
        if (requestDTO != null) {
            ordersQueryReq.setMemberId(requestDTO.getUserId());
            ordersQueryReq.setOrderSn(requestDTO.getOrderNo());
            ordersQueryReq.setStartTime(requestDTO.getFromDate());
            ordersQueryReq.setEndTime(requestDTO.getToDate());
            ordersQueryReq.setOrderType("0");
            if(StringUtils.isNotEmpty(requestDTO.getOrderNo())){
                ordersQueryReq.setOrderSn(requestDTO.getOrderNo());
            }
            ordersQueryReq.setProductCategorys(upgradePackageService.getProductCategoryIds());
        }
        return ordersQueryReq;
    }

//    private Map<String, PointsQueryFlowsVO> getUserPoints(MemberOrderRequestDTO requestDTO) {
//        Map<String, PointsQueryFlowsVO> result = Maps.newHashMap();
//        PointsQueryFlowsDTO pointsQueryFlowsDTO = new PointsQueryFlowsDTO();
//        pointsQueryFlowsDTO.setUserId(requestDTO.getUserId().toString());
//        if (requestDTO.getFromDate() != null) {
//            pointsQueryFlowsDTO.setBeginDate(DATE_FORMATE.format(requestDTO.getFromDate()));
//        }
//        if (requestDTO.getToDate() != null) {
//            pointsQueryFlowsDTO.setEndDate(DATE_FORMATE.format(requestDTO.getToDate()));
//        }
//        List<PointsQueryFlowsVO> pointsQueryFlowsVOList = pointsRemoteService.queryFlows(pointsQueryFlowsDTO);
//        if (CollectionUtils.isNotEmpty(pointsQueryFlowsVOList)) {
//            pointsQueryFlowsVOList.forEach(pointsQueryFlowsVO -> {
//                result.put(pointsQueryFlowsVO.getBusinessNo(), pointsQueryFlowsVO);
//            });
//        }
//        return result;
//    }
    private  String getOrderSn(String text){
        if(StringUtils.isNotEmpty(text)&&text.contains("OYO_MONEY-CheckOutGrantCoin")){
            int start =text.indexOf("&")+1;
            int end =text.indexOf("|");
            if(start<end){
                return text.substring(start,end);

            }
        }
        return text;
    }
}
