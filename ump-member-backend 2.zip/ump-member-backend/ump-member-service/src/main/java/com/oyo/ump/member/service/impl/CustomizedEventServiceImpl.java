package com.oyo.ump.member.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.oyo.ump.member.service.CustomizedEventService;
import com.oyo.ump.member.service.bo.*;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Lists;
import org.assertj.core.util.Sets;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @Author hubin
 * @Description:
 * @Date 2019/9/10
 */
@Service
@Slf4j
public class CustomizedEventServiceImpl implements CustomizedEventService {

    @Value("${CUSTOMIZED_EVENT_VIEW}")
    private String customizedEventViewSQL;

    @Value("${VIEW_RELATION}")
    private String viewRelation;

//    @Override
//    public String getSqlSegmentByConfig(JSONArray configs) {
//        List<TriggerEventItemBo> conditionList = configs.toJavaList(TriggerEventItemBo.class);
//        Set<String> filters = Sets.newHashSet();
//        for(TriggerEventItemBo item : conditionList) {
//            filters.addAll(getFilterSQL(item));
//        }
//        return StringUtils.join(filters, " and ");
//    }

    @Override
    public String getEventViewSql() {
        return customizedEventViewSQL;
    }

    @Override
    public DynamicSqlBo dynamicBuildSql(String json) {
        Map<String,ViewRelationModel> relationModelMap=new HashMap<>();
        List<ViewRelationModel> viewRelationModels=JSON.parseArray(viewRelation,ViewRelationModel.class);
        viewRelationModels.forEach(obj->{
            relationModelMap.put(obj.getViewName(),obj);
        });
        EventModelBo eventModelBo = JSON.parseObject(json,EventModelBo.class);
        CustomizedEventParam customizedEventParam=new CustomizedEventParam();
        DynamicSqlBo dynamicSqlBo=new DynamicSqlBo();
        for (EvenTriggerConditionBo item:eventModelBo.getTriggerCondition()) {
            dynamicSqlBo.getViewSet().add(item.getViewName());
            String temp=buildTempView(item,eventModelBo.getTimeUnit(),eventModelBo.getDelay(),relationModelMap,eventModelBo.isEventOrder());
            customizedEventParam.getJoinCondition().put(item.getItemId(),temp);
            customizedEventParam.getWhereCondition().put(item.getItemId(),item.isExistFlag());
        }

        dynamicSqlBo.setJoinFragment(buildSqlJoinFragment(eventModelBo.getTriggerCondition(),customizedEventParam,relationModelMap));
        dynamicSqlBo.setWhereFragment(buildSqlWhereFragment(eventModelBo.getTriggerCondition(),customizedEventParam,relationModelMap,eventModelBo.isEventOrder()));
        return dynamicSqlBo;
    }
    private String buildSqlJoinFragment(List<EvenTriggerConditionBo> list,CustomizedEventParam customizedEventParam,Map<String,ViewRelationModel> relationModelMap){
        StringBuilder stringBuilder=new StringBuilder();
        String lastViewName="member_dim";
        for (EvenTriggerConditionBo item:list) {
            stringBuilder.append(" left join ( ");
            stringBuilder.append(customizedEventParam.getJoinCondition().get(item.getItemId()));
            stringBuilder.append(" ) ");
            stringBuilder.append("tmp" +item.getItemId());
            stringBuilder.append(" on ");
            List<String> onCondition=relationModelMap.get(lastViewName).getRelationConditionMap().get(item.getViewName());
            if(item.getItemId()==0){
                stringBuilder.append("member_dim.");
            }else{
                stringBuilder.append("tmp" );
                stringBuilder.append(item.getItemId()-1);
                stringBuilder.append("." );
            }
            stringBuilder.append(onCondition.get(0));
            stringBuilder.append("=");
            stringBuilder.append("tmp" +item.getItemId()+".");
            stringBuilder.append(onCondition.get(1));
            lastViewName=item.getViewName();
        }
        return stringBuilder.toString();
    }

    private String buildSqlWhereFragment(List<EvenTriggerConditionBo> list,CustomizedEventParam customizedEventParam,Map<String,ViewRelationModel> relationModelMap,boolean eventOrder){
        StringBuilder stringBuilder=new StringBuilder();
        for (EvenTriggerConditionBo item:list) {
            if (customizedEventParam.getWhereCondition().get(item.getItemId())){
                stringBuilder.append(" and ");
                stringBuilder.append(" tmp" +item.getItemId()+".");
                stringBuilder.append(relationModelMap.get(item.getViewName()).getWhereColumn());
                stringBuilder.append(" is not null");
            }else{
                stringBuilder.append(" and ");
                stringBuilder.append(" tmp" +item.getItemId()+".");
                stringBuilder.append(relationModelMap.get(item.getViewName()).getWhereColumn());
                stringBuilder.append(" is null");
            }
        }
        if(eventOrder&&list.size()>1){
            for(int i=0;i<list.size()-1;i++){
                stringBuilder.append(" and tmp").append(list.get(i).getItemId()).append(".e_time<")
                        .append("tmp").append(list.get(i+1).getItemId()).append(".e_time");
            }
        }

        return stringBuilder.toString();
    }
    private String buildTempView( EvenTriggerConditionBo item,Integer timeUnit,Integer delay,Map<String,ViewRelationModel> relationModelMap,boolean eventOrder){
        StringBuilder stringBuilder=new StringBuilder();
        stringBuilder.append(" SELECT ");
        stringBuilder.append(relationModelMap.get(item.getViewName()).getColumn());
        if (relationModelMap.get(item.getViewName()).getTimeDependence()&&eventOrder){
            stringBuilder.append(",e_time ");
        }
        stringBuilder.append(" from ");
        stringBuilder.append(item.getViewName());
        stringBuilder.append(" where ");
        //判断视图是否依赖时间
        if(relationModelMap.get(item.getViewName()).getTimeDependence()) {
            stringBuilder.append("e_time > date_add(");
            if (timeUnit == 1) {
                stringBuilder.append("'MINUTE',");
            } else if (timeUnit == 2) {
                stringBuilder.append("'HOUR',");
            } else if (timeUnit == 3) {
                stringBuilder.append("'DAY',");
            }
            stringBuilder.append("-" + delay + ",");
            stringBuilder.append("now()) ");
        }

        //拼接事件过滤条件
        StringBuffer subFilter=new StringBuffer();
        subFilter.append(item.getViewFilter());
        Map<Integer,TriggerEventItemBo> subMap= item.getSubTriggerEventMap();
        for (Integer key:subMap.keySet()) {
            subFilter.append(" and ");
            subFilter.append(getFilterSQL(subMap.get(key)));
        }
        if (StringUtils.isNotBlank(subFilter.toString())){
            stringBuilder.append(" and ").append(subFilter.toString());
        }

        return stringBuilder.toString();
    }
    private String getFilterSQL(TriggerEventItemBo item) {
        StringBuilder sb = new StringBuilder();
        sb.append('`')
                .append(item.getViewName())
                .append('`')
                .append('.')
                .append(item.getViewColumn())
                .append(' ')
                .append(item.getTriggerOperator());
        Integer tagType = item.getTriggerPropertyType();
        switch (tagType) {
            case 1:
                JSONArray jsonElements = JSON.parseArray(item.getTriggerValue());
                if (jsonElements.size() > 0) {
                    sb.append('(');
                    Iterator<Object> iterator = jsonElements.iterator();
                    List<String> strList = Lists.newArrayList();
                    while (iterator.hasNext()) {
                        strList.add("\'" + iterator.next().toString() + "\'");
                    }
                    sb.append(StringUtils.join(strList, ","));
                    sb.append(')');
                }
                break;
            case 2:
            case 4:
            case 6:
                String tagValueSelectValueStr = item.getTriggerValue();
                sb.append("\'" + tagValueSelectValueStr + "\'");
                break;
            case 3:
            case 5:
                String tagValueSelectValueNum = item.getTriggerValue();
                sb.append(tagValueSelectValueNum);
                break;
            default:
                break;
        }
        return sb.toString();
    }

}
