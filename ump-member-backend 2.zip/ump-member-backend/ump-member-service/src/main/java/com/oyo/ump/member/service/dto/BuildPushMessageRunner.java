package com.oyo.ump.member.service.dto;

import com.google.common.collect.Lists;
import com.oyo.ump.member.dal.model.PushMessageEntity;
import com.oyo.ump.member.service.PushProcessService;
import com.oyo.ump.member.service.PushService;
import com.oyo.ump.member.service.UniformPushService;
import com.oyo.ump.member.service.bo.PushInfoAndParams;
import com.oyo.ump.member.service.enums.TriggerTypeEnum;
import com.oyo.ump.member.service.producer.memberPush.MemberPushMessage;
import com.oyo.ump.member.service.producer.memberPush.MemberPushPublisher;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;

import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 *  组装消息，发送消息
* @author leijin
* @date 2019-09-23 14:57
**/
@Slf4j
public class BuildPushMessageRunner implements Runnable{
    private Long jobId;

    MemberPushPublisher memberPushPublisher;

    private List<Map<String,Object>> items;

    private PushProcessService pushProcessService;


    private PushInfoAndParams pushInfoAndParams;

    private PushService pushService;

    public BuildPushMessageRunner(Long jobId, MemberPushPublisher memberPushPublisher,
                                  List<Map<String, Object>> items, PushProcessService pushProcessService,
                                  PushInfoAndParams pushInfoAndParams,PushService pushService) {
        this.jobId = jobId;
        this.memberPushPublisher = memberPushPublisher;
        this.items = items;
        this.pushProcessService = pushProcessService;
        this.pushInfoAndParams = pushInfoAndParams;
        this.pushService=pushService;
    }

    @Override
    public void run() {
        log.info("组装消息线程方法开始");
        if (CollectionUtils.isEmpty(this.items)){
            log.info("本批次可发消息为空！");
        }
        if (pushInfoAndParams.triggerType.equals(TriggerTypeEnum.CUSTOM_EVENT_TYPE.getType())) {
            List<Map<String,Object>> pushMessageMapList=new ArrayList<>();
            List<Long> ids = this.items.stream().map(item -> Long.valueOf(item.get("member_id").toString())).collect(Collectors.toList());
            List<Long> sendAbleList=pushService.getIntervalUserIds(ids,pushInfoAndParams.getPushId(),pushInfoAndParams.getIntervalTime().longValue(), ChronoUnit.DAYS);
            log.info("可发用户id数量为:{}",sendAbleList.size());
            for(int i=0;i<this.items.size();i++){
                Map<String,Object> item=this.items.get(i);
                Long memberId=Long.valueOf(item.get("member_id").toString());
                if (sendAbleList.contains(memberId)){
                    pushMessageMapList.add(item);
                }
            }
            this.items=pushMessageMapList;
        }
        if (CollectionUtils.isEmpty(this.items)){
            return;
        }
        List<List<Map<String,Object>>> arrays= Lists.partition(items,100);
        arrays.stream().forEach(obj->{
            List<PushMessageEntity> pushMessageEntities=new ArrayList<>();
            for (Map<String,Object> item:obj) {
                PushMessageEntity pushMessageEntity=this.pushProcessService.buildPushMessageEntity(this.pushInfoAndParams,item,new HashMap<>(),this.jobId,1);
                if (pushMessageEntity!=null) {
                    pushMessageEntities.add(pushMessageEntity);
                }
            }
            if (CollectionUtils.isNotEmpty(pushMessageEntities)) {
                MemberPushMessage memberPushMessage = new MemberPushMessage();
                memberPushMessage.setPushMessageEntities(pushMessageEntities);
                //TODO
                log.info(memberPushMessage.toString());
               this.memberPushPublisher.execute(memberPushMessage);
                log.info("消息发送至mq！");
            }else{
                log.info("消息不完整，可发消息为零！");
            }
        });
        log.info("组装消息线程方法结束");
    }
}
