package com.oyo.ump.member.service.impl;

import com.oyo.ump.member.common.beanutils.MapperWrapper;
import com.oyo.ump.member.dal.dao.PushEventMetaMapper;
import com.oyo.ump.member.dal.dao.PushRuleMapper;
import com.oyo.ump.member.dal.model.PushEventMetaEntity;
import com.oyo.ump.member.dal.model.PushRuleEntity;
import com.oyo.ump.member.service.PushRuleService;
import com.oyo.ump.member.service.bo.PushEventMetaBO;
import com.oyo.ump.member.service.bo.PushRuleBO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Dong
 * @Classname PushServiceImpl
 * @Description 事件推送业务接口实现类
 * @Date 2019-05-06
 */
@Service
@Slf4j
public class PushRuleServiceImpl implements PushRuleService {
    @Autowired
    PushRuleMapper pushRuleMapper;
    @Autowired
    PushEventMetaMapper pushEventMetaMapper;


    @Override
    public PushRuleBO selectById(Long id) {
        PushRuleEntity pushRuleEntity = pushRuleMapper.selectById(id);
        if(pushRuleEntity != null){
           return  MapperWrapper.instance().map(pushRuleEntity, PushRuleBO.class);
        }else{
            return null;
        }
    }

    @Override
    public List<PushEventMetaBO> selectAll() {
        List<PushEventMetaEntity> pushEventMetaEntities = pushEventMetaMapper.selectAll();
        if (CollectionUtils.isNotEmpty(pushEventMetaEntities)) {
            List<PushEventMetaBO> pushEventMetaBOS = Lists.newArrayList();
            pushEventMetaEntities.forEach(pushEventMeta -> {
                PushEventMetaBO pushEventMetaBO = MapperWrapper.instance().map(pushEventMeta, PushEventMetaBO.class);
                pushEventMetaBOS.add(pushEventMetaBO);
            });
            return pushEventMetaBOS;
        } else {
            return null;
        }
    }
}
