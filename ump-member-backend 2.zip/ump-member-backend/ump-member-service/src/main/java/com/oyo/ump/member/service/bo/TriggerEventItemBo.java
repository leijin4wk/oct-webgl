package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;
@Data
public class TriggerEventItemBo implements Serializable {

    private Integer itemId;
    private String triggerName;

    private Integer triggerPropertyType;
    private String viewFilter;

    private String viewName ;

    private String viewColumn;

    private String triggerOperator;

    private String triggerValue;

    private Integer parentId;

}

