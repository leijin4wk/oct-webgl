package com.oyo.ump.member.service.bo;

import lombok.Data;
/**
 * 事件定义bo对象
* @author frank
* @date 2019-07-30 10:50
**/
@Data
public class PushEventDefineBo {
    private Long id;
    private String delineationName;
    private String eventKey;

}
