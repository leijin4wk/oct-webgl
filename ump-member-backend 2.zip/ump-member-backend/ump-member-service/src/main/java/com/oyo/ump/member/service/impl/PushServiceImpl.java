package com.oyo.ump.member.service.impl;

import com.alibaba.fastjson.JSON;
import com.ctrip.framework.apollo.spring.annotation.ApolloJsonValue;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.gson.Gson;
import com.oyo.common.response.PagedResponse;
import com.oyo.ump.discount.service.discount.dto.DiscBaseInfoDTO;
import com.oyo.ump.discount.service.discount.dto.SceneRuleDTO;
import com.oyo.ump.discount.service.discount.dto.TimePeriodDTO;
import com.oyo.ump.member.common.constants.MemberConstants;
import com.oyo.ump.member.common.enums.CrowdTypeEnum;
import com.oyo.ump.member.common.exception.UmpException;
import com.oyo.ump.member.dal.dao.*;
import com.oyo.ump.member.dal.model.PushEntity;
import com.oyo.ump.member.dal.model.PushExtraEntity;
import com.oyo.ump.member.dal.model.PushJobRecordEntity;
import com.oyo.ump.member.dal.model.PushRuleEntity;
import com.oyo.ump.member.integration.service.diccount.DiscountService;
import com.oyo.ump.member.service.*;
import com.oyo.ump.member.service.bo.*;
import com.oyo.ump.member.service.component.NettyDelayQueue;
import com.oyo.ump.member.service.dto.BasePushTimer;
import com.oyo.ump.member.service.dto.WithOutDelayTimer;
import com.oyo.ump.member.service.enums.PushRecordStatusEnum;
import com.oyo.ump.member.service.enums.SendTypeEnum;
import com.oyo.ump.member.service.enums.TriggerChannelEnum;
import com.oyo.ump.member.service.enums.TriggerTypeEnum;
import com.oyo.ump.member.service.enums.UserTypeEnum;
import com.oyo.utp.pa.common.utils.DateUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalUnit;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * @author Dong
 * @Classname PushServiceImpl
 * @Description 事件推送业务接口实现类
 * @Date 2019-05-06
 */
@Service
@Slf4j
public class PushServiceImpl implements PushService {
    @Autowired
    PushMapper pushMapper;
    @Autowired
    PushExtraMapper pushExtraMapper;
    @Autowired
    PushRuleMapper pushRuleMapper;
    @Autowired
    NettyDelayQueue nettyDelayQueue;
    @Autowired
    MessagePushService messagePushService;
    @Autowired
    PushJobRecordMapper pushJobRecordMapper;
    @Autowired
    PushTemplateRelationMapper pushTemplateRelationMapper;
    @Autowired
    @Qualifier("fromGson")
    private Gson gson;
    @Autowired
    private PushMessageMapper pushMessageMapper;
    @Autowired
    private PushProcessService pushProcessService;
    @Autowired
    private CrowdService crowdService;
    @Autowired
    private PushPromotionService pushPromotionService;
    @Autowired
    private PushTemplateRelationService pushTemplateRelationService;
    @Autowired
    private DiscountService discountService;
    @Autowired
    private PushJobRecordService pushJobRecordService;
    @ApolloJsonValue("${PROMOTION_PUSH_INFO}")
    private Map<String, String> promotionConfigMap;
    @Value("${PUSH_TIME_INTERVAL}")
    private Long pushTimeInterval;

    @Transactional(rollbackFor = Exception.class)
    @Override
    public Long insertPush(PushBO pushBO) {
        PushEntity pushEntity = convert2Entity(pushBO);
        PushRuleEntity pushRuleEntity = new PushRuleEntity();
        pushRuleEntity.setRuleDetail(gson.toJson(pushBO.getTargetCrowdConfig()));
        pushRuleEntity.setEventType(pushBO.getTriggerType());
        pushRuleMapper.insert(pushRuleEntity);
        pushEntity.setRule(pushRuleEntity.getId());

        pushMapper.insertPush(pushEntity);
        pushBO.setId(pushEntity.getId());
        pushExtraMapper.insert(getPushExtraEntity(pushBO));
        return pushBO.getId();
    }

    @Override
    public PushBO selectById(Long id) {
        PushEntity pushEntity = pushMapper.selectById(id);
        PushExtraEntity pushExtraEntity = pushExtraMapper.selectByPushId(id);

        if (pushEntity != null) {
            PushBO pushBO = new PushBO();
            pushBO = convert2BO(pushEntity);
            if (pushExtraEntity != null) {
                pushBO = addExtra(pushBO, pushExtraEntity);
            }
            PushRuleEntity pushRuleEntity = pushRuleMapper.selectById(pushBO.getRule());
            PushBO.TargetCrowdConfig targetCrowdConfig = gson.fromJson(pushRuleEntity.getRuleDetail(), PushBO.TargetCrowdConfig.class);
            pushBO.setTargetCrowdConfig(targetCrowdConfig);
            return pushBO;
        } else {
            return null;
        }
    }

    @Override
    public PagedResponse<PushBO> selectByConditionPaged(PushBO pushBO, Integer pageNum, Integer pageSize) {
        PagedResponse<PushBO> pagedResponse = new PagedResponse<>();
        pagedResponse.setPageSize(pageSize);

        List<PushBO> pushBOList = Lists.newArrayList();
        PushEntity pushEntity = convert2Entity(pushBO);
        PageHelper.startPage(pageNum, pageSize);
        List<PushEntity> pushEntityList = pushMapper.selectByCondition(pushEntity);
        PageInfo<PushEntity> entityPageInfo = PageInfo.of(pushEntityList);
        if (CollectionUtils.isNotEmpty(pushEntityList)) {
            pushBOList = convert2BOList(pushEntityList);
        }
        pagedResponse.setTotalCount(entityPageInfo.getTotal());
        pagedResponse.setPageNum(pageNum);
        pagedResponse.setResult(pushBOList);
        return pagedResponse;
    }

    @Override
    public List<PushBO> selectByCondition(PushBO pushBO) {
        List<PushBO> pushBOList = Lists.newArrayList();
        PushEntity pushEntity = convert2Entity(pushBO);
        List<PushEntity> pushEntityList = pushMapper.selectByCondition(pushEntity);
        if (CollectionUtils.isNotEmpty(pushEntityList)) {
            pushBOList = convert2BOList(pushEntityList);
        }
        return pushBOList;
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public Boolean updatePushCrowdInfo(PushBO pushBO) {
        PushEntity pushEntity = convert2Entity(pushBO);
        PushBO oriPushBO = selectById(pushEntity.getId());
        PushRuleEntity pushRuleEntity = new PushRuleEntity();
        pushRuleEntity.setRuleDetail(gson.toJson(pushBO.getTargetCrowdConfig()));
        pushRuleEntity.setEventType(pushBO.getTriggerType());
        pushRuleMapper.update(pushRuleEntity, oriPushBO.getRule());

        pushMapper.updatePushCrowdInfo(pushEntity);
        // 如果附加信息有改动
        PushExtraEntity oriPushExtraEntity = pushExtraMapper.selectByPushId(pushBO.getId());
        if(!oriPushExtraEntity.equals(getPushExtraEntity(pushBO))){
            pushExtraMapper.deleteByPushId(pushBO.getId());
            pushExtraMapper.insert(getPushExtraEntity(pushBO));
        }
        return true;
    }

    @Override
    public Boolean updatePushSendRule(PushBO pushBO) {
        PushEntity pushEntity = convert2Entity(pushBO);
        pushMapper.updatePushSendRule(pushEntity);
        return true;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateSwitch(PushBO pushBO) {
        PushEntity pushEntity = convert2Entity(pushBO);
        PushEntity result= pushMapper.selectById(pushEntity.getId());
        //判断push 编辑状态
        if (Integer.valueOf(0).equals(result.getIsFinish())){
            throw new UmpException("该push没有编辑完成无法开启发送！");
        }
        //1.先查询是否存在record 记录，如果存在说明已经开启过了
        List<PushJobRecordEntity> records= pushJobRecordMapper.findByPushId(pushEntity.getId());
        boolean openFlag=false;
        if(CollectionUtils.isNotEmpty(records)){
            openFlag=true;
        }
        //判断当前开关状态和修改的开关状态
        if (Integer.valueOf(1).equals(pushBO.getPushStatus())){
            // 关--》开
            // 如果这个push已经存在发送记录，不让再开启
            if (openFlag){
                throw new UmpException("该push已经处于开启状态无法再次开启！");
            }
            PushBO.SendConfig sendConfig = gson.fromJson(result.getSendConfig(), PushBO.SendConfig.class);
            //判断是否为立即发送
            if(SendTypeEnum.WithOutDelay.getType().equals(result.getSendType())){
                //因为默认为立即发送，当前支持立即发送的目标类型为画像，b端酒店英雄小程序用户和apollo用户
                if(TriggerTypeEnum.PORTRAY_TYPE.getType().equals(result.getTriggerType())
                        ||TriggerTypeEnum.BUSINESS_MINI_WECHAT_USER_TYPE.getType().equals(result.getTriggerType())
                        ||TriggerTypeEnum.BUSINESS_APOLLO_USER_TYPE.getType().equals(result.getTriggerType())){
                    // 被修改对象是 画像并且立即推送
                    PushJobRecordEntity pushJobRecordEntity = new PushJobRecordEntity();
                    pushJobRecordEntity.setSendType(SendTypeEnum.WithOutDelay.getType());
                    pushJobRecordEntity.setMemberPushId(pushEntity.getId());
                    pushJobRecordEntity.setSendTime(new Date());
                    pushJobRecordEntity.setSendStatus(PushRecordStatusEnum.Ready.getStatus());
                    pushJobRecordMapper.insert(pushJobRecordEntity);
                    List<BasePushTimer> list = new ArrayList<>();
                    list.add(new WithOutDelayTimer(pushProcessService, pushJobRecordMapper, pushEntity.getId(),pushJobRecordEntity.getId(),10L));
                    nettyDelayQueue.addTask(list);
                }
                //判断是否为定时
            }else if (SendTypeEnum.Timing.getType().equals(result.getSendType())){
                Date now=new Date();
                if (now.after(sendConfig.getSendStartTime())){
                    throw new UmpException("定时时间必须大于当前时间！");
                }
                PushJobRecordEntity pushJobRecordEntity = new PushJobRecordEntity();
                pushJobRecordEntity.setSendType(SendTypeEnum.Timing.getType());
                pushJobRecordEntity.setMemberPushId(pushEntity.getId());
                pushJobRecordEntity.setSendTime(sendConfig.getSendStartTime());
                pushJobRecordEntity.setSendStatus(PushRecordStatusEnum.Init.getStatus());
                pushJobRecordMapper.insert(pushJobRecordEntity);
                //判断是否为周期
            }else if(SendTypeEnum.CyclePush.getType().equals(result.getSendType())){
                List<PushJobRecordEntity> pushJobRecordEntities=new ArrayList<>();
                Date end=sendConfig.getSendEndTime();
                Date now=new Date();
                if (end.before(now)){
                    throw new UmpException("结束时间必须大于当前时间");
                }
                long nowTime=now.getTime();
                long startTime=sendConfig.getSendStartTime().getTime();
                long endTime=sendConfig.getSendEndTime().getTime();
                while(startTime<endTime){
                    if (startTime<nowTime){
                        startTime+=sendConfig.getSendInterval().longValue() * 1000 * 60 * 60 * 24;
                        continue;
                    }else{
                        PushJobRecordEntity pushJobRecordEntity = new PushJobRecordEntity();
                        pushJobRecordEntity.setSendType(SendTypeEnum.CyclePush.getType());
                        pushJobRecordEntity.setMemberPushId(pushEntity.getId());
                        pushJobRecordEntity.setSendTime(new Date(startTime));
                        pushJobRecordEntity.setSendStatus(PushRecordStatusEnum.Init.getStatus());
                        pushJobRecordEntities.add(pushJobRecordEntity);
                        startTime+=sendConfig.getSendInterval().longValue() * 1000 * 60 * 60 * 24;
                    }
                }
                if (CollectionUtils.isNotEmpty(pushJobRecordEntities)) {
                    pushJobRecordMapper.insertList(pushJobRecordEntities);
                }
            }else{
                throw new UmpException("发送类型异常！");
            }
            pushMapper.updateSwitch(pushEntity);
        }else if (Integer.valueOf(1).equals(result.getPushStatus())&&Integer.valueOf(0).equals(pushBO.getPushStatus())){
            // 开--》关
            if (openFlag){
                if (records.size()==1){
                    //定时任务处理
                    if (!PushRecordStatusEnum.Init.getStatus().equals(records.get(0).getSendStatus())){
                        throw new UmpException("发送任务已经结束或者即将进行，无法关闭！");
                    }else{
                        pushJobRecordMapper.deleteNotSendByPushId(pushBO.getId());
                    }
                }else{
                    //周期任务删除没有发送的任务
                    pushJobRecordMapper.deleteNotSendByPushId(pushBO.getId());
                }
            }
            pushMapper.updateSwitch(pushEntity);
        }else{
            throw new UmpException("操作错误!");
        }

    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deletePush(Long id) {
        pushMapper.deletePush(id);
        pushExtraMapper.deleteByPushId(id);
        pushTemplateRelationMapper.deleteRelationByPushId(id);
    }

    @Override
    public List<Long> getIntervalUserIds(List<Long> userIds, Long pushId, Long interval, TemporalUnit temporalUnit) {
        if (CollectionUtils.isEmpty(userIds)) {
            return Lists.emptyList();
        }
        String dateStr = LocalDateTime.now().minus(interval, temporalUnit).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        List<Long> userIdList = pushMessageMapper.getUserIdsByInterval(userIds, pushId, dateStr);
        if (CollectionUtils.isNotEmpty(userIdList)) {
            return userIds.stream().filter(userId -> !userIdList.contains(userId)).collect(Collectors.toList());
        }
        return userIds;
    }

    @Override
    public void createPromotionPushByJob() {
        DiscBaseInfoDTO discBaseInfoDTO = new DiscBaseInfoDTO();
        discBaseInfoDTO.setId(Long.parseLong(promotionConfigMap.get("promotionId")));
        DiscBaseInfoDTO resDiscBaseInfoDTO = discountService.getBaseInfo(discBaseInfoDTO);
        if(null != resDiscBaseInfoDTO && null != resDiscBaseInfoDTO.getActVisibleTimeLimit()){
            List<TimePeriodDTO> sceneList = resDiscBaseInfoDTO.getActVisibleTimeLimit().getLimitTime();
            List<String> dateList = Lists.newArrayList();
            LocalDate dateToday = LocalDate.now();
            String today = DateUtils.format(dateToday,"yyyy-MM-dd");
            LocalDate dateTomorrow = LocalDate.now().plusDays(1);
            String tomorrow = DateUtils.format(dateTomorrow,"yyyy-MM-dd");
            dateList.add(today);
            dateList.add(tomorrow);
            if(CollectionUtils.isNotEmpty(sceneList)){
                for(String date:dateList){
                    sceneList.forEach(scene->{
                        if(null != scene.getBeginTime()){
                            String detailTime = scene.getBeginTime().toString();
                            PushPromotionBO pushPromotionBO = new PushPromotionBO();
                            pushPromotionBO.setPromotionType(promotionConfigMap.get("promotionType"));
                            pushPromotionBO.setPromotionId(promotionConfigMap.get("promotionId"));
                            pushPromotionBO.setStartTime(date+" "+detailTime);
                            // 1、检查（promotionType+promotionId+startTime）push是否已创建（先查缓存，再查库）
                            PushPromotionBO resPushPromotionBO =  pushPromotionService.selectByCondition(pushPromotionBO);
                            if(null == resPushPromotionBO){
                                createPromotionPush(pushPromotionBO);
                            }
                        }
                    });
                }
            }
        }
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public Long createPromotionPush(PushPromotionBO pushPromotionBO) {
        log.info("创建活动push流程开始");
        // 1 建人群
        Long crowdId = crowdService.insertCrowd(getCrowdBO(pushPromotionBO));
        // 2 创建push,关联人群
        Long pushId = insertPush(convert2PushBO(pushPromotionBO,crowdId));
        // 3 关联push和模板
        pushTemplateRelationService.insertRelation(convert2PushTemplateRelationBO(pushId));
        // 4 写活动push表，写缓存
        pushPromotionService.insert(convert2PushPromotionBO(pushPromotionBO,pushId,crowdId));

        Date startTime = DateUtils.formatByStringDate(pushPromotionBO.getStartTime(), "yyyy-MM-dd HH:mm:ss");
        if(startTime.after(new Date(System.currentTimeMillis())) && !startTime.after(new Date(System.currentTimeMillis()+pushTimeInterval*60*1000))){
            log.info("发送时间与当前时间的间隔小于定时任务发送间隔，直接挂时间轮");
            // 5 插入pushJobRecord
            Long jobId = pushJobRecordService.insert(getPushJobRecordBO(pushId,pushPromotionBO.getStartTime(),PushRecordStatusEnum.Ready.getStatus()));
            List<BasePushTimer> list = new ArrayList<>();
            list.add(new WithOutDelayTimer(pushProcessService, pushJobRecordMapper, pushId,jobId, (long) DateUtils.getDifferToMillisecond(new Date(),startTime)));
            nettyDelayQueue.addTask(list);
        }else {
            // 5 插入pushJobRecord
            Long jobId = pushJobRecordService.insert(getPushJobRecordBO(pushId,pushPromotionBO.getStartTime(),PushRecordStatusEnum.Init.getStatus()));
        }

        log.info("创建活动push流程结束，人群Id：{},pushId：{}",crowdId,pushId);
        return crowdId;
    }

    private PushBO convert2BO(PushEntity pushEntity) {
        PushBO pushBO = new PushBO();
        try {
            pushBO.setId(pushEntity.getId());
            pushBO.setPushName(pushEntity.getPushName());
            pushBO.setPushStatus(pushEntity.getPushStatus());
            pushBO.setDescription(pushEntity.getDescription());
            pushBO.setDepartmentId(pushEntity.getDepartmentId());
            pushBO.setTriggerType(pushEntity.getTriggerType());
            pushBO.setValidityFlag(pushEntity.getValidityFlag());
            pushBO.setValidityStart(pushEntity.getValidityStart());
            pushBO.setValidityEnd(pushEntity.getValidityEnd());
            pushBO.setRule(pushEntity.getRule());
            pushBO.setTriggerChannel(pushEntity.getTriggerChannel());
            pushBO.setPushTemplateId(pushEntity.getPushTemplateId());
            pushBO.setCreateTime(pushEntity.getCreateTime());
            pushBO.setCreateUserId(pushEntity.getCreateUserId());
            pushBO.setCreateUserName(pushEntity.getCreateUserName());
            pushBO.setUpdateUserId(pushEntity.getUpdateUserId());
            pushBO.setUpdateUserName(pushEntity.getUpdateUserName());
            pushBO.setIsDeleted(pushEntity.getIsDeleted());
            pushBO.setSendType(pushEntity.getSendType());
            PushBO.SendConfig sendConfig = gson.fromJson(pushEntity.getSendConfig(), PushBO.SendConfig.class);
            pushBO.setSendConfig(sendConfig);
            PushBO.SendFrequency sendFrequency = gson.fromJson(pushEntity.getSendFrequency(), PushBO.SendFrequency.class);
            pushBO.setSendFrequency(sendFrequency);
            PushBO.TriggerReward triggerReward = gson.fromJson(pushEntity.getTriggerReward(), PushBO.TriggerReward.class);
            pushBO.setTriggerReward(triggerReward);
            pushBO.setIsFinish(pushEntity.getIsFinish());
            pushBO.setUserType(pushEntity.getUserType());
        } catch (Exception e) {
            log.info("PushServiceImpl.convert2BO 出现异常：", e);
        }
        return pushBO;
    }

    private PushEntity convert2Entity(PushBO pushBO) {
        PushEntity pushEntity = new PushEntity();
        try {
            pushEntity.setId(pushBO.getId());
            pushEntity.setPushName(pushBO.getPushName());
            pushEntity.setPushStatus(pushBO.getPushStatus());
            pushEntity.setDescription(pushBO.getDescription());
            pushEntity.setDepartmentId(pushBO.getDepartmentId());
            pushEntity.setTriggerType(pushBO.getTriggerType());
            pushEntity.setValidityFlag(pushBO.getValidityFlag());
            pushEntity.setValidityStart(pushBO.getValidityStart());
            pushEntity.setValidityEnd(pushBO.getValidityEnd());
            pushEntity.setRule(pushBO.getRule());
            pushEntity.setTriggerChannel(pushBO.getTriggerChannel());
            pushEntity.setPushTemplateId(pushBO.getPushTemplateId());
            pushEntity.setCreateUserId(pushBO.getCreateUserId());
            pushEntity.setCreateUserName(pushBO.getCreateUserName());
            pushEntity.setUpdateUserId(pushBO.getUpdateUserId());
            pushEntity.setUpdateUserName(pushBO.getUpdateUserName());
            pushEntity.setIsDeleted(pushBO.getIsDeleted());
            pushEntity.setSendType(pushBO.getSendType());
            pushEntity.setSendConfig(gson.toJson(pushBO.getSendConfig()));
            pushEntity.setSendFrequency(gson.toJson(pushBO.getSendFrequency()));
            pushEntity.setTriggerReward(gson.toJson(pushBO.getTriggerReward()));
            pushEntity.setStartTime(pushBO.getStartTime());
            pushEntity.setEndTime(pushBO.getEndTime());
            pushEntity.setIsFinish(pushBO.getIsFinish());
            pushEntity.setUserType(pushBO.getUserType());
        } catch (Exception e) {
            log.info("PushServiceImpl.convert2Entity 出现异常：", e);
        }
        return pushEntity;
    }

    private List<PushBO> convert2BOList(List<PushEntity> pushEntityList) {
        List<PushBO> pushBOList = Lists.newArrayList();
        pushEntityList.forEach(pushEntity -> {
            PushBO pushBO = convert2BO(pushEntity);
            pushBOList.add(pushBO);
        });
        return pushBOList;
    }

    private PushExtraEntity getPushExtraEntity(PushBO pushBO) {
        PushExtraEntity pushExtraEntity = new PushExtraEntity();
        pushExtraEntity.setPushId(pushBO.getId());
        pushExtraEntity.setActUserType(pushBO.getActUserType());
        pushExtraEntity.setActType(pushBO.getActType());
        pushExtraEntity.setActTypeDetail(pushBO.getActTypeDetail());
        pushExtraEntity.setCouponCode(pushBO.getCouponCode());
        pushExtraEntity.setCouponAmount(pushBO.getCouponAmount());
        pushExtraEntity.setCouponType(pushBO.getCouponType());
        return pushExtraEntity;
    }

    private PushBO addExtra(PushBO pushBO, PushExtraEntity pushExtraEntity) {
        pushBO.setActUserType(pushExtraEntity.getActUserType());
        pushBO.setActType(pushExtraEntity.getActType());
        pushBO.setActTypeDetail(pushExtraEntity.getActTypeDetail());
        pushBO.setCouponCode(pushExtraEntity.getCouponCode());
        pushBO.setCouponAmount(pushExtraEntity.getCouponAmount());
        pushBO.setCouponType(pushExtraEntity.getCouponType());
        return pushBO;
    }


    private CrowdBO getCrowdBO(PushPromotionBO pushPromotionBO){
        List<Long> userIds = Lists.newArrayList(); // 创建一个空的人群列表
        CrowdBO crowdBO = new CrowdBO();
        crowdBO.setCrowdName(promotionConfigMap.get("promotionType")+promotionConfigMap.get("promotionId")+pushPromotionBO.getStartTime());
        crowdBO.setCrowdStatus("1"); // 人群状态 开
        crowdBO.setCrowdCreateType(MemberConstants.CREATE_BY_CUSTOM); // 创建方式 自定义
        crowdBO.setCrowdType(CrowdTypeEnum.USER_ID.getType());
        crowdBO.setUserType(UserTypeEnum.CLIENT_TYPE.getType());
        crowdBO.setUserIds(userIds);
        crowdBO.setIsDeleted(0);
        crowdBO.setCrowdNum(userIds.size());
        return crowdBO;
    }

    private PushBO convert2PushBO(PushPromotionBO pushPromotionBO, Long crodwId){
        PushBO pushBO = new PushBO();
        pushBO.setPushName(promotionConfigMap.get("promotionType")+promotionConfigMap.get("promotionId")+pushPromotionBO.getStartTime());
        pushBO.setPushStatus(1);
        pushBO.setTriggerType(TriggerTypeEnum.PORTRAY_TYPE.getType());
        PushBO.TargetCrowdConfig targetCrowdConfig = new PushBO.TargetCrowdConfig();
        targetCrowdConfig.setTargetCrowdType(4);// 上传人群
        Map<String,Object> customCrowdInfoMap = new HashMap<>();
        customCrowdInfoMap.put("upLoadCrowdId",crodwId);
        customCrowdInfoMap.put("memberNum",0);
        customCrowdInfoMap.put("uploadType",1);
        targetCrowdConfig.setCustomCrowdInfo(JSON.toJSONString(customCrowdInfoMap));
        pushBO.setTargetCrowdConfig(targetCrowdConfig);
        pushBO.setSendType(MemberConstants.SEND_REGULARLY); // 定时发送
        PushBO.SendConfig sendConfig = new PushBO.SendConfig();
        sendConfig.setSendStartTime(DateUtils.formatByStringDate(pushPromotionBO.getStartTime(), "yyyy-MM-dd HH:mm:ss"));
        pushBO.setSendConfig(sendConfig);
        pushBO.setValidityFlag(1);
        pushBO.setValidityStart(null);
        pushBO.setValidityEnd(null);
        pushBO.setTriggerChannel(TriggerChannelEnum.APPPUSH.getType());
        pushBO.setIsFinish(1); // 是否完成 1是
        pushBO.setUserType(UserTypeEnum.CLIENT_TYPE.getType());
        return pushBO;
    }

    private PushTemplateRelationBO convert2PushTemplateRelationBO(Long pushId){
        PushTemplateRelationBO pushTemplateRelationBO = new PushTemplateRelationBO();
        pushTemplateRelationBO.setPushId(pushId);
        pushTemplateRelationBO.setTemplateNum(promotionConfigMap.get("templateId"));
        pushTemplateRelationBO.setTriggerChannel(TriggerChannelEnum.APPPUSH.getType());
        pushTemplateRelationBO.setPercent(100);
        Map<String,String> map = new HashMap<>();
        map.put("isShowAlert","1");
        pushTemplateRelationBO.setExtraParameter(JSON.toJSONString(map));
        return pushTemplateRelationBO;
    }

    private PushPromotionBO convert2PushPromotionBO(PushPromotionBO pushPromotionBO,Long pushId,Long crowdId){
        PushPromotionBO resPushPromotionBO = new PushPromotionBO();
        resPushPromotionBO.setPromotionType(pushPromotionBO.getPromotionType());
        resPushPromotionBO.setPromotionId(pushPromotionBO.getPromotionId());
        resPushPromotionBO.setStartTime(pushPromotionBO.getStartTime());
        resPushPromotionBO.setPushId(pushId);
        resPushPromotionBO.setCrowdId(crowdId);
        return resPushPromotionBO;
    }

    private PushJobRecordBO getPushJobRecordBO(Long pushId, String startTime, Integer status){
        PushJobRecordBO pushJobRecordBO = new PushJobRecordBO();
        pushJobRecordBO.setMemberPushId(pushId);
        pushJobRecordBO.setSendType(SendTypeEnum.Timing.getType());
        pushJobRecordBO.setSendTime(DateUtils.formatByStringDate(startTime, "yyyy-MM-dd HH:mm:ss"));
        pushJobRecordBO.setSendStatus(status);
        return pushJobRecordBO;
    }


}
