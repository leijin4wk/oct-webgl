package com.oyo.ump.member.service.push;

import com.oyo.ump.member.dal.model.PushTemplateRelationEntity;
import com.oyo.ump.member.dal.model.TemplateUrlParameterEntity;
import com.oyo.ump.member.service.bo.PushBO;

import java.util.List;

public interface UserModel{
    List<PushTemplateRelationEntity> getTemplateRelationList();

    PushBO getPushBO();

}
