package com.oyo.ump.member.service.dto;

import com.oyo.ump.member.dal.dao.PushJobRecordMapper;
import com.oyo.ump.member.dal.dao.PushMapper;
import com.oyo.ump.member.dal.model.PushEntity;
import com.oyo.ump.member.dal.model.PushJobRecordEntity;
import com.oyo.ump.member.service.MessagePushService;
import com.oyo.ump.member.service.PushProcessService;
import com.oyo.ump.member.service.enums.PushRecordStatusEnum;
import io.netty.util.Timeout;
import lombok.extern.slf4j.Slf4j;

/**
 *
 * 处理无延时任务
* @author frank
* @date 2019-06-14 10:42
**/
@Slf4j
public class WithOutDelayTimer extends BasePushTimer{

    private PushJobRecordMapper pushJobRecordMapper;

    private PushProcessService pushProcessService;

    private Long pushId;

    private Long pushJobRecordId;

    public WithOutDelayTimer(PushProcessService pushProcessService, PushJobRecordMapper pushJobRecordMapper,Long pushId,Long pushJobRecordId,Long delayTime) {
        super(delayTime);
        this.pushProcessService = pushProcessService;
        this.pushJobRecordMapper = pushJobRecordMapper;
        this.pushId = pushId;
        this.pushJobRecordId=pushJobRecordId;
    }

    @Override
    public void run(Timeout timeout) {
        log.info("开始发送任务，{}", pushId);
        try {
            pushJobRecordMapper.updateStatus(pushJobRecordId, PushRecordStatusEnum.Sending.getStatus());
            log.info("发送id：{} record 任务！",pushJobRecordId);
            pushProcessService.sendMessageByPushId(pushId, pushJobRecordId);
            pushJobRecordMapper.updateStatus(pushJobRecordId, PushRecordStatusEnum.SendFinish.getStatus());
        } catch (Exception e) {
            e.printStackTrace();
            log.error("消息推送异常,{}", e.getMessage());
            pushJobRecordMapper.updateStatus(pushJobRecordId, PushRecordStatusEnum.Error.getStatus());
        }
    }
}
