package com.oyo.ump.member.service.enums;
/**
 * 触发推送的事件类型枚举
* @author frank
* @date 2019-05-13 16:04
**/
public enum TriggerTypeEnum {
    PORTRAY_TYPE(1,"画像"),
    EVENT_TYPE(2,"实时事件"),
    CUSTOM_EVENT_TYPE(3,"自定义事件"),
    BUSINESS_MINI_WECHAT_USER_TYPE(4,"B端微信小程序用户"),
    BUSINESS_APOLLO_USER_TYPE(5,"apllo用户");
    private final Integer type;
    private final String name;

    public Integer getType() {
        return type;
    }
    public String getName() {
        return name;
    }
    TriggerTypeEnum(Integer type, String name){
        this.name=name;
        this.type=type;
    }
}
