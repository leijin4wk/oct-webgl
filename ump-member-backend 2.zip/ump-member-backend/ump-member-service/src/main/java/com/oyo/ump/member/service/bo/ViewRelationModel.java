package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * 视图关系
* @author leijin
* @date 2019-11-18 11:23
**/
@Data
public class ViewRelationModel implements Serializable {

    private String viewName;

    private String column;

    private String whereColumn;

    private Boolean timeDependence;

    private Map<String, List<String>> relationConditionMap;
}
