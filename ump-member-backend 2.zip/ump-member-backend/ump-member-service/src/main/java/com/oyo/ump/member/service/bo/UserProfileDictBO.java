package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author Dong
 * @Classname UserProfileDictBO
 * @Description 用户标签BO
 * @Date 2019-06-04
 */
@Data
public class UserProfileDictBO implements Serializable {
    private Integer id;
    private String tagNo;
    private Integer tagStatus;
    private Integer firstClass;
    private Integer secondClass;
    private String tagName;
    private Integer tagType;
    private String tagTable;
    private String tagColumn;
    private String tagDesc;
    private String sampleSql;
    private String valueArea;
    /**
     * B端用户画像字典表用
     */
    private String filter;
}
