package com.oyo.ump.member.service.producer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import top.rdfa.framework.mq.ons.client.core.normalmq.MqMessagePublisher;
import top.rdfa.framework.mq.ons.client.core.normalmq.MqProducerFactoryBean;
import top.rdfa.framework.mq.ons.client.core.serializer.FastJsonSerlizer;

/**
 * @Author hubin
 * @Description:
 * @Date 2019-04-01
 */
@Configuration
public class MemberRegisterConfiguration {
    @Value("${mq.ump-member.group.id}")
    private String groupId;
    @Value("${mq.ump-member.topic}")
    private String topic;
    @Autowired
    private FastJsonSerlizer serializer;

    /**
     * 无序消息发送
     */
    @Bean
    public MqProducerFactoryBean mqProducerFactoryBean() {
        MqProducerFactoryBean mqProducerFactoryBean = new MqProducerFactoryBean();
        mqProducerFactoryBean.setId(groupId);
        mqProducerFactoryBean.setTopic(topic);
        return mqProducerFactoryBean;
    }

    @Bean
    public MqMessagePublisher mqMessagePublisher(MqProducerFactoryBean mqProducerFactoryBean) throws Exception {
        MqMessagePublisher mqMessagePublisher = new MqMessagePublisher();
        mqMessagePublisher.setProducer(mqProducerFactoryBean.getObject());
        mqMessagePublisher.setTopic(topic);
        mqMessagePublisher.setSerializer(serializer);
        return mqMessagePublisher;
    }
}
