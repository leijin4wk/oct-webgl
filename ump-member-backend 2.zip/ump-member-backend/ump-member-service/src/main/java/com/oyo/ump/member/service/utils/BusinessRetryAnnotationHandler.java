package com.oyo.ump.member.service.utils;

import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @Description:重试处理类
 * @Author: fang
 * @create: 2019-12-17
 **/
@Slf4j
@Aspect
@Component
public class BusinessRetryAnnotationHandler {
    @Autowired
    private RetryUtilService retryService;

    @Pointcut("@annotation(com.oyo.ump.member.service.utils.BusinessRetry)")
    public void pointCut(){
    }
    @Around("pointCut()")
    public Object retryProcess(ProceedingJoinPoint point)throws Throwable{
        String method = "";
        Object result =null;
        BusinessRetry annotation=null;
        try {
            MethodSignature methodSignature=(MethodSignature) point.getSignature();
            annotation= methodSignature.getMethod().getAnnotation(BusinessRetry.class);
            method = methodSignature.getName();
            result = point.proceed();
            if(!retryService.isProcessSuccess(result,annotation.field(),annotation.result())){
                retryService.insertDb(point, annotation.retry(), result,annotation.result(),annotation.field(),annotation.type(),annotation.retryMethod());
            }
            return result;
        }catch (Exception e) {
            log.error("retry error,method:{},param:{}",method, JSON.toJSONString(point.getArgs()),e);
            retryService.insertDb(point, annotation.retry(), result,annotation.result(),annotation.field(),annotation.type(),annotation.retryMethod());
        }
        return null;
    }


}
