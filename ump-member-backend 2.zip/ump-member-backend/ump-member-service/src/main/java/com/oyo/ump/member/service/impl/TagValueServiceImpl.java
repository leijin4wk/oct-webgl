package com.oyo.ump.member.service.impl;

import com.oyo.ump.member.service.TagValueService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * @author Dong
 * @Classname TagValueServiceImpl
 * @Description
 * @Date 2019-06-10
 */
@Service
@Slf4j
public class TagValueServiceImpl implements TagValueService {
    @Autowired
    @Qualifier("adbJdbcTemplate")
    JdbcTemplate jdbcTemplate;

    @Override
    public List<Map<String,Object>> selectByValueArea(String valueArea) {
        List<Map<String, Object>> resultList = jdbcTemplate.queryForList(valueArea);
        return resultList;
    }

    @Override
    public long countNum(String strSql) {
        strSql = "select count(member_id) as num  FROM `ump_data_member_dim_dw` as member_dim where " + strSql;
        List<Map<String, Object>> resList = jdbcTemplate.queryForList(strSql);
        if(CollectionUtils.isNotEmpty(resList)){
            return Long.parseLong(resList.get(0).get("num").toString());
        }
        return 0;
    }

    @Override
    public List<Long> getUsers(String strSql) {
        strSql = "select member_id FROM `ump_data_member_dim_dw` as member_dim where " + strSql;
        List<Map<String, Object>> resList = jdbcTemplate.queryForList(strSql);
        if(CollectionUtils.isNotEmpty(resList)){
            List<Long> res = Lists.newArrayList();
            resList.forEach(user ->{
                res.add(Long.parseLong(user.get("member_id").toString()));
            });
            return res;
        }

        return null;
    }

    @Override
    public List<Map<String, Object>> selectBySql(String SqlStr, Integer start, Integer pageSize) {
        String sql=SqlStr+" limit "+start+","+pageSize;
        List<Map<String, Object>> resultList = jdbcTemplate.queryForList(sql);
        return resultList;
    }
    @Override
    public List<Map<String, Object>> selectAllBySql(String SqlStr) {
        List<Map<String, Object>> resultList = jdbcTemplate.queryForList(SqlStr);
        return resultList;
    }

}
