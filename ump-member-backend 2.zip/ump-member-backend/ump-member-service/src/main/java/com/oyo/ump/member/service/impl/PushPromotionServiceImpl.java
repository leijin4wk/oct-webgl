package com.oyo.ump.member.service.impl;

import com.alibaba.fastjson.JSON;
import com.oyo.ump.member.common.beanutils.MapperWrapper;
import com.oyo.ump.member.common.constants.RedisConstants;
import com.oyo.ump.member.dal.dao.PushPromotionMapper;
import com.oyo.ump.member.dal.model.PushPromotionEntity;
import com.oyo.ump.member.service.PushPromotionService;
import com.oyo.ump.member.service.RedisService;
import com.oyo.ump.member.service.bo.PushPromotionBO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author Dong
 * @Classname PushPromotionServiceImpl
 * @Description 活动push接口实现类
 * @Date 2019-05-06
 */
@Service
@Slf4j
public class PushPromotionServiceImpl implements PushPromotionService {
    @Autowired
    private RedisService redisService;
    @Autowired
    PushPromotionMapper pushPromotionMapper;

    @Override
    public void insert(PushPromotionBO pushPromotionBO) {
        PushPromotionEntity entity = MapperWrapper.instance().map(pushPromotionBO,PushPromotionEntity.class);
        pushPromotionMapper.insert(entity);
        try {
            redisService.setNXValue(getKey(pushPromotionBO), JSON.toJSONString(pushPromotionBO), RedisConstants.PUSH_PROMOTION_EXPIRE);
        }catch (Exception e){
            log.error("写入RPC Push信息缓存异常",e);
        }
    }

    @Override
    public PushPromotionBO selectByCondition(PushPromotionBO reqPushPromotionBO) {
        String key = getKey(reqPushPromotionBO);
        Object pushInfoStr=null;
        try {
            pushInfoStr = redisService.getValue(key);
        }catch (Exception e){
            log.error("获取RPC Push信息缓存异常",e);
        }
        if (pushInfoStr != null) {
            return JSON.parseObject(pushInfoStr.toString(),PushPromotionBO.class);
        }
        PushPromotionEntity reqEntity = MapperWrapper.instance().map(reqPushPromotionBO,PushPromotionEntity.class);
        PushPromotionEntity pushPromotionEntity = pushPromotionMapper.selectByCondition(reqEntity);
        if(null != pushPromotionEntity){
            PushPromotionBO pushPromotionBO = MapperWrapper.instance().map(pushPromotionEntity,PushPromotionBO.class);
            try {
                redisService.setNXValue(key, JSON.toJSONString(pushPromotionBO), RedisConstants.PUSH_PROMOTION_EXPIRE);
            }catch (Exception e){
                log.error("写入RPC Push信息缓存异常",e);
            }
            return pushPromotionBO;
        }
        return null;
    }

    private String getKey(PushPromotionBO pushPromotionBO){
        return RedisConstants.PUSH_PROMOTION+pushPromotionBO.getPromotionType()+"_"+pushPromotionBO.getPromotionId()+"_"+pushPromotionBO.getStartTime();
    }
}
