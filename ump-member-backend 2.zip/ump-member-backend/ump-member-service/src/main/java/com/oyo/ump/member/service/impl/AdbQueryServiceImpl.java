package com.oyo.ump.member.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.oyo.ump.member.dal.dao.CrowdCustomMapper;
import com.oyo.ump.member.dal.dao.CrowdMapper;
import com.oyo.ump.member.dal.adb.AdbUserMapper;
import com.oyo.ump.member.dal.model.*;
import com.oyo.ump.member.service.AdbQueryService;
import com.oyo.ump.member.service.MessagePushService;
import com.oyo.ump.member.service.dto.UserDetailPageResponseDTO;
import com.oyo.ump.member.service.dto.UserEventPageResponseDTO;
import com.oyo.ump.member.service.dto.UserTradePageResponseDTO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @Description: abd 查询实现类
 * @Author: fang
 * @create: 2019-09-04
 **/
@Slf4j
@Component
public class AdbQueryServiceImpl implements AdbQueryService {
    @Autowired
    @Qualifier("adbJdbcTemplate")
    JdbcTemplate jdbcTemplate;
    @Autowired
    private AdbUserMapper adbUserMapper;
    @Autowired
    private MessagePushService messagePushService;
    @Autowired
    private CrowdCustomMapper crowdCustomMapper;
    @Autowired
    private CrowdMapper crowdMapper;
    private Map<Integer,String> TRADE_STATUS= Maps.newHashMap();
    private Map<Integer,String> TRADE_FREQUENCY=Maps.newHashMap();
    private Map<Integer,String> PRICE_FREQUENCY=Maps.newHashMap();
    private static final SimpleDateFormat END_FORMATE = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");



    {
        TRADE_STATUS.put(0,"待入住");
        TRADE_STATUS.put(1,"在住");
        TRADE_STATUS.put(2,"离店");
        TRADE_STATUS.put(3,"取消");
        TRADE_STATUS.put(4,"noShow");

        TRADE_FREQUENCY.put(3,"无交易");
        TRADE_FREQUENCY.put(2,"1次交易");
        TRADE_FREQUENCY.put(1,"多余1次交易");
        TRADE_FREQUENCY.put(-1,"无交易");

        PRICE_FREQUENCY.put(0,"较敏感");
        PRICE_FREQUENCY.put(1,"中单敏感");
        PRICE_FREQUENCY.put(2,"不甚敏感");
        PRICE_FREQUENCY.put(-1,"不甚敏感");
    }



    @Override
    public Map<String, Object> queryUserBasicInfo(Long userId) {
        String sql ="SELECT member_id,register_time,channel,phone,phone_os,wechant_user_flag,alipay_user_flag,is_push_flag,is_active_in_latest_month,is_delete_app,is_oyo_wechat_fans,frequency,susceptibility,auvp,suvp,base_city FROM ump_data_member_dim_dw where member_id= "+userId;
        List<Map<String, Object>> result =jdbcTemplate.queryForList(sql);
        if(CollectionUtils.isNotEmpty(result)){
            Map<String, Object> map =  result.get(0);
            String frequency = TRADE_FREQUENCY.get(map.get("frequency"));
            map.put("frequency",frequency);
            String susceptibility = PRICE_FREQUENCY.get(map.get("susceptibility"));
            map.put("susceptibility",susceptibility);
            return map;
        }
        return null;
    }

    @Override
    public UserEventPageResponseDTO queryUserEvent(Long userId, String startTime, String endTime, Integer pageNum, Integer pageSize) {
        UserEventPageResponseDTO pageResponseDTO =new UserEventPageResponseDTO();
        pageResponseDTO.setPageNum(pageNum);
        pageResponseDTO.setPageSize(pageSize);
        pageResponseDTO.setMemberIdentityBOList(Lists.newArrayList());
        String distinctId = adbUserMapper.getDistinctIdByUserId(userId);
       if(StringUtils.isNotEmpty(distinctId)){
           PageHelper.startPage(pageNum, pageSize);
           List<UserEventEntity> userEventEntityList = adbUserMapper.queryUserEvent(distinctId,startTime,endTime);
           if(CollectionUtils.isNotEmpty(userEventEntityList)){
               List<UserEventPageResponseDTO.UserEventInfo> userEventInfos=userEventEntityList.stream().map(entity->{
                   UserEventPageResponseDTO.UserEventInfo userEventInfo =new UserEventPageResponseDTO.UserEventInfo();
                   userEventInfo.setAppVersion(entity.getAppVersion());
                   userEventInfo.setCheckinDate(entity.getCheckinDate());
                   userEventInfo.setCheckoutDate(entity.getCheckoutDate());
                   userEventInfo.setCity(entity.getCity());
                   userEventInfo.setDt(entity.getDt());
                   userEventInfo.setEvent(entity.getEvent());
                   userEventInfo.setHotelId(entity.getHotelId());
                   userEventInfo.setHotelName(entity.getHotelName());
                   userEventInfo.setIp(entity.getIp());
                   userEventInfo.setKeyword(entity.getKeyword());
                   userEventInfo.setManufacturer(entity.getManufacturer());
                   userEventInfo.setMaxPrice(entity.getMaxPrice());
                   userEventInfo.setMinPrice(entity.getMinPrice());
                   userEventInfo.setNetworkType(entity.getNetworkType());
                   userEventInfo.setNightCount(entity.getNightCount());
                   userEventInfo.setOs(entity.getOs());
                   userEventInfo.setPlatform(entity.getPlatform());
                   userEventInfo.setRoomType(entity.getRoomType());
                   userEventInfo.setSearchType(entity.getSearchType());
                   userEventInfo.setTime(entity.getTime());
                   return userEventInfo;
               }).collect(Collectors.toList());
               PageInfo pageinfo = PageInfo.of(userEventEntityList);
               pageResponseDTO.setTotal(pageinfo.getTotal());
               pageResponseDTO.setMemberIdentityBOList(userEventInfos);
           }

       }
      return pageResponseDTO;
    }

    @Override
    public UserTradePageResponseDTO queryTradeEvent(Long userId, String startTime, String endTime, Integer pageNum, Integer pageSize) {
        UserTradePageResponseDTO pageResponseDTO = new UserTradePageResponseDTO();
        pageResponseDTO.setPageNum(pageNum);
        pageResponseDTO.setPageSize(pageSize);
        pageResponseDTO.setMemberIdentityBOList(Lists.newArrayList());
        PageHelper.startPage(pageNum, pageSize);
        List<UserTradeEntity> entityList =adbUserMapper.getUserTradeInfo(userId,startTime,endTime);
        if(CollectionUtils.isNotEmpty(entityList)){
            List<UserTradePageResponseDTO.UserTradeInfo> userTradeInfos =entityList.stream().map(entity->{
                UserTradePageResponseDTO.UserTradeInfo userTradeInfo =new UserTradePageResponseDTO.UserTradeInfo();
                userTradeInfo.setActualAmount(entity.getActualAmount());
                userTradeInfo.setAmount(entity.getAmount());
                userTradeInfo.setBookingSn(entity.getBookingSn());
                userTradeInfo.setCheckinTime(entity.getCheckinTime()==null?"":END_FORMATE.format(entity.getCheckinTime()) );
                userTradeInfo.setCheckoutTime(entity.getCheckoutTime()==null?"":END_FORMATE.format(entity.getCheckoutTime()));
                userTradeInfo.setDiscountMoney(entity.getDiscountMoney());
                userTradeInfo.setHotelId(entity.getHotelId());
                userTradeInfo.setHotelName(entity.getHotelName());
                userTradeInfo.setId(entity.getId());
                userTradeInfo.setOrderSn(entity.getOrderSn());
                userTradeInfo.setOrderTime(entity.getOrderTime()==null?"":END_FORMATE.format(entity.getOrderTime()));
                userTradeInfo.setPayTime(entity.getPayTime()==null?"":END_FORMATE.format(entity.getPayTime()));
                userTradeInfo.setStatus(TRADE_STATUS.get(entity.getStatus()));
                userTradeInfo.setTerminal(entity.getTerminal());
                return userTradeInfo;
            }).collect(Collectors.toList());
            PageInfo pageinfo = PageInfo.of(entityList);
            pageResponseDTO.setTotal(pageinfo.getTotal());
            pageResponseDTO.setMemberIdentityBOList(userTradeInfos);

        }
        return pageResponseDTO;
    }

    @Override
    public UserDetailPageResponseDTO queryUserList(Long crowdId, Integer pageSize, Integer pageNum) {
        UserDetailPageResponseDTO userDetailPageResponseDTO =new UserDetailPageResponseDTO();
        CrowdEntity crowdEntity =crowdMapper.selectById(crowdId);
        if(crowdEntity==null||StringUtils.isEmpty(crowdEntity.getCrowdCreateType())){
            return userDetailPageResponseDTO;
        }
        Long count =messagePushService.getUsersQtyByCrowdIds(Lists.newArrayList(crowdId),null);
        userDetailPageResponseDTO.setTotal(count);
        userDetailPageResponseDTO.setPageNum(pageNum);
        userDetailPageResponseDTO.setPageSize(pageSize);
        crowdEntity.getCrowdCreateType();
        List<UserDetailPageResponseDTO.UserInfo> userInfoList =Lists.newArrayList();
        if("2".equals(crowdEntity.getCrowdCreateType())){
            PageHelper.startPage(pageNum, pageSize);
            List<CrowdCustomEntity>  crowdCustomEntityList = crowdCustomMapper.selectByCrowdId(crowdId);
            if(CollectionUtils.isNotEmpty(crowdCustomEntityList)){
                List<Long> userIdList =crowdCustomEntityList.stream().map(CrowdCustomEntity::getUserId).collect(Collectors.toList());
                if(CollectionUtils.isNotEmpty(userIdList)){
                    List<UserDetailEntity>  entityList = adbUserMapper.getUserDetailList(userIdList);
                    if(CollectionUtils.isNotEmpty(entityList)){
                            userInfoList =entityList.stream().map(entity->{
                            UserDetailPageResponseDTO.UserInfo userInfo=new UserDetailPageResponseDTO.UserInfo();
                            userInfo.setMemberId(entity.getMemberId());
                            userInfo.setFirstAppTime(entity.getFirstAppTime());
                            userInfo.setLastAppTime(entity.getLastAppTime());
                            userInfo.setRegisterTime(entity.getRegisterTime());
                            userInfo.setDateCountAdvance(entity.getDateCountAdvance());
                            return userInfo;
                        }).collect(Collectors.toList());
                    }
                }
            }
        }else {
           String condition =  messagePushService.getWhereStatement(crowdEntity.getCrowdTag());
           int start =(pageNum-1)*pageSize;
           String strSql = "select member_id,register_time,first_app_time,last_app_time FROM ump_data_member_dim_dw as member_dim  where " + condition +" order by register_time desc "+ "limit "+start+","+pageSize;
            List<Map<String, Object>> mapList =  jdbcTemplate.queryForList(strSql);
            if(CollectionUtils.isNotEmpty(mapList)){
                    userInfoList =mapList.stream().map(map->{
                    UserDetailPageResponseDTO.UserInfo userInfo=new UserDetailPageResponseDTO.UserInfo();
                    userInfo.setMemberId(map.get("member_id")==null?null:Long.valueOf(map.get("member_id").toString()));
                    userInfo.setFirstAppTime(map.get("register_time")==null?null:map.get("register_time").toString());
                    userInfo.setLastAppTime(map.get("first_app_time")==null?null:map.get("first_app_time").toString());
                    userInfo.setRegisterTime(map.get("last_app_time")==null?null:map.get("last_app_time").toString());
                    return userInfo;
                }).collect(Collectors.toList());
            }
        }
        userDetailPageResponseDTO.setMemberInfoList(userInfoList);
        return userDetailPageResponseDTO;
    }
}
