package com.oyo.ump.member.service.component;

import com.oyo.ump.member.service.dto.BasePushTimer;
import io.netty.util.HashedWheelTimer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.TimeUnit;

@Component
@Slf4j
public class NettyDelayQueue {

    /**
     *  创建一个netty时间轮数据结构
    * @author frank
    * @date 2019-06-13 15:17
    **/
    private HashedWheelTimer timer = new HashedWheelTimer(24,
            TimeUnit.MILLISECONDS,
            12);


    /**
     * 添加任务
    * @author frank
    * @date 2019-06-13 15:26
    **/
    public void addTask(List<BasePushTimer> tasks){
        tasks.stream().forEach(item->{
            log.info("发送绑定时间轮!");
            timer.newTimeout(item,item.getDelayTime(), TimeUnit.MILLISECONDS);
        });
    }
}
