package com.oyo.ump.member.service.impl;

import com.oyo.ump.member.common.beanutils.MapperWrapper;
import com.oyo.ump.member.dal.dao.EventConfigDictMapper;
import com.oyo.ump.member.dal.model.EventConfigDictEntity;
import com.oyo.ump.member.service.EventConfigDictService;
import com.oyo.ump.member.service.bo.EventConfigDictBO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Dong
 * @Classname EventConfigDictServiceImpl
 * @Description 事件配置字典相关接口
 * @Date 2019-08-27
 */
@Service
@Slf4j
public class EventConfigDictServiceImpl implements EventConfigDictService {
    @Autowired
    EventConfigDictMapper eventConfigDictMapper;


    @Override
    public List<EventConfigDictBO> getAllEventName() {
        List<EventConfigDictBO> eventConfigDictBOList = Lists.newArrayList();
        List<EventConfigDictEntity> eventConfigDictEntities = eventConfigDictMapper.getAllEventName();
        if(CollectionUtils.isNotEmpty(eventConfigDictEntities)){
            eventConfigDictEntities.forEach(eventConfigDictEntity -> {
                EventConfigDictBO eventConfigDictBO =  MapperWrapper.instance().map(eventConfigDictEntity, EventConfigDictBO.class);
                eventConfigDictBOList.add(eventConfigDictBO);
            });
            return eventConfigDictBOList;
        }
        return null;
    }

    @Override
    public List<EventConfigDictBO> getPropertyName(String eventName) {
        List<EventConfigDictBO> eventConfigDictBOList = Lists.newArrayList();
        List<EventConfigDictEntity> eventConfigDictEntities = eventConfigDictMapper.getPropertyName(eventName);
        if(CollectionUtils.isNotEmpty(eventConfigDictEntities)){
            eventConfigDictEntities.forEach(eventConfigDictEntity -> {
                EventConfigDictBO eventConfigDictBO =  MapperWrapper.instance().map(eventConfigDictEntity, EventConfigDictBO.class);
                eventConfigDictBOList.add(eventConfigDictBO);
            });
            return eventConfigDictBOList;
        }
        return null;
    }

    @Override
    public EventConfigDictBO selectByTagColumn(String eventName,String tagColumn) {
        EventConfigDictEntity eventConfigDictEntity = eventConfigDictMapper.selectByTagColumn(eventName,tagColumn);
        if(null != eventConfigDictEntity){
            EventConfigDictBO eventConfigDictBO = MapperWrapper.instance().map(eventConfigDictEntity, EventConfigDictBO.class);
            return eventConfigDictBO;
        }
        return null;
    }
}
