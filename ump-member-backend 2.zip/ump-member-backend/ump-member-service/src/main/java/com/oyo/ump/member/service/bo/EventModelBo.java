package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class EventModelBo implements Serializable {

    private Integer timeUnit;
    private Integer delay;
    private List<EvenTriggerConditionBo> triggerCondition;
    private boolean eventOrder;
}
