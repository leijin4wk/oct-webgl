package com.oyo.ump.member.service.enums;

/**
 * 发送push消息的事件类型
* @author frank
* @date 2019-05-13 10:16
**/
public enum EventKeyEnum {
    BOOK_ONLINE("book_online","在线付预订"),
    UPDATE_ONLINE("update_online","在线付修改"),
    CANCEL_ONLINE("cancel_online","在线付取消"),

    ;

    private final String type;
    private final String name;

    EventKeyEnum(String type, String name) {
        this.type = type;
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public String getName() {
        return name;
    }
}
