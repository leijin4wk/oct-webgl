package com.oyo.ump.member.service;

import com.oyo.ump.member.service.dto.*;

/**
 * @Description: 查询用户交易数据
 * @Author: fang
 * @create: 2019-03-29
 **/
public interface TradeService {

    MemberOrderResponseDTO queryUserTradeList(MemberOrderRequestDTO requestDTO);

    MemberPointResponseDTO queryPointsList(MemberPointRequestDTO requestDTO);

    RefundResponseDTO refund(RefundRequestDTO requestDTO);
}
