package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;

/**
 * @author Dong
 * @Classname PushTemplateRelationBO
 * @Description
 * @Date 2019-08-31
 */
@Data
public class PushTemplateRelationBO implements Serializable {
    private Long id;
    private Long pushId;
    // 1-短信；2-推送；3-微信
    private Integer triggerChannel;
    private String templateNum;
    private String templateContentParameter;
    private String templateUrlParameter;
    private Long templateUrlId;
    private String templateUtmParameter;
    private Integer percent;
    private String extraParameter;
    private String contentParams;
    private String urlParams;

}
