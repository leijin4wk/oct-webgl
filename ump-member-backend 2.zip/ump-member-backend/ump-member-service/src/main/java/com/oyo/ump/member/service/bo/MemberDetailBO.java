package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;

/**
 * @Description: 会员详情BO
 * @Author: fang
 * @create: 2019-03-25
 **/
@Data
public class MemberDetailBO implements Serializable {
    //基础信息
    private Long userId;
    private String certificateType;//证件类型
    private String certificateNo;
    private String address;
    private String userName;
    private String phone;
    private Integer bonus;
    private String bonusLimitTime;
    private String icon;
    private String validTime;
    private String grade;
    private String tenant;
}
