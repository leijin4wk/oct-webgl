package com.oyo.ump.member.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author zhangjianjun
 * @date 2018年7月10日
 */
public interface RedisService {

    public Object getValue(String key);

    public void pushValue(String key,Object value);

    public Object popValue(String key);

    public void setValue(String key, Object value);

    public void setValue(String key, Object value, Long expiredTime);

    public void removeKey(String key);

    public Long incr(String key, long liveTime);

    public Long incrBy(String key, long num, long liveTime);

    public Long decr(String key);

    public Boolean hasKey(String key);

    public Boolean setNXValue(String key, Object value);

    public Boolean setNXValue(String key, Object value, long liveTime);

    public List<Object> mGet(List<String> keys);

    public Long lPushValue(String key,Object value);

    public List<Object> getAllListValue(String key);

    public Map<Object, Object> getMapEntries(String key);

    public void putMapEntry(String key,Object hey,Object hv );

    public Object getMapValue(String key, Object hashKey);

    public Long deleteMapEntry(String key,Object hashKey);

    public Set<Object> getAllSetValues(String key);

    public Long addSetValue(String key,Object value);

    public void batchAddSet(String key, Object... values);

    public void batchRemoveSet(String key, Object... values);

    public Boolean isMemberOfSet(String key, Object value);

    public Long getSizeOfSet(String key);

}
