package com.oyo.ump.member.service.impl;

import com.alibaba.fastjson.JSON;
import com.oyo.ump.member.common.constants.MemberConstants;
import com.oyo.ump.member.dal.dao.MemberGradeDetailMapper;
import com.oyo.ump.member.dal.dao.MemberGradeMapper;
import com.oyo.ump.member.dal.model.MemberGradeDetailEntity;
import com.oyo.ump.member.dal.model.MemberGradeEntity;
import com.oyo.ump.member.integration.service.user.UserInfoRemoteService;
import com.oyo.ump.member.service.ChangeGradeService;
import com.oyo.ump.member.service.GradeService;
import com.oyo.ump.member.service.MemberInfoService;
import com.oyo.ump.member.service.bo.ChangeGradeBO;
import com.oyo.ump.member.service.bo.GradeInfoBO;
import com.oyo.ump.member.service.producer.memberGrade.MemberGradeMessage;
import com.oyo.ump.member.service.producer.memberGrade.MemberGradePublisher;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;


/**
 * @author Dong
 * @Classname ChangeGradeServiceImpl
 * @Description 变更等级接口实现类
 * @Date 2019-04-02
 */
@Service
@Slf4j
public class ChangeGradeServiceImpl implements ChangeGradeService {
    @Autowired
    private MemberGradeMapper memberGradeMapper;
    @Autowired
    private MemberGradeDetailMapper memberGradeDetailMapper;
    @Autowired
    private GradeService gradeService;
    @Autowired
    private MemberInfoService memberInfoService;
    @Autowired
    private MemberGradePublisher memberGradePublisher;
    @Autowired
    private UserInfoRemoteService userInfoRemoteService;

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void changeGrade(ChangeGradeBO changeGradeBO) {
        log.info("等级变更请求信息changeGradeBO：{}", JSON.toJSONString(changeGradeBO));
        MemberGradeDetailEntity memberGradeDetailEntity = new MemberGradeDetailEntity();
        MemberGradeEntity memberGradeEntity = new MemberGradeEntity();
        if (changeGradeBO.getChangeType() == null) {
            changeGradeBO.setChangeType(changeGradeBO.getUpdateRuleType());
        }
        convert2Entity(changeGradeBO, memberGradeEntity);
        convert2DetailEntity(changeGradeBO, memberGradeDetailEntity);
        memberGradeMapper.changeGrade(memberGradeEntity);
        memberGradeDetailMapper.addMemberGradeDetail(memberGradeDetailEntity);

        // 此处需要删除会员信息缓存
        memberInfoService.clearMemberInfoCache(changeGradeBO.getUserId(),changeGradeBO.getTenant());
        sendMq(changeGradeBO);
    }

    public void convert2Entity(ChangeGradeBO changeGradeBO, MemberGradeEntity memberGradeEntity){
        memberGradeEntity.setUserId(changeGradeBO.getUserId());
        memberGradeEntity.setGradeId(changeGradeBO.getGradeId());
        memberGradeEntity.setPreviousGradeId(changeGradeBO.getPreviousGradeId());
        memberGradeEntity.setUpdateRuleType(changeGradeBO.getUpdateRuleType());
        memberGradeEntity.setRoomNights(changeGradeBO.getRoomNights());
        memberGradeEntity.setNoShow(changeGradeBO.getNoShow());
        memberGradeEntity.setTenant(changeGradeBO.getTenant());
        memberGradeEntity.setGradeUpdateTime(new Date());
        // 有效期设置
        if(MemberConstants.OYO_JP_TENANT.equals(changeGradeBO.getTenant())){
            memberGradeEntity.setValidTime(changeGradeBO.getValidTime());
        }else {
            GradeInfoBO gradeInfoBO = gradeService.getGradeByGradeId(changeGradeBO.getGradeId());
            if (gradeInfoBO != null && gradeInfoBO.getValidPeriod() > 0) {
                memberGradeEntity.setValidTime(DateUtils.addDays(new Date(), gradeInfoBO.getValidPeriod()));
            } else {
                memberGradeEntity.setValidTime(null);
            }
        }

    }

    public void convert2DetailEntity(ChangeGradeBO changeGradeBO, MemberGradeDetailEntity memberGradeDetailEntity){
        memberGradeDetailEntity.setUserId(changeGradeBO.getUserId());
        memberGradeDetailEntity.setCurrentGradeId(changeGradeBO.getGradeId());
        memberGradeDetailEntity.setPreviousGradeId(changeGradeBO.getPreviousGradeId());
        memberGradeDetailEntity.setChangeType(changeGradeBO.getChangeType());
        memberGradeDetailEntity.setDescription(changeGradeBO.getDescription());
        memberGradeDetailEntity.setTenant(changeGradeBO.getTenant());
    }
    private void sendMq(ChangeGradeBO changeGradeBO) {
        try {
            String source = changeGradeBO.getTenant();
            if (MemberConstants.OYO_TENANT.equals(source)&&userInfoRemoteService.isFliggyMember(changeGradeBO.getUserId())) {
                source = MemberConstants.FEIZHU_PLATEFORM;
            }
            memberGradePublisher.execute(MemberGradeMessage.builder().preGradeId(changeGradeBO.getPreviousGradeId()).curGradeId(changeGradeBO.getGradeId()).source(source).userId(changeGradeBO.getUserId()).build());
        }catch (Exception e){
            log.error("发送等级变化消息异常",e);
        }
    }
}
