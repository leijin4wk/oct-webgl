package com.oyo.ump.member.service.push;

import com.oyo.ump.member.service.bo.KeyModelBo;
import lombok.Data;
import org.apache.commons.collections.CollectionUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
public class SqlModel {

    private Integer triggerChannel;

    private Long pushId;

    private String templateNum;

    private Long pushRelationTempalteId;
    //sql 语句
    private String sqlStr;

    private String countSqlStr;

    private String testSqlStr;

    //内容字
    private List<KeyModelBo> contentKeysList=new ArrayList<>();

    private List<KeyModelBo> urlKeysList=new ArrayList<>();


    private String baseUrl;

    private String deeplinkUrl;

    private Map<String,String> extraMap=new HashMap<>();

    public Map<String, String> buildUtmMap() {
        Map<String, String> map = new HashMap<>();
        if (CollectionUtils.isNotEmpty(urlKeysList)) {
            for (KeyModelBo keyModelBo : urlKeysList) {
                switch (keyModelBo.getName()) {
                    case "utmContent":
                        if (org.apache.commons.lang.StringUtils.isNotEmpty(keyModelBo.getValue())) {
                            map.put("utmContent", keyModelBo.getValue());
                        } else {
                            map.put("utmContent", "");
                        }
                        break;
                    case "utmSource":
                        if (org.apache.commons.lang.StringUtils.isNotEmpty(keyModelBo.getValue())) {
                            map.put("utmSource", keyModelBo.getValue());
                        } else {
                            map.put("utmSource", "");
                        }
                        break;
                    case "utmMedium":
                        if (org.apache.commons.lang.StringUtils.isNotEmpty(keyModelBo.getValue())) {
                            map.put("utmMedium", keyModelBo.getValue());
                        } else {
                            map.put("utmMedium", "");
                        }
                        break;
                    case "utmCampaign":
                        if (org.apache.commons.lang.StringUtils.isNotEmpty(keyModelBo.getValue())) {
                            map.put("utmCampaign", keyModelBo.getValue());
                        } else {
                            map.put("utmCampaign", "");
                        }
                        break;
                    default:
                        break;
                }
            }
        }
        return map;
    }
}
