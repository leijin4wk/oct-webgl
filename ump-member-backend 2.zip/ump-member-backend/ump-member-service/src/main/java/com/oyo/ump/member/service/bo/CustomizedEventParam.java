package com.oyo.ump.member.service.bo;


import lombok.Data;

import java.util.*;

/**
 * 自定义事件组装对象
* @author leijin
* @date 2019-11-18 10:25
**/
@Data
public class CustomizedEventParam {



    private Map<Integer,Boolean> whereCondition=new HashMap<>();

    private Map<Integer,String> joinCondition=new HashMap<>();


}
