package com.oyo.ump.member.service.enums;

public enum SendTypeEnum {
    WithOutDelay(1,"立即发送"),
    Timing(2,"定时发送"),
    CyclePush(3,"周期发送");

    private final Integer type;
    private final String name;

    public Integer getType() {
        return type;
    }
    public String getName() {
        return name;
    }
    SendTypeEnum(Integer type, String name){
        this.name=name;
        this.type=type;
    }
}
