package com.oyo.ump.member.service.enums;

import com.oyo.openapi.client.mp.miniapp.enums.MiniappEnum;
import org.assertj.core.util.Lists;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Dong
 * @Description
 * @Date 2019-09-07
 */
public enum WeChatMiniAPPEnum {
    WECHAT_HOTEL_HERO("wx03ef434e8f6195b4","酒店英雄小程序","WECHAT_HOTEL_HERO",2,MiniappEnum.HMI, "/pages/messageDetails/index");

    private String appId;
    private String mp;
    private String appNme;
    private Integer userType;
    private MiniappEnum miniappEnum;
    private String interMsgDetailPageRootPath;

    public String getAppId(){return  appId;}

    public String getMp(){return  mp;}

    public String getAppNme(){return appNme;}

    public Integer getUserType(){return userType;}

    public MiniappEnum getMiniappEnum(){return miniappEnum;}

    public String getInterMsgDetailPageRootPath(){return interMsgDetailPageRootPath;}



    WeChatMiniAPPEnum(String appId, String mp, String appNme, Integer userType,MiniappEnum miniappEnum,String interMsgDetailPageRootPath){
        this.appId = appId;
        this.mp=mp;
        this.appNme = appNme;
        this.userType = userType;
        this.miniappEnum = miniappEnum;
        this.interMsgDetailPageRootPath = interMsgDetailPageRootPath;
    }

    private static Map<String, WeChatMiniAPPEnum> enumMap = new HashMap<>();
    static {
        WeChatMiniAPPEnum[] values = values();
        for(WeChatMiniAPPEnum e : values){
            enumMap.put(e.getAppId(), e);
        }
    }

    /**
     * 获取枚举元素
     * @param appId
     * @return
     */
    public static WeChatMiniAPPEnum getByAppId(String appId){
        return enumMap.get(appId);
    }

    /**
     * 根据类型获取枚举元素
     * @param userType（1-c端，2-b端）
     * @return
     */
    public static List<WeChatMiniAPPEnum> getByUserType(Integer userType){
        Map<Integer, List<WeChatMiniAPPEnum>> enumMap = new HashMap<>();
        List<WeChatMiniAPPEnum> cList = Lists.newArrayList();
        List<WeChatMiniAPPEnum> bList = Lists.newArrayList();
        WeChatMiniAPPEnum[] values = values();
        for(WeChatMiniAPPEnum e : values){
            if(1==e.getUserType()){
                cList.add(e);
            }else if(2==e.getUserType()){
                bList.add(e);
            }
        }
        enumMap.put(1,cList);
        enumMap.put(2,bList);
        return enumMap.get(userType);
    }
}
