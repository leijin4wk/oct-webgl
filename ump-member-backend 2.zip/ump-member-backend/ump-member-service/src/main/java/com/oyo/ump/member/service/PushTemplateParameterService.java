package com.oyo.ump.member.service;

import com.oyo.ump.member.service.bo.TemplateParameterBO;
import com.oyo.ump.member.service.bo.TemplateUrlParameterBO;

import java.util.List;
import java.util.Map;

/**
 * @author Dong
 * @Classname PushTemplateParameterService
 * @Description 推送模板页面的参数方法
 * @Date 2019-09-04
 */
public interface PushTemplateParameterService {
    /**
     * 根据参数类型查询模板长链信息
     * @param urlType
     * @return java.util.List<com.oyo.ump.member.service.bo.TemplateUrlParameterBO>
     */
    List<TemplateUrlParameterBO> getAllUrlParameter(Integer urlType);

    /**
     * 根据miniAppId查询模板长链信息
     * @param miniAppId
     * @return java.util.List<com.oyo.ump.member.service.bo.TemplateUrlParameterBO>
     */
    List<TemplateUrlParameterBO> getAllUrlParameterByMiniAppId(String miniAppId);

    /**
     * 根据参数类型、参数来源 查询参数信息
     * @param parameterName
     * @return java.util.List<com.oyo.ump.member.service.bo.TemplateParameterBO>
     */
    List<TemplateParameterBO> getAllParameterByType(String parameterName, Integer source);
}
