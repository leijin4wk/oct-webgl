package com.oyo.ump.member.service;

import com.github.pagehelper.PageInfo;
import com.oyo.common.response.PagedResponse;
import com.oyo.ump.member.dal.model.MemberGradeConfigEntity;
import com.oyo.ump.member.service.bo.MemberIdentityBO;
import com.oyo.ump.member.service.bo.MemberIdentityPageBO;

import java.util.List;
import java.util.Map;

/**
 * @author Dong
 * @Classname MemberIdentityListService
 * @Description 会员身份信息列表业务接口
 * @Date 2019-03-20
 */
public interface MemberIdentityListService {

    PagedResponse<MemberIdentityBO> getMemberIdentityList(Map<String, Object> params);

    Map<String, String> getAllGrade(String tenant);
}
