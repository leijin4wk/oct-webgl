package com.oyo.ump.member.service.push;

import com.oyo.ump.member.dal.model.PushMessageEntity;

import java.util.List;
import java.util.Map;

/**
 * 所有pushModel接口
* @author leijin
* @date 2020-03-01 09:33
**/
public interface PushBuilder {


    /**
     * 获取sql
     * ids  测试用
    **/
    List<SqlModel> buildSql(UserModel userModel,List<String> ids);





    boolean sendPushMessage(SqlModel pushSqlModel,Integer page, Long jobId);




    PushMessageEntity sendTestPushMessageEntity(SqlModel pushSqlModel);
}
