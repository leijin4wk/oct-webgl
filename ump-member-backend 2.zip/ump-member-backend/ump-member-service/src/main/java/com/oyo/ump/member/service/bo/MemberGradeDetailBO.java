package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author Dong
 * @Classname MemberGradeDetailBO
 * @Description 会员等级变更记录
 * @Date 2019-03-30
 */
@Data
public class MemberGradeDetailBO implements Serializable {
    private Long id;
    private Long userId;
    private Integer previousGradeId;
    private Integer currentGradeId;
    private Integer updateRuleType;
    private Date createTime;
}
