package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @Description: 会员信息BO
 * @Author: fang
 * @create: 2019-03-22
 **/
@Data
public class MemberInfoBO implements Serializable {
    	private Long userId;
    	private Integer gradeId;
    	private String grade;
    	private String gradeName;
    	private Integer upgradeRoomNights;
    	private Integer nextGradeId;
    	private Integer roomNight;
    	private Integer noshow;
		private Date updateTime;
		private Date validTime;
		private Date gradeUpdateTime;
		private String tenant;
        private Integer validPeriod;
	/**
	 * 是否虚构,是否兜底增加的数据
	 */
	private boolean fictitious;



}
