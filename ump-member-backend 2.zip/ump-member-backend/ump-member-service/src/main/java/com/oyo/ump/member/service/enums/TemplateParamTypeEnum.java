package com.oyo.ump.member.service.enums;

public enum  TemplateParamTypeEnum {

    TEXT(1,"自定义文本"),
    SYS_KEY(2,"系统参数");

    private final Integer type;

    private final String name;

    public Integer getType() {
        return type;
    }

    public String getName() {
        return name;
    }

    TemplateParamTypeEnum(Integer type, String name){
        this.name=name;
        this.type=type;
    }
}
