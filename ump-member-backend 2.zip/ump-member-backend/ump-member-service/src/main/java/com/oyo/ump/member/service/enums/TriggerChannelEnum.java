package com.oyo.ump.member.service.enums;


/**
 * 推送渠道
* @author frank
* @date 2019-05-15 11:55
**/
public enum  TriggerChannelEnum {

    SMS(1,"短信"),
    APPPUSH(2,"APP推送"),
    WECHAT(3,"微信公众号"),
    WECHATAPP(4,"微信小程序"),
    ALIAPP(5,"支付宝小程序"),
    INTERNALMSG(6,"站内信推送");

    private final Integer type;
    private final String name;

    public Integer getType() {
        return type;
    }
    public String getName() {
        return name;
    }

    TriggerChannelEnum(Integer type, String name) {
        this.type = type;
        this.name = name;
    }
    public static TriggerChannelEnum getByType(Integer type){
        for (TriggerChannelEnum triggerChannelEnum:TriggerChannelEnum.values()) {
            if (triggerChannelEnum.type.equals(type)){
                return triggerChannelEnum;
            }
        }
        return null;
    }
}
