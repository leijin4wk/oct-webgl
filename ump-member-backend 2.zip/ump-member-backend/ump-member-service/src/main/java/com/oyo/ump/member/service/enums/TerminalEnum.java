package com.oyo.ump.member.service.enums;
/**
* 用户终端类型
 * @author frank
* @date 2019-05-13 19:06
**/
public enum  TerminalEnum {


    PMS("PMS"),
    CRS("CRS"),
    IOS("IOS"),
    ANDROID("ANDROID"),
    WECHAT_APP("WECHAT_APP"),
    ALIMINI_APP("ALIMINI_APP"),
    WECHAT_APP_QRCODE("WECHAT_APP_QRCODE"),
    OTA_PLUGIN("OTA_PLUGIN"),
    OTA("OTA"),
    MM("MM"),
    MIGRATION("MIGRATION"),
    ALIMINIAPP("ALIMINIAPP");
    ;

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    TerminalEnum(String name) {
        this.name = name;
    }
}
