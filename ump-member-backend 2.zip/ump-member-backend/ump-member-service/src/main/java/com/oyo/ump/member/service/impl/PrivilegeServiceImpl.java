package com.oyo.ump.member.service.impl;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.oyo.ump.member.common.constants.MemberConstants;
import com.oyo.ump.member.dal.dao.MemberPrivilegeMapper;
import com.oyo.ump.member.dal.model.MemberPrivilegeEntity;
import com.oyo.ump.member.service.PrivilegeService;
import com.oyo.ump.member.service.RedisService;
import com.oyo.ump.member.service.bo.GradePrivilegeBO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.Map;

/**
 * @Description: 等级权益实现类
 * @Author: fang
 * @create: 2019-03-22
 **/
@Service
@Slf4j
public class PrivilegeServiceImpl implements PrivilegeService {
    private List<GradePrivilegeBO> PRIVILEGE_CACHE_LIST = Lists.newArrayList();
    private Map<Integer,GradePrivilegeBO> PRIVILEGE_CACHE_MAP = Maps.newHashMap();

    @Autowired
    private MemberPrivilegeMapper memberPrivilegeMapper;

    @Override
    public List<GradePrivilegeBO> getGradePrivilegeList() {
        if(CollectionUtils.isEmpty(PRIVILEGE_CACHE_LIST)){
            refreshPrivilegeFromDB();
        }
        return PRIVILEGE_CACHE_LIST;
    }

    @Override
    public GradePrivilegeBO getGradePrivilegeByGradeId(Integer gradeId) {
        if(MapUtils.isEmpty(PRIVILEGE_CACHE_MAP)){
            refreshPrivilegeFromDB();
        }
        return PRIVILEGE_CACHE_MAP.get(gradeId);
    }
    /**
     *inti时从数据库中读取并塞入list
     * @return
     */
    @PostConstruct
    private void refreshPrivilegeFromDB() {
        List<MemberPrivilegeEntity> memberPrivilegeEntityList = memberPrivilegeMapper.queryAll();
        convert2Dto(memberPrivilegeEntityList);


    }

    /**
     * entitylist 转化为dto
     * @param memberPrivilegeEntityList
     */
    private void convert2Dto(List<MemberPrivilegeEntity> memberPrivilegeEntityList) {
        PRIVILEGE_CACHE_LIST=Lists.newArrayList();
        PRIVILEGE_CACHE_MAP=Maps.newHashMap();
        if (CollectionUtils.isNotEmpty(memberPrivilegeEntityList)) {
            memberPrivilegeEntityList.forEach(entity -> {
                GradePrivilegeBO gradePrivilegeBO = convert2MemberPrivilegeInfo(entity);
                PRIVILEGE_CACHE_LIST.add(gradePrivilegeBO);
                PRIVILEGE_CACHE_MAP.put(gradePrivilegeBO.getGradeId(),gradePrivilegeBO);
            });
        }
    }

    /**
     * 转化entity为info
     *
     * @param entity
     * @return
     */
    private GradePrivilegeBO convert2MemberPrivilegeInfo(MemberPrivilegeEntity entity) {
        GradePrivilegeBO gradePrivilegeBO = new GradePrivilegeBO();
        try {
            gradePrivilegeBO.setGradeId(entity.getId());
            gradePrivilegeBO.setGrade(entity.getGrade());
            GradePrivilegeBO.SpecialDiscount specialDiscount = JSON.parseObject(entity.getSpecialDiscount(), GradePrivilegeBO.SpecialDiscount.class);
            if(specialDiscount==null){
                specialDiscount =new GradePrivilegeBO.SpecialDiscount();
                specialDiscount.setHold(false);
            }
            gradePrivilegeBO.setSpecialDiscount(specialDiscount);
            GradePrivilegeBO.OptimalPriceGurantee optimalPriceGurantee = JSON.parseObject(entity.getOptimalPriceGurantee(), GradePrivilegeBO.OptimalPriceGurantee.class);
            if(optimalPriceGurantee==null){
                optimalPriceGurantee=new GradePrivilegeBO.OptimalPriceGurantee();
                optimalPriceGurantee.setHold(false);
            }
            gradePrivilegeBO.setOptimalPriceGurantee(optimalPriceGurantee);
            GradePrivilegeBO.LateCheckout lateCheckout =JSON.parseObject(entity.getLateCheckout(), GradePrivilegeBO.LateCheckout.class);
            if(lateCheckout==null){
                lateCheckout=new GradePrivilegeBO.LateCheckout();
                lateCheckout.setHold(false);
            }
            gradePrivilegeBO.setLateCheckout(lateCheckout);
            GradePrivilegeBO.ReservationGuarantee reservationGuarantee =JSON.parseObject(entity.getReservationGuarantee(), GradePrivilegeBO.ReservationGuarantee.class);
            if(reservationGuarantee==null){
                reservationGuarantee=new GradePrivilegeBO.ReservationGuarantee();
                reservationGuarantee.setHold(false);
            }
            gradePrivilegeBO.setReservationGuarantee(reservationGuarantee);
            GradePrivilegeBO.FreeWifi freeWifi = JSON.parseObject(entity.getFreeWifi(), GradePrivilegeBO.FreeWifi.class);
            if(freeWifi==null){
                freeWifi=new GradePrivilegeBO.FreeWifi();
                freeWifi.setHold(false);
            }
            gradePrivilegeBO.setFreeWifi(freeWifi);
            GradePrivilegeBO.BonusConfig bonusConfig = JSON.parseObject(entity.getBonusConfig(), GradePrivilegeBO.BonusConfig.class);
            if(bonusConfig==null){
                bonusConfig=new GradePrivilegeBO.BonusConfig();
                bonusConfig.setHold(false);
            }
            gradePrivilegeBO.setBonusConfig(bonusConfig);
        } catch (Exception e) {
            log.error("method:convert2GradePrivilegeBO error", e);
        }
        return gradePrivilegeBO;
    }
}
