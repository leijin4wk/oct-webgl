package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author Dong
 * @Classname UpgradePackageBO
 * @Description 升级包信息BO
 * @Date 2019-03-25
 */
@Data
public class UpgradePackageBO implements Serializable {
    private Integer id;
    /**
     * 升级包code(商品中心维护)
     */
    private String skuCode;
    private String packageName;
    /**
     * 升级前的等级id
     */
    private Integer gradeId;
    private Integer gradeOrd;
    /**
     * 升级后的等级名
     */
    private String gradeName;
    /**
     * 升级后的等级id
     */
    private Integer upgradeId;
    private Integer upgradeOrd;
    /**
     * 升级后的等级名
     */
    private String upgradeName;
    /**
     * 前台分佣
     */
    private BigDecimal frontCommission;
    /**
     * 业主分佣
     */
    private BigDecimal ownerCommission;
    /**
     * oyo分佣
     */
    private BigDecimal oyoCommission;
    /**
     * 升级包状态，1 已启用；0 未启用
     */
    private Boolean status;
    /**
     * 升级包价格
     */
    private BigDecimal price;

    private Long stock;
    private String channel;
}
