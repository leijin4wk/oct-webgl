package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;
@Data
public class SelectCrowdBo implements Serializable {

    private Date countTime;

    private String crowdName;

    private Long crowdQty;
}
