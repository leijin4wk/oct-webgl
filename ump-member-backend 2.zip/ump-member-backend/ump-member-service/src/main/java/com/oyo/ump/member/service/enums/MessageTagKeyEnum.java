package com.oyo.ump.member.service.enums;
/**
 *队列处理tag枚举类
 * @author frank
* @date 2019-05-09 17:40
**/
public enum MessageTagKeyEnum {

    BOOKING_NEW("booking_new", "booking_new_key"),
    BOOKING_CANCEL("booking_cancel", "booking_cancel_key"),
    BOOKING_UPDATE("booking_update","booking_update_key")
    ;


    private String tagName;

    private String tagKey;

    public String getTagName() {
        return tagName;
    }

    public void setTagName(String tagName) {
        this.tagName = tagName;
    }

    public String getTagKey() {
        return tagKey;
    }

    public void setTagKey(String tagKey) {
        this.tagKey = tagKey;
    }

    MessageTagKeyEnum(String tagName, String tagKey) {
        this.tagName = tagName;
        this.tagKey = tagKey;
    }

}
