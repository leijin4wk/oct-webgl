package com.oyo.ump.member.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.google.gson.*;
import com.oyo.ump.member.common.constants.MemberConstants;
import com.oyo.ump.member.common.constants.ViewNameConstants;
import com.oyo.ump.member.common.enums.CrowdTypeEnum;
import com.oyo.ump.member.common.exception.UmpException;
import com.oyo.ump.member.dal.dao.*;
import com.oyo.ump.member.dal.model.*;
import com.oyo.ump.member.integration.service.push.QrCodeService;
import com.oyo.ump.member.service.*;
import com.oyo.ump.member.service.bo.*;
import com.oyo.ump.member.service.component.NettyDelayQueue;

import com.oyo.ump.member.service.dto.BuildPushMessageRunner;

import com.oyo.ump.member.service.enums.*;
import com.oyo.ump.member.service.producer.memberPush.MemberPushMessage;
import com.oyo.ump.member.service.producer.memberPush.MemberPushPublisher;
import com.oyo.ump.member.service.push.SqlModel;
import com.oyo.ump.member.service.push.builder.NoRegisterClientPersonasUserBuilder;
import com.oyo.ump.member.service.push.model.NoRegisterClientPersonasUser;
import freemarker.cache.StringTemplateLoader;
import freemarker.template.Configuration;
import freemarker.template.Template;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

import javax.validation.Valid;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.stream.Collectors;

@Service
@Slf4j
public class PushProcessServiceImpl implements PushProcessService {
    @Autowired
    private TemplateParameterService templateParameterService;
    @Autowired
    private PushService pushService;
    @Autowired
    private MessagePushService messagePushService;
    @Autowired
    private PushTemplateRelationMapper pushTemplateRelationMapper;
    @Autowired
    private CustomizedEventService customizedEventService;
    @Autowired
    private CrowdMapper crowdMapper;
    @Autowired
    private CrowdCustomMapper crowdCustomMapper;
    @Autowired
    private TagValueService tagValueService;
    @Autowired
    private QrCodeService qrCodeService;
    @Autowired
    private PushMessageMapper pushMessageMapper;
    @Autowired
    @Qualifier("pushThreadPoolTaskExecutor")
    ThreadPoolTaskExecutor pushThreadPoolExecutor;
    @Autowired
    MemberPushPublisher memberPushPublisher;
    @Value("${CROWD_PUSH_PERCENT}")
    private String crowdPushPercent;
    @Autowired
    NettyDelayQueue nettyDelayQueue;
    @Autowired
    PushJobRecordMapper pushJobRecordMapper;
    @Autowired
    RedisService redisService;


    @Value("${EVENT_VIEW_DEFINE}")
    private String eventViewDefine;

    @Value("${BOOKING_VIEW_DEFINE}")
    private String bookingViewDefine;

    @Value("${USERS_VIEW_DEFINE}")
    private String userViewDefine;
    @Value("${BUSINESS_APOLLO_USER_FILTER}")
    private String  businessApolloUserFilter;
    @Value("${BUSINESS_MINI_WECHAT_USER_FILTER}")
    private String  businessMiniWechatAppFilter;
    @Autowired
    private CrowdService crowdService;
    @Autowired
    private TemplateUrlParameterMapper templateUrlParameterMapper;
    @Override
    public void sendMessageByPushId(Long pushId, Long jobId) {
        PushBO pushBO = pushService.selectById(pushId);
        //此处添加未注册用户逻辑判断
        if (MemberConstants.USER_TYPE_FOR_C.equals(pushBO.getUserType())&&
                TriggerChannelEnum.APPPUSH.getType().equals(pushBO.getTriggerChannel())
                && TargetCrowdTypeEnum.NoRegisterCrowd.getType().equals(pushBO.getTargetCrowdConfig().getTargetCrowdType())){
            List<PushTemplateRelationEntity> list = pushTemplateRelationMapper.getRelationsByPushId(pushBO.getId());
            NoRegisterClientPersonasUser noRegisterClientPersonasUser=new NoRegisterClientPersonasUser(pushBO,list);
            NoRegisterClientPersonasUserBuilder noRegisterClientPersonasUserBuilder=
                    new NoRegisterClientPersonasUserBuilder(templateUrlParameterMapper,tagValueService,
                            pushThreadPoolExecutor,memberPushPublisher,qrCodeService);

            List<SqlModel> sqlModels=noRegisterClientPersonasUserBuilder.buildSql(noRegisterClientPersonasUser,new ArrayList<>());

            if (CollectionUtils.isNotEmpty(list)) {
                sqlModels.stream().forEach(item -> {
                    int i = 0;
                    boolean flag = false;
                    do {
                        flag = noRegisterClientPersonasUserBuilder.sendPushMessage(item, i, jobId);
                        i++;
                    } while (flag);
                });
            }
            log.info("无注册用户pushId:{},jobId:{}发送结束!",pushId,jobId);
        }else {
            List<PushInfoAndParams> list = getPushInfoAndParams(pushBO, null);
            if (CollectionUtils.isNotEmpty(list)) {
                list.stream().forEach(item -> {
                    int i = 0;
                    boolean flag = false;
                    do {
                        flag = sendPushMessage(item, i, jobId);
                        i++;
                    } while (flag);
                });
            }
            log.info("发送结束!");
        }
    }

    @Override
    public void sendMqPushMessageByPushId(Long pushId, Map<String, String> mqKeysParams, Long memberId) {
        PushBO pushBO = pushService.selectById(pushId);
        List<PushInfoAndParams> list = getPushInfoAndParams(pushBO, null);
        Map<String, Object> map = new HashMap<>();
        map.put("memberId", memberId);
        PushInfoAndParams pushInfoAndParams = list.get(0);
        PushMessageEntity pushMessageEntity = buildPushMessageEntity(pushInfoAndParams, map, mqKeysParams, null, 2);
        if (pushMessageEntity == null) {
            log.info("mq消息不完整！");
            return;
        }
        log.info("Build pushMessageEntity:{}", pushMessageEntity.toString());
        List<PushMessageEntity> pushMessages = new ArrayList<>();
        pushMessages.add(pushMessageEntity);
        MemberPushMessage memberPushMessage = new MemberPushMessage();
        memberPushMessage.setPushMessageEntities(pushMessages);
        memberPushPublisher.execute(memberPushMessage);
    }

    @Override
    public void testPushMessage(Long pushId, String templateNum, String id) {
        log.info("pushId:{},\n templateNum:{},\n phone:{}", pushId, templateNum, id);
        List<PushMessageEntity> pushMessages = new ArrayList<>();
        PushBO pushBO = pushService.selectById(pushId);
        List<String> ids = new ArrayList<>();
        ids.add(id);
        MemberPushMessage memberPushMessage = new MemberPushMessage();
        if (MemberConstants.USER_TYPE_FOR_C.equals(pushBO.getUserType())&&
                TriggerChannelEnum.APPPUSH.getType().equals(pushBO.getTriggerChannel())
                && TargetCrowdTypeEnum.NoRegisterCrowd.getType().equals(pushBO.getTargetCrowdConfig().getTargetCrowdType())) {
            List<PushTemplateRelationEntity> list = pushTemplateRelationMapper.getRelationsByPushId(pushBO.getId());
            NoRegisterClientPersonasUser noRegisterClientPersonasUser = new NoRegisterClientPersonasUser(pushBO, list);
            NoRegisterClientPersonasUserBuilder noRegisterClientPersonasUserBuilder =
                    new NoRegisterClientPersonasUserBuilder(templateUrlParameterMapper, tagValueService,
                            pushThreadPoolExecutor, memberPushPublisher, qrCodeService);
            List<SqlModel> sqlModels = noRegisterClientPersonasUserBuilder.buildSql(noRegisterClientPersonasUser, ids);
            SqlModel testTemplate=null;
            for (SqlModel item:sqlModels) {
                if (item.getTemplateNum().equals(templateNum)){
                    testTemplate=item;
                }
            }
            memberPushMessage.setTestFlag(false);
            pushMessages.add(noRegisterClientPersonasUserBuilder.sendTestPushMessageEntity(testTemplate));
            log.info("无注册用户测试发送:templateNum：{}，pushId：{}", templateNum,pushId);
        }else {
            List<PushInfoAndParams> list = getPushInfoAndParams(pushBO, ids);
            for (PushInfoAndParams item : list) {
                log.info("PushInfoAndParams:{}", item.toString());
                if (item.getTemplateNum().equals(templateNum)) {
                    PushMessageEntity messageEntity = buildClientTestMessage(item, new HashMap<>());
                    if (messageEntity == null) {
                        log.info("用户电话号码 adb不存在!{}", id);
                        throw new UmpException("用户电话号码 adb不存在!");
                    } else {
                        pushMessages.add(messageEntity);
                    }
                }
            }
            memberPushMessage.setTestFlag(true);
        }
        log.info("PushMessageEntity:{}", pushMessages);
        if (CollectionUtils.isNotEmpty(pushMessages)) {
            memberPushMessage.setPushMessageEntities(pushMessages);
            memberPushPublisher.execute(memberPushMessage);
        }else{
            log.info("用户信息adb不存在!{}", id);
        }
    }

    @Override
    public void testBusinessMessage(Long pushId, String userId) {
        PushBO pushBO = pushService.selectById(pushId);
        List<String> ids = new ArrayList<>();
        ids.add(userId);
        List<Long> userIdList=crowdService.getUserIdsByEmployeeNos(ids);
        if (CollectionUtils.isEmpty(userIdList)){
            throw new UmpException("员工工号不存在!");
        }
        List<PushInfoAndParams> list = getPushInfoAndParams(pushBO, userIdList.stream().map(item->item+"").collect(Collectors.toList()));
        if (CollectionUtils.isNotEmpty(list)){
            List<PushMessageEntity> pushMessages = new ArrayList<>();
            PushInfoAndParams item=list.get(0);
            PushMessageEntity messageEntity = buildBusinessTestMessage(item, userIdList.get(0));
            if (messageEntity == null) {
                log.info("用户不存在!{}", userId);
                throw new UmpException("用户不存在!");
            }
            pushMessages.add(messageEntity);
            log.info("PushMessageEntity:{}", pushMessages);
            MemberPushMessage memberPushMessage = new MemberPushMessage();
            memberPushMessage.setPushMessageEntities(pushMessages);
            memberPushMessage.setTestFlag(true);
            memberPushPublisher.execute(memberPushMessage);
        }else{
            throw new UmpException("可发送模板不存在!");
        }

    }


    /**
     * 组装sql片段
     *
     * @author leijin
     * @date 2019-09-09 20:34
     **/
    private List<PushInfoAndParams> getPushInfoAndParams(PushBO pushBO, List<String> ids) {
        List<PushInfoAndParams> result = new ArrayList<>();
        List<PushTemplateRelationEntity> list = pushTemplateRelationMapper.getRelationsByPushId(pushBO.getId());
        long temp = 0;

        //初始化模板参数
        for (PushTemplateRelationEntity item : list) {
            PushInfoAndParams pushInfoAndParamsItem = new PushInfoAndParams(item, pushBO.getTriggerType(), temp, temp + item.getPercent());
            //设置用户类型
            pushInfoAndParamsItem.setUserType(pushBO.getUserType());
            //自定义事件添加发送时间间隔
            if (pushBO.getTriggerType().equals(TriggerTypeEnum.CUSTOM_EVENT_TYPE.getType())) {
                pushInfoAndParamsItem.setIntervalTime(pushBO.getSendConfig().getSendInterval());
            }
            //解析URL参数
            if (StringUtils.isNotBlank(item.getUrlParams())) {
                List<PushTemplateParamBo> urlParamList = JSON.parseArray(item.getUrlParams(), PushTemplateParamBo.class);
                pushInfoAndParamsItem.getColumnAndMqParamBo().setUrlParamList(urlParamList);
            }
            //解析内容参数
            if (StringUtils.isNotBlank(item.getContentParams())) {
                List<PushTemplateParamBo> contentParamList = JSON.parseArray(item.getContentParams(), PushTemplateParamBo.class);
                pushInfoAndParamsItem.getColumnAndMqParamBo().setContentParamList(contentParamList);
            }
            //添加额外参数
            if (StringUtils.isNotBlank(item.getExtraParameter())){
                JsonObject extraParams = new JsonParser().parse(item.getExtraParameter()).getAsJsonObject();
                //处理额外参数
                for (Map.Entry<String, JsonElement> entry : extraParams.entrySet()) {
                    pushInfoAndParamsItem.getColumnAndMqParamBo().getExtraMap().put(entry.getKey(), entry.getValue().getAsString());
                }
            }
            pushInfoAndParamsItem.getColumnAndMqParamBo().setTemplateLongLink(item.getTemplateUrlId());
            pushInfoAndParamsItem.setTargetCrowdConfig(pushBO.getTargetCrowdConfig());

            result.add(pushInfoAndParamsItem);
            temp = temp + item.getPercent();
        }
        PushBO.TargetCrowdConfig targetCrowdConfig = pushBO.getTargetCrowdConfig();
        //判断是否为上传人群
        if (TargetCrowdTypeEnum.UploadCrowd.getType().equals(targetCrowdConfig.getTargetCrowdType())) {
            return buildCustomCrowdSql(pushBO, list, result, ids);
        } else {
            return buildTagCrowdSql(pushBO, list, result, ids);
        }
    }

    /**
     * 构建每个模板对应的sql
     *
     * @author leijin
     * @date 2019-11-20 10:11
     **/
    private List<PushInfoAndParams> buildTagCrowdSql(PushBO pushBO, List<PushTemplateRelationEntity> list, List<PushInfoAndParams> result, List<String> ids) {
        //获取偏移量
        long offset = 0;
        if (list.size() > 1) {
            offset = pushBO.getId() % 50;
        }
        //处理灰度
        Integer grayFlag = 0;
        Integer grayPercent = 0;
        if (pushBO.getTargetCrowdConfig() != null) {
            grayFlag = pushBO.getTargetCrowdConfig().getGrayFlag() != null ? pushBO.getTargetCrowdConfig().getGrayFlag() : 0;
            grayPercent = pushBO.getTargetCrowdConfig().getGrayPercent() != null ? pushBO.getTargetCrowdConfig().getGrayPercent() : 0;
        }

        for (PushInfoAndParams item : result) {
            //初始化取模语句片段
            if (grayFlag == 1) {
                buildModelCondition(item, offset, grayPercent / 100.0);
            } else {
                buildModelCondition(item, offset, 1);
            }
            // 处理渠道条件
            buildChannelCondition(item);
            // 处理人群筛选条件
            buildCrowdsCondition(item);

            // 事件筛选条件(只有在自定义事件的条件下才处理)
            if (item.triggerType.equals(TriggerTypeEnum.CUSTOM_EVENT_TYPE.getType())) {
                buildEventCondition(item);
            }
            // 处理参数和url
            item.setColumnAndMqParamBo(templateParameterService.buildColumnAndMqKeyParam(item.getColumnAndMqParamBo()));;
            // 转换为SQL
            buildSQL(item);
            //组装测试用sql
            buildTestPushSql(item,ids);
            //组装统计人数的sql
            buildCountSQL(item);
        }

        log.info("get result: {}", JSON.toJSONString(result));
        return result;
    }

    private List<PushInfoAndParams> buildCustomCrowdSql(PushBO pushBO, List<PushTemplateRelationEntity> list, List<PushInfoAndParams> result, List<String> ids) {
        //获取偏移量
        long offset = 0;
        if (list.size() > 1) {
            offset = pushBO.getId() % 50;
        }
        //处理灰度
        Integer grayFlag = 0;
        Integer grayPercent = 0;
        if (pushBO.getTargetCrowdConfig() != null) {
            grayPercent = pushBO.getTargetCrowdConfig().getGrayPercent() != null ? pushBO.getTargetCrowdConfig().getGrayPercent() : 0;
            grayFlag = pushBO.getTargetCrowdConfig().getGrayFlag() != null ? pushBO.getTargetCrowdConfig().getGrayFlag() : 0;
        }
        PushBO.TargetCrowdConfig targetCrowdConfig = pushBO.getTargetCrowdConfig();
        UploadCrowdInfoBo uploadCrowdInfoBo = JSON.parseObject(targetCrowdConfig.getCustomCrowdInfo(), UploadCrowdInfoBo.class);
        for (PushInfoAndParams item : result) {
            item.setUploadCrowdInfoBo(uploadCrowdInfoBo);
            //初始化取模语句片段
            if (grayFlag == 1) {
                buildUploadModelCondition(item, offset, grayPercent / 100.0);
            } else {
                buildUploadModelCondition(item, offset, 1);
            }
            // 处理参数和url
            item.setColumnAndMqParamBo(templateParameterService.buildColumnAndMqKeyParam(item.getColumnAndMqParamBo()));;

            buildUploadSQL(item);
            //组装测试用sql

            buildTestPushSql(item,ids);
        }
        log.info("get result: {}", JSON.toJSONString(result));
        return result;
    }

    private void buildUploadModelCondition(PushInfoAndParams pushInfoAndParams, long offset, double gray) {
        if (MemberConstants.USER_TYPE_FOR_C.equals(pushInfoAndParams.getUserType())) {
            StringBuilder stringBuilder = new StringBuilder();
            long a = pushInfoAndParams.getStart() + offset;
            long b = (long) (pushInfoAndParams.getEnd() * gray) + offset;
            String cloumnName = "";
            if (CrowdTypeEnum.USER_ID.getType().equals(pushInfoAndParams.getUploadCrowdInfoBo().getUploadType())) {
                cloumnName = "member_crowd_custom.id";
            }
            if (CrowdTypeEnum.PUSH_ID.getType().equals(pushInfoAndParams.getUploadCrowdInfoBo().getUploadType())) {
                cloumnName = "member_crowd_pushid.id";
            }
            if (CrowdTypeEnum.OPEN_ID.getType().equals(pushInfoAndParams.getUploadCrowdInfoBo().getUploadType())) {
                cloumnName = "member_crowd_openid.id";
            }
            if (a >= 100) {
                stringBuilder.append("MOD(" + cloumnName + ",100) >=").append(a - 100);
                stringBuilder.append(" and MOD(" + cloumnName + ",100) <").append(b - 100);
            } else {
                stringBuilder.append("MOD(" + cloumnName + ",100) >=").append(a);
                if (b >= 100) {
                    stringBuilder.append(" and MOD(" + cloumnName + ",100) <100");
                    stringBuilder.append(" or ( MOD(" + cloumnName + ",100) >=0 and MOD(" + cloumnName + ",100) <").append(b - 100).append(")");
                } else {
                    stringBuilder.append(" and MOD(" + cloumnName + ",100) <").append(b);
                }
            }
            if (StringUtils.isNotBlank(stringBuilder.toString())) {
                pushInfoAndParams.setModelCondition('(' + stringBuilder.toString() + ')');
            }
        }else{
            pushInfoAndParams.setModelCondition("");
        }
    }


    private boolean sendPushMessage(PushInfoAndParams pushInfoAndParams, Integer page, Long jobId) {
        int pageSize = 20000;
        List<Map<String, Object>> list;
        if (!TargetCrowdTypeEnum.UploadCrowd.getType().equals(pushInfoAndParams.getTargetCrowdConfig().getTargetCrowdType())) {
            log.info("page sql:{}", pushInfoAndParams.getGeneratedSQL());
            list = tagValueService.selectBySql(pushInfoAndParams.getGeneratedSQL(), page * pageSize, pageSize);
        } else {
            log.info("page sql:{}", pushInfoAndParams.getUploadMysqlCrowdSql());
            list = crowdCustomMapper.findCrowdCustomBySql(pushInfoAndParams.getUploadMysqlCrowdSql(), page * pageSize, pageSize);
        }
        int currentSize = 0;
        if (CollectionUtils.isEmpty(list)) {
            log.info("本次查询数量为 0");
            return false;
        } else {
            currentSize = list.size();
        }
        log.info("本次查询数量为;{},page:{},jobId:{}", list.size(), page, jobId);
        //此处添加多线程
        List<List<Map<String, Object>>> arrays = Lists.partition(list, 2000);
        CountDownLatch countDownLatch = new CountDownLatch(arrays.size());
        arrays.stream().forEach(item -> {
            pushThreadPoolExecutor.execute(new BuildPushMessageRunner(
                    jobId,
                    memberPushPublisher,
                    item,
                    this, pushInfoAndParams,
                    pushService
            ));
            countDownLatch.countDown();
        });
        try {
            countDownLatch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        log.info("page:{} 发送完毕！", page);
        if (currentSize < pageSize) {
            return false;
        } else {
            return true;
        }

    }
    /**
     * c端用户测试发送消息构建
    * @author leijin
    * @date 2020-01-16 11:32
    **/
    private PushMessageEntity buildClientTestMessage(PushInfoAndParams pushInfoAndParams, Map<String, String> mqKeysParams) {
        List<Map<String, Object>>  list = tagValueService.selectAllBySql(pushInfoAndParams.getTestPushSql());
        if (CollectionUtils.isNotEmpty(list)) {
            PushMessageEntity pushMessageEntity = buildPushMessageEntity(pushInfoAndParams, list.get(0), mqKeysParams, null, 1);
            if (pushMessageEntity == null) {
                log.info("测试消息不完整!");
                return null;
            }
            return pushMessageEntity;
        } else {
            return null;
        }
    }
    /**
     * B端用户测试发送消息构建
     * @author leijin
     * @date 2020-01-16 11:32
     **/
    private PushMessageEntity buildBusinessTestMessage(PushInfoAndParams pushInfoAndParams,Long userId){
        Map<String,Object> map=new HashMap<>();
        map.put("member_id",userId);
        PushMessageEntity pushMessageEntity = buildPushMessageEntity(pushInfoAndParams, map, new HashMap<>(), null, 1);
        if (pushMessageEntity == null) {
            log.info("测试消息不完整!");
            return null;
        }
        return pushMessageEntity;
    }
    /**
     * @author leijin
     * source 1标识参数数据来自数据库，2标识参数数据来自MQ
     * @date 2019-10-16 18:27
     **/
    @Override
    public PushMessageEntity buildPushMessageEntity(PushInfoAndParams pushInfoAndParams,
                                                    Map<String, Object> dbMap, Map<String, String> mqKeysParams, Long jobId, int source) {
        PushMessageEntity pushMessageEntity = new PushMessageEntity();
        pushMessageEntity.setMemberPushId(pushInfoAndParams.getPushId());
        pushMessageEntity.setCreateTime(new Date());
        pushMessageEntity.setStatus(0);
        pushMessageEntity.setIsDeleted(false);
        pushMessageEntity.setTriggerChannel(pushInfoAndParams.getTriggerChannel());
        pushMessageEntity.setUniformTemplateId(pushInfoAndParams.getTemplateNum());
        pushMessageEntity.setPushJobRecordId(jobId);
        pushMessageEntity.setTriggerChannel(pushInfoAndParams.getTriggerChannel());
        //构建utm参数
        Map<String, String> utmMap = buildUtmMap(pushInfoAndParams.getColumnAndMqParamBo().getUrlKeysList());
        Map<String, String> paramMap = new HashMap<>();
        //添加额外不为空的参数
        Set<String> extraSet=pushInfoAndParams.getColumnAndMqParamBo().getExtraMap().keySet();
        Map<String,String> extraMap=pushInfoAndParams.getColumnAndMqParamBo().getExtraMap();
        extraSet.forEach(item->{
            if(StringUtils.isNotBlank(extraMap.get(item))){
                paramMap.put(item,extraMap.get(item));
            }
        });

        paramMap.putAll(utmMap);

        Map<String, String> urlParamMap = new HashMap<>();
        //组装url参数
        List<KeyModelBo> urlKeyModels = pushInfoAndParams.getColumnAndMqParamBo().getUrlKeysList();
        if (!buildAndValidator(urlKeyModels, dbMap, mqKeysParams, source, urlParamMap)) {
            return null;
        }
        //生成url
        String url = buildUrl(pushInfoAndParams, urlParamMap);
        if(StringUtils.isNotBlank(url)) {
            if (TriggerChannelEnum.WECHAT.getType().equals(pushInfoAndParams.getTriggerChannel())) {
                if ("1".equals(pushInfoAndParams.getColumnAndMqParamBo().getExtraMap().get("urlType"))) {
                    paramMap.put("urlType", "1");
                    paramMap.put("url", url);
                } else {
                    //小程序链接
                    paramMap.put("urlType", "2");
                    paramMap.put("pagepath", url);
                    paramMap.put("appId", pushInfoAndParams.getColumnAndMqParamBo().getExtraMap().get("miniAppId"));
                }
            } else if(TriggerChannelEnum.WECHATAPP.getType().equals(pushInfoAndParams.getTriggerChannel())){
                paramMap.put("url", url);
            } else {
                paramMap.put("jumpValue", url);
            }
        }else{
            if (TriggerChannelEnum.APPPUSH.getType().equals(pushInfoAndParams.getTriggerChannel())
                    &&MemberConstants.USER_TYPE_FOR_C.equals(pushInfoAndParams.getUserType())) {
                if ("2".equals(pushInfoAndParams.getColumnAndMqParamBo().getExtraMap().get("urlType"))) {
                    String activityUrl= pushInfoAndParams.getColumnAndMqParamBo().getExtraMap().get("activityUrl");
                    if (StringUtils.isNotBlank(activityUrl)) {
                        paramMap.put("jumpValue", activityUrl);
                    }
                }

            }


        }

        //组装内容参数
        List<KeyModelBo> contentKeyModels = pushInfoAndParams.getColumnAndMqParamBo().getContentKeysList();
        if (!buildAndValidator(contentKeyModels, dbMap, mqKeysParams, source, paramMap)) {
            return null;
        }
        //添加图片
        if (TriggerChannelEnum.APPPUSH.getType().equals(pushInfoAndParams.getTriggerChannel())) {
            if (StringUtils.isNotBlank(pushInfoAndParams.getColumnAndMqParamBo().getExtraMap().get("imageUrl"))) {
                paramMap.put("imageUrl", pushInfoAndParams.getColumnAndMqParamBo().getExtraMap().get("imageUrl"));
            }
        }

        if (source == 1) {
            if (TargetCrowdTypeEnum.UploadCrowd.getType().equals(pushInfoAndParams.getTargetCrowdConfig().getTargetCrowdType())) {
                if (CrowdTypeEnum.USER_ID.getType().equals(pushInfoAndParams.getUploadCrowdInfoBo().getUploadType())) {
                    pushMessageEntity.setMemberId(Long.valueOf(dbMap.get("member_id").toString()));
                }else if(CrowdTypeEnum.EMPLOYEE_ID.getType().equals(pushInfoAndParams.getUploadCrowdInfoBo().getUploadType())) {
                    pushMessageEntity.setMemberId(Long.valueOf(dbMap.get("member_id").toString()));
                }else {
                    pushMessageEntity.setMemberId(MemberConstants.NOT_MEMBER_MEMBER_ID);
                    for (String key : dbMap.keySet()) {
                        paramMap.put(key, dbMap.get(key).toString());
                    }
                }
            } else {
                pushMessageEntity.setMemberId(Long.valueOf(dbMap.get("member_id").toString()));
            }
        } else {
            pushMessageEntity.setMemberId(Long.valueOf(mqKeysParams.get("memberId")));
        }
        pushMessageEntity.setContentKeyList(contentKeyModels.stream().map(item -> item.getName()).collect(Collectors.toList()));
        String paramsStr = JSON.toJSONString(paramMap);
        pushMessageEntity.setMessageDetail(paramsStr);
        log.info("MessageDetail:{}", pushMessageEntity.getMessageDetail());
        return pushMessageEntity;
    }

    @Override
    public long countPushUsersByPushId(Long pushId) {
        PushBO pushBO = pushService.selectById(pushId);
        if (TargetCrowdTypeEnum.UploadCrowd.getType().equals(pushBO.getTargetCrowdConfig().getTargetCrowdType())) {
            PushBO.TargetCrowdConfig targetCrowdConfig = pushBO.getTargetCrowdConfig();
            UploadCrowdInfoBo uploadCrowdInfoBo = JSON.parseObject(targetCrowdConfig.getCustomCrowdInfo(), UploadCrowdInfoBo.class);
            return uploadCrowdInfoBo.getMemberNum();
        }else {
            if (MemberConstants.USER_TYPE_FOR_C.equals(pushBO.getUserType())&&
                    TriggerChannelEnum.APPPUSH.getType().equals(pushBO.getTriggerChannel())
                    && TargetCrowdTypeEnum.NoRegisterCrowd.getType().equals(pushBO.getTargetCrowdConfig().getTargetCrowdType())) {
                List<PushTemplateRelationEntity> list = pushTemplateRelationMapper.getRelationsByPushId(pushBO.getId());
                NoRegisterClientPersonasUser noRegisterClientPersonasUser = new NoRegisterClientPersonasUser(pushBO, list);
                NoRegisterClientPersonasUserBuilder noRegisterClientPersonasUserBuilder =
                        new NoRegisterClientPersonasUserBuilder(templateUrlParameterMapper, tagValueService,
                                pushThreadPoolExecutor, memberPushPublisher, qrCodeService);
                List<SqlModel> sqlModels = noRegisterClientPersonasUserBuilder.buildSql(noRegisterClientPersonasUser, new ArrayList<>());

                if (CollectionUtils.isEmpty(sqlModels)){
                    return 0;
                }else {
                    List<Map<String, Object>> countNums = tagValueService.selectAllBySql(sqlModels.get(0).getCountSqlStr());
                    Map<String, Object> map = countNums.get(0);
                    log.info("无注册用户统计sql {}",sqlModels.get(0).getCountSqlStr());
                    return Integer.parseInt(map.get("num").toString());
                }

            }else {
                List<PushInfoAndParams> list = getPushInfoAndParams(pushBO, null);
                if (CollectionUtils.isNotEmpty(list)) {
                    PushInfoAndParams pushInfoAndParams = list.get(0);
                    List<Map<String, Object>> countNums = tagValueService.selectAllBySql(pushInfoAndParams.getCountSQL());
                    Map<String, Object> map = countNums.get(0);
                    return Integer.parseInt(map.get("num").toString());
                } else {
                    return 0;
                }
            }
        }
    }

    private Map<String, String> buildUtmMap(List<KeyModelBo> urlKeysList) {
        Map<String, String> map = new HashMap<>();
        if (CollectionUtils.isNotEmpty(urlKeysList)) {
            for (KeyModelBo keyModelBo : urlKeysList) {
                switch (keyModelBo.getName()) {
                    case "utmContent":
                        if (org.apache.commons.lang.StringUtils.isNotEmpty(keyModelBo.getValue())) {
                            map.put("utmContent", keyModelBo.getValue());
                        } else {
                            map.put("utmContent", "");
                        }
                        break;
                    case "utmSource":
                        if (org.apache.commons.lang.StringUtils.isNotEmpty(keyModelBo.getValue())) {
                            map.put("utmSource", keyModelBo.getValue());
                        } else {
                            map.put("utmSource", "");
                        }
                        break;
                    case "utmMedium":
                        if (org.apache.commons.lang.StringUtils.isNotEmpty(keyModelBo.getValue())) {
                            map.put("utmMedium", keyModelBo.getValue());
                        } else {
                            map.put("utmMedium", "");
                        }
                        break;
                    case "utmCampaign":
                        if (org.apache.commons.lang.StringUtils.isNotEmpty(keyModelBo.getValue())) {
                            map.put("utmCampaign", keyModelBo.getValue());
                        } else {
                            map.put("utmCampaign", "");
                        }
                        break;
                    default:
                        break;
                }
            }
        }
        return map;
    }

    private boolean buildAndValidator(List<KeyModelBo> models, Map<String, Object> dbMap, Map<String, String> mqKeysParams, int source, Map<String, String> result) {
        for (KeyModelBo item : models) {
            if (TemplateParamTypeEnum.SYS_KEY.getType().equals(item.getType())) {
                if (source == 1) {
                    if (dbMap.get(item.getValue()) == null) {
                        log.info("参数：{}为空，消息组装失败！", item);
                        return false;
                    }
                    String str = dbMap.get(item.getValue()).toString();
                    if (StringUtils.isBlank(str)) {
                        log.info("参数：{}为空，消息组装失败！", item);
                        return false;
                    }
                    result.put(item.getName(), str);
                } else {
                    String str = mqKeysParams.get(item.getValue());
                    if (StringUtils.isBlank(str)) {
                        log.info("参数：{}为空，消息组装失败！", item);
                        return false;
                    }
                    result.put(item.getName(), str);
                }
            } else if (TemplateParamTypeEnum.TEXT.getType().equals(item.getType())) {
                result.put(item.getName(), item.getValue());
            }
        }
        return true;
    }

    private String freemarkerProcess(Map input, String templateStr) {
        StringTemplateLoader stringLoader = new StringTemplateLoader();
        String template = "content";
        stringLoader.putTemplate(template, templateStr);
        Configuration cfg = new Configuration();
        cfg.setTemplateLoader(stringLoader);
        try {
            Template templateCon = cfg.getTemplate(template);
            StringWriter writer = new StringWriter();
            templateCon.process(input, writer);
            return writer.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }


    //构造url
    private String buildUrl(PushInfoAndParams pushInfoAndParams, Map<String, String> urlParamMap) {
        String baseUrl = pushInfoAndParams.getColumnAndMqParamBo().getBaseUrl();
        if (StringUtils.isBlank(baseUrl)){
           return "";
        }
        String deepLinkUrl = pushInfoAndParams.getColumnAndMqParamBo().getDeeplinkUrl();
        if (StringUtils.isBlank(deepLinkUrl)){
            return baseUrl;
        }else {
            String res = freemarkerProcess(urlParamMap, deepLinkUrl);
            if(StringUtils.isBlank(res)){
                return "";
            }
            if (pushInfoAndParams.getTriggerChannel().equals(TriggerChannelEnum.SMS.getType())){
                String encodeUrl;
                try {
                    encodeUrl = URLEncoder.encode(res, "utf-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                    encodeUrl = "";
                }
                if (StringUtils.isBlank(encodeUrl)){
                    return "";
                }
                String shortUrl= qrCodeService.getShortUrl(baseUrl + encodeUrl);
                if (StringUtils.isBlank(shortUrl)){
                    return "";
                }else{
                    return shortUrl;
                }
            }else{
                return baseUrl + res;
            }
        }
    }

    /**
     * 处理取模和灰度
     *
     * @author leijin
     * @date 2019-09-09 20:53
     **/

    private void buildModelCondition(PushInfoAndParams pushInfoAndParams, long offset, double gray) {
        if (MemberConstants.USER_TYPE_FOR_C.equals(pushInfoAndParams.getUserType())) {
            log.info("stat:{},end:{},offset:{},gray:{}", pushInfoAndParams.getStart(), pushInfoAndParams.getEnd(), offset, gray);
            StringBuilder stringBuilder = new StringBuilder();
            long a = pushInfoAndParams.getStart() + offset;
            long b = (long) (pushInfoAndParams.getEnd() * gray) + offset;
            log.info("statPoint:{},endPoint:{}", a, b);
            if (a >= 100) {
                stringBuilder.append("MOD(member_dim.member_id,100) >=").append(a - 100);
                stringBuilder.append(" and MOD(member_dim.member_id,100) <").append(b - 100);
            } else {
                stringBuilder.append("MOD(member_dim.member_id,100) >=").append(a);
                if (b >= 100) {
                    stringBuilder.append(" and MOD(member_dim.member_id,100) <100");
                    stringBuilder.append(" or ( MOD(member_dim.member_id,100) >=0 and MOD(member_dim.member_id,100) <").append(b - 100).append(")");
                } else {
                    stringBuilder.append(" and MOD(member_dim.member_id,100) <").append(b);
                }
            }
            if (StringUtils.isNotBlank(stringBuilder.toString())) {
                pushInfoAndParams.setModelCondition('(' + stringBuilder.toString() + ')');
            }
        }else{
            pushInfoAndParams.setModelCondition("");
        }
    }

    /**
     * 处理发送渠道
     *
     * @author leijin
     * @date 2019-09-09 20:53
     **/
    private void buildChannelCondition(PushInfoAndParams pushInfoAndParams) {
        if (pushInfoAndParams.getTriggerChannel() == null) {
            pushInfoAndParams.setChannelCondition("");
        }
        String filter = "";

        if (MemberConstants.USER_TYPE_FOR_C.equals(pushInfoAndParams.getUserType())) {
            switch (TriggerChannelEnum.getByType(pushInfoAndParams.getTriggerChannel())) {
                case APPPUSH:
                    filter = "member_dim.is_push_flag=1 ";
                    break;
                case SMS:
                    filter = "member_dim.phone is not null";
                    break;
                case WECHAT:
                    filter = "member_dim.is_oyo_wechat_fans=1";
                    break;
                default:
                    break;
            }
        }else{
            if(TriggerTypeEnum.BUSINESS_APOLLO_USER_TYPE.getType().equals(pushInfoAndParams.triggerType)){
                filter=businessApolloUserFilter;
            }else if(TriggerTypeEnum.BUSINESS_MINI_WECHAT_USER_TYPE.getType().equals(pushInfoAndParams.triggerType)){
                filter="";
            }
        }
        if (StringUtils.isNotBlank(filter)) {
            pushInfoAndParams.setChannelCondition('(' + filter + ')');
        }
    }

    //处理人群sql组装
    private void buildCrowdsCondition(PushInfoAndParams pushInfoAndParams) {
        PushBO.TargetCrowdConfig targetCrowdConfig = pushInfoAndParams.getTargetCrowdConfig();
        if (null == targetCrowdConfig || null == targetCrowdConfig.getTargetCrowdType()) {
            return;
        }
        String filter = "";
        //全部人群
        if (TargetCrowdTypeEnum.AllUser.getType().equals(targetCrowdConfig.getTargetCrowdType())) {
            filter="";
        }
        //之前的不兼容
        if (targetCrowdConfig.getTargetCrowdType().equals(2)) {
            filter = "member_dim.member_id < 0 ";
        }
        //自定义人群
        if (TargetCrowdTypeEnum.DefineCrowd.getType().equals(targetCrowdConfig.getTargetCrowdType())) {
            filter = messagePushService.getWhereStatement(targetCrowdConfig.getCustomCrowdInfo());
        }
        //已有标签人群
        if (TargetCrowdTypeEnum.SelectCrowd.getType().equals(targetCrowdConfig.getTargetCrowdType())) {
            StringBuilder stringBuilder = new StringBuilder();
            JSONArray config = JSON.parseArray(targetCrowdConfig.getCrowdsGather());
            List<Long> list = new ArrayList<>();
            JSONArray values = config.getJSONObject(0).getJSONArray("value");
            Iterator<Object> iterator = values.iterator();
            while (iterator.hasNext()) {
                list.add(Long.valueOf(iterator.next().toString()));
            }
            List<CrowdEntity> crowdEntities = crowdMapper.selectByIds(list);
            String sqlStr = messagePushService.getSqlByTagCrowds(crowdEntities);
            stringBuilder.append("(").append(sqlStr);
            if (config.size() > 1) {
                List<Long> diffList = new ArrayList<>();
                JSONArray diffValues = config.getJSONObject(1).getJSONArray("value");
                Iterator<Object> diffIterator = diffValues.iterator();
                while (diffIterator.hasNext()) {
                    diffList.add((Long) iterator.next());
                }
                List<CrowdEntity> diffCrowdEntities = crowdMapper.selectByIds(diffList);
                String diffSqlStr = messagePushService.getSqlByTagCrowds(diffCrowdEntities);
                stringBuilder.append("and member_dim.member_id NOT in( select member_id from member_dim where ")
                        .append(diffSqlStr).append(")");
            }
            stringBuilder.append(")");
            filter = stringBuilder.toString();
        }
        //通过用户中心提供的组件获取人群
        if(TargetCrowdTypeEnum.MuseCrowd.getType().equals(targetCrowdConfig.getTargetCrowdType())){
            JSONObject config = JSON.parseObject(targetCrowdConfig.getCustomCrowdInfo());
            List<String > arrary=Arrays.asList(config.getString("regions").split(","));
            Map<String,List<String>> map=new HashMap<>();
            arrary.forEach(item->{
                String[] strs=item.split("_");
                if(strs.length==2) {
                    List<String> list = map.get(strs[0]);
                    if (CollectionUtils.isEmpty(list)) {
                        list = new ArrayList<>();
                    }
                    list.add(strs[1]);
                    map.put(strs[0], list);
                }
            });
            StringBuilder sb=new StringBuilder();
            int i=0;
            for (String item:map.keySet()) {
                ApolloUserColumn apolloUserColumn=ApolloUserColumn.getColumnByName(item.toLowerCase());
                if (apolloUserColumn!=null){
                    sb.append(apolloUserColumn.getColumn()).append(" in (").append(org.apache.commons.lang.StringUtils.join(map.get(item),",")).append(")");
                }
                if (i!=map.keySet().size()-1){
                    sb.append(" and ");
                }
            }
            Iterator jsonArray=config.getJSONArray("profiles").iterator();
            List<Long> ids=new ArrayList<>();
             while(jsonArray.hasNext()){
                 JSONObject obj=(JSONObject)jsonArray.next();
                 ids.add(obj.getLongValue("id"));
            }
             if (CollectionUtils.isNotEmpty(ids)){
                 if (StringUtils.isNotBlank(sb.toString())) {
                     sb.append(" and ").append("profile_id in(").append(StringUtils.join(ids, ",")).append(") ");
                 }else {
                     sb.append("profile_id in(").append(StringUtils.join(ids, ",")).append(") ");
                 }

             }
            filter=sb.toString();
        }
        if (StringUtils.isNotBlank(filter)) {
            pushInfoAndParams.setCrowdsCondition('(' + filter + ')');
        }
    }

    //处理事件sql组装
    private void buildEventCondition(PushInfoAndParams pushInfoAndParams) {
        PushBO.TargetCrowdConfig targetCrowdConfig = pushInfoAndParams.getTargetCrowdConfig();
        if (null == targetCrowdConfig || StringUtils.isBlank(targetCrowdConfig.getTriggerCondition())) {
            return;
        }
        DynamicSqlBo dynamicSqlBo = customizedEventService.dynamicBuildSql(targetCrowdConfig.getTriggerCondition());
        if (StringUtils.isNotBlank(dynamicSqlBo.getJoinFragment())) {
            pushInfoAndParams.setJoinCondition(dynamicSqlBo.getJoinFragment());
        } else {
            pushInfoAndParams.setJoinCondition("");
        }
        if (StringUtils.isNotBlank(dynamicSqlBo.getWhereFragment())) {
            pushInfoAndParams.setEventCondition(dynamicSqlBo.getWhereFragment());
        } else {
            pushInfoAndParams.setEventCondition("");
        }
        pushInfoAndParams.setViewSet(dynamicSqlBo.getViewSet());

    }

    private void buildSQL(PushInfoAndParams pushInfoAndParams) {
        StringBuilder sb = new StringBuilder();
        List<String> list=new ArrayList<>();
        if(CollectionUtils.isNotEmpty(pushInfoAndParams.getViewSet())) {
            sb.append("with ");
            int i=0;
            for (String name : pushInfoAndParams.getViewSet()) {
                if(ViewNameConstants.EVENT_VIEW_DEFINE.equals(name)){
                    list.add(eventViewDefine);
                }
                if(ViewNameConstants.BOOKING_VIEW_DEFINE.equals(name)){
                    list.add(bookingViewDefine);
                }
                if(ViewNameConstants.USERS_VIEW_DEFINE.equals(name)){
                    list.add(userViewDefine);
                }
            }
            sb.append(StringUtils.join(list,","));
            sb.append("\n");
        }

        if (MemberConstants.USER_TYPE_FOR_C.equals(pushInfoAndParams.getUserType())){
            if (CollectionUtils.isNotEmpty(pushInfoAndParams.getColumnAndMqParamBo().getColumns())) {
                sb.append("select distinct member_dim.member_id, ").append(StringUtils.join(pushInfoAndParams.getColumnAndMqParamBo().getColumns(), ',')).append('\n');
            } else {
                sb.append("select distinct member_dim.member_id ").append('\n');
            }
            sb.append(" FROM ump_data_member_dim_dw as member_dim");
            // 拼装join
            if (StringUtils.isNotBlank(pushInfoAndParams.getJoinCondition())) {
                sb.append(pushInfoAndParams.getJoinCondition());
            }
        }else{
            if (CollectionUtils.isNotEmpty(pushInfoAndParams.getColumnAndMqParamBo().getColumns())) {
                sb.append("select distinct member_dim.user_id as member_id, ").append(StringUtils.join(pushInfoAndParams.getColumnAndMqParamBo().getColumns(), ',')).append('\n');
            } else {
                sb.append("select distinct member_dim.user_id as member_id ").append('\n');
            }
            if (TriggerTypeEnum.BUSINESS_APOLLO_USER_TYPE.getType().equals(pushInfoAndParams.triggerType)){
                sb.append(" FROM upm_user_manager_hotel as member_dim");
            }else{
                sb.append(" FROM ump_data_staff_user_profile as member_dim");
            }
        }

        sb.append("\n  where 1=1 ");
        // 拼装channel
        if (StringUtils.isNotBlank(pushInfoAndParams.getChannelCondition())) {
            sb.append(" and ").append(pushInfoAndParams.getChannelCondition());
        }
        // 拼装分流
        if (StringUtils.isNotBlank(pushInfoAndParams.getModelCondition())) {
            sb.append(" and ").append(pushInfoAndParams.getModelCondition());
        }
        // 拼装人群
        if (StringUtils.isNotBlank(pushInfoAndParams.getCrowdsCondition())) {
            sb.append(" and ").append(pushInfoAndParams.getCrowdsCondition());
        }
        // 拼装事件
        if (StringUtils.isNotBlank(pushInfoAndParams.getEventCondition())) {
            //实时事件已经拼接过and的，此处无需再拼接
            sb.append(pushInfoAndParams.getEventCondition());
        }
        if (MemberConstants.USER_TYPE_FOR_C.equals(pushInfoAndParams.getUserType())) {
            sb.append(" order by member_dim.member_id ");
        }else{
            sb.append(" order by member_dim.user_id ");
        }
        log.info("generate SQL is: {}", sb.toString());
        pushInfoAndParams.setGeneratedSQL(sb.toString());
    }


    private void buildTestPushSql(PushInfoAndParams pushInfoAndParams,List<String> ids){
        StringBuilder sb = new StringBuilder();
        if (MemberConstants.USER_TYPE_FOR_C.equals(pushInfoAndParams.getUserType())) {
            if (CollectionUtils.isNotEmpty(pushInfoAndParams.getColumnAndMqParamBo().getColumns())) {
                sb.append("select distinct member_dim.member_id, ").append(StringUtils.join(pushInfoAndParams.getColumnAndMqParamBo().getColumns(), ',')).append('\n');
            } else {
                sb.append("select distinct member_dim.member_id ").append('\n');
            }
            sb.append(" FROM ump_data_member_dim_dw as member_dim");
            sb.append("\n  where ");
            sb.append("member_dim.phone in(");
            if (CollectionUtils.isNotEmpty(ids)) {
                sb.append("'");
                sb.append(StringUtils.join(ids, "','"));
                sb.append("'");
            }
            sb.append(")");
        }else{
            if (CollectionUtils.isNotEmpty(pushInfoAndParams.getColumnAndMqParamBo().getColumns())) {
                sb.append("select distinct member_dim.user_id as member_id, ").append(StringUtils.join(pushInfoAndParams.getColumnAndMqParamBo().getColumns(), ',')).append('\n');
            } else {
                sb.append("select distinct member_dim.user_id as member_id").append('\n');
            }
            if (TriggerTypeEnum.BUSINESS_APOLLO_USER_TYPE.getType().equals(pushInfoAndParams.triggerType)){
                sb.append(" FROM upm_user_manager_hotel as member_dim");
            }else{
                sb.append(" FROM ump_data_staff_user_profile as member_dim");
            }
            sb.append("\n  where ");
            sb.append("member_dim.user_id in(");
            if (CollectionUtils.isNotEmpty(ids)) {
                sb.append("'");
                sb.append(StringUtils.join(ids, "','"));
                sb.append("'");
            }
            sb.append(")");
        }
        log.info("Test sql is: {}", sb.toString());
        pushInfoAndParams.setTestPushSql(sb.toString());

    }

    private void buildUploadSQL(PushInfoAndParams pushInfoAndParams) {
        StringBuilder sb = new StringBuilder();
        sb.append("select  ").append('\n');
        if (CrowdTypeEnum.EMPLOYEE_ID.getType().equals(pushInfoAndParams.getUploadCrowdInfoBo().getUploadType())) {
            sb.append("user_id as member_id").append('\n');
            sb.append("from  ").append('\n');
            sb.append("member_crowd_custom  ").append('\n');
        }
        if (CrowdTypeEnum.USER_ID.getType().equals(pushInfoAndParams.getUploadCrowdInfoBo().getUploadType())) {
            sb.append("user_id as member_id").append('\n');
            sb.append("from  ").append('\n');
            sb.append("member_crowd_custom  ").append('\n');
        }
        if (CrowdTypeEnum.PUSH_ID.getType().equals(pushInfoAndParams.getUploadCrowdInfoBo().getUploadType())) {
            sb.append("push_id as pushId,channel_type as channelType ").append('\n');
            sb.append("from  ").append('\n');
            sb.append("member_crowd_pushid  ").append('\n');
        }
        if (CrowdTypeEnum.OPEN_ID.getType().equals(pushInfoAndParams.getUploadCrowdInfoBo().getUploadType())) {
            sb.append("open_id as openId").append('\n');
            sb.append("from  ").append('\n');
            sb.append("member_crowd_openid  ").append('\n');
        }
        sb.append("where  ").append('\n');
        sb.append("crowd_id = ").append('\n');
        sb.append(pushInfoAndParams.getUploadCrowdInfoBo().getUpLoadCrowdId());
        if (StringUtils.isNotBlank(pushInfoAndParams.getModelCondition())) {
            sb.append(" and ").append(pushInfoAndParams.getModelCondition());
        }
        sb.append(" order by id ");
        log.info("uploadMysql SQL is: {}", sb.toString());
        pushInfoAndParams.setUploadMysqlCrowdSql(sb.toString());
    }
    private void buildCountSQL(PushInfoAndParams pushInfoAndParams) {
        StringBuilder sb = new StringBuilder();
        if (MemberConstants.USER_TYPE_FOR_C.equals(pushInfoAndParams.getUserType())){
            sb.append("select count(distinct member_dim.member_id) as num ").append('\n');
            sb.append(" FROM ump_data_member_dim_dw as member_dim");
        }else {
            sb.append("select count(distinct member_dim.user_id) as num ").append('\n');
            if (TriggerTypeEnum.BUSINESS_APOLLO_USER_TYPE.getType().equals(pushInfoAndParams.triggerType)){
                sb.append(" FROM upm_user_manager_hotel as member_dim");
            }else{
                sb.append(" FROM ump_data_staff_user_profile as member_dim");
            }
        }
        sb.append("\n  where 1=1 ");

        // 拼装channel
        if (StringUtils.isNotBlank(pushInfoAndParams.getChannelCondition())) {
            sb.append(" and ").append(pushInfoAndParams.getChannelCondition());
        }
        // 拼装人群
        if (StringUtils.isNotBlank(pushInfoAndParams.getCrowdsCondition())) {
            sb.append(" and ").append(pushInfoAndParams.getCrowdsCondition());
        }
        log.info("generate CountSQL is: {}", sb.toString());
        pushInfoAndParams.setCountSQL(sb.toString());
    }
}
