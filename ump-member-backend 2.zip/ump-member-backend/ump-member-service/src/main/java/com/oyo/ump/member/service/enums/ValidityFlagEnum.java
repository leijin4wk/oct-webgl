package com.oyo.ump.member.service.enums;

public enum ValidityFlagEnum {

    PERMANENT(1,"永久有效"),

    TIME_QUANTUM(2,"时间段");

    private final Integer type;
    private final String name;

    public Integer getType() {
        return type;
    }
    public String getName() {
        return name;
    }
    ValidityFlagEnum(Integer type, String name){
        this.name=name;
        this.type=type;
    }
}
