package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;

/**
 * @author Dong
 * @Classname HotelBO
 * @Description 酒店信息BO
 * @Date 2019-03-25
 */
@Data
public class HotelBO implements Serializable {
    private Integer id;
    private Long hotelId;
    private Integer cityId;
}
