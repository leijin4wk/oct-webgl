package com.oyo.ump.member.service.enums;

/**
 * 支付类型枚举
* @author frank
* @date 2019-05-13 19:29
**/
public enum OrderPayTypeEnum {

    PAY_ONLINE(1,"预付"),
    PAY_ARRIVE_HOTEL(0,"到付");



    private final Integer type;
    private final String name;

    public Integer getType() {
        return type;
    }
    public String getName() {
        return name;
    }
    OrderPayTypeEnum(Integer type, String name){
        this.name=name;
        this.type=type;
    }
}
