package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;

/**
 * @author Dong
 * @Classname TemplateParameterBO
 * @Description 模板参数信息配置
 * @Date 2019-08-30
 */
@Data
public class TemplateParameterBO implements Serializable {
    private Long id;
    private String name;
    private String dictCol;
    private String dictTab;
    private Integer source;
    private Integer parameterType;
}
