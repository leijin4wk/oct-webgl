package com.oyo.ump.member.service.bo;

import lombok.AllArgsConstructor;
import lombok.Data;
/**
 * 模板参数实体
* @author leijin
* @date 2019-10-16 17:27
**/
@Data
@AllArgsConstructor
public class KeyModelBo {

    private String name;

    private Integer type;

    private String value;

}
