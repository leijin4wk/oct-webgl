package com.oyo.ump.member.service.impl;

import com.alibaba.fastjson.JSON;
import com.google.gson.Gson;
import com.oyo.ump.member.common.constants.MemberConstants;
import com.oyo.ump.member.dal.dao.BonusCostRuleMapper;
import com.oyo.ump.member.dal.model.BonusCostRuleEntity;
import com.oyo.ump.member.service.BonusCostRuleService;
import com.oyo.ump.member.service.RedisService;
import com.oyo.ump.member.service.dto.BonusCostRuleDTO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Classname BonusCostRuleServiceImpl
 * @Description 积分消费规则实现类
 * @Date 2019-03-15 16:10
 * @author Dong
 */
@Service
@Slf4j
public class BonusCostRuleServiceImpl implements BonusCostRuleService {
    @Autowired
    private BonusCostRuleMapper bonusCostRuleMapper;

    @Autowired
    @Qualifier("fromGson")
    private Gson gson;
    @Autowired
    private RedisService redisService;

    @Override
    public BonusCostRuleDTO getCostRuleList() {

        List<BonusCostRuleEntity> bonusCostRuleEntityList = Lists.newArrayList();

        BonusCostRuleDTO bonusCostRuleDTO = new BonusCostRuleDTO();
        Object exchangeRate= redisService.getValue(MemberConstants.POINT_EXCHANGER);
        if(exchangeRate!=null){
         return JSON.parseObject(exchangeRate.toString(),BonusCostRuleDTO.class) ;
        }
        try{
            bonusCostRuleEntityList = bonusCostRuleMapper.getCostRuleList();
        }catch (Exception e){
            log.error("获取所有积分消费规则sql异常", e);
        }

        convert2Dto(bonusCostRuleEntityList, bonusCostRuleDTO);
        redisService.setValue(MemberConstants.POINT_EXCHANGER,JSON.toJSONString(bonusCostRuleDTO),MemberConstants.POINT_EXCHANGER_EXPIRED);
        return bonusCostRuleDTO;
    }


    /**
     * EntityList 转化为 DTO
     * @param bonusCostRuleEntityList 积分消耗规则实体类列表
     * @param bonusCostRuleDTO 积分消耗规则DTO
     */
    private void convert2Dto(List<BonusCostRuleEntity> bonusCostRuleEntityList, BonusCostRuleDTO bonusCostRuleDTO) {

        List<BonusCostRuleDTO.BonusCostRuleInfo> bonusCostRuleInfoList = Lists.newArrayList();

        if (CollectionUtils.isNotEmpty(bonusCostRuleEntityList)) {
            bonusCostRuleEntityList.forEach(entity -> {

                BonusCostRuleDTO.BonusCostRuleInfo bonusCostRuleInfo = convert2BonusCostRuleInfo(entity);
                bonusCostRuleInfoList.add(bonusCostRuleInfo);

            });
        }
        bonusCostRuleDTO.setBonusCostRuleInfoList(bonusCostRuleInfoList);
    }

    /**
     * Entity 转化为 Info
     *
     * @param entity 实体类
     * @return om.oyo.ump.member.service.dto.BonusCostRuleDTO.BonusCostRuleInfo
     */
    private BonusCostRuleDTO.BonusCostRuleInfo convert2BonusCostRuleInfo(BonusCostRuleEntity entity) {

        BonusCostRuleDTO.BonusCostRuleInfo bonusCostRuleInfo = new BonusCostRuleDTO.BonusCostRuleInfo();

        try {
            bonusCostRuleInfo.setId(entity.getId());
            bonusCostRuleInfo.setDeductionRatio(entity.getDeductionRatio());

            // 把数据库中取出的 积分兑换配置，转换成ExchangeConfig类
            BonusCostRule.ExchangeConfig exchangeConfig = gson.fromJson(entity.getExchangeConfig(), BonusCostRule.ExchangeConfig.class);

            // 积分兑换中的KV数据 赋值到 BonusCostRuleDTO.BonusCostRuleInfo
            bonusCostRuleInfo.setPricePerUnit(exchangeConfig.getPricePerUnit());
            bonusCostRuleInfo.setMinBonus(exchangeConfig.getMinBonus());

        } catch (Exception e) {
            log.error("method:convert2BonusCostRuleInfo error", e);
        }
        return bonusCostRuleInfo;
    }


}
