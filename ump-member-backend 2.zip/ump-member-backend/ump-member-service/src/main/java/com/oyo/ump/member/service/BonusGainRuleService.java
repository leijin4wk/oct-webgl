package com.oyo.ump.member.service;

import com.oyo.ump.member.service.dto.BonusGainRuleDTO;

/**
 * @Classname BonusGainRuleService
 * @Description 积分获取规则业务接口
 * @Date 2019-03-16 11:00
 * @author Dong
 */
public interface BonusGainRuleService {
    /**
     * 查询所有的积分获取规则DTO
     * @return com.oyo.ump.member.service.dto.BonusGainRuleDTO
     */
    default BonusGainRuleDTO getGainRuleList(){
        return getGainRuleList("OYO");
    }

    BonusGainRuleDTO getGainRuleList(String tenant);

}
