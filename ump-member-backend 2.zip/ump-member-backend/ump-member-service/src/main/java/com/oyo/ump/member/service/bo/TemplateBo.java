package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;

@Data
public class TemplateBo implements Serializable {
    private String templateNum;
    private String templateName;
    private Integer bizChannel;
    private String bizChannelName;
    private String label;
    private Integer templateType;
}
