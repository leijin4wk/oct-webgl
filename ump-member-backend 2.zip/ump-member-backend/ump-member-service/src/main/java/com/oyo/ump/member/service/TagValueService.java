package com.oyo.ump.member.service;

import java.util.List;
import java.util.Map;

/**
 * @Description: 获取ADB中标签值等级接口
 * @Author: Dong
 * @create: 2019-06-10
 **/
public interface TagValueService {
     List<Map<String,Object>> selectByValueArea(String valueArea);
     long countNum(String strSql);
     List<Long> getUsers(String strSql);
     List<Map<String,Object>> selectBySql(String SqlStr,Integer start,Integer pageSize);
     List<Map<String,Object>> selectAllBySql(String SqlStr);
}
