package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;
@Data
public class UploadCrowdInfoBo implements Serializable {

    private Long upLoadCrowdId;

    private Long memberNum;

    private Integer uploadType;
}
