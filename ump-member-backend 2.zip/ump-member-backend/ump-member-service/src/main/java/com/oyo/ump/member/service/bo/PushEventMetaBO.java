package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author Dong
 * @Classname PushBO
 * @Description 事件推送BO
 * @Date 2019-05-06
 */
@Data
public class PushEventMetaBO implements Serializable {
    private Long id;
    private String eventName;
    private String eventKey;
    private Date createTime;
    private Date updateTime;
    private Boolean isDeleted;
}
