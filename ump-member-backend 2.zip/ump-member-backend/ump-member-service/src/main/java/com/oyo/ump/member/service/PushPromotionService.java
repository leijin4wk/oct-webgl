package com.oyo.ump.member.service;

import com.oyo.common.response.PagedResponse;
import com.oyo.ump.member.service.bo.PushBO;
import com.oyo.ump.member.service.bo.PushPromotionBO;

import java.time.temporal.TemporalUnit;
import java.util.List;

/**
 * @author Dong
 * @Description 活动push相关接口
 * @Date 2019-05-06
 */
public interface PushPromotionService {
    /**
     * 插入
     * @param pushPromotionBO
     * @return
     */
    void insert(PushPromotionBO pushPromotionBO);
    /**
     * 通过条件查询活动push
     * @param pushPromotionBO
     * @return com.oyo.ump.member.service.bo.PushPromotionBO
     */
    PushPromotionBO selectByCondition(PushPromotionBO pushPromotionBO);
}
