package com.oyo.ump.member.service.impl;

import com.oyo.ump.member.service.RedisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.data.redis.support.atomic.RedisAtomicLong;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * 缓存
 * @author tim.li
 */
@Service
public class RedisServiceImpl implements RedisService {

    @Autowired
    private ValueOperations<String, Object> valueOperations;

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    @Override
    public Object getValue(String key) {
        return redisTemplate.opsForValue().get(key);
    }

    @Override
    public void pushValue(String key, Object value) {
       Long re = redisTemplate.opsForList().leftPush(key,value);
       System.out.println("ASDASDA :"+re);
    }

    @Override
    public Object popValue(String key) {
        return redisTemplate.opsForList().leftPop(key);
    }

    @Override
    public Long incr(String key, long liveTime) {
        RedisAtomicLong entityIdCounter = new RedisAtomicLong(key, Objects.requireNonNull(redisTemplate.getConnectionFactory()));
        Long increment = entityIdCounter.incrementAndGet();
        //初始设置过期时间
        if (increment == 1 && liveTime > 0) {
            entityIdCounter.expire(liveTime, TimeUnit.SECONDS);
        }

        return increment;
    }

    @Override
    public void setValue(String key, Object value) {
        valueOperations.set(key, value);
    }

    @Override
    public Long incrBy(String key, long num, long liveTime) {
        Long increment = valueOperations.increment(key, num);
        //初始设置过期时间
        if (liveTime > 0) {
            redisTemplate.expire(key, liveTime, TimeUnit.SECONDS);
        }
        return increment;
    }

    @Override
    public Long decr(String key) {
        RedisAtomicLong entityIdCounter = new RedisAtomicLong(key, Objects.requireNonNull(redisTemplate.getConnectionFactory()));
        return entityIdCounter.decrementAndGet();
    }

    @Override
    public Boolean hasKey(String key) {
        return redisTemplate.hasKey(key);
    }

    @Override
    public void setValue(String key, Object value, Long expiredTime) {
        valueOperations.set(key, value, expiredTime, TimeUnit.SECONDS);
    }

    @Override
    public void removeKey(String key) {

        redisTemplate.delete(key);
    }

    @Override
    public Boolean setNXValue(String key, Object value) {

        return valueOperations.setIfAbsent(key,value);
    }

    @Override
    public Boolean setNXValue(String key, Object value, long liveTime) {
        redisTemplate.opsForValue().set(key,value);
        return redisTemplate.expire(key, liveTime, TimeUnit.SECONDS);

    }

    @Override
    public List<Object> mGet(List<String> keys) {
        return redisTemplate.opsForValue().multiGet(keys);
    }

    @Override
    public Long lPushValue(String key, Object value) {
        return redisTemplate.opsForList().leftPush(key,value);
    }

    @Override
    public List<Object> getAllListValue(String key) {
     return  redisTemplate.opsForList().range(key,0,-1);
    }

    @Override
    public Map<Object, Object> getMapEntries(String key) {
        return redisTemplate.opsForHash().entries(key);

    }

    @Override
    public void putMapEntry(String key, Object hey, Object hv) {
        redisTemplate.opsForHash().put(key, hey, hv);
    }

    @Override
    public Object getMapValue(String key, Object hashKey) {
        return redisTemplate.opsForHash().get(key, hashKey);
    }

    @Override
    public Long deleteMapEntry(String key, Object hashKey) {
        return redisTemplate.opsForHash().delete(key, hashKey);
    }

    @Override
    public Set<Object> getAllSetValues(String key) {
       return redisTemplate.opsForSet().members(key);
    }

    @Override
    public Long addSetValue(String key, Object value) {
       return redisTemplate.opsForSet().add(key,value);
    }

    /**
     * 批量增加set元素
     *
     * @param key
     * @param values
     */
    @Override
    public void batchAddSet(String key, Object... values) {
        redisTemplate.opsForSet().add(key, values);
    }

    /**
     * 批量删除set元素
     *
     * @param key
     * @param values
     */
    @Override
    public void batchRemoveSet(String key, Object... values) {
        redisTemplate.opsForSet().remove(key, values);
    }

    /**
     * 是否是set元素
     *
     * @param key
     * @param value
     */
    @Override
    public Boolean isMemberOfSet(String key, Object value) {
        return redisTemplate.opsForSet().isMember(key, value);
    }

    @Override
    public Long getSizeOfSet(String key) {
        return redisTemplate.opsForSet().size(key);
    }


}
