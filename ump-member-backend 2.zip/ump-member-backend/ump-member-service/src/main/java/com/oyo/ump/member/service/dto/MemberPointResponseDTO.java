package com.oyo.ump.member.service.dto;

import lombok.Data;
import org.assertj.core.util.Lists;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @Description: 会员积分请求返回dto
 * @Author: fang
 * @create: 2019-04-04
 **/
@Data
public class MemberPointResponseDTO implements Serializable {
    private Long userId;
    private int pageNum;
    private int pageSize;
    private long totalPages;
    private long totalCount;
    private List<MemberPointResponseDTO.MemberBonusInfo> result = Lists.newArrayList();
    @Data
    public static class MemberBonusInfo implements Serializable {
        private String orderSn;
        private Date createTime;
        private Date payTime;
        private Date bonusAddTime;
        private BigDecimal actualAmount;
        private String orderStatus;
        private Integer totalPointsNum;
        private Integer consumePoints=0;
        private Integer awardPoints=0;
        private Integer activityPoints=0;
        private Integer signIn;
        private String grade;
        private String businessType;
        private String marketingName;
        private Integer pointNum;



    }
}
