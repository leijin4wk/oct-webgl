package com.oyo.ump.member.service;

import com.oyo.common.response.BaseResponse;
import com.oyo.ump.member.common.constants.MemberConstants;
import com.oyo.ump.member.service.bo.MemberDetailBO;
import com.oyo.ump.member.service.bo.MemberEditBO;
import com.oyo.ump.member.service.bo.MemberInfoBO;
import com.oyo.ump.member.service.bo.SyncMemberGradeRequestBO;
import com.oyo.ump.member.service.dto.MemberRegisterDTO;

import java.util.List;

/**
 * @Description: 会员信息接口
 * @Author: fang
 * @create: 2019-03-22
 **/
public interface MemberInfoService {
    /**
     * 提供对外的领域内的会员信息查询
     * @param userId
     * @return
     */
    default MemberInfoBO getMemberInfoByUserId(Long userId){
        return getMemberInfoByUserId(userId,"OYO");
    }

    MemberInfoBO getMemberInfoByUserId(Long userId,String tenant);


    default List<MemberInfoBO> getMemberInfoByUserIdList(List<Long> userIds){
        return getMemberInfoByUserIdList(userIds,"OYO");
    }

    List<MemberInfoBO> getMemberInfoByUserIdList(List<Long> userIds,String tenant);


    MemberDetailBO getMemberDetailByUserId(Long userId,String tenant);

    /**
     * 从db获取会员等级信息
     * @param userId
     * @return
     */
    default MemberInfoBO getMemberInfoFromDB(Long userId){
        return getMemberInfoFromDB(userId,"OYO");
    }

    MemberInfoBO getMemberInfoFromDB(Long userId,String tenant);


    /**
     * 清除会员缓存
     * @param userId
     */
    default void clearMemberInfoCache(Long userId){
        clearMemberInfoCache(userId,"OYO");
    }

    void clearMemberInfoCache(Long userId,String tenant);


    MemberEditBO updateUserInfoByUserId(Long userId, String certificateNo);

    default void registerMember(Long userId){
        MemberRegisterDTO memberRegisterDTO=new MemberRegisterDTO();
        memberRegisterDTO.setUserId(userId);
        memberRegisterDTO.setTenant(MemberConstants.OYO_TENANT);
        memberRegisterDTO.setPlatform(MemberConstants.OYO_TENANT);
        registerMemberV2(memberRegisterDTO);
    }

    /**
     * 会员注册支持多租户
     */
    void registerMemberV2(MemberRegisterDTO memberRegisterDTO);

    /**
     * 会员同步
     * @return
     */
    Boolean syncMemberGrade(SyncMemberGradeRequestBO requestBO);

    void asynProess(Long userId,String tenant);
}
