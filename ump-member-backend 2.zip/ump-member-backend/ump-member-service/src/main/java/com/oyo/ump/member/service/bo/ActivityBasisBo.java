package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;

@Data
public class ActivityBasisBo implements Serializable {
    private Long id;
    private String activityName;
}
