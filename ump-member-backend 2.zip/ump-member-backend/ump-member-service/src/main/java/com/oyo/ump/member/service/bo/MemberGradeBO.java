package com.oyo.ump.member.service.bo;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author Dong
 * @Classname MemberGradeBO
 * @Description 会员身份信息BO
 * @Date 2019-03-30
 */
@Data
public class MemberGradeBO implements Serializable {
    private Long id;
    private Long userId;
    private String grade;
    private Integer gradeOrd;
    private Integer gradeId;
    private Integer previousGradeId;
    private String gradeName;
    private Integer updateRuleType;
    private Integer validPeriod;
    private Integer roomNights;
    private Integer relegationNights;
    private Integer noShow;
    private Date validTime;
    private Date updateTime;
    private Date gradeUpdateTime;
}
