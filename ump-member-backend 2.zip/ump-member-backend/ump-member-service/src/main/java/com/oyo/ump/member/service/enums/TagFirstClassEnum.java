package com.oyo.ump.member.service.enums;


import com.google.common.collect.Maps;

import java.util.Map;

public enum TagFirstClassEnum {
    BASIC_INFO("1","基础信息"),
    BEHAVIOR_INFO("2","行为信息"),
    TRADE_INFO("3","交易信息"),
    PREFERENCE_INFO("4", "偏好信息");

    private final String code;
    private final String name;
    private static Map<String,String> initMap= Maps.newHashMap();
    static  {
        TagFirstClassEnum[] values = values();
        for (int i = 0; i <values.length ; i++) {
            initMap.put(values[i].code,values[i].name);
        }

    }

    public String getCode() {
        return code;
    }
    public String getName() {
        return name;
    }
    TagFirstClassEnum(String code, String name){
     this.name=name;
     this.code=code;
    }
    public static String getNameByCode(String code){
       return initMap.containsKey(code)?initMap.get(code):"";
    }

}
