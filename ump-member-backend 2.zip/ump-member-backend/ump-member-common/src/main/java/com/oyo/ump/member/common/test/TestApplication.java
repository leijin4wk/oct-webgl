package com.oyo.ump.member.common.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * @author Ding
 * @description
 * @date 2019-02-03
 */
@ComponentScan(basePackages={"com.oyo.ump", "top.rdfa.framework"})
@SpringBootApplication
public class TestApplication {

    public static void main(String[] args) {
        SpringApplication.run(TestApplication.class, args);
    }

}
