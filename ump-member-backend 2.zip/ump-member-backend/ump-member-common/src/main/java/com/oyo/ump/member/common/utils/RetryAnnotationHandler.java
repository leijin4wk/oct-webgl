package com.oyo.ump.member.common.utils;

import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

/**
 * @Description:重试处理类
 * @Author: fang
 * @create: 2019-10-31
 **/
@Slf4j
@Aspect
@Component
public class RetryAnnotationHandler {

    @Pointcut("@annotation(com.oyo.ump.member.common.utils.Retry)")
    public void pointCut(){
    }
    @Around("pointCut()")
    public Object retryProcess(ProceedingJoinPoint point)throws Throwable{
        String method = "";
        Object result =null;
        Retry annotation=null;
        try {
            MethodSignature methodSignature=(MethodSignature) point.getSignature();
            annotation= methodSignature.getMethod().getAnnotation(Retry.class);
            method = methodSignature.getName();
            result = point.proceed();
            RetryUtil.addTask(point, annotation.retry(),annotation.interval(), result,annotation.result(),null,annotation.exception(),annotation.field());
            return result;
        }catch (Exception e) {
            log.error("retry error,method:{},param:{}",method, JSON.toJSONString(point.getArgs()),e);
            RetryUtil.addTask(point, annotation.retry(),annotation.interval(), result,annotation.result(),e,annotation
                .exception(),annotation.field());
        }
        return null;
    }


}
