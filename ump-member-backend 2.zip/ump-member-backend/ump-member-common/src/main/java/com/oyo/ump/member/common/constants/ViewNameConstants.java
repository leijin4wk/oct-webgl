package com.oyo.ump.member.common.constants;

import org.springframework.beans.factory.annotation.Value;
/**
 * 系统中定义的几个视图
* @author leijin
* @date 2019-11-20 17:16
**/
public class ViewNameConstants {

    public static final String EVENT_VIEW_DEFINE="event_view";


    public static final String BOOKING_VIEW_DEFINE="booking";

    public static final String USERS_VIEW_DEFINE="users";
}
