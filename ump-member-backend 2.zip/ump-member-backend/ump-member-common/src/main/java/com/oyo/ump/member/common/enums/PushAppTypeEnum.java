package com.oyo.ump.member.common.enums;

public enum PushAppTypeEnum {

    OYO_APP(0,"OYO酒店客户端"),
    APOLLO_APP(2,"apollo客户端");

    private  final Integer type;
    private final String name;

    PushAppTypeEnum(Integer type, String name) {
        this.type = type;
        this.name = name;
    }

    public Integer getType() {
        return type;
    }
    public String getName() {
        return name;
    }
}
