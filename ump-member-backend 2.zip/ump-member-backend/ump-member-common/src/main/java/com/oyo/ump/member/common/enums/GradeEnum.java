package com.oyo.ump.member.common.enums;


import com.google.common.collect.Maps;

import java.util.Map;

public enum GradeEnum {

    GRADE_V1(1,"V1","OYO"),
    GRADE_V2(2,"V2","OYO"),
    GRADE_V3(3,"V3","OYO"),
    GRADE_V4(4,"V4","OYO"),
    GRADE_JP_V1(11,"V1","OYO_JP"),
    GRADE_JP_V2(12,"V2","OYO_JP"),
    GRADE_JP_V0(0,"V0","OYO_JP");



    private  final int gradeId;
    private final String grade;
    private final String tenant;

    GradeEnum(Integer gradeId, String grade,String tenant) {
        this.gradeId = gradeId;
        this.grade = grade;
        this.tenant=tenant;
    }
    private static Map<String,Integer> gradeMap= Maps.newHashMap();
   static  {
        GradeEnum[] values = values();
        for (int i = 0; i <values.length ; i++) {
            gradeMap.put(values[i].grade+values[i].tenant,values[i].gradeId);
        }

    }

    public Integer getGradeId() {
        return gradeId;
    }

    public String getGrade() {
        return grade;
    }
    public static Integer getGradeByName(String grade,String tenant){
        return gradeMap.get(grade+tenant);
    }
}
