package com.oyo.ump.member.common.utils;

import io.netty.util.HashedWheelTimer;
import io.netty.util.TimerTask;

import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * @Description:
 * @Author: fang
 * @create: 2019-10-31
 **/
public class RetryWheelTimer {
    private static HashedWheelTimer timer = new HashedWheelTimer(50L,
            TimeUnit.MILLISECONDS,
            512);

    public static void addTask(TimerTask task,Long delayTime){
            timer.newTimeout(task,delayTime, TimeUnit.MILLISECONDS);
    }
}
