package com.oyo.ump.member.common.enums;

public enum TemplateUrlTypeEnum {

    C_APP(1,"C端appPush链接"),
    C_WECHAT_MINIAPP(2,"C端微信小程序链接"),
    C_SMS(3,"C端用户短信链接"),
    C_WECHAT_PUBLICACCOUNT(4,"C端微信公众号链接"),
    APOLLO(5,"阿波罗APP链接"),
    B_WECHAT_MINIAPP(6,"B端微信小程序链接"),
    B_WECHAT_PUBLICACCOUNT(7,"B端微信公众号链接");

    private  final Integer type;
    private final String name;

    TemplateUrlTypeEnum(Integer type, String name) {
        this.type = type;
        this.name = name;
    }

    public Integer getType() {
        return type;
    }
    public String getName() {
        return name;
    }
}
