package com.oyo.ump.member.common.config;
import com.google.common.collect.Lists;
import com.oyo.sso.authorization.context.ListPermissionContext;
import com.oyo.sso.authorization.context.PermissionContext;
import com.oyo.sso.authorization.filter.SsoAuthorizationFilter;
import com.oyo.sso.authorization.permission.Permission;
import com.oyo.sso.core.config.SsoConstant;
import com.oyo.sso.core.filter.SsoFilter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

/**
 * @Description: 单点登陆配置类
 * @Author: fang
 * @create: 2019-03-25
 **/
@Configuration
public class SsoConfig {
    @Value("${oyo.sso.cas.server}")
    private String  casServer;

    //当前服务退出的url
    @Value("${oyo.sso.client.logout.path}")
    private String clientLogoutPath;

    //jwt验签公钥
    @Value("${oyo.sso.cas.public.key}")
    private String publicKey;

    //单点登录的前端服务地址
    @Value("${oyo.sso.server}")
    private String ssoServer;



    //单点登录过滤器
    @Bean
    public FilterRegistrationBean ssoFilterRegistration() {


        // filter
        FilterRegistrationBean registration = new FilterRegistrationBean();


        registration.setName("SsoFilter");
        registration.setOrder(1);
        registration.addUrlPatterns("/member/package/*","/member/costRule/*","/member/gainRule/*","/member/crowd/*",
                "/member/hotel/*","/member/detail/*","/member/order/*","/member/privilege/*","/member/push/*",
                "/member/eventDefine/*","/member/pushTemplateMap/*","/member/v1/*","/member/ProfileDict/*","/member/pushTemplate/*",
                "/api/v1/user","/api/logout");
        registration.setFilter(new SsoFilter());

        //设置不需要登录久访问的接口，目前只支持以字符数组方式的url匹配
        String excludePath = "/ping,/member/grade/queryall,/member/identity/*";

        //设置不需要登录访问的url
        registration.addInitParameter(SsoConstant.SSO_EXCLUDE_PATHS, excludePath);

        //设置单点中央认证的服务地址，http方式
        registration.addInitParameter(SsoConstant.SSO_CAS_SERVER, casServer);

        //设置当前client退出地址
        registration.addInitParameter(SsoConstant.SSO_CLIENT_LOGOUT_PATH, clientLogoutPath);

        //设置jwt 验签公钥，需要去缪斯那边去申请
        registration.addInitParameter(SsoConstant.SSO_PUBLIC_KEY, publicKey);

        //设置sso前端登录服务的地址，用来当验证没有登录，跳转的地址
        registration.addInitParameter(SsoConstant.SSO_SERVER, ssoServer);

        //当前服务在缪斯中注册的key，用来拿权限列表
        registration.addInitParameter(SsoConstant.CLIENT_SERVICE, "crm");
        return registration;
    }





    //权限过滤器
    @Bean
    public FilterRegistrationBean PermissionFilterRegistration() {




        // filter
        FilterRegistrationBean registration = new FilterRegistrationBean();


        registration.setName("SsoPermissionFilter");
        registration.setOrder(2);
//        registration.addUrlPatterns("/member/*");
        registration.addUrlPatterns("/member/package/*","/member/costRule/*","/member/gainRule/*","/member/crowd/*",
                "/member/hotel/*","/member/detail/*","/member/order/*","/member/privilege/*","/member/push/*",
                "/member/eventDefine/*","/member/pushTemplateMap/*","/member/v1/*","/member/ProfileDict/*","/member/pushTemplate/*"
        );



        List<Permission> permissions = Lists.newArrayList();

        PermissionContext permissionContext = new ListPermissionContext(permissions);

        SsoAuthorizationFilter ssoAuthorizationFilter = new SsoAuthorizationFilter(permissionContext);


        //当前服务在缪斯中注册的key，用来拿权限列表
        registration.addInitParameter(SsoConstant.CLIENT_SERVICE, "crm");

        //设置单点中央认证的服务地址，http方式。用来获取权限
        registration.addInitParameter(SsoConstant.SSO_CAS_SERVER, casServer);

        //设置登录后是否需要返回整个资源树: true-是、false-否
        registration.addInitParameter(SsoConstant.NEED_QUERY_DETAIL_TREES, String.valueOf(true));

        registration.setFilter(ssoAuthorizationFilter);
        return registration;
    }

}
