package com.oyo.ump.member.common.enums;

import org.assertj.core.util.Lists;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Dong
 * @Description
 * @Date 2019-09-07
 */
public enum WeChatPublicAccountEnum {
    WECHAT_OYO_HOTEL("wx03ef434e8f6195b4","OYO酒店","WECHAT_OYO_HOTEL",1);

    private String appId;
    private String mp;
    private String appNme;
    private Integer userType;

    public String getAppId(){return  appId;}

    public String getMp(){return  mp;}

    public String getAppNme(){return appNme;}

    public Integer getUserType(){return userType;}


    WeChatPublicAccountEnum(String appId, String mp, String appNme, Integer userType){
        this.appId = appId;
        this.mp = mp;
        this.appNme = appNme;
        this.userType = userType;
    }

    private static Map<String, WeChatPublicAccountEnum> enumMap = new HashMap<>();
    static {
        WeChatPublicAccountEnum[] values = values();
        for(WeChatPublicAccountEnum e : values){
            enumMap.put(e.getAppId(), e);
        }
    }

    /**
     * 获取枚举元素
     * @param appId
     * @return
     */
    public static WeChatPublicAccountEnum getByAppId(String appId){
        return enumMap.get(appId);
    }

    /**
     * 根据类型获取枚举元素
     * @param userType（1-c端，2-b端）
     * @return
     */
    public static List<WeChatPublicAccountEnum> getByUserType(Integer userType){
        Map<Integer, List<WeChatPublicAccountEnum>> enumMap = new HashMap<>();
        List<WeChatPublicAccountEnum> cList = Lists.newArrayList();
        List<WeChatPublicAccountEnum> bList = Lists.newArrayList();
        WeChatPublicAccountEnum[] values = values();
        for(WeChatPublicAccountEnum e : values){
            if(1==e.getUserType()){
                cList.add(e);
            }else if(2==e.getUserType()){
                bList.add(e);
            }
        }
        enumMap.put(1,cList);
        enumMap.put(2,bList);
        return enumMap.get(userType);
    }
}
