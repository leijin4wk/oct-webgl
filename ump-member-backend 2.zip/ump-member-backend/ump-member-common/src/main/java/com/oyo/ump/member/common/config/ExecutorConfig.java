package com.oyo.ump.member.common.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.ThreadPoolExecutor;

/**
 * @Description: 线程池
 * @Author: fang
 * @create: 2019-04-29
 **/
@Configuration
@EnableAsync
public class ExecutorConfig {
    private int corePoolSize = 20;
    private int maxPoolSize = 200;
    private int queueCapacity = 100;

    @Bean
    public ThreadPoolTaskExecutor threadPoolTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(corePoolSize);
        executor.setMaxPoolSize(maxPoolSize);
        executor.setQueueCapacity(queueCapacity);
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        executor.setThreadNamePrefix("ump—member-task-thread-" + executor);
        executor.initialize();
        return executor;
    }

    @Bean("pushThreadPoolTaskExecutor")
    public ThreadPoolTaskExecutor pushThreadPoolTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(corePoolSize);
        executor.setMaxPoolSize(maxPoolSize);
        executor.setQueueCapacity(queueCapacity);
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        executor.setThreadNamePrefix("ump—member-push-task-thread-" + executor);
        executor.initialize();
        return executor;
    }

    @Bean("insertPushThreadPoolTaskExecutor")
    public ThreadPoolTaskExecutor insertPushThreadPoolTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(corePoolSize);
        executor.setMaxPoolSize(maxPoolSize);
        executor.setQueueCapacity(queueCapacity);
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        executor.setThreadNamePrefix("ump—member-insert-push-task-thread-" + executor);
        executor.initialize();
        return executor;
    }
}
