package com.oyo.ump.member.common.enums;

/**
 * @author Dong
 * @Description
 * @Date 2019-09-07
 */
public enum SmsTemplateTypeEnum {

    V_CODE(0, "短信验证码"),
    NOTIFICATION(1, "通知短信"),
    MARKETING(2, "推广短信");

    private int ordinal;
    private String name;

    SmsTemplateTypeEnum(int ordinal, String name) {
        this.ordinal = ordinal;
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public int getOrdinal() {
        return ordinal;
    }

}
