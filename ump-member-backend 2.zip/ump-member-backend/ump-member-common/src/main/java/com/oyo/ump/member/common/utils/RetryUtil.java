package com.oyo.ump.member.common.utils;

import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Objects;

/**
 * @Description: 重试方法工具类
 * @Author: fang
 * @create: 2019-11-01
 **/
@Slf4j
public class RetryUtil {

     public static void addTask(ProceedingJoinPoint point, int retry, long interval, Object result, String[] resultArray, Throwable e, Class<? extends Throwable>[] exceptionClasses, String fieldStr) {
        if (retry <= 0) {
            MethodSignature methodSignature = (MethodSignature) point.getSignature();
            methodSignature.getParameterNames();
            log.error("method:{} retry result error,param:{}", methodSignature.getName(), JSON.toJSONString(point.getArgs()));
            return;
        }
        if (resultArray.length > 0 && result != null) {
            if (StringUtils.isEmpty(fieldStr)) {
                if (Arrays.stream(resultArray).filter(Objects::nonNull).allMatch(object -> object.equals(result.toString()))) {
                    return;
                }
            } else {
                try {
                    Field field = result.getClass().getDeclaredField(fieldStr);
                    field.setAccessible(true);
                    Object fieldValue = field.get(result);
                    if (fieldValue != null) {
                        if (Arrays.stream(resultArray).filter(Objects::nonNull).allMatch(object -> object.equals(fieldValue.toString()))) {
                            return;
                        }
                    }
                } catch (Exception ex) {
                    log.error("retry util reflect error", e);
                }
            }

        }
        if (e != null && !Arrays.stream(exceptionClasses).allMatch(aClass -> aClass.isInstance(e))) {
            return;
        }
        RetryTimeTask retryTimeTask = RetryTimeTask.builder().joinPoint(point).retry(retry).interval(interval).results(resultArray).exceptionClasses(exceptionClasses).field(fieldStr).build();
        RetryWheelTimer.addTask(retryTimeTask, interval);

    }
}
