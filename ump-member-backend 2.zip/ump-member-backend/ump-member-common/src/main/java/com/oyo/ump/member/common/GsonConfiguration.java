package com.oyo.ump.member.common;

import com.google.gson.Gson;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Configuration
@Component
@EnableAutoConfiguration
public class GsonConfiguration {


    @Bean(name = "fromGson")
    public Gson getGson() {
        return new Gson();
    }

    @Bean(name = "toGson")
    public Gson getDefaultGson() {
        return new Gson();
    }
}
