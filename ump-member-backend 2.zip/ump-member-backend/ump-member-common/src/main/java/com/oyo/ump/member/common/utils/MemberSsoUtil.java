package com.oyo.ump.member.common.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.google.common.collect.Lists;
import com.oyo.sso.core.util.SsoUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;

import java.util.*;

/**
 * 用户缪斯系统信息工具类
 *
 * @return
 */
@Slf4j
public class MemberSsoUtil {

    static List<String> codeList = Lists.newArrayList();
    /**
     * 将json字符串解析为map
     */
    public static List<String> parseJsonString(String json) {
        LinkedHashMap<String, Object> jsonMap = JSON.parseObject(json, new TypeReference<LinkedHashMap<String, Object>>() {
        });
        for (Map.Entry<String, Object> entry : jsonMap.entrySet()) {
            parseJsonMap(entry);
        }
        return codeList;
    }

    /**
     * 解析map获取code值
     */
    public static void parseJsonMap(Map.Entry<String, Object> entry) {
        System.out.println(entry.getKey() + ":" + entry.getValue());
        //如果是单个map继续遍历
        if (entry.getValue() instanceof Map) {
            LinkedHashMap<String, Object> jsonMap = JSON.parseObject(entry.getValue().toString(), new TypeReference<LinkedHashMap<String, Object>>() {
            });
            for (Map.Entry<String, Object> entry2 : jsonMap.entrySet()) {
                parseJsonMap(entry2);
            }
        }
        //如果是list就提取出来
        if (entry.getValue() instanceof List) {
            List list = (List) entry.getValue();
            for (int i = 0; i < list.size(); i++) {
                //如何还有，循环提取
                LinkedHashMap<String, Object> jsonMap = JSON.parseObject(list.get(i).toString(), new TypeReference<LinkedHashMap<String, Object>>() {
                });
                for (Map.Entry<String, Object> entry3 : jsonMap.entrySet()) {
                    parseJsonMap(entry3);
                }
            }
        }
        //如果是String就获取它的值
        if ("code".equals(entry.getKey()) && entry.getValue() instanceof String) {
            System.out.println(entry.getKey() + ":" + entry.getValue());
            codeList.add(entry.getValue().toString());
        }
    }
}
