package com.oyo.ump.member.common.exception;

import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import lombok.Getter;

/**
 * @author fang
 * @description
 * @date 2019-04-30
 */
@Getter
public class UmpException extends RuntimeException {

    private BaseResponse resp;

    public UmpException(String msg) {
        super(msg);
    }

    public UmpException(ResponseCode responseCode, String msg) {
        super(msg);
        this.resp = BaseResponse.fail(responseCode.getCode(), msg);
    }

    public UmpException(String code, String msg) {
        super(msg);
        this.resp = BaseResponse.fail(code, msg);
    }

    public UmpException(ResponseCode responseCode) {
        this.resp = BaseResponse.fail(responseCode.getCode(), responseCode.getMsg());
    }
}
