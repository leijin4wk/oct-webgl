package com.oyo.ump.member.common.constants;

/**
 * @author Dong
 * @Classname MemberConstans
 * @Description 会员中心用到的常量
 * @Date 2019-03-30
 */
public class MemberConstants {
    /**
     * 自然
     */
    public static final Integer UPDATE_GRADE_BY_NATURE = 1;
    /**
     * 升级包
     */
    public static final Integer UPDATE_GRADE_BY_PACKAGE = 2;
    /**
     * 通过OTA 升级
    * @author leijin
    * @date 2019-08-08 18:30
    **/
    public static final Integer UPDATE_GRADE_BY_OTA=6;

    /**
     * 升级
     */
    public static final Integer UPGRADE = 1;
    /**
     * 降级
     */
    public static final Integer DEGRADE = 2;

    /**
     * 保级
     */
    public static final Integer RELEGATION = 3;
    /**
     * 间夜数清零
     */
    public static final Integer RESET_NIGHTS = 4;
    /**
     * 会员默认折扣
     */
    public static final int DEFAULT_DISCOUNT = 95;
    /**
     * 会员默认折扣
     */
    public static final int FREIGHT_DISCOUNT = 95;
    /**
     * 会员计算折扣的折扣数
     */
    public static final int CALCULATE_DISCOUNT = 100;

    /**
     * V1等级
     */
    public static final String V1 = "V1";
    /**
     * V1等级ord
     */
    public static final Integer V1_ORD = 1;
    /**
     * V2等级
     */
    public static final String V2 = "V2";
    /**
     * V2等级ord
     */
    public static final Integer V2_ORD = 2;
    /**
     * V3等级
     */
    public static final String V3 = "V3";
    /**
     * V3等级ord
     */
    public static final Integer V3_ORD = 3;

    /**
     * 升级包channel
     */
    public static final String PACKAGE_CHANNEL = "OYO_APP";

    /**
     * 调用用户中心 默认pageSize
     */
    public static final  Integer PAGE_SIZE = 20;

    /**
     * 发券失败重试次数
     */
    public static final  Integer RETRY_TIMES = 4;
    /**
     * 默认发券张数
     */
    public static final  Integer COUPON_NUM = 1;

    /**
     * 发券失败redis缓存key
     */
    public static final  String SEND_COUPON_REDIS = "ump-member-backend:coupon:SendCoupon";
    /**
     * 废券失败redis缓存key
     */
    public static final  String FAIL_COUPON_REDIS = "ump-member-backend:coupon:FailureCoupon";

    /**
     * 人群的创建方式，1 通过标签创建
     */
    public static final String CREATE_BY_TAG = "1";
    /**
     * 人群的创建方式，2 用户自定义创建
     */
    public static final String CREATE_BY_CUSTOM = "2";

    /**
     * 自定义人群创建，分批插入用户的基数
     */
    public static final Integer INSERT_CROWD_SIZE = 2500;

    /**
     * 邮箱转userId,每批数量
     */
    public static final Integer EMAIL_TO_USERID_SIZE = 2000;
    /**
     * 工号转userId,调用用户中心批量接口每批数量
     */
    public static final Integer EMPLOYEE_TO_USERID_SIZE = 100;

    /**
     * push发送规则，1立即发送；2定时发送；3重复发送
     */
    public static final Integer SEND_IMMEDIATELY = 1;
    public static final Integer SEND_REGULARLY = 2;
    public static final Integer SEND_REPEATEDLY = 3;

    /**
     * push定时任务执行周期
     */
    public static final Long TIME_INTERVAL=1000*60*30L;

    public static final String BONUS_POINTS_TYPE = "2";

    public static final String OYO_TENANT="OYO";
    public static final String OYO_JP_TENANT="OYO_JP";
    public static final String FEIZHU_PLATEFORM="RM008007_FZ";

    /**
     * 推送模板应用渠道，会员中心为1
     */
    public static final Integer MEMBER_CHANNEL = 1;

    /**
     * 调用push发送dubbo服务异常重试次数
     */
    public static final Integer PUSH_RETRY_TIME = 3;

    public static final  String POINT_EXCHANGER = "ump-member-backend:point:cost:exchange";

    public static final  String POINT_GAIN_RULE = "ump-member-backend:point:gain:rule";


    public static final Long POINT_EXCHANGER_EXPIRED=60*60*3L;
    /**
     * 有效期类型（1-次年某月某日； 2-自获取之日起N年（月、日））
     */
    public static final Integer FIXED_TYPE = 1;
    /**
     * 有效期类型（1-次年某月某日； 2-自获取之日起N年（月、日））
     */
    public static final Integer UNFIXED_TYPE = 2;
    /**
     * 有效期类型1的长度
     */
    public static final Integer FIXED_TYPE_LENGTH = 8;
    /**
     * 非会员push默认的memberId
     */
    public static final Long NOT_MEMBER_MEMBER_ID=0L;

    /**
     * 目标用户类型（1-C端用户，2-B端用户）
     */
    public static final Integer USER_TYPE_FOR_C = 1;
    public static final Integer USER_TYPE_FOR_B = 2;
}
