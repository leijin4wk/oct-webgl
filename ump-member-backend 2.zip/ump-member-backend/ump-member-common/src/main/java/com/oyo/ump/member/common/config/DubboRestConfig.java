package com.oyo.ump.member.common.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.ServletListenerRegistrationBean;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.alibaba.dubbo.remoting.http.servlet.BootstrapListener;
import com.alibaba.dubbo.remoting.http.servlet.DispatcherServlet;

/**
 * Rest Protocol Config
 * @author zhao.liangshu
 */
//@Configuration
public class DubboRestConfig {
	
	public static final String REST_SERVLET_URL_MAPPING = "dubbo.rest.servlet.urlmapping";
	
	public static final String REST_SERVLET_NAME = "dubbo-rest-servlet-name";
	
	public static final String DEFAULT_URL_MAPPING = "/api/*";

	@Value("${" + REST_SERVLET_URL_MAPPING + ":}")
	private String servletUrlMapping;

	@Bean("restServletRegistrationBean")
	public ServletRegistrationBean<DispatcherServlet> servletRegistrationBean() {
		ServletRegistrationBean<DispatcherServlet> bean = new ServletRegistrationBean<DispatcherServlet>(
				new DispatcherServlet());
		bean.setLoadOnStartup(2);
		bean.setName(REST_SERVLET_NAME);
		if (servletUrlMapping != null && !servletUrlMapping.isEmpty()) {
			bean.addUrlMappings(servletUrlMapping.trim());
		} else {
			bean.addUrlMappings(DEFAULT_URL_MAPPING);
		}
		return bean;
	}

	@Bean("restBootstrapListenerBean")
	public ServletListenerRegistrationBean<BootstrapListener> bootstrapListenerBean() {
		ServletListenerRegistrationBean<BootstrapListener> bootstrapListener = new ServletListenerRegistrationBean<BootstrapListener>(
				new BootstrapListener());
		return bootstrapListener;
	}

}
