package com.oyo.ump.member.common.enums;

/**
 * @author Dong
 * @Description
 * @Date 2019-09-07
 */
public enum SmsSignatureEnum {

    OYO_WECHAT_PLATFORM(1, "OYO微信平台"),
    OYO_HOTEL(2, "OYO酒店");

    private int ordinal;
    private String name;

    SmsSignatureEnum(int ordinal, String name) {
        this.ordinal = ordinal;
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public int getOrdinal() {
        return ordinal;
    }

}

