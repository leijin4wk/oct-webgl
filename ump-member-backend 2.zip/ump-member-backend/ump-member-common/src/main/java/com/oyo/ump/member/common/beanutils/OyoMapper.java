package com.oyo.ump.member.common.beanutils;

import com.oyo.common.response.PagedResponse;
import org.dozer.Mapper;

import java.util.List;

public interface OyoMapper extends Mapper{
	
	public <T> List<T> mapList(List sourceList, Class<T> destinationClazz);

	public <T> PagedResponse<T> mapPage(PagedResponse sourceList, Class<T> destinationClazz);
}
