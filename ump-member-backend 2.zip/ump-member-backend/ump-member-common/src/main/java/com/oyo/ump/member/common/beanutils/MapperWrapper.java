package com.oyo.ump.member.common.beanutils;

public class MapperWrapper {
	
	private static OyoMapper mapper = null;
	
	static {
		//we could specify some configure file if we want
		mapper= new OyoDozerBeanMapper();
	}
	
	public static OyoMapper instance() {
		 return mapper;
		
	}

}
