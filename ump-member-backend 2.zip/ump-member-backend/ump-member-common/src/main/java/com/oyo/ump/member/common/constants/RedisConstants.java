package com.oyo.ump.member.common.constants;

/**
 * 缓存key
 * @author tim.li
 */
public class RedisConstants {

    /**
     * 基础KEY
     */
    public static final String BASE = "ump-member-backend:";

    /**
     *  双写失败key
     */
    public static final String WRITE_FAILED_KEY = BASE +"writeFailed";
    /**
     * 会员信息缓存
     */
    public static final String MEMBERINFO = "ump-member-backend:memberInfo:";
    /**
     * 会员等级缓存
     */
    public static final String MEMBERGRADE = "ump-member-backend:memberGrade:";
    /**
     * 活动push信息缓存
     */
    public static final String PUSH_PROMOTION = "ump-member-backend:memberPromotion:";
    /**
     * 会员积分job已计算过用户 缓存
     */
    public static final String MEMBERPOINTS = "ump-member-backend:memberPoints:userInfo";

    public static final String MEMBER_HOTEL = "ump-member-backend:memberHotels:";

    public static final String MEMBER_OYO_MONEY = "ump-member-backend:memberOyoMoney:";

    public static final Long MEMBER_OYO_MONEY_EXPIRE = 60*60*36L;

    public static final String MEMBER_DIM_PREFIX = "ump-member-backend:memberDimPrefix:";
    public static final String MEMBER_DISTINCT_DIM_PREFIX = "ump-member-backend:memberDimPrefix:distinct:";

    public static final String MEMBER_CROWD_PREFIX = "ump-member-backend:memberCrowdPrefix:";

    public static final Long MEMBER_DIM_EXPIRE = 60*60*3L;
    /**
     * 活动push信息缓存 过期时间
     */
    public static final Long PUSH_PROMOTION_EXPIRE = 60*60*24L;

    public static final String BONUS_DELAY_PREFIX = "ump-member-backend:memberBonusDelayPrefix:";






}
