package com.oyo.ump.member.common.enums;

import com.google.common.collect.Maps;
import com.oyo.ump.member.common.constants.MemberConstants;
import org.assertj.core.util.Lists;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * 等级刷新规则枚举类
 * @author Dong
 */

public enum GradeRefreshRuleEnum {
    /**
     * 等级刷新规则
     */
    SYS_ERROR("000", 0, 0, 0, "异常保留", "SYS"),

    OYO_STAY_V1_V2("112", 1, 2, 1, "入住V1升V2", MemberConstants.OYO_TENANT),
    OYO_STAY_V2_V3("123", 2, 3, 1, "入住V2升V3", MemberConstants.OYO_TENANT),
    OYO_STAY_V3_V4("134", 3, 4, 1, "入住V3升V4", MemberConstants.OYO_TENANT),
    OYO_STAY_V4_V3("143", 4, 3, 1, "V4降级V3", MemberConstants.OYO_TENANT),
    OYO_PACKAGE_V1_V2("212", 1, 2, 2, "升级包V1升V2", MemberConstants.OYO_TENANT),
    OYO_PACKAGE_V1_V3("213", 1, 3, 2, "升级包V1升V3", MemberConstants.OYO_TENANT),
    OYO_PACKAGE_V2_V3("223", 2, 3, 2, "升级包V2升V3", MemberConstants.OYO_TENANT),
    OYO_PACKAGE_V2_V1("221", 2, 1, 2, "升级包退款V2降V1", MemberConstants.OYO_TENANT),
    OYO_PACKAGE_V3_V1("231", 3, 1, 2, "升级包退款V3降V1", MemberConstants.OYO_TENANT),
    OYO_PACKAGE_V3_V2("232", 3, 2, 2, "升级包退款V3降V2", MemberConstants.OYO_TENANT),

    OYO_JP_REGISTER_V1("10011", 0, 11, 1, "注册升初级", MemberConstants.OYO_JP_TENANT),
    OYO_JP_REGISTER_V1_V2("11112", 11, 12, 1, "V1升级V2", MemberConstants.OYO_JP_TENANT),
    OYO_JP_REGISTER_V2_V1("11211", 12, 11, 1, "V2降级V1", MemberConstants.OYO_JP_TENANT),
    OYO_JP_REGISTER_V2_V2("11212", 12, 12, 1, "V2保级V2", MemberConstants.OYO_JP_TENANT),
    OYO_JP_REGISTER_V2("10012", 0, 12, 1, "注册升高级", MemberConstants.OYO_JP_TENANT);


    private final String code;
    private final Integer previousId;
    private final Integer gradeId;
    private final Integer updateRuleType;
    private final String msg;
    private final String tenant;

    GradeRefreshRuleEnum(String code, Integer preGradeId, Integer gradeId, Integer updateRuleType, String msg, String tenant) {
        this.code = code;
        this.previousId = preGradeId;
        this.gradeId = gradeId;
        this.updateRuleType = updateRuleType;
        this.msg = msg;
        this.tenant = tenant;
    }

    public String getCode() {
        return code;
    }

    public Integer getPreviousId() {
        return previousId;
    }

    public Integer getGradeId() {
        return gradeId;
    }

    public Integer getUpdateRuleType() {
        return updateRuleType;
    }

    public String getMsg() {
        return msg;
    }

    public String getTenant() {
        return tenant;
    }

    @Override
    public String toString() {
        return "GradeRefreshRule{" +
                "code='" + code + '\'' +
                ", previousId=" + previousId +
                ", gradeId=" + gradeId +
                ", updateRuleType=" + updateRuleType +
                ", msg='" + msg + '\'' +
                ", tenant='" + tenant + '\'' +
                '}';
    }
    private static List<GradeRefreshRuleEnum> gradeRefreshRuleEnumList = Lists.newArrayList();
    private static Map<String, GradeRefreshRuleEnum> gradeRefreshRuleEnumMap = Maps.newHashMap();
    private static Map<String, List<GradeRefreshRuleEnum>> gradeRefreshRuleEnumListTenantMap = Maps.newHashMap();
    static {
        Arrays.stream(GradeRefreshRuleEnum.values()).forEach(gradeRefreshRuleEnum -> {
            gradeRefreshRuleEnumList.add(gradeRefreshRuleEnum);
            gradeRefreshRuleEnumMap.put(gradeRefreshRuleEnum.getCode(), gradeRefreshRuleEnum);
            if (gradeRefreshRuleEnumListTenantMap.get(gradeRefreshRuleEnum.getTenant()) == null) {
                gradeRefreshRuleEnumListTenantMap.put(gradeRefreshRuleEnum.getTenant(), Lists.newArrayList(gradeRefreshRuleEnum));
            } else {
                List<GradeRefreshRuleEnum> tempList = gradeRefreshRuleEnumListTenantMap.get(gradeRefreshRuleEnum.getTenant());
                tempList.add(gradeRefreshRuleEnum);
                gradeRefreshRuleEnumListTenantMap.put(gradeRefreshRuleEnum.getTenant(), tempList);

            }
        });
    }

    public static List<GradeRefreshRuleEnum> getList() {
        return gradeRefreshRuleEnumList;
    }

    public static List<GradeRefreshRuleEnum> getListByTenant(String tenant) {
        return gradeRefreshRuleEnumListTenantMap.get(tenant);
    }

    public static GradeRefreshRuleEnum getByCode(String code) {
        GradeRefreshRuleEnum ruleEnum = gradeRefreshRuleEnumMap.get(code);
        if (ruleEnum == null) {
            return SYS_ERROR;
        }
        return ruleEnum;
    }
}
