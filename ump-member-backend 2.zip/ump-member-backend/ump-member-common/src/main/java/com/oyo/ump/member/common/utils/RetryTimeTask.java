package com.oyo.ump.member.common.utils;

import io.netty.util.Timeout;
import io.netty.util.TimerTask;
import lombok.Builder;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
/**
 * @Description:
 * @Author: fang
 * @create: 2019-10-31
 **/
@Data
@Builder
@Slf4j
public class RetryTimeTask implements TimerTask {
    private ProceedingJoinPoint joinPoint;
    private Integer retry;
    private Long interval;
    private Class[] exceptionClasses;
    private String[] results;
    private String field;
    @Override
    public void run(Timeout timeout) {
        Object result =null;
        try {
            result =  joinPoint.proceed();
            RetryUtil.addTask(joinPoint, --retry,interval, result,results,null,exceptionClasses,field);
        }catch (Throwable e){
           log.error("retryTask process error",e);
            RetryUtil.addTask(joinPoint, --retry,interval, result,results,e,exceptionClasses,field);
        }

    }

}
