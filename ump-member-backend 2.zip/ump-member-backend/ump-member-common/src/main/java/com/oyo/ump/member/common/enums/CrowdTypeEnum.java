package com.oyo.ump.member.common.enums;

public enum CrowdTypeEnum {

    USER_ID(1,"userId类型人群"),
    PUSH_ID(2,"pushId类型人群"),
    OPEN_ID(3,"openId类型人群"),
    EMPLOYEE_ID(4,"工号类型人群");

    private  final Integer type;
    private final String name;

    CrowdTypeEnum(Integer type, String name) {
        this.type = type;
        this.name = name;
    }

    public Integer getType() {
        return type;
    }
    public String getName() {
        return name;
    }
}
