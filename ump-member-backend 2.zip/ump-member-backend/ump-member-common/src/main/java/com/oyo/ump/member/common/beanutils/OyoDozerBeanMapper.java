package com.oyo.ump.member.common.beanutils;

import com.oyo.common.response.PagedResponse;
import org.dozer.DozerBeanMapper;

import java.util.ArrayList;
import java.util.List;

class OyoDozerBeanMapper extends DozerBeanMapper implements OyoMapper {
	@Override
	public <T> List<T> mapList(List sourceList, Class<T> destinationClazz) {
		List<T> destinationObjs = new ArrayList();
		for(Object obj: sourceList) {
			T destinationObj = (T)this.map(obj, destinationClazz);
			destinationObjs.add(destinationObj);
		}
		return destinationObjs;
	}

	@Override
	public <T> PagedResponse<T> mapPage(PagedResponse sourcePage, Class<T> destinationClazz) {
		PagedResponse<T> response = new PagedResponse<>();
		response.setPageNum(sourcePage.getPageNum());
		response.setPageSize(sourcePage.getPageSize());
		response.setTotalCount(sourcePage.getTotalCount());
		response.setResult(mapList(sourcePage.getResult(), destinationClazz));
		return response;
	}
}
