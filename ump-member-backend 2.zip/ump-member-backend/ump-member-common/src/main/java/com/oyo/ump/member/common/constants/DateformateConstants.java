package com.oyo.ump.member.common.constants;

import java.text.SimpleDateFormat;

public class DateformateConstants {

    public static final String DATE_NORMAL_FORMAT = "yyyy-MM-dd HH:mm:ss";

    public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(DATE_NORMAL_FORMAT);

    public static final SimpleDateFormat SHORT_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");

}
