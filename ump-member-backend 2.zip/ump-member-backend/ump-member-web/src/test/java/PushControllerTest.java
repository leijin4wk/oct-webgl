import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.oyo.common.response.BaseResponse;
import com.oyo.sso.core.user.SsoUser;
import com.oyo.sso.core.util.SsoUtil;
import com.oyo.ump.member.common.test.TestApplication;
import com.oyo.ump.member.service.CustomizedEventService;
import com.oyo.ump.member.service.PushProcessService;
import com.oyo.ump.member.service.PushService;
import com.oyo.ump.member.service.bo.PushBO;
import com.oyo.ump.member.service.bo.PushTemplateParamBo;
import com.oyo.ump.member.service.dto.PushTemplateDTO;
import com.oyo.ump.member.service.enums.TriggerChannelEnum;
import com.oyo.ump.member.web.vo.CrowdListVo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.assertj.core.util.Lists;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.util.*;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.assertNotNull;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class PushControllerTest {

    @Autowired
    private WebApplicationContext context;

    private MockMvc mockMvc;

    @Autowired
    private CustomizedEventService customizedEventService;
    @Autowired
    private PushService pushService;
    @Autowired
    private PushProcessService pushProcessService;

    @Before
    public void setUp() {
        //单个类,项目拦截器无效
//      mvc = MockMvcBuilders.standaloneSetup(new ProductController()).build();
        //项目拦截器有效
        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
    }
    @Test
    public void test01() throws Exception{
        CrowdListVo crowdListVo=new CrowdListVo();
        crowdListVo.setCrowds(new ArrayList<Long>(Arrays.asList(1L,7L,9L)));
        RequestBuilder request = MockMvcRequestBuilders.post("/member/crowd/findCrowdListByIds")
           .contentType(MediaType.APPLICATION_JSON_UTF8)
                .content(JSON.toJSONString(crowdListVo));
        MvcResult mvcResult = mockMvc.perform(request).andReturn() ;
        int status = mvcResult.getResponse().getStatus();
        String content = mvcResult.getResponse().getContentAsString();
        Assert.assertTrue("正确", status == 200);
        Assert.assertFalse("错误", status != 200);
        System.out.println("返回结果："+status);
        System.out.println(content);
    }
    @Test
    public void test02() throws Exception{
        for (int i=0;i<100;i++) {
            RequestBuilder request = MockMvcRequestBuilders.get("/member/push/appPushTemplateList");
            MvcResult mvcResult = mockMvc.perform(request).andReturn() ;
            int status = mvcResult.getResponse().getStatus();
            String content = mvcResult.getResponse().getContentAsString();
            Assert.assertFalse("错误", status != 200);
            System.out.println(content);
        }
    }

    @Test
    public void test03() throws Exception{
        RequestBuilder request = MockMvcRequestBuilders.get("/member/push/pushTemplateList?triggerChannel=3");
        MvcResult mvcResult = mockMvc.perform(request).andReturn() ;
        int status = mvcResult.getResponse().getStatus();
        System.out.println(status);
        String content = mvcResult.getResponse().getContentAsString();
        System.out.println("aaaaaaaaaaaaaa");
        System.out.println(content);

    }


    @Test
    public void testPush04() throws Exception{
        //设置sso user
        SsoUser ssoUser=new SsoUser();
        ssoUser.setUserId(-1L);
        ssoUser.setUserName("admin@oyohotel.com");
        SsoUtil.setUser(ssoUser);
        //调用创建接口
        RequestBuilder request = MockMvcRequestBuilders.post("/member/push/insertOrUpdate")
                .contentType(MediaType.APPLICATION_JSON_UTF8)
                .content("{\"triggerType\":1,\"triggerChannel\":1,\"targetCrowdType\":3,\"grayFlag\":false,\"grayPercent\":0,\"description\":\"\",\"pushName\":\"测试发送\",\"departmentId\":13561,\"actUserType\":\"\",\"actType\":\"\",\"actTypeDetail\":\"\",\"couponCode\":\"\",\"couponAmount\":0,\"couponType\":\"\",\"customCrowdInfo\":\"[{\\\"tagClassSelectValue\\\":\\\"1\\\",\\\"tagType\\\":4,\\\"tagSelectValue\\\":\\\"phone\\\",\\\"tagOperatorValue\\\":\\\"=\\\",\\\"tagValueSelectValue\\\":\\\"18875016131\\\",\\\"relationValue\\\":1}]\",\"pushStatus\":0,\"sendType\":1,\"sendStartTime\":\"\",\"sendEndTime\":\"\",\"sendInterval\":1,\"id\":\"\"}");;
        MvcResult mvcResult = mockMvc.perform(request).andReturn() ;
        int status = mvcResult.getResponse().getStatus();
        Assert.assertTrue(status==200);
        String content = mvcResult.getResponse().getContentAsString();
        System.err.println(content);
        BaseResponse<Integer> baseResponse= JSON.parseObject(content, BaseResponse.class);
        Integer id=baseResponse.getData();
        //调用修改接口
        RequestBuilder request1 = MockMvcRequestBuilders.post("/member/push/insertOrUpdate")
                .contentType(MediaType.APPLICATION_JSON_UTF8)
                .content("{\"triggerType\":1,\"triggerChannel\":1,\"targetCrowdType\":3,\"grayFlag\":false,\"grayPercent\":0,\"description\":\"\",\"pushName\":\"测试发送\",\"departmentId\":13561,\"actUserType\":\"\",\"actType\":\"\",\"actTypeDetail\":\"\",\"couponCode\":\"\",\"couponAmount\":0,\"couponType\":\"\",\"customCrowdInfo\":\"[{\\\"tagClassSelectValue\\\":\\\"1\\\",\\\"tagType\\\":4,\\\"tagSelectValue\\\":\\\"phone\\\",\\\"tagOperatorValue\\\":\\\"=\\\",\\\"tagValueSelectValue\\\":\\\"15721222427\\\",\\\"relationValue\\\":1}]\",\"pushStatus\":0,\"sendType\":1,\"sendStartTime\":\"\",\"sendEndTime\":\"\",\"sendInterval\":1,\"id\":"+id+"}");;
        MvcResult mvcResult1 = mockMvc.perform(request1).andReturn() ;
        int status1 = mvcResult1.getResponse().getStatus();
        Assert.assertTrue(status1==200);
        String content1 = mvcResult1.getResponse().getContentAsString();
        System.err.println(content1);

        //调用创建推送模板接口
        RequestBuilder request2 = MockMvcRequestBuilders.post("/member/push/createTemplate")
                .contentType(MediaType.APPLICATION_JSON_UTF8)
                .content("{\"pushId\":"+id+",\"triggerChannel\":3,\"departmentId\":13561,\"templateInfos\":[{\"key\":1,\"templateTitle\":\"花更少，住更少\",\"templateContent\":\"{{first.DATA}}\\n会员卡ID：{{keyword1.DATA}}\\n所属卡种：{{keyword2.DATA}}\\n开卡时间：{{keyword3.DATA}}\\n{{remark.DATA}}\",\"templateLongLink\":7,\"urlParams\":[{\"name\":\"perfer_citys\",\"type\":2,\"value\":1},{\"name\":\"perfer_city_id\",\"type\":2,\"value\":6},{\"name\":\"utmSource\",\"type\":1,\"value\":\"aa\"},{\"name\":\"utmMedium\",\"type\":1,\"value\":\"bb\"},{\"name\":\"utmCampaign\",\"type\":1,\"value\":\"cc\"},{\"name\":\"utmContent\",\"type\":1,\"value\":\"dd\"}]," +
                        "\"contentParams\":[{\"name\":\"first\",\"type\":1,\"value\":\"花更少，住更少\"},{\"name\":\"keyword1\",\"type\":1,\"value\":\"11\"},{\"name\":\"keyword2\",\"type\":1,\"value\":\"222\"},{\"name\":\"keyword3\",\"type\":1,\"value\":\"3333\"},{\"name\":\"remark\",\"type\":1,\"value\":\"花更少，住更少\"}],\"imageUrl\":\"\",\"appId\":\"wx03ef434e8f6195b4\",\"appName\":\"WECHAT_OYO_HOTEL\",\"smsTemplateType\":\"\",\"smsSgin\":\"\",\"urlType\":1,\"wechatTemplateId\":\"EeBEJ1KpKOLXRLUOK7L8uBHELvCeeB3R6W0yaC2GKnk\",\"miniAppId\":\"\",\"percent\":100}]}");
        MvcResult mvcResult2 = mockMvc.perform(request2).andReturn() ;
        int status2 = mvcResult2.getResponse().getStatus();
        Assert.assertTrue(status2==200);
        String content2 = mvcResult2.getResponse().getContentAsString();
        System.err.println(content2);
        //调用查询推送模板接口
        RequestBuilder request3 = MockMvcRequestBuilders.get("/member/push/queryTemplate?pushId="+id);
        MvcResult mvcResult3 = mockMvc.perform(request3).andReturn() ;
        int status3 = mvcResult3.getResponse().getStatus();
        Assert.assertTrue(status3==200);
        String content3 = mvcResult3.getResponse().getContentAsString();
        System.err.println(content3);

        //更新push发送规则

        //调用修改发送规则
        RequestBuilder request4 = MockMvcRequestBuilders.post("/member/push/insertOrUpdate")
                .contentType(MediaType.APPLICATION_JSON_UTF8)
                .content("{\"pushName\":\"测试微信\",\"departmentId\":13561,\"description\":\"\",\"actUserType\":\"\"," +
                        "\"actType\":\"\",\"actTypeDetail\":\"\",\"couponCode\":\"\",\"couponAmount\":0,\"couponType\":\"\"," +
                        "\"grayFlag\":false,\"grayPercent\":0,\"customCrowdInfo\":\"[{\\\"tagClassSelectValue\\\":\\\"1\\\",\\\"tagType\\\":4,\\\"tagSelectValue\\\":\\\"phone\\\",\\\"tagOperatorValue\\\":\\\"=\\\",\\\"tagValueSelectValue\\\":\\\"18875016131\\\",\\\"relationValue\\\":1}]\",\"targetCrowdType\":3,\"triggerType\":1,\"triggerChannel\":3,\"sendType\":1,\"sendStartTime\":\"\",\"sendEndTime\":\"\",\"sendInterval\":1,\"isFinish\":1,\"id\":"+id+"}");;
        MvcResult mvcResult4 = mockMvc.perform(request4).andReturn() ;
        int status4 = mvcResult4.getResponse().getStatus();
        Assert.assertTrue(status4==200);
        String content4 = mvcResult4.getResponse().getContentAsString();
        System.err.println(content4);

        //调用查询推送模板接口
        RequestBuilder request5 = MockMvcRequestBuilders.get("/member/push/switch?id="+id+"&pushStatus=1");
        MvcResult mvcResult5 = mockMvc.perform(request5).andReturn() ;
        int status5 = mvcResult5.getResponse().getStatus();
        Assert.assertTrue(status5==200);
        String content5 = mvcResult5.getResponse().getContentAsString();
        System.err.println(content5);
        TimeUnit.SECONDS.sleep(50);
    }

    @Test
    public void dynamicBuildSqlTest(){
        PushBO pushBO=pushService.selectById(816L);
        System.out.println(customizedEventService.dynamicBuildSql(pushBO.getTargetCrowdConfig().getTriggerCondition()));
    }

    @Test
    public void eventPush(){
        pushProcessService.sendMessageByPushId(839L,1000L);
    }
    @Test
    //TODO 添加mapper
    public void ApolloPushCrowdSQLFilter(){
        String temp="{\"regions\":\"ZONE_8,ZONE_14,CLC_1615,STREET_3273,STREET_3275\",\"parents\":\"REGION_1,REGION_2,ZONE_15,HUB_50,CLC_1621\"}";
        JSONObject config = JSON.parseObject(temp);
        List<String > arrary=Arrays.asList(config.getString("regions").split(","));
        Map<String,List<String>> map=new HashMap<>();
        arrary.forEach(item->{
            String[] strs=item.split("_");
            List<String> list=map.get(strs[0]);
            if (CollectionUtils.isEmpty(list)) {
                list = new ArrayList<>();
            }
            list.add(strs[1]);
            map.put(strs[0],list);
        });
        StringBuilder stringBuilder=new StringBuilder();
        int i=0;
        for (String item:map.keySet()) {
            String column=item+"_id";
            if (i!=0) {
                stringBuilder.append(" and ");
            }
            stringBuilder.append(column.toLowerCase()).append(" in (").append(StringUtils.join(map.get(item),",")).append(")");
            i++;
        }
        System.out.println(stringBuilder.toString());

    }

    @Test
    public void PushApollo(){
        pushProcessService.sendMessageByPushId(1482L,11111L);
    }
}
