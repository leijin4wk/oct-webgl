import com.oyo.ump.member.common.test.TestApplication;
import com.oyo.ump.member.integration.service.push.PushMessageService;
import com.oyo.ump.member.processor.job.push.MemberPushJob;
import com.oyo.ump.member.service.MessagePushService;
import com.oyo.ump.member.service.PushProcessService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class PushJobTest {
    @Autowired
    private MemberPushJob memberPushJob;
    @Autowired
    private PushMessageService pushMessageService;

    @Autowired
    private MessagePushService messagePushService;

    @Autowired
    private PushProcessService pushProcessService;
    // @Test
    public void testMemberPushJob() throws Exception{
      //  memberPushJob.processAllPersonasPush();
        TimeUnit.SECONDS.sleep(1000);
    }
    @Test
    public void testMemberPushMessage1(){
        List<Long> list=new ArrayList<>();
        list.add(27776149L);
        list.add(16782203L);
        pushMessageService.sendAppPushMessage(list,"T201906061212121234",new ArrayList<>());
    }
    @Test
    public void testMemberSMSMessage1(){
        List<Long> list=new ArrayList<>();
        list.add(99999998L);
        list.add(99999999L);
        pushMessageService.sendSmsPushMessage(list,"T201907081522374210",new ArrayList<>());
    }
    @Test
    public void testMemberWechatMessage1(){
        List<Long> list=new ArrayList<>();
        list.add(27776149L);
        list.add(16782203L);
        pushMessageService.sendWeChatMpPushMessage(list,"T201906061212121234",new ArrayList<>());
    }
    @Test
    public void testTriggerChannelEnum() {
        messagePushService.getTemplateBoList(2);
    }

    @Test
    public void testEventPush(){
        pushProcessService.sendMessageByPushId(1483L,8888L);
    }

}
