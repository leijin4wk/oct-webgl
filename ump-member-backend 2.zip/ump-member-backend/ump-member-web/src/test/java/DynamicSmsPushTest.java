import com.aliyun.openservices.ons.api.Message;
import com.oyo.ump.member.common.test.TestApplication;
import com.oyo.ump.member.processor.mq.consumer.userOrderChange.UserOrderChangeListener;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@Slf4j
public class DynamicSmsPushTest {
    @Autowired
    UserOrderChangeListener userOrderChangeListener;
    @Test
    public void messageNewInfo(){
        String json="{\"arrivalDate\":1558454400000," +
                "\"bookingGuestName\":\"OYO会员\"," +
                "\"bookingGuestPhone\":\"16601726441\"," +
                "\"bookingId\":559452," +
                "\"bookingSn\":\"PBE215832459\"," +
                "\"bookingStatus\":0," +
                "\"centralChannel\":false," +
                "\"channelId\":62," +
                "\"expectDate\":1558519200000," +
                "\"extBookingSn\":\"\"," +
                "\"hotelId\":20023," +
                "\"memberId\":27776149," +
                "\"nights\":1," +
                "\"paidAmount\":10.90," +
                "\"payStatus\":1," +
                "\"paymentType\":1," +
                "\"publishTime\":1558415847427," +
                "\"retentionDate\":1558519200000," +
                "\"roomNumber\":1," +
                "\"roomType\":\"标准双床房\"," +
                "\"roomTypeDesc\":\"标准双床房Desc\"," +
                "\"terminal\":\"IOS\"} ";
        Message message=new Message();
        message.setBody(json.getBytes());
        message.setTag("booking_new");
        userOrderChangeListener.processMessage(message);
    }
    @Test
    public void messageUpdateInfo(){
        String json="{\"arrivalDate\":1558454400000," +
                "\"bookingGuestName\":\"OYO会员\"," +
                "\"bookingGuestPhone\":\"16601726441\"," +
                "\"bookingId\":559452," +
                "\"bookingSn\":\"PBE215832459\"," +
                "\"bookingStatus\":0," +
                "\"centralChannel\":false," +
                "\"channelId\":62," +
                "\"expectDate\":1558519200000," +
                "\"extBookingSn\":\"\"," +
                "\"hotelId\":20023," +
                "\"memberId\":27776149," +
                "\"nights\":1," +
                "\"paidAmount\":10.90," +
                "\"payStatus\":1," +
                "\"paymentType\":1," +
                "\"publishTime\":1558415847427," +
                "\"retentionDate\":1558519200000," +
                "\"roomNumber\":1," +
                "\"roomType\":\"标准双床房\"," +
                "\"terminal\":\"IOS\"} ";
        Message message=new Message();
        message.setBody(json.getBytes());
        message.setTag("booking_update");
        userOrderChangeListener.processMessage(message);
    }
    @Test
    public void messageCancelArrive(){
        String json="{\"arrivalDate\":1558454400000," +
                "\"bookingGuestName\":\"OYO会员\"," +
                "\"bookingGuestPhone\":\"16601726441\"," +
                "\"bookingId\":559452," +
                "\"bookingSn\":\"PBE215832459\"," +
                "\"bookingStatus\":0," +
                "\"centralChannel\":false," +
                "\"channelId\":62," +
                "\"expectDate\":1558519200000," +
                "\"extBookingSn\":\"\"," +
                "\"hotelId\":20023," +
                "\"memberId\":27776149," +
                "\"nights\":1," +
                "\"paidAmount\":10.90," +
                "\"payStatus\":1," +
                "\"paymentType\":1," +
                "\"publishTime\":1558415847427," +
                "\"retentionDate\":1558519200000," +
                "\"roomNumber\":1," +
                "\"roomType\":\"标准双床房\"," +
                "\"terminal\":\"IOS\"} ";
        Message message=new Message();
        message.setBody(json.getBytes());
        message.setTag("booking_cancel");
        userOrderChangeListener.processMessage(message);
    }
}
