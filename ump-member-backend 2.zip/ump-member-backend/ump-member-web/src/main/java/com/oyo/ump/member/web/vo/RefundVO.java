package com.oyo.ump.member.web.vo;

import lombok.Data;

/**
 * @Description: 退订返回
 * @Author: fang
 * @create: 2019-04-15
 **/
@Data
public class RefundVO {
    private Boolean isSuccess;
    private String msg;
}
