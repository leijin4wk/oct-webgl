package com.oyo.ump.member.web.vo;

import lombok.Data;

import java.io.Serializable;
/** 通用select 组件返回结果对象
* @author leijin
* @date 2020-01-13 11:48
**/
@Data
public class SelectComponentVo implements Serializable {

    private String label;
    private String value;
}
