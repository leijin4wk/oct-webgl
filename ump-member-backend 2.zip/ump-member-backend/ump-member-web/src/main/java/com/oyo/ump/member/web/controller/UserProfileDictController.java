package com.oyo.ump.member.web.controller;

import com.google.common.collect.Maps;
import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import com.oyo.ump.member.common.beanutils.MapperWrapper;
import com.oyo.ump.member.common.constants.MemberConstants;
import com.oyo.ump.member.service.TagValueService;
import com.oyo.ump.member.service.bo.UserProfileDictBO;
import com.oyo.ump.member.service.enums.TagFirstClassEnum;
import com.oyo.ump.member.service.enums.TagFirstClassForBEnum;
import com.oyo.ump.member.service.schedule.UserProfileDictService;
import com.oyo.ump.member.web.vo.UserProfileDictVO;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Dong
 * @Classname CrowdController
 * @Description 人群分类业务处理类
 * @Date 2019-06-06
 */
@RestController
@RequestMapping(value = "/member/ProfileDict")
@Api(tags = {"ProfileDict"}, value = "ProfileDict")
@Slf4j
public class UserProfileDictController {
    @Autowired
    UserProfileDictService userProfileDictService;
    @Autowired
    TagValueService tagValueService;

    @GetMapping("/firstClass")
    public BaseResponse<Map<String, String>> getFirstClassMap(@RequestParam(value = "userType", defaultValue = "1") Integer userType){
        Map<String, String> ruleMap = Maps.newHashMap();
        if(MemberConstants.USER_TYPE_FOR_B.equals(userType)){
            TagFirstClassForBEnum[] types = TagFirstClassForBEnum.values();
            for (TagFirstClassForBEnum type : types) {
                ruleMap.put(type.getCode(), type.getName());
            }
        }else if (MemberConstants.USER_TYPE_FOR_C.equals(userType)){
            TagFirstClassEnum[] types = TagFirstClassEnum.values();
            for (TagFirstClassEnum type : types) {
                ruleMap.put(type.getCode(), type.getName());
            }
        }else {
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(),"userType参数值有误");
        }
        return  BaseResponse.success(ruleMap);
    }

    @GetMapping("/tag")
    public BaseResponse<List<UserProfileDictVO>> getTag(@RequestParam(value = "firstId") String firstId,
                                                        @RequestParam(value = "userType", defaultValue = "1") Integer userType){
        BaseResponse<List<UserProfileDictVO>> response = new BaseResponse<>();
        List<UserProfileDictVO> resList = Lists.newArrayList();

        List<UserProfileDictBO> userProfileDictBOList = Lists.newArrayList();
        userProfileDictBOList = userProfileDictService.selectByFirstId(firstId,userType);

        if(CollectionUtils.isNotEmpty(userProfileDictBOList)){
            userProfileDictBOList.forEach(userProfileDictBO -> {
                UserProfileDictVO userProfileDictVO =  MapperWrapper.instance().map(userProfileDictBO, UserProfileDictVO.class);
                resList.add(userProfileDictVO);
            });
        }
        response.setCode(ResponseCode.SUCCESS.getCode());
        response.setMsg(ResponseCode.SUCCESS.getMsg());
        response.setData(resList);

        return response;
    }

    @GetMapping("/last")
    public BaseResponse<List<Map<String,Object>>> getLast(@RequestParam(value = "tagColumn") String tagColumn,
                                                          @RequestParam(value = "userType", defaultValue = "1") Integer userType){
        BaseResponse<List<Map<String,Object>>> response = new BaseResponse<>();
        List<Map<String,Object>> resList = Lists.newArrayList();
        UserProfileDictBO userProfileDictBO;
        try{
            userProfileDictBO = userProfileDictService.selectByTagColumn(tagColumn,userType);
        }catch (Exception e){
            log.info("查询value_area异常：", e);
            response.setCode(ResponseCode.FAILURE.getCode());
            response.setMsg("系统繁忙，请您稍后重试！");
            return response;
        }

        if(userProfileDictBO != null && userProfileDictBO.getValueArea() != null){
            try{
                resList = tagValueService.selectByValueArea(userProfileDictBO.getValueArea());
            }catch (Exception e){
                log.info("查询ADB标签值异常：", e);
                response.setCode(ResponseCode.FAILURE.getCode());
                response.setMsg("系统繁忙，请您稍后重试！");
                return response;
            }

        }

        response.setCode(ResponseCode.SUCCESS.getCode());
        response.setMsg(ResponseCode.SUCCESS.getMsg());
        response.setData(resList);

        return response;
    }


}
