package com.oyo.ump.member.web.controller;

import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import com.oyo.ump.member.biz.upgradePackage.UpgradePackageBizServiceImpl;
import com.oyo.ump.member.common.beanutils.MapperWrapper;
import com.oyo.ump.member.service.UpgradePackageService;
import com.oyo.ump.member.service.bo.UpgradePackageBO;
import com.oyo.ump.member.service.bo.UpgradePackagePageBO;
import com.oyo.ump.member.service.dto.UpgradePackageDTO;
import com.oyo.ump.member.web.common.RequirePermission;
import com.oyo.ump.member.web.vo.UpgradePackagePageVO;
import com.oyo.ump.member.web.vo.UpgradePackageVO;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.ibatis.annotations.Param;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @Classname UpgradePackageController
 * @Description 升级包业务处理类
 * @Date 2019-03-14 17:07
 * @author Dong
 */
@RestController
@RequestMapping(value = "/member/package")
@Api(tags = {"UpgradePackage"}, value = "UpgradePackage")
@Slf4j
public class UpgradePackageController {

    @Autowired
    private UpgradePackageBizServiceImpl upgradePackageBizService;

    @GetMapping()
    @RequirePermission(value = "memberPay_manage")
    public BaseResponse<UpgradePackagePageVO> getUpgradePackageList(@RequestParam(value = "pageNum", required = false, defaultValue = "1") Integer pageNum,
                                                                    @RequestParam(value = "pageSize", required = false, defaultValue = "5") Integer pageSize){

        BaseResponse<UpgradePackagePageVO> response = new BaseResponse<>();
        UpgradePackagePageVO upgradePackagePageVO = new UpgradePackagePageVO();
        UpgradePackagePageBO upgradePackagePageBO;
        List<UpgradePackageVO> upgradePackageVOList = Lists.newArrayList();

        try {
            upgradePackagePageBO = upgradePackageBizService.getUpgradePackageList(pageNum, pageSize);
        }catch (Exception e){
            log.error("升级包查询结果异常",e);
            return BaseResponse.fail(ResponseCode.FAILURE);
        }

        response.setCode(ResponseCode.SUCCESS.getCode());
        response.setMsg(ResponseCode.SUCCESS.getMsg());

        if(CollectionUtils.isNotEmpty(upgradePackagePageBO.getUpgradePackageBOList())){
            upgradePackagePageBO.getUpgradePackageBOList().forEach(upgradePackageBO -> {
                UpgradePackageVO upgradePackageVO =  MapperWrapper.instance().map(upgradePackageBO, UpgradePackageVO.class);
                upgradePackageVOList.add(upgradePackageVO);
            });
        }else{
            response.setMsg("数据异常");
        }
        upgradePackagePageVO.setUpgradePackageVOList(upgradePackageVOList);
        upgradePackagePageVO.setTotal(upgradePackagePageBO.getTotal());
        upgradePackagePageVO.setPageNum(upgradePackagePageBO.getPageNum());
        upgradePackagePageVO.setPageSize(upgradePackagePageBO.getPageSize());

        response.setData(upgradePackagePageVO);

        return response;
    }

}
