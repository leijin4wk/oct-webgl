package com.oyo.ump.member.web.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import com.oyo.common.response.PagedResponse;
import com.oyo.ump.coupon.facade.dto.request.ListUserCouponRequest;
import com.oyo.ump.coupon.facade.dto.response.CouponDataDTO;
import com.oyo.ump.coupon.facade.dto.response.UserCouponListDTO;
import com.oyo.ump.coupon.facade.util.GeneralResponse;
import com.oyo.ump.defender.service.enums.RiskResultSourceEnum;
import com.oyo.ump.defender.service.member.dto.MemberdefRecordDTO;
import com.oyo.ump.member.biz.member.MemberDefenderBizService;
import com.oyo.ump.member.biz.member.MemberPreferentialBizService;
import com.oyo.ump.member.common.beanutils.MapperWrapper;
import com.oyo.ump.member.service.AdbQueryService;
import com.oyo.ump.member.service.MemberInfoService;
import com.oyo.ump.member.service.bo.MemberDetailBO;
import com.oyo.ump.member.service.bo.MemberEditBO;
import com.oyo.ump.member.service.dto.UserDetailPageResponseDTO;
import com.oyo.ump.member.service.dto.UserEventPageResponseDTO;
import com.oyo.ump.member.service.dto.UserTradePageResponseDTO;
import com.oyo.ump.member.web.common.RequirePermission;
import com.oyo.ump.member.web.vo.MemberDefRecordVO;
import com.oyo.ump.member.web.vo.MemberDetailVO;
import com.oyo.ump.member.web.vo.MemberEditVO;
import com.oyo.ump.member.web.vo.PreferentialVO;
import com.oyo.utp.pa.common.utils.DateUtils;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Description: 会员信息controller
 * @Author: fang
 * @create: 2019-03-20
 **/
@RestController
@RequestMapping(value = "/member/detail")
@Api(tags = {"Info"}, value = "Info")
@Slf4j
public class MemberInfoController {

    @Autowired
    private MemberInfoService memberInfoService;
    @Autowired
    private MemberPreferentialBizService memberPreferentialBizService;
    @Autowired
    private MemberDefenderBizService memberDefenderBizService;
    @Autowired
    private AdbQueryService adbQueryService;
    private String DATATIME_FORMATTER="yyyy-MM-dd HH:mm:ss";

    @GetMapping("/query")
    @RequirePermission(value = "membershipStatus_membershipStatusList$button$memberQuery")
    public BaseResponse<MemberDetailVO> queryMemberInfoByUserId(@RequestParam("userId") Long userId,@RequestParam(value = "tenant", required = false,defaultValue = "OYO") String tenant){
        MemberDetailBO memberDetailBO =memberInfoService.getMemberDetailByUserId(userId,tenant);
        MemberDetailVO memberDetailVO = MapperWrapper.instance().map(memberDetailBO, MemberDetailVO.class);
        return BaseResponse.success(memberDetailVO);
    }
    @GetMapping("/edit")
    public BaseResponse<MemberEditVO> updateUserByUserId(@RequestParam("userId") Long userId,@RequestParam("certificateNo") String certificateNo){
        if(userId!=null&& StringUtils.isNotEmpty(certificateNo)) {
            MemberEditBO editBO = memberInfoService.updateUserInfoByUserId(userId, certificateNo);
            MemberEditVO memberEditVO = MapperWrapper.instance().map(editBO, MemberEditVO.class);
            return BaseResponse.success(memberEditVO);
        }else {
            return BaseResponse.fail(ResponseCode.ILLEGAL_ARGUMENT);
        }

    }

    @GetMapping("/preferential")
    public BaseResponse<PagedResponse<PreferentialVO>> queryPreferential(@RequestParam(value = "userId") Long userId,
                                                                         @RequestParam(value = "preferentialType", required = false) String preferentialType,
                                                                         @RequestParam(value = "startTime", required = false) String startTime,
                                                                         @RequestParam(value = "endTime", required = false) String endTime,
                                                                         @RequestParam(value = "pageNum", required = false) Integer pageNum,
                                                                         @RequestParam(value = "pageSize", required = false) Integer pageSize){
        BaseResponse<PagedResponse<PreferentialVO>> response = new BaseResponse<>();
        List<PreferentialVO> preferentialVOList = Lists.newArrayList();
        PagedResponse<PreferentialVO> preferentialVOPagedResponse = new PagedResponse<>();
        if(userId!=null) {
            ListUserCouponRequest request = new ListUserCouponRequest();
            request.setUserId(userId);
            request.setObtainBeginTime(StringUtils.isBlank(startTime)?null: DateUtils.formatByStringDate(startTime, "yyyy-MM-dd"));
            request.setObtainEndTime(StringUtils.isBlank(endTime)?null: DateUtils.formatByStringDate(endTime, "yyyy-MM-dd"));
            request.setPageNum(pageNum);
            request.setPageSize(pageSize);
            log.info("查询优惠券请求信息---{}", JSON.toJSONString(request));
            GeneralResponse<UserCouponListDTO> couponPreferential = memberPreferentialBizService.getPreferential(request);
            log.info("优惠券返回信息---{}", JSON.toJSONString(couponPreferential));
            if(couponPreferential != null && couponPreferential.getBody() != null){
                UserCouponListDTO userCouponListDTO = (UserCouponListDTO) couponPreferential.getBody();
                preferentialVOPagedResponse.setPageSize(userCouponListDTO.getPageSize());
                preferentialVOPagedResponse.setTotalCount(userCouponListDTO.getTotalCount());
                preferentialVOPagedResponse.setPageNum(userCouponListDTO.getPageNum());
                if(CollectionUtils.isNotEmpty(userCouponListDTO.getCouponList())){
                    userCouponListDTO.getCouponList().forEach(couponDataDTO -> {
                        preferentialVOList.add(convert2VO(couponDataDTO));
                    });
                }
                preferentialVOPagedResponse.setResult(preferentialVOList);
            }
            response.setCode(ResponseCode.SUCCESS.getCode());

            response.setData(preferentialVOPagedResponse);
        }else {
            response.setCode(ResponseCode.FAILURE.getCode());
        }
        log.info("优惠券VO返回信息---{}", JSON.toJSONString(response));
        return response;
    }

    @GetMapping("/defender")
    public BaseResponse<List<MemberDefRecordVO>> queryDefRecord(@RequestParam(value = "userId") Long userId,
                                                                   @RequestParam(value = "activityId", required = false) Long activityId){
        BaseResponse<List<MemberDefRecordVO>> response = new BaseResponse<>();
        List<MemberDefRecordVO> memberDefRecordVOList = Lists.newArrayList();
        if(userId!=null) {
            log.info("查询用户活动风控记录请求信息:userId:{},activityId:{}", userId,activityId);
            BaseResponse<List<MemberdefRecordDTO>> defRecords = memberDefenderBizService.getMemberDefActivityRecord(userId,activityId);
            log.info("查询用户活动风控记录返回信息:{}", JSON.toJSONString(defRecords));
            if(null != defRecords && CollectionUtils.isNotEmpty(defRecords.getData())){
                defRecords.getData().forEach(memberDefRecordDTO -> {
                    MemberDefRecordVO memberDefRecordVO = new MemberDefRecordVO();
                    BeanUtils.copyProperties(memberDefRecordDTO, memberDefRecordVO);
                    memberDefRecordVO.setResultSourceDesc(RiskResultSourceEnum.get(memberDefRecordDTO.getResultSource()) == null ? "" : RiskResultSourceEnum.get(memberDefRecordDTO.getResultSource()).getDesc());
                    memberDefRecordVOList.add(memberDefRecordVO);
                });
            }

            response.setCode(ResponseCode.SUCCESS.getCode());
            response.setData(memberDefRecordVOList);
        }else {
            response.setCode(ResponseCode.FAILURE.getCode());
            response.setMsg("用户ID不能空！");
        }
        log.info("查询用户活动风控记录VO返回信息---{}", JSON.toJSONString(response));
        return response;
    }

    /**
     * 查询用户参与的有风控记录的活动
     * @param userId
     * @return com.oyo.common.response.BaseResponse<java.util.List<com.oyo.ump.member.web.vo.MemberDefRecordVO>>
     */
    @GetMapping("/activity")
    public BaseResponse<Map<Long, String>> getActivity(@RequestParam(value = "userId") Long userId){
        BaseResponse<Map<Long, String>> response = new BaseResponse<>();
        Map<Long, String> activityMap = new HashMap<>();
        if(userId!=null) {
            log.info("查询用户参与的有风控记录的活动请求信息:userId:{}", userId);
            BaseResponse<List<MemberdefRecordDTO>> defRecords = memberDefenderBizService.getMemberDefActivityRecord(userId,null);
            log.info("查询用户参与的有风控记录的活动返回信息:{}", JSON.toJSONString(defRecords));
            if(null != defRecords && CollectionUtils.isNotEmpty(defRecords.getData())){
                defRecords.getData().forEach(memberDefRecordDTO -> {
                    activityMap.put(memberDefRecordDTO.getActivityId(), memberDefRecordDTO.getActivityName());
                });
            }

            response.setCode(ResponseCode.SUCCESS.getCode());
            response.setData(activityMap);
        }else {
            response.setCode(ResponseCode.FAILURE.getCode());
            response.setMsg("用户ID不能空！");
        }
        log.info("查询用户参与的有风控记录的活动Map返回信息---{}", JSON.toJSONString(response));
        return response;
    }

    private PreferentialVO convert2VO(CouponDataDTO couponDataDTO){
        PreferentialVO preferentialVO = new PreferentialVO();
        preferentialVO.setPreferentialType("优惠券");
        preferentialVO.setShowName(couponDataDTO.getShowName());
        preferentialVO.setReceiveTime(couponDataDTO.getReceiveTime()==null?null:DateUtils.format(couponDataDTO.getReceiveTime(),"yyyy-MM-dd HH:mm:ss"));
        preferentialVO.setStartTime(couponDataDTO.getStartTime()==null?null:DateUtils.format(couponDataDTO.getStartTime(),"yyyy-MM-dd HH:mm:ssm"));
        preferentialVO.setEndTime(couponDataDTO.getEndTime()==null?null:DateUtils.format(couponDataDTO.getEndTime(),"yyyy-MM-dd HH:mm:ss"));
        preferentialVO.setIdentifyCode(couponDataDTO.getIdentifyCode());
        preferentialVO.setStatus(couponDataDTO.getStatus());
        preferentialVO.setUsedTime(couponDataDTO.getUsedTime()==null?null:DateUtils.format(couponDataDTO.getUsedTime(),"yyyy-MM-dd HH:mm:ss"));
        return preferentialVO;
    }
    @GetMapping("/basic")
    public BaseResponse<Map<String,Object>> getUserBasicInfo(@RequestParam(value = "userId") Long userId){
        return BaseResponse.success(adbQueryService.queryUserBasicInfo(userId));

    }
    @GetMapping("/event")
    public BaseResponse<UserEventPageResponseDTO> getUserEventInfo(@RequestParam(value = "userId") Long userId,
                                                                   @RequestParam(value = "startTime",required = false)  String startTime,
                                                                   @RequestParam(value = "endTime",required = false) String endTime,
                                                                   @RequestParam(value = "pageNum", required = false, defaultValue = "1") Integer pageNum,
                                                                   @RequestParam(value = "pageSize", required = false, defaultValue = "5") Integer pageSize){
        return BaseResponse.success(adbQueryService.queryUserEvent(userId,startTime,endTime,pageNum,pageSize));
    }
    @GetMapping("/trade")
    public BaseResponse<UserTradePageResponseDTO> getUserTradeInfo(@RequestParam(value = "userId") Long userId,
                                                                   @RequestParam(value = "startTime",required = false) String startTime,
                                                                   @RequestParam(value = "endTime",required = false) String endTime,
                                                                   @RequestParam(value = "pageNum", required = false, defaultValue = "1") Integer pageNum,
                                                                   @RequestParam(value = "pageSize", required = false, defaultValue = "5") Integer pageSize){
        return BaseResponse.success(adbQueryService.queryTradeEvent(userId,startTime,endTime,pageNum,pageSize));
    }
    @GetMapping("/list")
    public BaseResponse<UserDetailPageResponseDTO> getUserDetialList(@RequestParam(value = "crowId") Long crowId,
                                                                     @RequestParam(value = "pageNum", required = false, defaultValue = "1") Integer pageNum,
                                                                     @RequestParam(value = "pageSize", required = false, defaultValue = "5") Integer pageSize){
        return BaseResponse.success(adbQueryService.queryUserList(crowId,pageSize,pageNum));

    }
}
