

package com.oyo.ump.member.web.controller;

import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import com.oyo.ump.member.integration.service.push.FileUploadService;
import com.oyo.ump.member.web.vo.UploadFileVo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * 文件上传
* @author leijin
* @date 2019-10-12 15:42
**/
@Controller
@RequestMapping(value = "/member/pushTemplate")
@Slf4j
public class FileUploadController {
    @Autowired
    private FileUploadService fileUploadService;
    @RequestMapping(value="/fileUpload", method= RequestMethod.POST)
    @ResponseBody
    public BaseResponse<UploadFileVo> addUser(@RequestParam MultipartFile img) {
        BaseResponse<UploadFileVo> response = new BaseResponse<>();
        try {
            byte[] bytes= IOUtils.toByteArray(img.getInputStream());
            String fullUrl=fileUploadService.uploadFile(img.getOriginalFilename(),bytes);
            log.info("picture url is {}",fullUrl);
            response.setCode(ResponseCode.SUCCESS.getCode());
            response.setMsg(ResponseCode.SUCCESS.getMsg());
            UploadFileVo uploadFileVo=new UploadFileVo();
            uploadFileVo.setUrl(fullUrl);
            uploadFileVo.set_public(true);
            uploadFileVo.setFileSize(bytes.length);
            response.setData(uploadFileVo);
        }catch (IOException e){
            response.setCode(ResponseCode.FAILURE.getCode());
            response.setMsg(ResponseCode.FAILURE.getMsg());
            response.setData(null);
        }
        return response;
    }


}
