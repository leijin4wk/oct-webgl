package com.oyo.ump.member.web.vo;

import lombok.Data;
import org.assertj.core.util.Lists;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @Description: todo
 * @Author: fang
 * @create: 2019-04-04
 **/
@Data
public class MemberBonusVO {
    private int pageNum;
    private int pageSize;
    private long totalPages;
    private long totalCount;
    private Long userId;
    private List<MemberBonusVO.MemberBonusInfo> result = Lists.newArrayList();
    @Data
    public static class MemberBonusInfo implements Serializable {
        private String orderSn;
        private Date createTime;
        private Date payTime;
        private Date bonusAddTime;
        private BigDecimal actualAmount;
        private String orderStatus;
        private Integer totalPointsNum;
        private Integer consumePoints;
        private Integer awardPoints;
        private Integer activityPoints;
        private String grade;
        private Integer signIn;
        private String businessType;
        private String marketingName;
        private Integer pointNum;


    }
}
