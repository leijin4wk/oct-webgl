package com.oyo.ump.member.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@ComponentScan(basePackages={"com.oyo.ump.member", "top.rdfa.framework","com.oyo.apm"})
@EnableCaching
@SpringBootApplication
@Slf4j
public class UmpWebApplication  {

    public static void main(String[] args) {
        log.info("-------启动开始-------");
        SpringApplication.run(UmpWebApplication.class, args);
        log.info("====================================================================================================");
        log.info("SpringBoot Start Success");
        log.info("====================================================================================================");
    }
    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/**").allowedOrigins("*").allowedMethods("PUT", "DELETE", "GET", "POST")
                        .allowedHeaders("*")
                        .allowCredentials(false).maxAge(3600);

            }
        };

    }
}
