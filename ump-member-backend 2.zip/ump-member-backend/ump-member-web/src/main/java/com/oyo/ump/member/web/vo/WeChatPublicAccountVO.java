package com.oyo.ump.member.web.vo;

import lombok.Data;

/**
 * @author ：AaronZhang
 * @date ：Created in 2019-07-03 19:35
 * @description：微信公众号VO
 * @modified By：
 * @version: 1.0$
 */
@Data
public class WeChatPublicAccountVO {
    private String appId;

    private String mp;

    private String appName;
}
