package com.oyo.ump.member.web.vo;

import lombok.Data;

import java.io.Serializable;

/**
 * @Classname HotelVO
 * @Description 酒店信息
 * @Date 2019-03-15 11:46
 * @author Dong
 */
@Data
public class HotelVO implements Serializable {
    private Integer id;
    private Long hotelId;
    private Integer cityId;
}
