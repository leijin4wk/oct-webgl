package com.oyo.ump.member.web.vo;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @Classname BonusCostRuleVO
 * @Description 积分消费信息
 * @Date 2019-03-15 18:21
 * @author Dong
 */

@Data
public class BonusCostRuleVO implements Serializable {
    private Integer id;
    private Integer deductionRatio;
    private BigDecimal pricePerUnit;
    private Integer minBonus;
}
