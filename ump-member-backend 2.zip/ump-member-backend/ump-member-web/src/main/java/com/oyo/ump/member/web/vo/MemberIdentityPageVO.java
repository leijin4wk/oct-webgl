package com.oyo.ump.member.web.vo;

import com.github.pagehelper.PageInfo;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author Dong
 * @Classname MemberIdentityPageVO
 * @Description 给前端的分页VO
 * @Date 2019-03-27
 */
@Data
public class MemberIdentityPageVO implements Serializable {
    private List<MemberIdentityInfoVO> memberIdentityInfoVOList;
    private Long total;
    private Integer pageNum;
    private Integer pageSize;
}
