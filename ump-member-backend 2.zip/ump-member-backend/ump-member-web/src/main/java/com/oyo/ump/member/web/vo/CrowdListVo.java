package com.oyo.ump.member.web.vo;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class CrowdListVo implements Serializable {

    private List<Long> crowds;
}
