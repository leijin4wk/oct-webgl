package com.oyo.ump.member.web.vo;

import lombok.Data;

import java.io.Serializable;

/**
 * 短信签名VO
 * @author toby Zhang
 * @date 2019-07-04 16:17
 * @description
 */
@Data
public class SmsSignVO implements Serializable {

    private static final long serialVersionUID = -8733877538285064623L;

    private int ordinal;

    private String name;
}
