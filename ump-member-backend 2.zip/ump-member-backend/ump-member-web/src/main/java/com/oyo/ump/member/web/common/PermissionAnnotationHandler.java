package com.oyo.ump.member.web.common;

import com.oyo.common.enums.ResponseCode;
import com.oyo.ump.member.common.exception.UmpException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

/**
 * @Description: 权限
 * @Author: fang
 * @create: 2019-04-30
 **/
@Slf4j
@Aspect
@Component
public class PermissionAnnotationHandler {

    @Pointcut("@annotation(com.oyo.ump.member.web.common.RequirePermission)")
    public void pointCut(){
    }

    @Before("pointCut()")
    public void checkPermisson(JoinPoint joinPoint){
          MethodSignature methodSignature=(MethodSignature) joinPoint.getSignature();
          Method method = methodSignature.getMethod();
          Annotation annotation= method.getAnnotation(RequirePermission.class);
          if(annotation==null|| StringUtils.isEmpty(((RequirePermission) annotation).value())){
              throw new UmpException(ResponseCode.FAILURE.getCode(),"内部权限配置error");
          }
         PermissionUtils.basicCheckPermission(((RequirePermission) annotation).value());
    }

}
