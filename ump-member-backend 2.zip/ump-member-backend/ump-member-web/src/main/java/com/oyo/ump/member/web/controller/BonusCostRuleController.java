package com.oyo.ump.member.web.controller;

import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import com.oyo.ump.member.common.beanutils.MapperWrapper;
import com.oyo.ump.member.service.BonusCostRuleService;
import com.oyo.ump.member.service.dto.BonusCostRuleDTO;
import com.oyo.ump.member.web.common.RequirePermission;
import com.oyo.ump.member.web.vo.BonusCostRuleVO;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @Classname BonusCostRuleController
 * @Description 积分消费规则业务处理类
 * @Date 2019-03-14 19:07
 * @author Dong
 */
@RestController
@RequestMapping(value = "/member/costRule")
@Api(tags = {"costRule"}, value = "costRule")
@Slf4j
public class BonusCostRuleController {
    @Autowired
    private BonusCostRuleService bonusCostRuleService;

    @GetMapping()
    @RequirePermission(value = "membershipScore_integralRule")
    public BaseResponse<List<BonusCostRuleVO>> getBonusCostRuleList() {

        BaseResponse<List<BonusCostRuleVO>> response = new BaseResponse<>();
        BonusCostRuleDTO bonusCostRuleDTO;

        List<BonusCostRuleVO> bonusCostRuleVOList = Lists.newArrayList();

        response.setCode(ResponseCode.SUCCESS.getCode());
        response.setMsg(ResponseCode.SUCCESS.getMsg());
        try {
            bonusCostRuleDTO = bonusCostRuleService.getCostRuleList();
            if (bonusCostRuleDTO != null && CollectionUtils.isNotEmpty(bonusCostRuleDTO.getBonusCostRuleInfoList())) {
                bonusCostRuleDTO.getBonusCostRuleInfoList().forEach(bonusCostRuleInfo -> {
                    BonusCostRuleVO bonusCostRuleVO = MapperWrapper.instance().map(bonusCostRuleInfo, BonusCostRuleVO.class);

                    bonusCostRuleVOList.add(bonusCostRuleVO);
                });
            } else {
                response.setMsg("数据异常");
            }
        } catch (Exception e) {
            log.error("鸥币消费规则查询结果异常", e);
            return BaseResponse.fail(ResponseCode.FAILURE);
        }
        response.setData(bonusCostRuleVOList);
        return response;
    }
}
