package com.oyo.ump.member.web.controller;

import com.oyo.common.response.BaseResponse;
import com.oyo.ump.member.common.beanutils.MapperWrapper;
import com.oyo.ump.member.service.GradeService;
import com.oyo.ump.member.service.bo.GradeInfoBO;
import com.oyo.ump.member.web.common.RequirePermission;
import com.oyo.ump.member.web.vo.MemberGradeInfoVO;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @Description: 会员等级相关查询接口
 * @Author: fang
 * @create: 2019-03-13
 **/
@RestController
@RequestMapping(value = "/member/grade")
@Api(tags = {"Grade"}, value = "Grade")
@Slf4j
public class GradeController {
    @Autowired
    private GradeService gradeService;

    @GetMapping("/queryall")
//    @RequirePermission(value = "membershipLevel_levelAndRights")
    public BaseResponse<List<MemberGradeInfoVO>> queryAllMemberGradeInfo(@RequestParam(value = "tenant", required = false, defaultValue = "OYO") String tenant) {
        List<MemberGradeInfoVO> memberGradeInfoVOList = Lists.newArrayList();
        List<GradeInfoBO> gradeInfoBOList= gradeService.getGradeInfoList(tenant);
        if ( CollectionUtils.isNotEmpty(gradeInfoBOList)) {
            gradeInfoBOList.forEach(gradeInfoBO -> {
                MemberGradeInfoVO memberGradeInfoVO = MapperWrapper.instance().map(gradeInfoBO, MemberGradeInfoVO.class);
                memberGradeInfoVOList.add(memberGradeInfoVO);
            });
        }
        return BaseResponse.success(memberGradeInfoVOList);
    }
}
