package com.oyo.ump.member.web.vo;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author Dong
 * @Classname PushVO
 * @Description 人群分类VO
 * @Date 2019-05-06
 */
@Data
public class UserProfileDictVO implements Serializable {
    private Integer id;
    private String tagNo;
    private Integer tagStatus;
    private Integer firstClass;
    private Integer secondClass;
    private String tagName;
    private Integer tagType;
    private String tagTable;
    private String tagColumn;
    private String tagDesc;
    private String sampleSql;
    private String valueArea;
    /**
     * B端用户画像字典表用
     */
    private String filter;
}
