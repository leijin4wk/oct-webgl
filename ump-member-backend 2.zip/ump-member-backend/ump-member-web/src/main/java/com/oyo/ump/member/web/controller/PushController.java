package com.oyo.ump.member.web.controller;

import com.google.common.collect.Maps;
import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import com.oyo.common.response.PagedResponse;
import com.oyo.sso.core.util.SsoUtil;
import com.oyo.ump.member.biz.push.PushBizServiceImpl;
import com.oyo.ump.member.common.beanutils.MapperWrapper;
import com.oyo.ump.member.common.constants.MemberConstants;
import com.oyo.ump.member.common.exception.UmpException;
import com.oyo.ump.member.integration.service.user.BUserInfoRemoteService;
import com.oyo.ump.member.integration.service.user.RemoteOrganizationService;
import com.oyo.ump.member.service.*;
import com.oyo.ump.member.service.bo.PushBO;
import com.oyo.ump.member.service.bo.PushEventMetaBO;
import com.oyo.ump.member.service.bo.PushTemplateRelationBO;
import com.oyo.ump.member.service.bo.TemplateBo;
import com.oyo.ump.member.service.dto.PushTemplateDTO;
import com.oyo.ump.member.service.enums.TriggerChannelEnum;
import com.oyo.ump.member.web.common.PermissionUtils;
import com.oyo.ump.member.web.vo.AppPushTemplateVo;
import com.oyo.ump.member.web.vo.FirstLevelOrganizationVO;
import com.oyo.ump.member.web.vo.PushVO;
import com.oyo.ump.member.web.vo.request.PushRequestVO;
import com.oyo.utp.pa.common.utils.DateUtils;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import top.rdfa.biz.actor.business.client.dto.AccountDto;
import top.rdfa.biz.actor.business.client.dto.DeptDetailDto;
import top.rdfa.biz.actor.business.client.dto.OrganizationDto;

import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * @author Dong
 * @Classname PushController
 * @Description 事件推送业务处理类
 * @Date 2019-05-06
 */
@RestController
@RequestMapping(value = "/member/push")
@Api(tags = {"Push"}, value = "Push")
@Slf4j
public class PushController {
    @Autowired
    PushService pushService;
    @Autowired
    PushBizServiceImpl pushBizServiceImpl;
    @Autowired
    PushRuleService pushRuleService;
    @Autowired
    MessagePushService messagePushService;
    @Autowired
    PushTemplateRelationService pushTemplateRelationService;
    @Autowired
    RemoteOrganizationService remoteOrganizationService;
    @Autowired
    PushProcessService pushProcessService;
    @Autowired
    BUserInfoRemoteService bUserInfoRemoteService;
    @Value("${PUSH_ADMIN}")
    private String PUSH_ADMIN;
    @Value("${PUSH_DEPARTMENT_ADMIN}")
    private String PUSH_DEPARTMENT_ADMIN;
    @Value("${PUSH_DEPARTMENT_MEMBER}")
    private String PUSH_DEPARTMENT_MEMBER;

    /**
     * 获取PUSH列表（带分页信息）
     * @param pushName  推送名称
     * @param startTime 开始时间
     * @param endTime   结束时间
     * @param triggerChannel 推送渠道
     * @param departmentId 部门
     * @param triggerType 推送类型
     * @param createUserName 创建人
     * @param pushStatus    状态
     * @param userType    目标用户类型（1-c端用户，2-b端用户）
     * @param pageNum 页码
     * @param pageSize 每页数量
     * @return com.oyo.common.response.BaseResponse<com.oyo.common.response.PagedResponse<com.oyo.ump.member.web.vo.PushVO>>
     */
    @GetMapping("/pageList")
//    @RequirePermission(value = "eventPush_eventPushList")
    public BaseResponse<PagedResponse<PushVO>> getPagePushList(@RequestParam(value = "pushName", required = false) String pushName,
                                     @RequestParam(value = "startTime", required = false) String startTime,
                                     @RequestParam(value = "endTime", required = false) String endTime,
                                     @RequestParam(value = "triggerChannel", required = false) Integer triggerChannel,
                                     @RequestParam(value = "departmentId", required = false) Long departmentId,
                                     @RequestParam(value = "triggerType", required = false) Integer triggerType,
                                     @RequestParam(value = "createUserName", required = false) String createUserName,
                                     @RequestParam(value = "pushStatus", required = false) Integer pushStatus,
                                     @RequestParam(value = "userType", required = false, defaultValue = "1") Integer userType,
                                     @RequestParam(value = "pageNum", required = false, defaultValue = "1") Integer pageNum,
                                     @RequestParam(value = "pageSize", required = false, defaultValue = "5") Integer pageSize
    ){
        log.info("用户{} 的资源树：{}",SsoUtil.currentUser().getUserName(),SsoUtil.currentUser().getResourceTree());
        Set<String> codeList = PermissionUtils.getUserCodeList();
        BaseResponse<PagedResponse<PushVO>> response = new BaseResponse<>();
        List<PushVO> pushVOList = Lists.newArrayList();
        PagedResponse<PushVO> pushVOPagedResponse = new PagedResponse<>();
        pushVOPagedResponse.setPageSize(pageSize);
        // 查询条件
        PushBO reqPushBO = new PushBO();
        reqPushBO.setPushName(pushName);
        reqPushBO.setDepartmentId(departmentId);
        reqPushBO.setTriggerType(triggerType);
        reqPushBO.setCreateUserName(createUserName);
        reqPushBO.setPushStatus(pushStatus);
        reqPushBO.setUserType(userType);
        reqPushBO.setStartTime(StringUtils.isBlank(startTime)?null:DateUtils.formatByStringDate(startTime, "yyyy-MM-dd HH:mm:ss"));
        reqPushBO.setEndTime(StringUtils.isBlank(endTime)?null:DateUtils.formatByStringDate(endTime, "yyyy-MM-dd HH:mm:ss"));
        reqPushBO.setTriggerChannel(triggerChannel);
        if(codeList.contains(PUSH_ADMIN)){
            log.info("资源树包括 push_admin 推送最高管理员");
        }else if(codeList.contains(PUSH_DEPARTMENT_ADMIN)){
            log.info("资源树包括 push_department_admin 推送部门管理员");
            Long userDepartmentId = getLevel2DepartmentIdByUserId(SsoUtil.currentUser().getUserId());
            log.info("部门ID：{}",userDepartmentId);
            reqPushBO.setDepartmentId(userDepartmentId);
        }else if(codeList.contains(PUSH_DEPARTMENT_MEMBER)){
            log.info("资源树包括 push_department_member 推送普通管理员");
            reqPushBO.setCreateUserId(SsoUtil.currentUser().getUserId());
        }else {
            log.info("资源树没有包含最高、部门和普通管理员权限");
            reqPushBO.setCreateUserId(SsoUtil.currentUser().getUserId());
        }


        PagedResponse<PushBO> pushBOPagedResponse = new PagedResponse<>();
        try{
            pushBOPagedResponse = pushService.selectByConditionPaged(reqPushBO, pageNum, pageSize);
        }catch (Exception e){
            log.info("查询事件推送列表异常：", e);
            response.setCode(ResponseCode.FAILURE.getCode());
            response.setMsg("系统繁忙，请您稍后重试！");
            return response;
        }
        if(CollectionUtils.isNotEmpty(pushBOPagedResponse.getResult())){
            pushBOPagedResponse.getResult().forEach(pushBO -> {
                PushVO pushVO = new PushVO();
                pushVO = convert2VO(pushBO);
                pushVOList.add(pushVO);
            });
        }
        pushVOPagedResponse.setResult(pushVOList);
        pushVOPagedResponse.setTotalCount(pushBOPagedResponse.getTotalCount());
        pushVOPagedResponse.setPageNum(pageNum);


        response.setCode(ResponseCode.SUCCESS.getCode());
        response.setMsg(ResponseCode.SUCCESS.getMsg());
        response.setData(pushVOPagedResponse);

        return response;
    }

    @GetMapping("/list")
    public BaseResponse<List<PushVO>> getPushList(@RequestParam(value = "pushName", required = false) String pushName,
                                                  @RequestParam(value = "startTime", required = false) String startTime,
                                                  @RequestParam(value = "endTime", required = false) String endTime,
                                                  @RequestParam(value = "triggerChannel", required = false) Integer triggerChannel,
                                                  @RequestParam(value = "departmentId", required = false) Long departmentId,
                                                  @RequestParam(value = "triggerType", required = false) Integer triggerType,
                                                  @RequestParam(value = "createUserName", required = false) String createUserName,
                                                  @RequestParam(value = "pushStatus", required = false) Integer pushStatus
    ){
        BaseResponse<List<PushVO>> response = new BaseResponse<>();
        List<PushVO> pushVOList = Lists.newArrayList();
        List<PushBO> pushBOList = Lists.newArrayList();

        PushBO reqPushBO = new PushBO();
        reqPushBO.setPushName(pushName);
        reqPushBO.setDepartmentId(departmentId);
        reqPushBO.setTriggerType(triggerType);
        reqPushBO.setCreateUserName(createUserName);
        reqPushBO.setPushStatus(pushStatus);
        reqPushBO.setStartTime(StringUtils.isBlank(startTime)?null:DateUtils.formatByStringDate(startTime, "yyyy-MM-dd HH:mm:ss"));
        reqPushBO.setEndTime(StringUtils.isBlank(endTime)?null:DateUtils.formatByStringDate(endTime, "yyyy-MM-dd HH:mm:ss"));
        reqPushBO.setTriggerChannel(triggerChannel);

        try{
            pushBOList = pushService.selectByCondition(reqPushBO);
        }catch (Exception e){
            log.info("查询事件推送列表异常：", e);
            response.setCode(ResponseCode.FAILURE.getCode());
            response.setMsg("系统繁忙，请您稍后重试！");
            return response;
        }
        if(CollectionUtils.isNotEmpty(pushBOList)){
            pushBOList.forEach(pushBO -> {
                PushVO pushVO = convert2VO(pushBO);
                pushVOList.add(pushVO);
            });
        }

        response.setCode(ResponseCode.SUCCESS.getCode());
        response.setMsg(ResponseCode.SUCCESS.getMsg());
        response.setData(pushVOList);

        return response;
    }

    /**
     * 获取PUSH详情信息
     * @param id
     * @return com.oyo.common.response.BaseResponse<com.oyo.ump.member.web.vo.PushVO>
     */
    @GetMapping("/info")
    public BaseResponse<PushVO> getPushInfo(@RequestParam(value = "id") Long id){
        BaseResponse<PushVO> response = new BaseResponse<>();
        PushBO pushBO;

        PushVO pushVO;
        try{
            pushBO = pushService.selectById(id);
            pushVO = convert2VO(pushBO);
        }catch (Exception e){
            log.info("查询推送详情异常：", e);
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(), "查询推送详情异常");
        }

        response.setCode(ResponseCode.SUCCESS.getCode());
        response.setData(pushVO);
        return response;
    }

    @PostMapping(path = "/insertOrUpdateOne")
    public BaseResponse<Long> insertOrUpdatePushCrowdInfo(@RequestBody PushRequestVO pushVO){
        BaseResponse<Long> response = new BaseResponse();
        if (!ResponseCode.SUCCESS.getCode().equals(checkPushRequestVO(pushVO).getCode())){
            return checkPushRequestVO(pushVO);
        }
        PushBO pushBO = convert2BO(pushVO);
        try{
            if(null == pushBO.getId()){
                // 插入
                Long pushId = pushService.insertPush(pushBO);
                response.setData(pushId);
            }else {
                // 修改
                pushService.updatePushCrowdInfo(pushBO);
                response.setData(pushBO.getId());
            }
        }catch (Exception e){
            log.info("新增（修改）事件推送第一页异常信息：",e);
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(),"新增（修改）事件推送第一页失败");
        }

        response.setCode(ResponseCode.SUCCESS.getCode());
        response.setMsg("新增（修改）事件推送第一页成功");
        return response;
    }

    @PostMapping(path = "/updateThree")
    public BaseResponse<Long> updatePushSendRule(@RequestBody PushRequestVO pushVO){
        BaseResponse<Long> response = new BaseResponse();
        if (!ResponseCode.SUCCESS.getCode().equals(checkPushRequestVO(pushVO).getCode())){
            return checkPushRequestVO(pushVO);
        }
        PushBO pushBO = convert2BO(pushVO);
        try{
            // 修改
            pushService.updatePushSendRule(pushBO);
            response.setData(pushBO.getId());
        }catch (Exception e){
            log.info("修改事件推送第三页异常信息：",e);
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(),"修改事件推送第三页失败");
        }

        response.setCode(ResponseCode.SUCCESS.getCode());
        response.setMsg("修改事件推送第三页成功");
        return response;
    }

    /**
     * 更改PUSH开关状态
     * @param id
     * @param pushStatus
     * @return com.oyo.common.response.BaseResponse
     */
    @GetMapping("/switch")
    public BaseResponse updatePushSwitch(@RequestParam(value = "id") Long id, @RequestParam(value = "pushStatus") Integer pushStatus){
        BaseResponse response = new BaseResponse<>();
        PushBO pushBO = new PushBO();
        pushBO.setPushStatus(pushStatus);
        pushBO.setId(id);
        try{
            pushService.updateSwitch(pushBO);
        }catch (Exception e){
            log.info("修改事件开关状态异常信息：",e);
            response.setCode(ResponseCode.FAILURE.getCode());
            response.setMsg(e.getMessage());
            return response;
        }
        response.setCode(ResponseCode.SUCCESS.getCode());
        response.setMsg("修改事件开关状态成功");
        return response;
    }

    /**
     * 通过PUSH id删除PUSH
     * @param id
     * @return com.oyo.common.response.BaseResponse
     */
    @GetMapping("/delete")
    public BaseResponse delete(@RequestParam(value = "id") Long id){
        BaseResponse response = new BaseResponse<>();
        PushBO pushBO = pushService.selectById(id);
        // 开启状态的push，检查是否满足删除条件
        PushBO oriPushBO = pushService.selectById(id);
        if(oriPushBO.getPushStatus().equals(1)){
            if(MemberConstants.SEND_IMMEDIATELY.equals(pushBO.getSendType())){
                log.info("立即发送的不能删除");
                response.setCode(ResponseCode.FAILURE.getCode());
                response.setMsg("立即发送类型的PUSH的不能删除");
                return response;
            }
            // 原来状态是定时发送，并且距离发送时间小于push定时job间隔，不允许修改
            if(!pushBO.getSendConfig().getSendStartTime().after(new Date(System.currentTimeMillis()+MemberConstants.TIME_INTERVAL))){
                log.info("已发送或邻近发送，不允许修改");
                response.setCode(ResponseCode.FAILURE.getCode());
                response.setMsg("已发送或邻近发送，不允许修改");
                return response;
            }
        }

        try{
            pushService.deletePush(id);
        }catch (Exception e){
            log.info("删除事件推送异常信息：",e);
            response.setCode(ResponseCode.FAILURE.getCode());
            response.setMsg("删除事件推送失败");
            return response;
        }
        response.setCode(ResponseCode.SUCCESS.getCode());
        response.setMsg("删除事件推送成功");
        return response;
    }

    /**
     * 新建、修改模板信息
     * @param pushTemplateDTO
     * @return com.oyo.common.response.BaseResponse
     */
    @PostMapping(path = "/createTemplate")
    public BaseResponse createPushTemplate(@RequestBody PushTemplateDTO pushTemplateDTO){
        List<OrganizationDto> dtoList = remoteOrganizationService.getAllFirstLevelOrganizations();
        String organizationCode = "";
        String organizationName = "";
        if(CollectionUtils.isNotEmpty(dtoList)){
            for(OrganizationDto organizationDto:dtoList){
                if(null!=pushTemplateDTO.getDepartmentId() && pushTemplateDTO.getDepartmentId().equals(organizationDto.getId())){
                    organizationCode = organizationDto.getCode();
                    organizationName = organizationDto.getName();
                }
            }
        }
        // 如果模板列表不为空
        if(CollectionUtils.isNotEmpty(pushTemplateDTO.getTemplateInfos())){
            // 先删掉push原有模板
            pushTemplateRelationService.deleteRelationByPushId(pushTemplateDTO.getPushId());
            // 创建模板
            List<String> templateNums = Lists.newArrayList();
            for(PushTemplateDTO.TemplateInfo templateInfo:pushTemplateDTO.getTemplateInfos()){
                templateInfo.setTriggerChannel(pushTemplateDTO.getTriggerChannel());
                templateInfo.setPushId(pushTemplateDTO.getPushId());
                templateInfo.setOrganizationCode(organizationCode);
                templateInfo.setOrganizationName(organizationName);

                // 附加站内信方式创建模板
                if(templateInfo.getIsAttachInternalMsg()){
                    String internalMsgTemplateCode = pushBizServiceImpl.createTemplate(templateInfo);
                    if(StringUtils.isNotBlank(internalMsgTemplateCode)){
                        log.info("站内信模板编码：{}",internalMsgTemplateCode);
                        templateInfo.setInternalMsgTemplateCode(internalMsgTemplateCode);
                        templateInfo.setIsAttachInternalMsg(false);
                    }
                }
                String templateNum=null;
                templateNum = pushBizServiceImpl.createTemplate(templateInfo);
                if(null != templateNum){
                    templateNums.add(templateNum);
                }
            }
            if(templateNums.size() != pushTemplateDTO.getTemplateInfos().size()){
                return BaseResponse.fail("999","创建(修改)模板参数异常！");
            }
        }
        return BaseResponse.success(ResponseCode.SUCCESS);
    }

    /**
     * 查Push关联的模板信息
     * @param pushId
     * @return com.oyo.common.response.BaseResponse
     */
    @GetMapping("/queryTemplate")
    public BaseResponse<PushTemplateDTO> queryTemplate(Long pushId){
        PushTemplateDTO pushTemplateDTO = new PushTemplateDTO();
        List<PushTemplateRelationBO> relationBOList = Lists.newArrayList();
        List<PushTemplateDTO.TemplateInfo> templateInfoList = Lists.newArrayList();
        try{
            // 关联上模板信息（远程模板内容信息+本地的模板参数信息）
            relationBOList = pushTemplateRelationService.getRelationBOsByPushId(pushId);
            if(CollectionUtils.isNotEmpty(relationBOList)){
                relationBOList.forEach(pushTemplateRelationBO -> {
                    PushTemplateDTO.TemplateInfo pushTemplateInfo = pushBizServiceImpl.queryTemplateInfo(pushTemplateRelationBO);
                    templateInfoList.add(pushTemplateInfo);
                });
            }
            pushTemplateDTO.setTemplateInfos(templateInfoList);
            return BaseResponse.success(pushTemplateDTO);
        }catch (Exception e){
            log.info("查询模板推送关系异常：", e);
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(), "查询模板推送关系异常");
        }
    }

    /**
     * 获取一级部门
     * @return
     */
    @GetMapping("/firstLevelOrganizations")
    public BaseResponse<List<FirstLevelOrganizationVO>> allFirstLevelOrganizations() {
        List<OrganizationDto> dtoList = remoteOrganizationService.getAllFirstLevelOrganizations();
        List<FirstLevelOrganizationVO> voList = MapperWrapper.instance().mapList(dtoList, FirstLevelOrganizationVO.class);
        return BaseResponse.success(voList);
    }

    @GetMapping("/departmentMap")
    public BaseResponse<Map<Long, String>> getDepartmentMap(){
        BaseResponse<Map<Long, String>> response = new BaseResponse<>();
        Map<Long, String> departmentMap = Maps.newHashMap();
        List<OrganizationDto> organizationDtoList = remoteOrganizationService.getAllFirstLevelOrganizations();
        organizationDtoList.forEach(organizationDto -> {
            departmentMap.put(organizationDto.getId(), organizationDto.getName());
        });
        response.setCode(ResponseCode.SUCCESS.getCode());
        response.setMsg(ResponseCode.SUCCESS.getMsg());
        response.setData(departmentMap);

        return response;
    }

    @GetMapping("/delineationMap")
    public BaseResponse<Map<String, String>> getDelineationMap(){
        BaseResponse<Map<String, String>> response = new BaseResponse<>();
        Map<String, String> delineationMap = new HashMap<>();
        List<PushEventMetaBO> pushEventMetaBOList = pushRuleService.selectAll();
        if(CollectionUtils.isNotEmpty(pushEventMetaBOList)){
            pushEventMetaBOList.forEach(pushEventMetaBO -> {
                delineationMap.put(pushEventMetaBO.getEventKey(), pushEventMetaBO.getEventName());
            });
        }

        response.setCode(ResponseCode.SUCCESS.getCode());
        response.setMsg(ResponseCode.SUCCESS.getMsg());
        response.setData(delineationMap);

        return  response;
    }

    private PushVO convert2VO(PushBO pushBO){
        PushVO pushVO = new PushVO();
        pushVO.setId(pushBO.getId());
        pushVO.setPushName(pushBO.getPushName());
        pushVO.setPushStatus(pushBO.getPushStatus());
        pushVO.setDescription(pushBO.getDescription());
        pushVO.setDepartmentId(pushBO.getDepartmentId());
        pushVO.setTriggerType(pushBO.getTriggerType());
        pushVO.setValidityFlag(pushBO.getValidityFlag());
        if(null != pushBO.getValidityFlag() && Integer.valueOf(1).equals(pushBO.getValidityFlag())){
            // 永久有效的情况
            pushVO.setValidityStart("");
            pushVO.setValidityEnd("");
        }else{
            //  非永久有效
            pushVO.setValidityStart(pushBO.getValidityStart() == null?"":DateUtils.format(pushBO.getValidityStart(), "yyyy-MM-dd HH:mm:ss"));
            pushVO.setValidityEnd(pushBO.getValidityEnd() == null?"":DateUtils.format(pushBO.getValidityEnd(), "yyyy-MM-dd HH:mm:ss"));
        }

        pushVO.setRule(pushBO.getRule());
        pushVO.setRuleDetail(pushBO.getRuleDetail());
        pushVO.setTriggerChannel(pushBO.getTriggerChannel());
        pushVO.setPushTemplateId(pushBO.getPushTemplateId());
        pushVO.setCreateUserId(pushBO.getCreateUserId());
        pushVO.setCreateUserName(pushBO.getCreateUserName());

        pushVO.setCreateTime(pushBO.getCreateTime()==null?"":DateUtils.format(pushBO.getCreateTime(),"yyyy-MM-dd HH:mm:ss"));
        pushVO.setUpdateUserId(pushBO.getUpdateUserId());
        pushVO.setUpdateUserName(pushBO.getUpdateUserName());
        pushVO.setUpdateTime(pushBO.getUpdateTime());
        pushVO.setIsDeleted(pushBO.getIsDeleted());
        pushVO.setSendType(pushBO.getSendType());
        pushVO.setActType(pushBO.getActType());
        pushVO.setActTypeDetail(pushBO.getActTypeDetail());
        pushVO.setActUserType(pushBO.getActUserType());
        pushVO.setCouponAmount(pushBO.getCouponAmount());
        pushVO.setCouponCode(pushBO.getCouponCode());
        pushVO.setCouponType(pushBO.getCouponType());
        if(pushBO.getTargetCrowdConfig() != null){
            pushVO.setTargetCrowdType(pushBO.getTargetCrowdConfig().getTargetCrowdType());
            pushVO.setCrowds(pushBO.getTargetCrowdConfig().getCrowds());
            pushVO.setGrayFlag(Integer.valueOf(1).equals(pushBO.getTargetCrowdConfig().getGrayFlag()));
            pushVO.setGrayPercent(pushBO.getTargetCrowdConfig().getGrayPercent());
            pushVO.setCrowdsGather(pushBO.getTargetCrowdConfig().getCrowdsGather());
            pushVO.setCustomCrowdInfo(pushBO.getTargetCrowdConfig().getCustomCrowdInfo());
            pushVO.setTriggerCondition(pushBO.getTargetCrowdConfig().getTriggerCondition());
        }
        if(pushBO.getSendConfig() != null){
            pushVO.setSendStartTime(pushBO.getSendConfig().getSendStartTime()==null?"":DateUtils.format(pushBO.getSendConfig().getSendStartTime(),"yyyy-MM-dd HH:mm:ss"));
            pushVO.setSendEndTime(pushBO.getSendConfig().getSendEndTime()==null?"":DateUtils.format(pushBO.getSendConfig().getSendEndTime(),"yyyy-MM-dd HH:mm:ss"));
            pushVO.setSendInterval(pushBO.getSendConfig().getSendInterval());
        }
        if(pushBO.getSendFrequency() != null){
            pushVO.setSendFrequencySwitch(pushBO.getSendFrequency().getSendFrequencySwitch());
            pushVO.setSendFrequencyDay(pushBO.getSendFrequency().getSendFrequencyDay());
            pushVO.setSendFrequencyTimes(pushBO.getSendFrequency().getSendFrequencyTimes());
        }
        if(pushBO.getTriggerReward() != null){
            pushVO.setTriggerRewardSwitch(pushBO.getTriggerReward().getTriggerRewardSwitch());
            pushVO.setTriggerRewardURL(pushBO.getTriggerReward().getTriggerRewardURL());
        }

        pushVO.setIsFinish(pushBO.getIsFinish());
        pushVO.setUserType(pushBO.getUserType());
        return pushVO;
    }

    private PushBO convert2BO(PushRequestVO pushVO){
        PushBO pushBO = new PushBO();
        pushBO.setId(pushVO.getId());
        pushBO.setPushName(pushVO.getPushName());
        pushBO.setPushStatus(pushVO.getPushStatus());
        pushBO.setDescription(pushVO.getDescription());

        pushBO.setActUserType(pushVO.getActUserType());
        pushBO.setActType(pushVO.getActType());
        pushBO.setActTypeDetail(pushVO.getActTypeDetail());
        pushBO.setCouponCode(pushVO.getCouponCode());
        pushBO.setCouponAmount(pushVO.getCouponAmount());
        pushBO.setCouponType(pushVO.getCouponType());

        pushBO.setDepartmentId(pushVO.getDepartmentId());
        pushBO.setTriggerType(pushVO.getTriggerType());

        PushBO.TargetCrowdConfig targetCrowdConfig = new PushBO.TargetCrowdConfig();
        targetCrowdConfig.setTargetCrowdType(pushVO.getTargetCrowdType());
        if(null != pushVO.getGrayFlag()){
            targetCrowdConfig.setGrayFlag(pushVO.getGrayFlag()?1:0);
        }
        targetCrowdConfig.setGrayPercent(pushVO.getGrayPercent());
        targetCrowdConfig.setCrowdsGather(pushVO.getCrowdsGather());
        targetCrowdConfig.setTriggerCondition(pushVO.getTriggerCondition());
        targetCrowdConfig.setCustomCrowdInfo(pushVO.getCustomCrowdInfo());
        pushBO.setTargetCrowdConfig(targetCrowdConfig);

        pushBO.setSendType(pushVO.getSendType());
        PushBO.SendConfig sendConfig = new PushBO.SendConfig();
        sendConfig.setSendStartTime(StringUtils.isBlank(pushVO.getSendStartTime())?null:DateUtils.formatByStringDate(pushVO.getSendStartTime(), "yyyy-MM-dd HH:mm:ss"));
        sendConfig.setSendEndTime(StringUtils.isBlank(pushVO.getSendEndTime())?null:DateUtils.formatByStringDate(pushVO.getSendEndTime(), "yyyy-MM-dd HH:mm:ss"));
        sendConfig.setSendInterval(pushVO.getSendInterval());
        pushBO.setSendConfig(sendConfig);

        pushBO.setValidityFlag(pushVO.getValidityFlag());
        if(null != pushVO.getValidityFlag() && Integer.valueOf(1).equals(pushBO.getValidityFlag())){
            // 永久有效
            pushBO.setValidityStart(null);
            pushBO.setValidityEnd(null);
        }else{
            // 非永久有效
            pushBO.setValidityStart(StringUtils.isBlank(pushVO.getValidityStart())?null:DateUtils.formatByStringDate(pushVO.getValidityStart(), "yyyy-MM-dd HH:mm:ss"));
            pushBO.setValidityEnd(StringUtils.isBlank(pushVO.getValidityEnd())?null:DateUtils.formatByStringDate(pushVO.getValidityEnd(), "yyyy-MM-dd HH:mm:ss"));
        }


        pushBO.setRule(pushVO.getRule());
        pushBO.setTriggerChannel(pushVO.getTriggerChannel());
        pushBO.setPushTemplateId(pushVO.getPushTemplateId());
        pushBO.setIsDeleted(pushVO.getIsDeleted());
        pushBO.setCreateUserId(SsoUtil.currentUser().getUserId());
        pushBO.setCreateUserName(SsoUtil.currentUser().getUserName());
        pushBO.setUpdateUserId(SsoUtil.currentUser().getUserId());
        pushBO.setUpdateUserName(SsoUtil.currentUser().getUserName());
        PushBO.SendFrequency sendFrequency = new PushBO.SendFrequency();
        pushBO.setSendFrequency(sendFrequency);
        pushBO.getSendFrequency().setSendFrequencySwitch(pushVO.getSendFrequencySwitch());
        pushBO.getSendFrequency().setSendFrequencyDay(pushVO.getSendFrequencyDay());
        pushBO.getSendFrequency().setSendFrequencyTimes(pushVO.getSendFrequencyTimes());
        PushBO.TriggerReward triggerReward = new PushBO.TriggerReward();
        pushBO.setTriggerReward(triggerReward);
        pushBO.getTriggerReward().setTriggerRewardSwitch(pushVO.getTriggerRewardSwitch());
        pushBO.getTriggerReward().setTriggerRewardURL(pushVO.getTriggerRewardURL());

        pushBO.setIsFinish(pushVO.getIsFinish());
        pushBO.setUserType(pushVO.getUserType());

        return pushBO;
    }

    @GetMapping(path = "/pushTemplateList")
    public BaseResponse<List<AppPushTemplateVo>> pushTemplateList(@RequestParam(value = "triggerChannel") Integer triggerChannel){
        BaseResponse response = new BaseResponse<>();
        //和前端的类型映射关系
        Map<Integer,Integer> map=new HashMap<>();
        map.put(TriggerChannelEnum.SMS.getType(),4);
        map.put(TriggerChannelEnum.APPPUSH.getType(),1);
        map.put(TriggerChannelEnum.WECHAT.getType(),2);
        List<AppPushTemplateVo> vos=new ArrayList<>();
        List<TemplateBo> list=messagePushService.getTemplateBoList(map.get(triggerChannel));
        for (TemplateBo item:list) {
            AppPushTemplateVo appPushTemplateVo=new AppPushTemplateVo();
            BeanUtils.copyProperties(item,appPushTemplateVo);
            vos.add(appPushTemplateVo);
        }
        response.setData(vos);
        response.setCode(ResponseCode.SUCCESS.getCode());
        response.setMsg("成功");
        return response;
    }

    /**
     * 获取push的受众数量
     * @param pushId
     * @return com.oyo.common.response.BaseResponse<java.lang.Long>
     */
    @GetMapping(path = "/pushUserCount")
    public BaseResponse<Long> getAllPushUserCount(@RequestParam(value = "pushId") Long pushId){
        Long num=  pushProcessService.countPushUsersByPushId(pushId);
        BaseResponse response = new BaseResponse<>();
        response.setData(num);
        response.setCode(ResponseCode.SUCCESS.getCode());
        response.setMsg("成功");
        return response;
    }

    /**
     * 校验新增和修改push 的请求PushRequestVO
     * @param pushVO
     * @return com.oyo.common.response.BaseResponse
     */
    private BaseResponse checkPushRequestVO(PushRequestVO pushVO){
        if(null == pushVO.getId()){
            // 新增的校验
            if(MemberConstants.SEND_REGULARLY.equals(pushVO.getSendType()) || MemberConstants.SEND_REPEATEDLY.equals(pushVO.getSendType())){
                if(pushVO.getSendStartTime()!=null){
                    Date startTime = DateUtils.formatByStringDate(pushVO.getSendStartTime(), "yyyy-MM-dd HH:mm:ss");
                    if(!startTime.after(new Date(System.currentTimeMillis()+MemberConstants.TIME_INTERVAL))){
                        log.info("开始时间与当前时间间隔太短");
                        return BaseResponse.fail(ResponseCode.FAILURE.getCode(),"开始时间与当前时间间隔太短");
                    }
                }
                if(MemberConstants.SEND_REPEATEDLY.equals(pushVO.getSendType()) && pushVO.getSendInterval()==null){
                    log.info("重复发送间隔不能为空");
                    return BaseResponse.fail(ResponseCode.FAILURE.getCode(),"重复发送间隔不能为空");
                }
            }
        }else {
            // 修改的校验
            PushBO oriPushBO = pushService.selectById(pushVO.getId());
            if(oriPushBO.getPushStatus().equals(1)){
                if(MemberConstants.SEND_IMMEDIATELY.equals(oriPushBO.getSendType())){
                    return BaseResponse.fail(ResponseCode.FAILURE.getCode(), "开启状态下立即发送类型的push不能修改");
                }
                // 原来状态是定时发送或者重复发送，并且当前距离发送开始时间小于push定时job间隔，不允许修改
                if(MemberConstants.SEND_REGULARLY.equals(oriPushBO.getSendType()) || MemberConstants.SEND_REPEATEDLY.equals(oriPushBO.getSendType())){
                    if(DateUtils.dateSubtract(oriPushBO.getSendConfig().getSendStartTime(), new Date(), TimeUnit.MILLISECONDS) < MemberConstants.TIME_INTERVAL){
                        return BaseResponse.fail(ResponseCode.FAILURE.getCode(), "push即将发送或已发送，不能修改");
                    }
                }
            }
        }
        return BaseResponse.success(ResponseCode.SUCCESS);
    }

    private Long getDepartmentIdByUserId(Long userId){
        AccountDto accountDto = bUserInfoRemoteService.getBUserInfoById(userId);
        if(null != accountDto && CollectionUtils.isNotEmpty(accountDto.getUser().getEmployees())){
            return Long.parseLong(accountDto.getUser().getEmployees().get(0).getDepartmentId());
        }
        return null;
    }

    private Long getLevel2DepartmentIdByUserId(Long userId){
        AccountDto accountDto = bUserInfoRemoteService.getBUserInfoById(userId);
        if(null != accountDto && CollectionUtils.isNotEmpty(accountDto.getUser().getEmployees())){
            if(CollectionUtils.isNotEmpty(accountDto.getUser().getEmployees().get(0).getDeptDetails())){
                for(DeptDetailDto deptDetailDto:accountDto.getUser().getEmployees().get(0).getDeptDetails()){
                    if(2==deptDetailDto.getDeptLevel()){
                        return deptDetailDto.getDepartmentId();
                    }
                }
            }
        }
        return null;
    }


}
