package com.oyo.ump.member.web.vo;

import lombok.Data;

import java.io.Serializable;

/**
 * @author Dong
 * @Description 模板参数信息配置
 * @Date 2019-09-09
 */
@Data
public class TemplateParameterVO implements Serializable {
    private Long id;
    private String name;
    private String dictCol;
    private String dictTab;
    private Integer source;
    private Integer parameterType;
}
