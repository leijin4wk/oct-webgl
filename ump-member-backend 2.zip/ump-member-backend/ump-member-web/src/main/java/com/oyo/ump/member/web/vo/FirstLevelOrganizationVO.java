package com.oyo.ump.member.web.vo;

import lombok.Data;

/**
 * @author Dong
 * @Description
 * @Date 2019-09-12
 */
@Data
public class FirstLevelOrganizationVO {

    private Long id;

    private String name;

    private Long parentId;

    private String code;

    private Boolean valid;

    private Boolean available;

}

