package com.oyo.ump.member.web.vo;

import lombok.Data;

import java.io.Serializable;

/**
 * @Description: 会员等级信息VO
 * @Author: fang
 * @create: 2019-03-13
 **/
@Data
public class MemberGradeInfoVO implements Serializable {
    private Integer gradeId;
    private String grade;
    private Integer gradeOrd;
    private String gradeName;
    private Integer roomNights;
    private Integer noShow;
    private Integer validPeriod;
    private Boolean degradeFlag;
    private Integer relegationNights;
    private Integer relegationNoshow;
    private String icon1;
    private String icon2;
    private String description;
    private Integer previousGradeId;
    private Integer nextGradeId;
    private String text;
    private Boolean memberLimit;
    /**
     * -1为无定级天数限制
     */
    private Integer relegationDays;
    private String tenant;

}
