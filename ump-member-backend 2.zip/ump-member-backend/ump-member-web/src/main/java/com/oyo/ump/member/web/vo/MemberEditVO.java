package com.oyo.ump.member.web.vo;

import lombok.Data;

import java.io.Serializable;

/**
 * @Description: todo
 * @Author: fang
 * @create: 2019-03-28
 **/
@Data
public class MemberEditVO implements Serializable {
    private Boolean success;
    private String msg;
}
