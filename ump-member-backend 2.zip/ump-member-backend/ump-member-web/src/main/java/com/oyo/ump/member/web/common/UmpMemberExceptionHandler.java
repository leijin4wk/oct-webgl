package com.oyo.ump.member.web.common;

import com.alibaba.dubbo.common.utils.CollectionUtils;
import com.alibaba.dubbo.common.utils.IOUtils;
import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import com.oyo.ump.member.common.exception.UmpException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.MapUtils;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.TimeoutException;

/**
 * @Description: Controller 异常统一处理
 * @Author: fang
 * @create: 2019-03-19
 **/
@Slf4j
@ControllerAdvice
@ResponseBody
public class UmpMemberExceptionHandler {
    @ExceptionHandler(value = Exception.class)
    public BaseResponse exceptionHandler(HttpServletRequest request, Exception e) {
        BaseResponse baseResponse = BaseResponse.fail(ResponseCode.FAILURE);
        final StringBuilder paramStr=new StringBuilder();
        Map<String, String[]> paramMap  =request.getParameterMap();
        if(MapUtils.isNotEmpty(paramMap)){
            paramMap.forEach((key,value)->{
                paramStr.append(key+ Arrays.toString(value));
            });
        }
        log.error("接口异常,接口URI:" + request.getRequestURI() + " 参数:" + paramStr, e);
        if (e instanceof TimeoutException) {
            return BaseResponse.fail(ResponseCode.REQUEST_TIMEOUT);
        }
        if(e instanceof UmpException){
            return ((UmpException) e).getResp();
        }
        if(e instanceof MethodArgumentNotValidException){
            MethodArgumentNotValidException exception=(MethodArgumentNotValidException)e;
            baseResponse.setMsg( getMessage(exception));
            return baseResponse;
        }
        return baseResponse;
    }
    private String  getMessage(MethodArgumentNotValidException exp) {
        StringBuilder sb =new StringBuilder();
        sb.append("[");
        Iterator var2 = exp.getBindingResult().getAllErrors().iterator();
        while (var2.hasNext()) {
            ObjectError error = (ObjectError) var2.next();
            sb.append(error.getDefaultMessage()+" ");
        }
        sb.append("]");
        return sb.toString();
    }
}

