package com.oyo.ump.member.web.controller;

import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import com.oyo.sso.core.user.SsoUser;
import com.oyo.sso.core.util.SsoUtil;
import com.oyo.ump.member.common.beanutils.MapperWrapper;
import com.oyo.ump.member.service.BonusDelayService;
import com.oyo.ump.member.service.BonusGainRuleService;
import com.oyo.ump.member.service.dto.BonusGainRuleDTO;
import com.oyo.ump.member.web.common.RequirePermission;
import com.oyo.ump.member.web.vo.BonusGainRuleVO;
import com.oyo.ump.member.web.vo.request.OyoMoneyDelayVO;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @Classname BonusGainRuleController
 * @Description 积分获取规则业务处理类
 * @Date 2019-03-16 13:15
 * @author Dong
 */
@RestController
@RequestMapping(value = "/member/gainRule")
@Api(tags = {"gainRule"}, value = "gainRule")
@Slf4j
public class BonusGainRuleController {
    @Autowired
    private BonusGainRuleService bonusGainRuleService;
    @Autowired
    private BonusDelayService bonusDelayService;

    @GetMapping()
    @RequirePermission(value = "membershipScore_integralRule")
    public BaseResponse<List<BonusGainRuleVO>> getBonusGainRuleList(){
        BaseResponse<List<BonusGainRuleVO>> response = new BaseResponse<>();
        BonusGainRuleDTO bonusGainRuleDTO;

        List<BonusGainRuleVO> bonusGainRuleVOList = Lists.newArrayList();

        response.setCode(ResponseCode.SUCCESS.getCode());
        response.setMsg(ResponseCode.SUCCESS.getMsg());
        try {
            bonusGainRuleDTO = bonusGainRuleService.getGainRuleList();
            if (bonusGainRuleDTO != null && CollectionUtils.isNotEmpty(bonusGainRuleDTO.getBonusGainRuleInfoList())) {
                bonusGainRuleDTO.getBonusGainRuleInfoList().forEach(bonusGainRuleInfo -> {
                    bonusGainRuleVOList.add(info2VO(bonusGainRuleInfo));
                });
            } else {
                response.setMsg("数据异常");
            }
        } catch (Exception e) {
            log.error("鸥币获取规则查询结果异常", e);
            return BaseResponse.fail(ResponseCode.FAILURE);
        }
        response.setData(bonusGainRuleVOList);
        return response;
    }

    private BonusGainRuleVO info2VO(BonusGainRuleDTO.BonusGainRuleInfo info){
        BonusGainRuleVO bonusGainRuleVO = MapperWrapper.instance().map(info, BonusGainRuleVO.class);
        bonusGainRuleVO.setValidType(info.getValidPeriodJson().getType());
        bonusGainRuleVO.setUndertake1(info.getComissionConfig().getUndertake1());
        bonusGainRuleVO.setUndertake1Ratio(info.getComissionConfig().getUndertake1Ratio());
        bonusGainRuleVO.setUndertake2(info.getComissionConfig().getUndertake2());
        bonusGainRuleVO.setUndertake2Ratio(info.getComissionConfig().getUndertake2Ratio());
        bonusGainRuleVO.setUndertake3(info.getComissionConfig().getUndertake3());
        bonusGainRuleVO.setUndertake3Ratio(info.getComissionConfig().getUndertake3Ratio());
        bonusGainRuleVO.setUndertake4(info.getComissionConfig().getUndertake4());
        bonusGainRuleVO.setUndertake4Ratio(info.getComissionConfig().getUndertake4Ratio());
        bonusGainRuleVO.setUndertake5(info.getComissionConfig().getUndertake5());
        bonusGainRuleVO.setUndertake5Ratio(info.getComissionConfig().getUndertake5Ratio());
        return bonusGainRuleVO;
    }
    @PutMapping("/delay")
    public BaseResponse<Boolean> updateDelay(@RequestBody OyoMoneyDelayVO oyoMoneyDelayVO ){
        SsoUser ssoUser = SsoUtil.currentUser();
        if(ssoUser==null||ssoUser.getUserId()==null){
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(),"操作人信息异常");
        }
        bonusDelayService.updateDelayByType(oyoMoneyDelayVO.getType(),oyoMoneyDelayVO.getDelay(),ssoUser.getUserId(),ssoUser.getUserName());
        return BaseResponse.success(true);
    }
    @GetMapping("/delay")
    public BaseResponse<Integer> updateDelay(@RequestParam(value = "type") Integer type){
        return BaseResponse.success(bonusDelayService.getDelayByType(type));
    }
}
