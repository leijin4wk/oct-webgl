package com.oyo.ump.member.web.controller;

import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import com.oyo.ump.member.common.exception.UmpException;
import com.oyo.ump.member.service.PushTemplateMapService;
import com.oyo.ump.member.service.bo.PushEventDefineBo;
import com.oyo.ump.member.web.vo.PushEventDefineVo;
import com.oyo.ump.member.web.vo.PushTemplateMapVo;
import com.oyo.ump.member.web.vo.request.PushEventDefineInsertVo;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.ws.rs.POST;
import java.util.List;
import java.util.stream.Collectors;


/**
 * 事件定义接口
* @author frank
* @date 2019-07-30 10:36
**/
@RestController
@RequestMapping(value = "/member/eventDefine")
@Api(tags = {"eventDefine"}, value = "eventDefine")
@Slf4j
public class PushEventDefineController {
    @Autowired
    private PushTemplateMapService pushTemplateMapService;

    @GetMapping("/list")
    public BaseResponse<List<PushEventDefineVo>> getPushTemplateMapVoList() {
        BaseResponse baseResponse = new BaseResponse();
        baseResponse.setCode(ResponseCode.SUCCESS.getCode());
        baseResponse.setMsg(ResponseCode.SUCCESS.getMsg());
        List<PushEventDefineBo> list=pushTemplateMapService.getPushEventDefineBoList();
        baseResponse.setData(list.stream().map(item->{
            PushEventDefineVo pushEventDefineVo=new PushEventDefineVo();
            pushEventDefineVo.setDelineationName(item.getDelineationName());
            pushEventDefineVo.setEventKey(item.getEventKey());
            pushEventDefineVo.setId(item.getId());
            return pushEventDefineVo;
        }).collect(Collectors.toList()));
        return baseResponse;
    }
    @PostMapping("/insert")
    public BaseResponse<List<PushTemplateMapVo>> insertEventDefine(@RequestBody @Valid PushEventDefineInsertVo pushEventDefineInsertVo) {
        BaseResponse baseResponse = new BaseResponse();
        baseResponse.setCode(ResponseCode.SUCCESS.getCode());
        baseResponse.setMsg(ResponseCode.SUCCESS.getMsg());
        try {
            PushEventDefineBo pushEventDefineBo=new PushEventDefineBo();
            pushEventDefineBo.setEventKey(pushEventDefineInsertVo.getEventKey());
            pushEventDefineBo.setDelineationName(pushEventDefineInsertVo.getDelineationName());
            pushTemplateMapService.insertPushEventDefine(pushEventDefineBo);
        }catch (UmpException e){
            baseResponse.setCode(ResponseCode.FAILURE.getCode());
            baseResponse.setMsg(e.getMessage());
        }
        return baseResponse;
    }

    @PostMapping("/update")
    public BaseResponse<List<PushTemplateMapVo>> updateEventDefine(@RequestBody @Valid PushEventDefineVo pushEventDefineVo) {
        BaseResponse baseResponse = new BaseResponse();
        baseResponse.setCode(ResponseCode.SUCCESS.getCode());
        baseResponse.setMsg(ResponseCode.SUCCESS.getMsg());
        try {
            PushEventDefineBo pushEventDefineBo=new PushEventDefineBo();
            pushEventDefineBo.setId(pushEventDefineVo.getId());
            pushEventDefineBo.setEventKey(pushEventDefineVo.getEventKey());
            pushEventDefineBo.setDelineationName(pushEventDefineVo.getDelineationName());
            pushTemplateMapService.updatePushEventDefine(pushEventDefineBo);
        }catch (UmpException e){
            baseResponse.setCode(ResponseCode.FAILURE.getCode());
            baseResponse.setMsg(e.getMessage());
        }
        return baseResponse;
    }

    @GetMapping("/findById")
    public BaseResponse<List<PushTemplateMapVo>> findById(@RequestParam("id") Long id) {
        BaseResponse baseResponse = new BaseResponse();
        baseResponse.setCode(ResponseCode.SUCCESS.getCode());
        baseResponse.setMsg(ResponseCode.SUCCESS.getMsg());
        baseResponse.setData(pushTemplateMapService.findPushEventDefineById(id));
        return baseResponse;
    }

}
