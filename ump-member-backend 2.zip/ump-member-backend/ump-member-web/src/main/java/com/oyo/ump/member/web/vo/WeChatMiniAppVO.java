package com.oyo.ump.member.web.vo;

import com.oyo.openapi.client.mp.miniapp.enums.MiniappEnum;
import lombok.Data;

/**
 * @author ：AaronZhang
 * @date ：Created in 2019-07-03 19:35
 * @description：微信小程序VO
 * @modified By：
 * @version: 1.0$
 */
@Data
public class WeChatMiniAppVO {
    private String appId;

    private String mp;

    private String appName;

    private MiniappEnum miniappEnum;

    private String interMsgDetailPageRootPath;
}
