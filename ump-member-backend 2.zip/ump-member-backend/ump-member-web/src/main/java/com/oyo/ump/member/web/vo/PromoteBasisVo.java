package com.oyo.ump.member.web.vo;

import lombok.Data;

import java.io.Serializable;

@Data
public class PromoteBasisVo implements Serializable {
    private String label;
    private Long value;
    private Long activityId;
}
