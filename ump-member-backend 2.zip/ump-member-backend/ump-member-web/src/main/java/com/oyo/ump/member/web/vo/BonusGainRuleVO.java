package com.oyo.ump.member.web.vo;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @Classname BonusGainRuleVO
 * @Description 积分获取规则信息类
 * @Date 2019-03-16 13:13
 * @author Dong
 */
@Data
public class BonusGainRuleVO implements Serializable {
    private Integer id;
    private String bonusType;
    private Boolean status;
    private Boolean gainFlag;
    private Boolean costFlag;
    private Integer initalValue;
    private Integer limitValue;
    private Boolean multipleFlag;
    private Date validPeriod;
    /**
     * 有效期类型 1、固定日期（例如：次年12月31）  2、即日起一段时间点（例如：100天）
     */
    private Integer validType;
    /**
     * 有效期str 给前端展示
     */
    private String validity;
    /**
     * 有效期str
     */
    private String strValidPeriod;
    private String undertake1;
    private Integer undertake1Ratio;
    private String undertake2;
    private Integer undertake2Ratio;
    private String undertake3;
    private Integer undertake3Ratio;
    private String undertake4;
    private Integer undertake4Ratio;
    private String undertake5;
    private Integer undertake5Ratio;

}
