package com.oyo.ump.member.web.vo;

import lombok.Data;

import java.io.Serializable;

/**
 * @Description: 权益VO
 * @Author: fang
 * @create: 2019-03-14
 **/
@Data
public class PrivilegeVO implements Serializable {
    private Integer id;
    private String grade;
    //专享折扣
    private String specialDiscount;
    //延迟退房
    private String lateCheckout;
    //最优价保障
    private String optimalPriceGurantee;
    //预定保障
    private String reservationGuarantee;
    //免费wifi
    private String freeWifi;
    //奖励积分
    private String bonus;
}
