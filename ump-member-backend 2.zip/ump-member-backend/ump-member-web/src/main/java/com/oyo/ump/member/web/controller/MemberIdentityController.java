package com.oyo.ump.member.web.controller;

import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import com.oyo.common.response.PagedResponse;
import com.oyo.ump.member.biz.member.MemberIdentityListBizService;
import com.oyo.ump.member.common.beanutils.MapperWrapper;
import com.oyo.ump.member.common.constants.MemberConstants;
import com.oyo.ump.member.service.MemberIdentityListService;
import com.oyo.ump.member.service.bo.MemberIdentityBO;
import com.oyo.ump.member.web.common.RequirePermission;
import com.oyo.ump.member.web.vo.MemberIdentityInfoVO;
import com.oyo.ump.member.web.vo.MemberIdentityPageVO;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.oyo.ump.member.common.constants.MemberConstants.OYO_TENANT;

/**
 * @author Dong
 * @Classname MemberIdentityController
 * @Description 会员身份业务逻辑
 * @Date 2019-03-21
 */
@RestController
@RequestMapping(value = "/member/identity")
@Api(tags = {"identity"}, value = "identity")
@Slf4j
public class MemberIdentityController {
    @Autowired
    MemberIdentityListService memberIdentityListService;

    @Autowired
    MemberIdentityListBizService memberIdentityListBizService;

    /**
     * 用户信息列表查询
     * @param startTime
     * @param endTime
     * @param refreshRule
     * @param nickName
     * @param phone
     * @param pageNum
     * @param pageSize
     * @return com.oyo.common.response.BaseResponse<com.oyo.ump.member.web.vo.MemberIdentityPageVO>
     */
//    @RequirePermission(value = "membershipStatus_membershipStatusList_page")
    @GetMapping("/list")
    public BaseResponse<MemberIdentityPageVO> getMemberIdentityList(@RequestParam(value = "startTime", required = false, defaultValue = "") String startTime,
                                                                    @RequestParam(value = "endTime", required = false, defaultValue = "") String endTime,
                                                                    @RequestParam(value = "refreshRule", required = false, defaultValue = "") String refreshRule,
                                                                    @RequestParam(value = "nickName", required = false, defaultValue = "") String nickName,
                                                                    @RequestParam(value = "phone", required = false, defaultValue = "") String phone,
                                                                    @RequestParam(value = "pageNum", required = false, defaultValue = "1") String pageNum,
                                                                    @RequestParam(value = "pageSize", required = false, defaultValue = "5") String pageSize,
                                                                    @RequestParam(value = "tenant", required = false, defaultValue = OYO_TENANT) String tenant
                                                                    ){
        BaseResponse<MemberIdentityPageVO> response = new BaseResponse<>();
        List<MemberIdentityInfoVO> memberIdentityInfoVOList = Lists.newArrayList();
        MemberIdentityPageVO memberIdentityPageVO = new MemberIdentityPageVO();

        Map<String, Object> params = new HashMap<>();
        params.put("startTime", startTime);
        params.put("endTime", endTime);
        params.put("refreshRule", refreshRule);
        params.put("nickName", nickName);
        params.put("phone", phone);
        params.put("pageNum", pageNum);
        params.put("pageSize", pageSize);
        params.put("tenant",tenant);

        // 由于OYO全量会员量大, 限制必须选择筛选条件进行查询
        if (MemberConstants.OYO_TENANT.equals(tenant) && StringUtils.isBlank(phone) && StringUtils.isBlank(nickName) && StringUtils.isBlank(refreshRule)) {
            memberIdentityPageVO.setTotal(0L);
            memberIdentityPageVO.setPageNum(Integer.parseInt(pageNum));
            memberIdentityPageVO.setPageSize(Integer.parseInt(pageSize));
            memberIdentityPageVO.setMemberIdentityInfoVOList(Lists.newArrayList());
            return BaseResponse.success(memberIdentityPageVO);
        }

        PagedResponse<MemberIdentityBO> memberIdentityPageBO = memberIdentityListBizService.getMemberIdentityList(params);

        if(memberIdentityPageBO != null && CollectionUtils.isNotEmpty(memberIdentityPageBO.getResult())){
            memberIdentityPageBO.getResult().forEach(memberIdentityInfo -> {
                if(memberIdentityInfo != null && memberIdentityInfo.getPhone() != null && memberIdentityInfo.getPhone().length() == 11 && MemberConstants.OYO_TENANT.equals(tenant)){
                    String normalPhone = memberIdentityInfo.getPhone();
                    memberIdentityInfo.setPhone(normalPhone.substring(0,3)+"****"+normalPhone.substring(7, 11));
                }
                MemberIdentityInfoVO memberIdentityInfoVO =  MapperWrapper.instance().map(memberIdentityInfo, MemberIdentityInfoVO.class);
                memberIdentityInfoVOList.add(memberIdentityInfoVO);
            });
        }else{
            response.setMsg("数据异常");
        }

        memberIdentityPageVO.setMemberIdentityInfoVOList(memberIdentityInfoVOList);
        if(memberIdentityPageBO != null){
            memberIdentityPageVO.setTotal(memberIdentityPageBO.getTotalCount());
            memberIdentityPageVO.setPageNum(memberIdentityPageBO.getPageNum());
            memberIdentityPageVO.setPageSize(memberIdentityPageBO.getPageSize());
        }

        response.setCode(ResponseCode.SUCCESS.getCode());
        response.setMsg(ResponseCode.SUCCESS.getMsg());

        response.setData(memberIdentityPageVO);

        return response;
    }

    /**
     * 获取所有的等级刷新规则
     * @param
     * @return com.oyo.common.response.BaseResponse<java.util.Map<java.lang.String,java.lang.String>>
     */
//    @RequirePermission(value = "membershipStatus_membershipStatusList_page")
    @GetMapping("/ruleMap")
    public BaseResponse<Map<String, String>> getRefreshRule(@RequestParam(value = "tenant", required = false, defaultValue = OYO_TENANT) String tenant){
        BaseResponse<Map<String, String>> response = new BaseResponse<>();
        Map<String, String> ruleMap = memberIdentityListService.getAllGrade(tenant);
        response.setCode(ResponseCode.SUCCESS.getCode());
        response.setMsg(ResponseCode.SUCCESS.getMsg());
        response.setData(ruleMap);
        return  response;
    }

}
