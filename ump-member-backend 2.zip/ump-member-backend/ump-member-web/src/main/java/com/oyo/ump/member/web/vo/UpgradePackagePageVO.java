package com.oyo.ump.member.web.vo;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author Dong
 * @Classname UpgradePackagePageVO
 * @Description TODO
 * @Date 2019-03-27
 */
@Data
public class UpgradePackagePageVO implements Serializable{
    private List<UpgradePackageVO> upgradePackageVOList;
    private Long total;
    private Integer pageNum;
    private Integer pageSize;
}
