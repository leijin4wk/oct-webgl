package com.oyo.ump.member.web.controller;

import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import com.oyo.ump.member.common.beanutils.MapperWrapper;
import com.oyo.ump.member.service.EventConfigDictService;
import com.oyo.ump.member.service.TagValueService;
import com.oyo.ump.member.service.bo.EventConfigDictBO;
import com.oyo.ump.member.web.vo.EventConfigDictVO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/**
 * @author Dong
 * @Classname EventConfigDictController
 * @Description 自定义事件的交互接口
 * @Date 2019-08-27
 */
@RestController
@RequestMapping(value = "/member/event")
@Slf4j
public class EventConfigDictController {
    @Autowired
    EventConfigDictService eventConfigDictService;
    @Autowired
    TagValueService tagValueService;

    @GetMapping("/eventName")
    public BaseResponse<List<EventConfigDictVO>> getAllEventName(){
        BaseResponse<List<EventConfigDictVO>> response = new BaseResponse<>();
        List<EventConfigDictVO> vos = Lists.newArrayList();
        try{
          List<EventConfigDictBO> eventConfigDictBOs = eventConfigDictService.getAllEventName();
          if(CollectionUtils.isNotEmpty(eventConfigDictBOs)){
              eventConfigDictBOs.forEach(eventConfigDictBO -> {
                  EventConfigDictVO eventConfigDictVO = MapperWrapper.instance().map(eventConfigDictBO, EventConfigDictVO.class);
                  vos.add(eventConfigDictVO);
              });
              response.setData(vos);
          }
        }catch (Exception e){
            log.info("获取大类自定义事件名异常:{}", e);
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(),"获取大类自定义事件名异常");
        }
        response.setCode(ResponseCode.SUCCESS.getCode());
        return response;
    }

    @GetMapping("/property")
    public BaseResponse<List<EventConfigDictVO>> getEventProperty(@RequestParam(value = "eventName") String eventName){
        if(StringUtils.isBlank(eventName)){
            return BaseResponse.fail(ResponseCode.ILLEGAL_ARGUMENT.getCode(),"参数有误，eventName不能为空");
        }
        BaseResponse<List<EventConfigDictVO>> response = new BaseResponse<>();
        List<EventConfigDictVO> eventConfigDictVOS = Lists.newArrayList();
        try{
            List<EventConfigDictBO> eventConfigDictBOs = eventConfigDictService.getPropertyName(eventName);
            if(CollectionUtils.isNotEmpty(eventConfigDictBOs)){
                eventConfigDictBOs.forEach(eventConfigDictBO -> {
                    EventConfigDictVO eventConfigDictVO = MapperWrapper.instance().map(eventConfigDictBO, EventConfigDictVO.class);
                    eventConfigDictVOS.add(eventConfigDictVO);
                });
                response.setData(eventConfigDictVOS);
            }
        }catch (Exception e){
            log.info("获取自定义事件属性信息:{}", e);
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(),"获取自定义事件属性信息");
        }
        response.setCode(ResponseCode.SUCCESS.getCode());
        return response;
    }

    @GetMapping("/last")
    public BaseResponse<List<Map<String,Object>>> getLast(@RequestParam(value = "eventName") String eventName,@RequestParam(value = "tagColumn") String tagColumn){
        if(StringUtils.isBlank(tagColumn)){
            return BaseResponse.fail(ResponseCode.ILLEGAL_ARGUMENT.getCode(), "参数有误");
        }
        BaseResponse<List<Map<String,Object>>> response = new BaseResponse<>();
        List<Map<String,Object>> resList = Lists.newArrayList();
        try{
            EventConfigDictBO eventConfigDictBO = eventConfigDictService.selectByTagColumn(eventName,tagColumn);
            if(eventConfigDictBO != null && eventConfigDictBO.getValueArea() != null){
                try{
                    resList = tagValueService.selectByValueArea(eventConfigDictBO.getValueArea());
                }catch (Exception e){
                    log.info("自定义事件查询ADB标签值异常：", e);
                    return BaseResponse.fail(ResponseCode.FAILURE.getCode(),"自定义事件查询ADB标签值异常");
                }
            }
        }catch (Exception e){
            log.info("自定义事件查询value_area异常：", e);
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(),"自定义事件查询value_area异常");
        }
        response.setCode(ResponseCode.SUCCESS.getCode());
        response.setMsg(ResponseCode.SUCCESS.getMsg());
        response.setData(resList);
        return response;
    }

}
