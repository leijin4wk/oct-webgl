package com.oyo.ump.member.web.common;

import lombok.Data;

import java.util.List;

/**
 * @author: fang
 * @date: 2019-03-29 16:58
 * @description:
 */
@Data
public class Resource {

    private String code;

    private List<Resource> resourceTrees;
}
