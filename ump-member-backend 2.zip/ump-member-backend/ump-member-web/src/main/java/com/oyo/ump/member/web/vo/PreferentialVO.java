package com.oyo.ump.member.web.vo;

import lombok.Data;

import java.io.Serializable;

/**
 * @author Dong
 * @Classname PreferentialVO
 * @Description 用户优惠信息VO
 * @Date 2019-07-04
 */
@Data
public class PreferentialVO implements Serializable {
    private Long id;  //用户优惠券id
    private String preferentialType;  //优惠类型
    private String showName;  //优惠券名称
    private Integer category;  //优惠券类型：1：现金抵用券、2：现金折扣券、3：免房券。目前仅支持现金抵用券，免房券
    private String startTime;  //优惠券开始时间（老券使用开始时间）
    private String endTime;  //发优惠优惠券结束时间（老券使用结束时间）
    private String usedTime;  //使用时间
    private String identifyCode;  //优惠券批次号
    private Integer checkinType;  //入住类型 2:钟点房 1: 全日房
    private Integer status;  //优惠券状态：0：未使用，1：已使用，2：已过期，3:冻结,4:废弃
    private String receiveTime;  //领券时间
}
