package com.oyo.ump.member.web.vo;

import lombok.Data;

import java.io.Serializable;

/**
 * 短信类型VO
 * @author toby Zhang
 * @date 2019-07-04 16:17
 * @description
 */
@Data
public class SmsTemplateTypeVO implements Serializable {

    private static final long serialVersionUID = -5097192948472986909L;

    private int ordinal;

    private String name;
}
