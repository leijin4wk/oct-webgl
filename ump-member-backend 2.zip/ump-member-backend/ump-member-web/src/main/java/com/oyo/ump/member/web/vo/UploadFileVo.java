package com.oyo.ump.member.web.vo;


import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;

import java.io.Serializable;

@Data
public class UploadFileVo implements Serializable {
    //fileSize: 2701
    //originalName: "userImg.png"
    //public: true
    //relPath: "permanent/ump_platform_backend/uniform_upload/20191206183841mDcWDz.png"
    //url: "https://test-oyo-common-file-r.oss-cn-beijing.aliyuncs.com/permanent/ump_platform_backend/uniform_upload/20191206183841mDcWDz.png"
    //msg: "成功"
    private Integer fileSize;

    private String originalName;
    @JSONField(name ="public")
    private Boolean _public;
    private String  relPath;
    private String url;
    private String msg;

}
