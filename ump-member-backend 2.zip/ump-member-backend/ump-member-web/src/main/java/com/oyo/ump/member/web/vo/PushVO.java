package com.oyo.ump.member.web.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @author Dong
 * @Classname PushVO
 * @Description 事件推送VO
 * @Date 2019-05-06
 */
@Data
public class PushVO implements Serializable {
    private Long id;
    private String pushName;
    private Integer pushStatus;
    private String description;
    /**
     * 活动信息
     */
    private String actUserType;
    private String actType;
    private String actTypeDetail;
    /**
     * 优惠券信息
     */
    private String couponCode;
    private BigDecimal couponAmount;
    private String couponType;

    /**
     * 部门
     */
    private Long departmentId;
    private Integer triggerType;

    /**
     * 目标人群 1、所有用户；2、定向人群
     */
    private Integer targetCrowdType;
    private List<Long> crowds;
    private Boolean grayFlag;
    private Integer grayPercent;
    /**
     * 支持人群包集合的交叉并补
     */
    private String crowdsGather;

    /**
     * targetCrowdType定制人群时，定制人群的信息（crowdCreateType:人群创建方式（1 按标签；2 自定义）;crowdTag:标签）
     */
    private String customCrowdInfo;
    /**
     * 自定义事件触发类型的触发条件选项
     */
    private String triggerCondition;

//    /**
//     * 模板信息
//     */
//    private String templatesInfo;

    /**
     * 发送规则 1、立即发送；2、定时发送；3、重复发送
     */
    private Integer sendType;

    private String sendStartTime;
    private String sendEndTime;
    private Integer sendInterval;

    private Integer validityFlag;
    private String validityStart;
    private String validityEnd;

    private Integer sendFrequencySwitch;
    private Integer sendFrequencyDay;
    private Integer sendFrequencyTimes;
    /**
     * 圈定条件
     */
    private Long rule;
    private String ruleDetail;
    private Integer triggerChannel;
    private Long pushTemplateId;
    private Integer triggerRewardSwitch;
    private String triggerRewardURL;

    private Long createUserId;
    private String createUserName;
    private String createTime;
    private Long updateUserId;
    private String updateUserName;
    private Date updateTime;
    private Boolean isDeleted;
    /**
     * 是否创建完成，0-否；1-是
     */
    private Integer isFinish;
    /**
     * push的目标用户类型（1-c端用户，2-b端用户）
     */
    private Integer userType;
}
