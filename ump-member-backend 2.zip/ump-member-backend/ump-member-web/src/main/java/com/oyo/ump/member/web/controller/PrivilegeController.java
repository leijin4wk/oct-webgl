package com.oyo.ump.member.web.controller;

import com.oyo.common.response.BaseResponse;
import com.oyo.ump.member.common.beanutils.MapperWrapper;
import com.oyo.ump.member.service.GradeService;
import com.oyo.ump.member.service.PrivilegeService;
import com.oyo.ump.member.service.bo.GradePrivilegeBO;
import com.oyo.ump.member.web.common.RequirePermission;
import com.oyo.ump.member.web.vo.PrivilegeDetailVO;
import com.oyo.ump.member.web.vo.PrivilegeVO;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @Description: 会员权益
 * @Author: fang
 * @create: 2019-03-14
 **/
@RestController
@RequestMapping(value = "/member/privilege")
@Api(tags = {"Privilege"}, value = "Privilege")
@Slf4j
public class PrivilegeController {
    @Autowired
    private PrivilegeService privilegeService;
    @Autowired
    private GradeService gradeService;


    @GetMapping("/query")
    @RequirePermission(value = "membershipLevel_levelAndRights")
    public BaseResponse<List<PrivilegeVO>> queryMemberPrivilege() {
        List<PrivilegeVO> privilegeVOList = Lists.newArrayList();
        List<GradePrivilegeBO> boList = privilegeService.getGradePrivilegeList();
        if (CollectionUtils.isNotEmpty(boList)) {
            boList.forEach(privilegeBO -> {
                PrivilegeVO privilegeVO = convert2PrivilegeVO(privilegeBO);
                privilegeVOList.add(privilegeVO);
            });
        }
        return BaseResponse.success(privilegeVOList);
    }

    @GetMapping("/query/detail")
//    @RequirePermission(value = "membershipPrivilege_detail")
    public BaseResponse<List<PrivilegeDetailVO>> queryMemberPrivilegeDetail() {
        List<PrivilegeDetailVO> privilegeVOList;
        List<GradePrivilegeBO> gradePrivilegeBOList = privilegeService.getGradePrivilegeList();
        privilegeVOList = convert2PrivilegeDetailVO(gradePrivilegeBOList);
        return BaseResponse.success(privilegeVOList);

    }

    private List<PrivilegeDetailVO> convert2PrivilegeDetailVO(List<GradePrivilegeBO> gradePrivilegeBOList) {
        List<PrivilegeDetailVO> result = Lists.newArrayList();
        if (CollectionUtils.isNotEmpty(gradePrivilegeBOList)) {
            return gradePrivilegeBOList.stream().map(privilegeBO -> {
                        PrivilegeDetailVO privilegeDetailVO = MapperWrapper.instance().map(privilegeBO, PrivilegeDetailVO.class);
                        privilegeDetailVO.setName(gradeService.getGradeByGradeId(privilegeDetailVO.getGradeId()).getGradeName());
                        return privilegeDetailVO;
                    }
            ).collect(Collectors.toList());
        }
        return result;
    }




    private PrivilegeVO convert2PrivilegeVO(GradePrivilegeBO privilegeBO) {
        PrivilegeVO privilegeVO = new PrivilegeVO();
        privilegeVO.setGrade(privilegeBO.getGrade());
        privilegeVO.setId(privilegeBO.getGradeId());
        privilegeVO.setSpecialDiscount("享受折扣"+privilegeBO.getSpecialDiscount().getDiscount());
        privilegeVO.setLateCheckout("延迟退房"+privilegeBO.getLateCheckout().getTimeLimit()+"点");
        privilegeVO.setFreeWifi("免费wifi");
        privilegeVO.setOptimalPriceGurantee(privilegeBO.getOptimalPriceGurantee().getDescription());
        privilegeVO.setReservationGuarantee("预订保障"+privilegeBO.getReservationGuarantee().getGuaranteeHours()+"小时");
        Double factor =NumberUtils.toDouble(privilegeBO.getBonusConfig().getBonusFactor())+NumberUtils.toDouble(privilegeBO.getBonusConfig().getConsumeFactor());
        String bigDecimal= BigDecimal.valueOf(factor).stripTrailingZeros().toPlainString();
        privilegeVO.setBonus("会员鸥币"+ bigDecimal+"倍");
        return privilegeVO;

    }
}
