package com.oyo.ump.member.web.vo;

import lombok.Data;

/**
 * @author ：AaronZhang
 * @date ：Created in 2019-07-04 17:15
 * @description：微信模板内容vo
 * @modified By：
 * @version: 1.0$
 */
@Data
public class WeChatTemplateContextVO {
    private String templateId;
    private String content;
}
