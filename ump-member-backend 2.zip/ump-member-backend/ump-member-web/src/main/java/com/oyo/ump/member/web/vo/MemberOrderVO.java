package com.oyo.ump.member.web.vo;

import lombok.Data;
import org.assertj.core.util.Lists;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @Description:
 * @Author: fang
 * @create: 2019-03-29
 **/
@Data
public class MemberOrderVO {
    private Long userId;
    private List<MemberOrderInfo> result = Lists.newArrayList();
    @Data
    public static class MemberOrderInfo implements Serializable {
        private String orderSn;
        private Date createTime;
        private Date payTime;
        private String orderType;
        private BigDecimal actualAmount;
        private String orderStatus;
        private String grade;
        private String productCode;
        private String productName;
        private String PaymentChannel;
        //是否可以退订
        private Boolean refund;


    }
}
