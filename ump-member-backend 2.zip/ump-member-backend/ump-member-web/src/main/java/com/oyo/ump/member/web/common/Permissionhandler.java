//package com.oyo.ump.member.web.common;
//
//import com.alibaba.fastjson.JSON;
//import com.oyo.common.enums.ResponseCode;
//import com.oyo.sso.core.user.SsoUser;
//import com.oyo.sso.core.util.SsoUtil;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.commons.lang.StringUtils;
//import org.aspectj.lang.JoinPoint;
//import org.aspectj.lang.annotation.Aspect;
//import org.aspectj.lang.annotation.Before;
//import org.aspectj.lang.reflect.MethodSignature;
//import org.springframework.stereotype.Component;
//import org.springframework.web.bind.annotation.GetMapping;
//
//import java.lang.reflect.Method;
//import java.util.List;
//
///**
// * @author: fang
// * @date: 2019-03-29 14:45
// * @description: 校验controller API请求权限
// */
//@Slf4j
//@Aspect
//@Component
//public class Permissionhandler {
//
//    //admin账户id
//    private static final long ADMIN = -1L;
//
//    //平台权限code
//    private static final String CRM = "crm";
//
//
//    @Before("execution(* com.oyo.ump.member.web.controller..*(..))")
//    public void create(JoinPoint joinPoint) throws Exception {
//        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
//        Method method = methodSignature.getMethod();
//        if("ping".equals(method.getName())||"getUserInfo".equals(method.getName())||"printUCM2".equals(method.getName())){
//            return;
//        }
//            if(PermissionUtils.METHOD_CODE_MAP.containsKey(method.getName())){
//                if(!hasPermission(PermissionUtils.METHOD_CODE_MAP.get(method.getName()))){
//                    throw new RuntimeException("无访问权限");
//                }
//            }else {
//                throw new RuntimeException("该方法还无配置"+method.getName());
//            }
//    }
//
//    private boolean hasPermission(String resourceCode){
//        if(PermissionUtils.basicCheckPermission(resourceCode)){
//            return true;
//        }
//        Resource resourceTree = getResource();
//        if(CRM.equalsIgnoreCase(resourceTree.getCode())){
//           return PermissionUtils.resolve(resourceTree,resourceCode);
//        }
//        return false;
//    }
//    private Resource getResource(){
//        return JSON.parseObject(SsoUtil.currentUser().getResourceTree(), Resource.class);
//    }
//
//
//
//
//}
