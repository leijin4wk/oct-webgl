package com.oyo.ump.member.web.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.Date;
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PushTemplateMapVo {
    @NotNull
    private Long id;
    @NotBlank
    private String templateName;
    @NotBlank
    private String aliTemplateId;
    @NotBlank
    private String detail;
    private Date createTime;
    private Date updateTime;
    private Boolean isDeleted;
}
