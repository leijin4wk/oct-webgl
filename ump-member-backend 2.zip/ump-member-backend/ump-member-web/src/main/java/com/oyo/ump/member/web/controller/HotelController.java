package com.oyo.ump.member.web.controller;

import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import com.oyo.ump.member.common.beanutils.MapperWrapper;
import com.oyo.ump.member.service.HotelService;
import com.oyo.ump.member.service.bo.HotelBO;
import com.oyo.ump.member.service.dto.HotelDTO;
import com.oyo.ump.member.web.vo.HotelVO;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @Classname HotelController
 * @Description 处理酒店业务处理类
 * @Date 2019-03-15 13:58
 * @author Dong
 */
@RestController
@RequestMapping(value = "/member/hotel")
@Api(tags = {"Hotel"}, value = "Hotel")
@Slf4j
public class HotelController {
    @Autowired
    private HotelService hotelService;

    @GetMapping()
    public BaseResponse<List<HotelVO>> getHotelList(){

        BaseResponse<List<HotelVO>> response = new BaseResponse<>();
        List<HotelBO> hotelBOList = Lists.newArrayList();

        List<HotelVO> hotelVOList = Lists.newArrayList();

        try {
            hotelBOList = hotelService.getHotelList();
        }catch (Exception e){
            log.error("酒店列表查询结果异常",e);
            return BaseResponse.fail(ResponseCode.FAILURE);
        }

        response.setCode(ResponseCode.SUCCESS.getCode());
        response.setMsg(ResponseCode.SUCCESS.getMsg());

        if(CollectionUtils.isNotEmpty(hotelBOList)){
            hotelBOList.forEach(hotelBO -> {
                HotelVO hotelVO =  MapperWrapper.instance().map(hotelBO, HotelVO.class);
                hotelVOList.add(hotelVO);
            });
        }else{
            response.setMsg("数据异常");
        }

        response.setData(hotelVOList);

        return response;
    }
}
