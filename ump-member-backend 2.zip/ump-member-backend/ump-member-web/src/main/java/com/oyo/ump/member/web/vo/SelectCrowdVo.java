package com.oyo.ump.member.web.vo;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class SelectCrowdVo implements Serializable {

    private Date countTime;

    private String crowdName;

    private Long crowdQty;
}
