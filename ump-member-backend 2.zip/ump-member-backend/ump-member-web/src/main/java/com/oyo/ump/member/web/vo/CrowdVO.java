package com.oyo.ump.member.web.vo;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author Dong
 * @Classname PushVO
 * @Description 人群分类VO
 * @Date 2019-05-06
 */
@Data
public class CrowdVO implements Serializable {
    private Long id;
    private String crowdName;
    private String crowdStatus;
    /**
     * 数据更新时间
     */
    private String dataUpdateTime;
    private Integer crowdNum;
    /**
     * 人群创建方式（1 按标签；2 自定义）
     */
    private String crowdCreateType;
    private String crowdTag;
    /**
     * 自定义人群创建方式传入的user列表
     */
    private List<Long> userIds;
    private String createTime;
    private String updateTime;
    private Integer isDeleted;
}
