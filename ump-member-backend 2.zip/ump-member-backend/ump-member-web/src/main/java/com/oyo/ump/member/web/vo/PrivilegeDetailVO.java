package com.oyo.ump.member.web.vo;

import com.oyo.ump.member.service.bo.GradePrivilegeBO;
import lombok.Data;

import java.io.Serializable;

/**
 * @Description: todo
 * @Author: fang
 * @create: 2019-06-03
 **/
@Data
public class PrivilegeDetailVO  implements Serializable {
    private Integer gradeId;
    private String grade;
    private String name;
    private String source;
    private PrivilegeDetailVO.SpecialDiscount specialDiscount;
    private PrivilegeDetailVO.LateCheckout lateCheckout;
    private PrivilegeDetailVO.OptimalPriceGurantee optimalPriceGurantee;
    private PrivilegeDetailVO.ReservationGuarantee reservationGuarantee;
    private PrivilegeDetailVO.FreeWifi freeWifi;
    private PrivilegeDetailVO.BonusConfig bonusConfig;
    private PrivilegeDetailVO.MultipleBonus multipleBonus;
    private PrivilegeDetailVO.OtherPrivilege otherPrivilege;
    @Data
    public static class SpecialDiscount implements Serializable{
        private Integer discount;
        private Boolean memberLimit;
        private Boolean discountLimit;
        private Integer undertakeOwner;
        private Integer undertakeOyo;
        private String icon;
        private String icon2;
        private Boolean hold;
        private String description;
        private Integer index;

    }
    @Data
    public static class LateCheckout implements Serializable{
        private Boolean memberLimit;
        private String detail;
        private String timeLimit;
        private String icon;
        private String icon2;
        private Boolean hold;
        private String description;
        private Integer index;

    }
    @Data
    public static class OptimalPriceGurantee implements Serializable{
        private Boolean memberLimit;
        private String guaranteeType;
        private String icon;
        private String icon2;
        private Boolean hold;
        private String description;
        private Integer index;

    }
    @Data
    public static class ReservationGuarantee implements Serializable {
        private Boolean memberLimit;
        private Integer guaranteeHours;
        private String icon;
        private String icon2;
        private Boolean hold;
        private String description;
        private Integer index;

    }
    @Data
    public static class FreeWifi implements Serializable{
        private Boolean memberLimit;
        private Integer wifiHours;
        private String icon;
        private String icon2;
        private Boolean hold;
        private String description;
        private Integer index;


    }
    @Data
    public static class BonusConfig implements Serializable{
        private Boolean memberLimit;
        private String bonusFactor;
        private String consumeFactor;
        private String icon;
        private String icon2;
        private Boolean hold;
        private String description;
        private Integer index;
        private String activityFactor;
        private Integer undertakeOwner;
        private Integer undertakeOyo;
        private SignPoint signPoint;
    }
    @Data
    public static class MultipleBonus implements Serializable{
        private Boolean memberLimit;
        private String bonusFactor;
        private Boolean hold;
        private String description;
        private Integer undertakeOwner;
    }
    @Data
    public static class OtherPrivilege implements Serializable{
        private Boolean deposit;
        private Boolean breakfast;
        private Boolean books;
        private Boolean fruits;
        private Boolean fastCheckout;
        private Boolean gym;
        private Boolean washClothes;
        private Boolean storage;
        private String reservation;
        private Boolean hold;
    }
    @Data
    public static class SignPoint{
        private Integer pointNum;
        private Integer delay;
        private Integer gainUndertakeOyo;
        private Integer gainUndertakeOwner;
        private Integer costUndertakeOyo;
        private Integer costUndertakeOwner;
    }
}
