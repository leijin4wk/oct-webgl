package com.oyo.ump.member.web.vo;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @Classname UpgradePackageVO
 * @Description 升级包信息给前端
 * @Date 2019-03-14 20:04
 * @author Dong
 */
@Data
public class UpgradePackageVO implements Serializable {
    private Integer id;
    private String skuCode;
    private String packageName;
    private Integer gradeOrd;
    private String gradeName;
    private Integer upgradeId;
    private String upgradeName;
    private BigDecimal price;
    private BigDecimal frontCommission;
    private BigDecimal ownerCommission;
    private BigDecimal oyoCommission;
    private Boolean status;
    private Long stock;
}
