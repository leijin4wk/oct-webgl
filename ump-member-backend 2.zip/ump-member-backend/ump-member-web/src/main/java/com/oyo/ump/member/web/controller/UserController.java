package com.oyo.ump.member.web.controller;

import com.oyo.framework.common.rest.RopResponse;
import com.oyo.sso.core.user.SsoUser;
import com.oyo.sso.core.util.SsoUtil;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Description: 用户信息接口
 * @Author: fang
 * @create: 2019-03-25
 **/
@RestController
@RequestMapping("/member/v1/user")
public class UserController {
    @RequestMapping(method = RequestMethod.GET)
    public RopResponse<SsoUser> getUserInfo() {
        SsoUser ssoUser = SsoUtil.currentUser();
        return RopResponse.ok(ssoUser);
    }
}
