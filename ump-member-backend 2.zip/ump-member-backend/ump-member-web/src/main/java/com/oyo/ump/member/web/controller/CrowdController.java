package com.oyo.ump.member.web.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import com.oyo.common.response.PagedResponse;
import com.oyo.ump.member.common.enums.CrowdTypeEnum;
import com.oyo.ump.member.service.CrowdService;
import com.oyo.ump.member.service.MessagePushService;
import com.oyo.ump.member.service.bo.CrowdBO;
import com.oyo.ump.member.service.bo.SelectCrowdBo;
import com.oyo.ump.member.web.common.RequirePermission;
import com.oyo.ump.member.web.vo.CrowdListVo;
import com.oyo.ump.member.web.vo.CrowdVO;
import com.oyo.ump.member.web.vo.SelectCrowdVo;
import com.oyo.ump.member.web.vo.request.CrowdRequestVO;
import com.oyo.ump.member.web.vo.request.DifferenceQueryVo;
import com.oyo.ump.member.web.vo.request.TagDetailVo;
import com.oyo.utp.pa.common.utils.DateUtils;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Lists;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Dong
 * @Classname CrowdController
 * @Description 人群分类业务处理类
 * @Date 2019-06-06
 */
@RestController
@RequestMapping(value = "/member/crowd")
@Api(tags = {"crowd"}, value = "crowd")
@Slf4j
public class CrowdController {
    @Autowired
    CrowdService crowdService;
    @Autowired
    MessagePushService messagePushService;

    @GetMapping("/pageList")
    @RequirePermission(value = "memberGroup_list")
    public BaseResponse<PagedResponse<CrowdVO>> getPageCrowdList(@RequestParam(value = "crowdName", required = false) String crowdName,
                                                                @RequestParam(value = "startTime", required = false) String startTime,
                                                                @RequestParam(value = "endTime", required = false) String endTime,
                                                                @RequestParam(value = "crowdStatus", required = false) String crowdStatus,
                                                                 @RequestParam(value = "crowdType", required = false) String crowdType,
                                                                @RequestParam(value = "userType", required = false) String userType,
                                                                @RequestParam(value = "pageNum", required = false, defaultValue = "1") Integer pageNum,
                                                                @RequestParam(value = "pageSize", required = false, defaultValue = "5") Integer pageSize){
        BaseResponse<PagedResponse<CrowdVO>> response = new BaseResponse<>();
        List<CrowdVO> crowdVOList = Lists.newArrayList();
        PagedResponse<CrowdVO> crowdVOPagedResponse = new PagedResponse<>();
        crowdVOPagedResponse.setPageSize(pageSize);

        Map<String, String> params = new HashMap<>();
        params.put("startTime", startTime);
        params.put("endTime", endTime);
        params.put("crowdStatus", crowdStatus);
        params.put("crowdName", crowdName);
        params.put("crowdType", crowdType);
        params.put("userType", userType);

        PagedResponse<CrowdBO> crowdBOPagedResponse = new PagedResponse<>();
        try{
            crowdBOPagedResponse = crowdService.selectByConditionPaged(params, pageNum, pageSize);
        }catch (Exception e){
            log.info("查询人群列表异常：", e);
            response.setCode(ResponseCode.FAILURE.getCode());
            response.setMsg("系统繁忙，请您稍后重试！");
            return response;
        }
        if(CollectionUtils.isNotEmpty(crowdBOPagedResponse.getResult())){
            crowdBOPagedResponse.getResult().forEach(crowdBO -> {
                CrowdVO crowdVO = new CrowdVO();
                crowdVO = convert2VO(crowdBO);
                crowdVOList.add(crowdVO);
            });
        }
        crowdVOPagedResponse.setTotalCount(crowdBOPagedResponse.getTotalCount());
        crowdVOPagedResponse.setPageNum(pageNum);
        crowdVOPagedResponse.setResult(crowdVOList);

        response.setCode(ResponseCode.SUCCESS.getCode());
        response.setMsg(ResponseCode.SUCCESS.getMsg());
        response.setData(crowdVOPagedResponse);

        return response;
    }

    @GetMapping("/list")
    public BaseResponse<List<CrowdVO>> getCrowdList(@RequestParam(value = "crowdName", required = false) String crowdName,
                                                    @RequestParam(value = "startTime", required = false) String startTime,
                                                    @RequestParam(value = "endTime", required = false) String endTime,
                                                    @RequestParam(value = "crowdCreateType", required = false) String crowdCreateType,
                                                    @RequestParam(value = "crowdStatus", required = false) String crowdStatus,
                                                    @RequestParam(value = "userType", required = false) String userType){
        BaseResponse<List<CrowdVO>> response = new BaseResponse<>();
        List<CrowdVO> crowdVOList = Lists.newArrayList();

        Map<String, String> params = new HashMap<>();
        params.put("startTime", startTime);
        params.put("endTime", endTime);
        params.put("crowdStatus", crowdStatus);
        params.put("crowdName", crowdName);
        params.put("crowdCreateType", crowdCreateType);
        params.put("userType", userType);

        List<CrowdBO> crowdBOList = Lists.newArrayList();
        try{
            crowdBOList = crowdService.selectByCondition(params);
        }catch (Exception e){
            log.info("查询人群列表异常：", e);
            response.setCode(ResponseCode.FAILURE.getCode());
            response.setMsg("系统繁忙，请您稍后重试！");
            return response;
        }
        if(CollectionUtils.isNotEmpty(crowdBOList)){
            crowdBOList.forEach(crowdBO -> {
                CrowdVO crowdVO = new CrowdVO();
                crowdVO = convert2VO(crowdBO);
                crowdVOList.add(crowdVO);
            });
        }

        response.setCode(ResponseCode.SUCCESS.getCode());
        response.setMsg(ResponseCode.SUCCESS.getMsg());
        response.setData(crowdVOList);

        return response;
    }

    @GetMapping("/info")
    public BaseResponse<CrowdVO> getCrowdInfo(@RequestParam(value = "id") Long id){
        BaseResponse<CrowdVO> response = new BaseResponse<>();
        CrowdBO crowdBO;
        CrowdVO crowdVO = new CrowdVO();
        try{
            crowdBO = crowdService.selectById(id);
        }catch (Exception e){
            log.info("人群详情异常：", e);
            response.setCode(ResponseCode.FAILURE.getCode());
            response.setMsg("系统繁忙，请您稍后重试！");
            return response;
        }
        if(crowdBO != null){
            crowdVO = convert2VO(crowdBO);
        }

        response.setCode(ResponseCode.SUCCESS.getCode());
        response.setMsg(ResponseCode.SUCCESS.getMsg());
        response.setData(crowdVO);

        return response;
    }

    @PostMapping(path = "/insert")
    public BaseResponse<Long> insert(@RequestBody @Valid CrowdRequestVO crowdRequestVO){
        BaseResponse response = new BaseResponse();
        CrowdBO crowdBO = convert2BO(crowdRequestVO);
        try{
            Long crowdId = crowdService.insertCrowd(crowdBO);
            response.setData(crowdId);
        }catch (Exception e){
            log.info("新增人群异常信息：",e);
            response.setCode(ResponseCode.FAILURE.getCode());
            response.setMsg("新增人群失败");
            return response;
        }
        response.setCode(ResponseCode.SUCCESS.getCode());
        response.setMsg("新增人群成功");
        return response;
    }

    @PostMapping(path = "/update")
    public BaseResponse update(@RequestBody @Valid CrowdRequestVO crowdRequestVO){
        BaseResponse response = new BaseResponse();
        CrowdBO crowdBO = convert2BO(crowdRequestVO);
        try{
            crowdService.updateCrowd(crowdBO);
        }catch (Exception e){
            log.info("修改人群异常信息：",e);
            response.setCode(ResponseCode.FAILURE.getCode());
            response.setMsg("修改人群失败");
            return response;
        }
        response.setCode(ResponseCode.SUCCESS.getCode());
        response.setMsg("修改人群成功");
        return response;
    }

    @GetMapping("/changeStatus")
    public BaseResponse updateCrowdStatus(@RequestParam(value = "id") Long id, @RequestParam(value = "crowdStatus") String crowdStatus){
        BaseResponse response = new BaseResponse<>();
        CrowdBO  crowdBO = new CrowdBO();
        crowdBO.setCrowdStatus(crowdStatus);
        crowdBO.setId(id);
        try{
            crowdService.updateCrowd(crowdBO);
        }catch (Exception e){
            log.info("修改人群状态异常信息：",e);
            response.setCode(ResponseCode.FAILURE.getCode());
            response.setMsg("修改人群状态失败");
            return response;
        }
        response.setCode(ResponseCode.SUCCESS.getCode());
        response.setMsg("修改人群状态成功");
        return response;
    }


    @GetMapping("/delete")
    public BaseResponse delete(@RequestParam(value = "id") Long id){
        BaseResponse response = new BaseResponse<>();
        try{
            crowdService.deleteCrowd(id);
        }catch (Exception e){
            log.info("删除人群异常信息：",e);
            response.setCode(ResponseCode.FAILURE.getCode());
            response.setMsg("删除失败");
            return response;
        }
        response.setCode(ResponseCode.SUCCESS.getCode());
        response.setMsg("删除成功");
        return response;
    }


    private CrowdVO convert2VO(CrowdBO crowdBO){
        CrowdVO crowdVO = new CrowdVO();
        crowdVO.setId(crowdBO.getId());
        crowdVO.setCrowdName(crowdBO.getCrowdName());
        crowdVO.setCreateTime(crowdBO.getCreateTime()==null?"": DateUtils.format(crowdBO.getCreateTime(), "yyyy-MM-dd HH:mm"));
        crowdVO.setUpdateTime(crowdBO.getUpdateTime()==null?"": DateUtils.format(crowdBO.getUpdateTime(), "yyyy-MM-dd HH:mm"));
        crowdVO.setDataUpdateTime(crowdBO.getDataUpdateTime()==null?"": DateUtils.format(crowdBO.getDataUpdateTime(), "yyyy-MM-dd HH:mm"));
        crowdVO.setCrowdNum(crowdBO.getCrowdNum());
        crowdVO.setCrowdStatus(crowdBO.getCrowdStatus());
        crowdVO.setCrowdCreateType(crowdBO.getCrowdCreateType());
        crowdVO.setCrowdTag(crowdBO.getCrowdTag());
        crowdVO.setUserIds(crowdBO.getUserIds());
        return crowdVO;
    }

    private CrowdBO convert2BO(CrowdRequestVO crowdRequestVO){
        CrowdBO crowdBO = new CrowdBO();
        crowdBO.setId(crowdRequestVO.getId());
        crowdBO.setCrowdName(crowdRequestVO.getCrowdName());
        crowdBO.setCrowdStatus(crowdRequestVO.getCrowdStatus());
        crowdBO.setCrowdCreateType(crowdRequestVO.getCrowdCreateType());
        crowdBO.setCrowdTag(crowdRequestVO.getCrowdTag());
        crowdBO.setCrowdType(crowdRequestVO.getCrowdType());
        crowdBO.setUserType(crowdRequestVO.getUserType());
        if(CrowdTypeEnum.USER_ID.getType().equals(crowdRequestVO.getCrowdType()) && CollectionUtils.isNotEmpty(crowdRequestVO.getUserIds())){
            crowdBO.setUserIds(crowdRequestVO.getUserIds());
            crowdBO.setCrowdNum(crowdRequestVO.getUserIds().size());
        }
        if(CrowdTypeEnum.PUSH_ID.getType().equals(crowdRequestVO.getCrowdType()) && CollectionUtils.isNotEmpty(crowdRequestVO.getPushIdInfos())){
            crowdBO.setPushIdInfos(crowdRequestVO.getPushIdInfos());
            crowdBO.setCrowdNum(crowdRequestVO.getPushIdInfos().size());
        }
        if(CrowdTypeEnum.OPEN_ID.getType().equals(crowdRequestVO.getCrowdType()) && CollectionUtils.isNotEmpty(crowdRequestVO.getOpenIdInfos())){
            crowdBO.setOpenIdInfos(crowdRequestVO.getOpenIdInfos());
            crowdBO.setCrowdNum(crowdRequestVO.getOpenIdInfos().size());
        }
        if(CrowdTypeEnum.EMPLOYEE_ID.getType().equals(crowdRequestVO.getCrowdType()) && CollectionUtils.isNotEmpty(crowdRequestVO.getEmployeeNos())){
            crowdBO.setCrowdType(CrowdTypeEnum.USER_ID.getType());
            crowdBO.setUserIds(crowdService.getUserIdsByEmployeeNos(crowdRequestVO.getEmployeeNos()));
            crowdBO.setCrowdNum(crowdBO.getUserIds().size());
        }

        crowdBO.setIsDeleted(crowdRequestVO.getIdDeleted()==null?0:crowdRequestVO.getIdDeleted());

        return crowdBO;
    }

    @PostMapping(path = "/previewCrowd")
    public BaseResponse<List<Long>> tagPreviewCrowdList(@RequestBody TagDetailVo tagDetailVo){
        BaseResponse response = new BaseResponse<>();
        if (StringUtils.isBlank(tagDetailVo.getTagDetail())){
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(),"参数不能为空！");
        }
        try {
            response.setData(messagePushService.getTagPreviewCrowd(tagDetailVo.getTagDetail()));
        }catch (Exception e){
            log.info("人群预览异常：",e);
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(),e.getMessage());
        }
        response.setCode(ResponseCode.SUCCESS.getCode());
        response.setMsg("成功");
        return response;
    }


    @PostMapping(path = "/findCrowdListByIds")
    public BaseResponse<List<SelectCrowdVo>> findCrowdListByIds( @RequestBody CrowdListVo crowdListVo){
        BaseResponse response = new BaseResponse<>();
        List<SelectCrowdBo> list=crowdService.findSelectCrowdBoByIds(crowdListVo.getCrowds());
        List<SelectCrowdVo> result=new ArrayList<>();
        list.forEach(item->{
            SelectCrowdVo selectCrowdVo=new SelectCrowdVo();
            BeanUtils.copyProperties(item,selectCrowdVo);
            result.add(selectCrowdVo);
        });
        response.setData(result);
        response.setCode(ResponseCode.SUCCESS.getCode());
        response.setMsg("成功");
        return response;
    }

    /**
     * 差集情况的人数统计
     * @param crowdsGather
     * @return com.oyo.common.response.BaseResponse<java.util.Map<java.lang.String,java.lang.Long>>
     */
    @PostMapping(path = "/differenceQuery")
    public BaseResponse<Map<String, Long>> differenceQuery(@RequestBody List<DifferenceQueryVo> crowdsGather){
        BaseResponse<Map<String, Long>> response = new BaseResponse();
        Map<String, Long> resMap = new HashMap<>();
        if(CollectionUtils.isEmpty(crowdsGather)){
            return BaseResponse.fail(ResponseCode.ILLEGAL_ARGUMENT.getCode(),"列表为空");
        }
        List<Long> crowdIds1 = Lists.newArrayList();
        List<Long> crowdIds2 = Lists.newArrayList();
        for(int i=0;i<crowdsGather.size();i++){
            DifferenceQueryVo vo=crowdsGather.get(i);
            if(vo.getId().equals(1)){
                crowdIds1=vo.getValue();
                    if(CollectionUtils.isNotEmpty(crowdIds1)){
                        crowdIds1.forEach(crowdId ->{
                            CrowdBO crowdBO= crowdService.selectById(crowdId);
                            resMap.put(crowdBO.getCrowdName(), messagePushService.getUsersQtyByCrowdId(crowdId));
                        });
                    }
                }
            if(vo.getId().equals(2)){
                    crowdIds2 = vo.getValue();
                    if(CollectionUtils.isNotEmpty(crowdIds2)){
                        crowdIds2.forEach(crowdId ->{
                            CrowdBO crowdBO= crowdService.selectById(crowdId);
                            resMap.put(crowdBO.getCrowdName(), messagePushService.getUsersQtyByCrowdId(crowdId));
                        });
                    }
            }
        }
        resMap.put("total", messagePushService.getUsersQtyByCrowdIdsDifference(crowdIds1,crowdIds2));
        return BaseResponse.success(resMap);
    }
}
