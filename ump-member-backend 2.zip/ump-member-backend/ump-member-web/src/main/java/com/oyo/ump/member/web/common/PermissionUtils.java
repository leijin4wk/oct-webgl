package com.oyo.ump.member.web.common;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.oyo.common.enums.ResponseCode;
import com.oyo.sso.core.user.SsoUser;
import com.oyo.sso.core.util.SsoUtil;
import com.oyo.ump.member.common.exception.UmpException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @Description: 会员权益类 一期/
 * @Author: fang
 * @create: 2019-03-29
 **/
@Slf4j
public class PermissionUtils {
    //admin账户id
    private static final long ADMIN = -1L;

    //平台权限code
    private static final String CRM = "crm";
    public static final Map<String, String> METHOD_CODE_MAP = Maps.newHashMap();
    private static Set<String> ADMIN_PERMISSION = Sets.newHashSet();
    private static final Map<String,Set<String>> FIRST_NODE_MAP=Maps.newHashMap();
    private static final Map<String,Set<String>> SECOND_NODE_MAP=Maps.newHashMap();


    //配置一级节点
    private static Set<String> FIRST_NODE_MEMBER_INFO = Sets.newHashSet();
    private static Set<String> FIRST_NODE_MEMBER_GRADE = Sets.newHashSet();
    private static Set<String> FIRST_NODE_MEMBER_BONUS = Sets.newHashSet();
    private static Set<String> FIRST_NODE_MEMBER_UPGRADE = Sets.newHashSet();
    //配置二级节点
    private static Set<String> SECOND_NODE_MEMBER_INFO = Sets.newHashSet();
    private static Set<String> SECOND_NODE_MEMBER_GRADE = Sets.newHashSet();
    private static Set<String> SECOND_NODE_MEMBER_BONUS = Sets.newHashSet();
    private static Set<String> SECOND_NODE_MEMBER_UPGRADE = Sets.newHashSet();

    //一级节点
    private static final String FIRST_NODE_MEMBER_INFO_CODE = "membershipStatus";
    private static final String FIRST_NODE_MEMBER_GRADE_CODE = "membershipLevel";
    private static final String FIRST_NODE_MEMBER_BONUS_CODE = "membershipScore";
    private static final String FIRST_NODE_MEMBER_UPGRADE_CODE = "memberPay";
    //二级节点
    private static final String SECOND_NODE_MEMBER_INFO_CODE = "membershipStatus_membershipStatusList";
    private static final String SECOND_NODE_MEMBER_GRADE_CODE = "membershipLevel_levelAndRights";
    private static final String SECOND_NODE_MEMBER_BONUS_CODE = "membershipScore_integralRule";
    private static final String SECOND_NODE_MEMBER_UPGRADE_CODE = "memberPay_manage";


    //各个权限点。三级点，目前项目最次级是这三级。
    //会员身份
    private static final String MEMBER_INFO_LIST = "membershipStatus_membershipStatusList_page";
    private static final String MEMBER_INFO = "membershipStatus_membershipStatusList$button$memberQuery";
    //会员等级
    private static final String MEMBER_GRADE_PRIVILEGE = "membershipLevel_levelAndRights_page";
    //会员积分
    private static final String MEMBER_BONUS = "membershipScore_integralRule_page";
    //会员升级包
    private static final String MEMBER_UPGRADE = "memberPay_manage_page";

    static {
        SECOND_NODE_MEMBER_INFO.add(MEMBER_INFO_LIST);
        SECOND_NODE_MEMBER_INFO.add(MEMBER_INFO);
        SECOND_NODE_MEMBER_GRADE.add(MEMBER_GRADE_PRIVILEGE);
        SECOND_NODE_MEMBER_BONUS.add(MEMBER_BONUS);
        SECOND_NODE_MEMBER_UPGRADE.add(MEMBER_UPGRADE);

        FIRST_NODE_MEMBER_INFO.addAll(SECOND_NODE_MEMBER_INFO);
        FIRST_NODE_MEMBER_GRADE.addAll(SECOND_NODE_MEMBER_GRADE);
        FIRST_NODE_MEMBER_BONUS.addAll(SECOND_NODE_MEMBER_BONUS);
        FIRST_NODE_MEMBER_UPGRADE.addAll(SECOND_NODE_MEMBER_UPGRADE);

        ADMIN_PERMISSION.addAll(FIRST_NODE_MEMBER_INFO);
        ADMIN_PERMISSION.addAll(FIRST_NODE_MEMBER_GRADE);
        ADMIN_PERMISSION.addAll(FIRST_NODE_MEMBER_BONUS);
        ADMIN_PERMISSION.addAll(FIRST_NODE_MEMBER_UPGRADE);
        //map 初始化
        METHOD_CODE_MAP.put("queryMemberInfoByUserId", MEMBER_INFO);
        METHOD_CODE_MAP.put("getMemberIdentityList", MEMBER_INFO_LIST);
        METHOD_CODE_MAP.put("queryAllMemberGradeInfo", MEMBER_GRADE_PRIVILEGE);
        METHOD_CODE_MAP.put("queryMemberPrivilege", MEMBER_GRADE_PRIVILEGE);
        METHOD_CODE_MAP.put("getBonusCostRuleList", MEMBER_BONUS);
        METHOD_CODE_MAP.put("getBonusGainRuleList", MEMBER_BONUS);
        METHOD_CODE_MAP.put("getUpgradePackageList", MEMBER_UPGRADE);
        METHOD_CODE_MAP.put("queryUpgradeOrderList",MEMBER_INFO);
        METHOD_CODE_MAP.put("queryBonusOrderList",MEMBER_INFO);
        METHOD_CODE_MAP.put("getRefreshRule",MEMBER_INFO_LIST);
        METHOD_CODE_MAP.put("getUserInfo",MEMBER_INFO_LIST);
        METHOD_CODE_MAP.put("refund",MEMBER_INFO);



        SECOND_NODE_MAP.put(SECOND_NODE_MEMBER_INFO_CODE,FIRST_NODE_MEMBER_INFO);
        SECOND_NODE_MAP.put(SECOND_NODE_MEMBER_GRADE_CODE,FIRST_NODE_MEMBER_GRADE);
        SECOND_NODE_MAP.put(SECOND_NODE_MEMBER_BONUS_CODE,FIRST_NODE_MEMBER_BONUS);
        SECOND_NODE_MAP.put(SECOND_NODE_MEMBER_UPGRADE_CODE,FIRST_NODE_MEMBER_UPGRADE);

        FIRST_NODE_MAP.put(FIRST_NODE_MEMBER_INFO_CODE,FIRST_NODE_MEMBER_INFO);
        FIRST_NODE_MAP.put(FIRST_NODE_MEMBER_GRADE_CODE,FIRST_NODE_MEMBER_GRADE);
        FIRST_NODE_MAP.put(FIRST_NODE_MEMBER_BONUS_CODE,FIRST_NODE_MEMBER_BONUS);
        FIRST_NODE_MAP.put(FIRST_NODE_MEMBER_UPGRADE_CODE,FIRST_NODE_MEMBER_UPGRADE);



    }

    /**
     * 解析 用户权益，并查看是否有权益
     * @param
     * @param code
     * @return
     */
    public static Boolean resolve(Resource resource, String code) {
       Set<String> result = Sets.newHashSet();
        if (resource == null || !"crm".equals(resource.getCode())) {
            return false;
        }
        if (resource.getResourceTrees() == null) {
            return true;
        } else {
            resource.getResourceTrees().forEach(node -> {
                //一级节点
                  if(FIRST_NODE_MAP.containsKey(node.getCode())){
                      if(node.getResourceTrees()==null){
                          result.addAll(FIRST_NODE_MAP.get(node.getCode()));
                      }else {
                          node.getResourceTrees().forEach(secondNode ->{
                              if(SECOND_NODE_MAP.containsKey(secondNode.getCode())) {
                                  if (secondNode.getResourceTrees() == null) {
                                      result.addAll(SECOND_NODE_MAP.get(secondNode.getCode()));
                                  }else {
                                      secondNode.getResourceTrees().forEach(thirdNode->{
                                          if(ADMIN_PERMISSION.contains(thirdNode.getCode())){
                                              result.add(thirdNode.getCode());
                                          }
                                      });
                                  }
                              }
                          } );

                      }
                  }
            });
        }
        return result.contains(code);
    }
    public static boolean basicCheckPermission(String code){
        SsoUser ssoUser = SsoUtil.currentUser();
        if(ssoUser == null){
            throw new UmpException(ResponseCode.FAILURE.getCode(),"获取用户信息异常");
        }
        String userResource = ssoUser.getResourceTree();
        if(StringUtils.isBlank(userResource)){
            log.info("{}用户资源权限为空,请检查用户资源权限信息", ssoUser.getUserName());
            throw new UmpException(ResponseCode.FAILURE.getCode(),"无访问权限");
        }
        log.info("{}用户权限为:{}", ssoUser.getUserName(), userResource);
        if(!getUserCodeList().contains(code)){
            throw new UmpException(ResponseCode.FAILURE.getCode(),"未配置相应访问权限");
        }
        return true;
    }
    private static Resource getResource(){
//        return JSON.parseObject("{\"code\":\"crm\",\"resourceTrees\":[{\"code\":\"memberPay\",\"resourceTrees\":[{\"code\":\"memberPay_manage\",\"resourceTrees\":[{\"code\":\"memberPay_manage$button$upgradeQuery\",\"resourceTrees\":null},{\"code\":\"memberPay_manage_page\",\"resourceTrees\":null},{\"code\":\"memberPay_manage$button$editUpgradeRule\",\"resourceTrees\":null},{\"code\":\"memberPay_manage$button$addUpgradeRule\",\"resourceTrees\":null}]}]},{\"code\":\"membershipScore\",\"resourceTrees\":[{\"code\":\"membershipScore_integralRule\",\"resourceTrees\":[{\"code\":\"membershipScore_integralRule$button$updateCreditUseRuel\",\"resourceTrees\":null},{\"code\":\"membershipScore_integralRule_page\",\"resourceTrees\":null},{\"code\":\"membershipScore_integralRule$button$updateCreditGainRule\",\"resourceTrees\":null},{\"code\":\"membershipScore_integralRule$button$addCreditGainRule\",\"resourceTrees\":null}]}]},{\"code\":\"membershipLevel\",\"resourceTrees\":[{\"code\":\"membershipLevel_levelAndRights\",\"resourceTrees\":[{\"code\":\"membershipLevel_levelAndRights$button$updateMemberRights\",\"resourceTrees\":null},{\"code\":\"membershipLevel_levelAndRights_page\",\"resourceTrees\":null},{\"code\":\"membershipLevel_levelAndRights$button$removeMemberLevel\",\"resourceTrees\":null},{\"code\":\"membershipLevel_levelAndRights$button$editMemberLevel\",\"resourceTrees\":null},{\"code\":\"membershipLevel_levelAndRights$button$addMemberlevel\",\"resourceTrees\":null}]}]},{\"code\":\"membershipStatus\",\"resourceTrees\":[{\"code\":\"membershipStatus_membershipStatusList\",\"resourceTrees\":[{\"code\":\"membershipStatus_membershipStatusList$button$memberQuery\",\"resourceTrees\":null},{\"code\":\"membershipStatus_membershipStatusList_page\",\"resourceTrees\":null}]}]}]}", Resource.class);
        return JSON.parseObject(SsoUtil.currentUser().getResourceTree(), Resource.class);
    }


    public static  Set<String> getUserCodeList(){
        Set<String> codeList= Sets.newHashSet();
        Resource resource=getResource();
        List<Resource> resourceList=resource.getResourceTrees();
        List<Resource> resourceList2=Lists.newArrayList();
        while (CollectionUtils.isNotEmpty(resourceList)){
            codeList.addAll(resourceList.stream().filter(resource1 -> resource1!=null).map(resource1 ->resource1.getCode()).collect(Collectors.toSet()));
            resourceList.stream().filter(resource1 -> resource1!=null&&resource1.getResourceTrees()!=null).forEach(resource1 -> resourceList2.addAll(resource1.getResourceTrees()));
            resourceList.clear();
            if(CollectionUtils.isNotEmpty(resourceList2)){
                resourceList2.stream().forEach(resource1 -> resourceList.add(resource1));
            }
            resourceList2.clear();
        }
        log.info("资源树权限codeList:{}",codeList);
        return codeList;
    }

    public static void main(String[] args) {
        getUserCodeList();
    }
}
