package com.oyo.ump.member.web.controller;

import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import com.oyo.openapi.client.mp.miniapp.dto.SubscribeTemplateDto;
import com.oyo.common.response.PagedResponse;
import com.oyo.cpush.client.constant.TemplateTypeEnum;
import com.oyo.cpush.client.dto.request.*;
import com.oyo.cpush.client.dto.response.TemplateDTO;
import com.oyo.cpush.client.response.ClientBaseResponse;
import com.oyo.cpush.client.response.ClientResponseCode;
import com.oyo.openapi.client.mp.wechat.dto.GetAllPrivateTemplateRequest;
import com.oyo.openapi.client.mp.wechat.dto.GetAllPrivateTemplateResponse.PrivateTemplate;
import com.oyo.sso.core.util.SsoUtil;
import com.oyo.ump.member.common.beanutils.MapperWrapper;
import com.oyo.ump.member.common.enums.TemplateUrlTypeEnum;
import com.oyo.ump.member.integration.service.user.BUserInfoRemoteService;
import com.oyo.ump.member.service.enums.WeChatMiniAPPEnum;
import com.oyo.ump.member.common.enums.WeChatPublicAccountEnum;
import com.oyo.ump.member.integration.service.push.MessageTemplateService;
import com.oyo.ump.member.integration.service.push.PushActivityLinkService;
import com.oyo.ump.member.integration.service.push.PushTemplateService;
import com.oyo.ump.member.integration.service.user.UserInfoRemoteService;
import com.oyo.ump.member.service.PushProcessService;
import com.oyo.ump.member.service.PushTemplateParameterService;
import com.oyo.ump.member.service.PushTemplateRelationService;
import com.oyo.ump.member.service.bo.*;
import com.oyo.ump.member.service.enums.TriggerChannelEnum;
import com.oyo.ump.member.web.common.RequirePermission;
import com.oyo.ump.member.web.vo.*;
import com.oyo.ump.member.web.vo.push.PushTemplateRequestVO;
import com.oyo.ump.member.web.vo.push.PushTemplateVO;
import com.oyo.ump.member.web.vo.request.ChannelLinkBasicVo;
import com.oyo.utp.pa.common.utils.DateUtils;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import com.google.common.collect.Lists;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.oyo.ump.member.common.enums.SmsSignatureEnum.OYO_HOTEL;
import static com.oyo.ump.member.common.enums.SmsSignatureEnum.OYO_WECHAT_PLATFORM;
import static com.oyo.ump.member.common.enums.SmsTemplateTypeEnum.MARKETING;
import static com.oyo.ump.member.common.enums.SmsTemplateTypeEnum.NOTIFICATION;

/**
 * @author Dong
 * @Classname PushTemplateController
 * @Description
 * @Date 2019-08-30
 */
@RestController
@RequestMapping(value = "/member/pushTemplate")
@Slf4j
public class PushTemplateController {
    @Autowired
    PushTemplateParameterService pushTemplateParameterService;

    @Autowired
    MessageTemplateService messageTemplateService;

    @Autowired
    PushProcessService pushProcessService;

    @Autowired
    private PushTemplateService pushTemplateService;

    @Autowired
    private PushTemplateRelationService pushTemplateRelationService;

    @Autowired
    BUserInfoRemoteService bUserInfoRemoteService;



    @GetMapping("/channels")
    public BaseResponse<List<TemplateChannelResponseDTO>> getChannels() {
        ClientBaseResponse<List<TemplateChannelResponseDTO>> response = pushTemplateService.queryTemplateChannels();
        if (response != null && ClientResponseCode.SUCCESS.getCode().equals(response.getCode())) {
            return BaseResponse.success(response.getData());
        } else {
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(), "应用渠道查询失败");
        }
    }

    @GetMapping("/info")
    @RequirePermission(value = "pushTemplate_templateList")
    public BaseResponse<PushTemplateVO> getTemplateById(@RequestParam(value = "templateType") Integer templateType, @RequestParam(value = "templateNum") String templateNum) {
        if (templateType == null) {
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(), "模板类型不能为空");
        }
        QueryTemplateRequestDTO queryTemplateRequestDTO = new QueryTemplateRequestDTO();
        queryTemplateRequestDTO.setTemplateNum(templateNum);
        PushTemplateVO pushTemplateVO = new PushTemplateVO();
        ClientBaseResponse response = pushTemplateService.queryTemplate(queryTemplateRequestDTO);
        if (response != null && ClientResponseCode.SUCCESS.getCode().equals(response.getCode())) {
            if (TriggerChannelEnum.SMS.getType().equals(templateType)) {
                SmsPushTemplateDTO smsPushTemplateDTO = (SmsPushTemplateDTO)response.getData();
                pushTemplateVO = MapperWrapper.instance().map(smsPushTemplateDTO, PushTemplateVO.class);
            } else if (TriggerChannelEnum.APPPUSH.getType().equals(templateType)) {
                AppPushTemplateDTO appPushTemplateDTO = (AppPushTemplateDTO)response.getData();
                pushTemplateVO = MapperWrapper.instance().map(appPushTemplateDTO, PushTemplateVO.class);
            } else if (TriggerChannelEnum.WECHAT.getType().equals(templateType)) {
                WeChatPublicAccountTemplateDTO weChatPublicAccountTemplateDTO = (WeChatPublicAccountTemplateDTO)response.getData();
                pushTemplateVO = MapperWrapper.instance().map(weChatPublicAccountTemplateDTO, PushTemplateVO.class);
            }
            pushTemplateVO.setTemplateType(templateType);
            return BaseResponse.success(pushTemplateVO);
        } else {
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(), "模板查询失败");
        }
    }

    @GetMapping("/list")
    @RequirePermission(value = "pushTemplate_templateList")
    public BaseResponse<PagedResponse<PushTemplateVO>> getTemplatesByPage(@RequestParam(value = "startDate", required = false, defaultValue = "") String startTime,
                                                         @RequestParam(value = "endDate", required = false, defaultValue = "") String endTime,
                                                         @RequestParam(value = "templateNum", required = false, defaultValue = "") String templateNum,
                                                         @RequestParam(value = "templateType", required = false, defaultValue = "") Integer templateType,
                                                         @RequestParam(value = "pageNum", required = false, defaultValue = "1") Integer pageNum,
                                                         @RequestParam(value = "pageSize", required = false, defaultValue = "10") Integer pageSize) {
        TemplateSearchDTO templateSearchDTO = new TemplateSearchDTO();
        templateSearchDTO.setPageNum(pageNum);
        templateSearchDTO.setPageSize(pageSize);
        if (templateType != null ) {
            // member的推送类型转push的推送类型
            Integer remoteTemplateType = null;
            if (TriggerChannelEnum.APPPUSH.getType().equals(templateType)) {
                remoteTemplateType = TemplateTypeEnum.PUSH.getCode();
            } else if (TriggerChannelEnum.WECHAT.getType().equals(templateType)) {
                remoteTemplateType = TemplateTypeEnum.WECHAT_PUBLIC_ACCOUNT.getCode();
            } else if (TriggerChannelEnum.SMS.getType().equals(templateType)) {
                remoteTemplateType = TemplateTypeEnum.SMS.getCode();
            }
            if (remoteTemplateType == null) {
                return BaseResponse.fail(ResponseCode.FAILURE.getCode(), "模板类型不能为空");
            }
            templateSearchDTO.setTemplateType(remoteTemplateType);
        }
        if (templateNum != null ) {
            templateSearchDTO.setTemplateCode(templateNum);
        }
        if (StringUtils.isNotBlank(startTime)) {
            templateSearchDTO.setStartDate(DateUtils.formatByStringDate(startTime, "yyyy-MM-dd HH:mm:ss"));
        }
        if (StringUtils.isNotBlank(endTime)) {
            templateSearchDTO.setEndDate(DateUtils.formatByStringDate(endTime, "yyyy-MM-dd HH:mm:ss"));
        }
        ClientBaseResponse<PagedResponse<TemplateDTO>> clientBaseResponse = pushTemplateService.queryTemplateByPage(templateSearchDTO);

        if (clientBaseResponse != null && ClientResponseCode.SUCCESS.getCode().equals(clientBaseResponse.getCode()) && clientBaseResponse.getData() != null) {
            List<PushTemplateVO> pushTemplateVOList = clientBaseResponse.getData().getResult().stream().map(templateDTO-> buildPushTemplate(templateDTO)).collect(Collectors.toList());
            PagedResponse<PushTemplateVO> pagedResponse = new PagedResponse<>(pageNum, pageSize, clientBaseResponse.getData().getTotalCount());
            pagedResponse.setResult(pushTemplateVOList);
            return BaseResponse.success(pagedResponse);
        } else {
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(), "模板列表查询失败");
        }
    }

    private PushTemplateVO buildPushTemplate(TemplateDTO templateDTO) {
        PushTemplateVO templateVO = new PushTemplateVO();
        templateVO.setUpdateAccountName(templateDTO.getUpdateAccountName());
        templateVO.setUpdateTime(templateDTO.getUpdateTime());
        templateVO.setCreateAccountName(templateDTO.getCreateAccountName());
        templateVO.setCreateTime(templateDTO.getCreateTime());
        templateVO.setTemplateNum(templateDTO.getTemplateCode());
        templateVO.setTemplateName(templateDTO.getTemplateName());
        if (TemplateTypeEnum.PUSH.getCode().equals(templateDTO.getTemplateType())) {
            templateVO.setTemplateType(TriggerChannelEnum.APPPUSH.getType());
            templateVO.setTemplateTypeName(TriggerChannelEnum.APPPUSH.getName());
        } else if (TemplateTypeEnum.WECHAT_PUBLIC_ACCOUNT.getCode().equals(templateDTO.getTemplateType())) {
            templateVO.setTemplateType(TriggerChannelEnum.WECHAT.getType());
            templateVO.setTemplateTypeName(TriggerChannelEnum.WECHAT.getName());
        } else if (TemplateTypeEnum.SMS.getCode().equals(templateDTO.getTemplateType())) {
            templateVO.setTemplateType(TriggerChannelEnum.SMS.getType());
            templateVO.setTemplateTypeName(TriggerChannelEnum.SMS.getName());
        }
        return templateVO;

    }

    @PostMapping("/create")
    @RequirePermission(value = "pushTemplate_createTemplate")
    public BaseResponse<String> createTemplate(@RequestBody PushTemplateRequestVO pushTemplateRequestVO) {
        pushTemplateRequestVO.setCreateAccountId(SsoUtil.currentUser().getUserId());
        pushTemplateRequestVO.setUpdateAccountId(SsoUtil.currentUser().getUserId());
        pushTemplateRequestVO.setCreateAccountName(bUserInfoRemoteService.getNameById(SsoUtil.currentUser().getUserId()));
        pushTemplateRequestVO.setUpdateAccountName(bUserInfoRemoteService.getNameById(SsoUtil.currentUser().getUserId()));
        ClientBaseResponse<String> clientBaseResponse = new ClientBaseResponse<>();
        if (TriggerChannelEnum.SMS.getType().equals(pushTemplateRequestVO.getTemplateType())) {
            SmsPushTemplateCreateDTO smsPushTemplateDTO = MapperWrapper.instance().map(pushTemplateRequestVO, SmsPushTemplateCreateDTO.class);
            clientBaseResponse = pushTemplateService.createTemplate(smsPushTemplateDTO);
        } else if (TriggerChannelEnum.APPPUSH.getType().equals(pushTemplateRequestVO.getTemplateType())) {
            AppPushTemplateCreateDTO appPushTemplateDTO = MapperWrapper.instance().map(pushTemplateRequestVO, AppPushTemplateCreateDTO.class);
            clientBaseResponse = pushTemplateService.createTemplate(appPushTemplateDTO);
        } else if (TriggerChannelEnum.WECHAT.getType().equals(pushTemplateRequestVO.getTemplateType())) {
            WeChatPublicAccountTemplateCreateDTO weChatPublicAccountTemplateDTO = MapperWrapper.instance().map(pushTemplateRequestVO, WeChatPublicAccountTemplateCreateDTO.class);
            clientBaseResponse = pushTemplateService.createTemplate(weChatPublicAccountTemplateDTO);
        }
        if (clientBaseResponse != null && ClientResponseCode.SUCCESS.getCode().equals(clientBaseResponse.getCode())) {
            return BaseResponse.success(clientBaseResponse.getData());
        }
        else {
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(), clientBaseResponse.getData());
        }
    }

    @PostMapping("/update")
    @RequirePermission(value = "pushTemplate_editTemplate")
    public BaseResponse<String> updateTemplate(@RequestBody PushTemplateRequestVO pushTemplateRequestVO) {
        pushTemplateRequestVO.setUpdateAccountId(SsoUtil.currentUser().getUserId());
        pushTemplateRequestVO.setUpdateAccountName(bUserInfoRemoteService.getNameById(SsoUtil.currentUser().getUserId()));
        ClientBaseResponse<String> clientBaseResponse = new ClientBaseResponse<>();
        if (TriggerChannelEnum.SMS.getType().equals(pushTemplateRequestVO.getTemplateType())) {
            SmsPushTemplateDTO smsPushTemplateDTO = MapperWrapper.instance().map(pushTemplateRequestVO, SmsPushTemplateDTO.class);
            clientBaseResponse = pushTemplateService.modifyTemplate(smsPushTemplateDTO);
        } else if (TriggerChannelEnum.APPPUSH.getType().equals(pushTemplateRequestVO.getTemplateType())) {
            AppPushTemplateDTO appPushTemplateDTO = MapperWrapper.instance().map(pushTemplateRequestVO, AppPushTemplateDTO.class);
            clientBaseResponse = pushTemplateService.modifyTemplate(appPushTemplateDTO);
        } else if (TriggerChannelEnum.WECHAT.getType().equals(pushTemplateRequestVO.getTemplateType())) {
            WeChatPublicAccountTemplateDTO weChatPublicAccountTemplateDTO = MapperWrapper.instance().map(pushTemplateRequestVO, WeChatPublicAccountTemplateDTO.class);
            clientBaseResponse = pushTemplateService.modifyTemplate(weChatPublicAccountTemplateDTO);
        }
        if (clientBaseResponse != null && ClientResponseCode.SUCCESS.getCode().equals(clientBaseResponse.getCode())) {
            return BaseResponse.success(clientBaseResponse.getData());
        }
        else {
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(), clientBaseResponse.getData());
        }
    }

    /**
     * 获取模板参数配置信息
     * @param parameterName
     * @return com.oyo.common.response.BaseResponse<java.util.Map<java.lang.Long,java.lang.String>>
     */
    @GetMapping("/getParameter")
    public BaseResponse<List<TemplateParameterVO>> getParameter(@RequestParam(value = "parameterName", required = false) String parameterName, @RequestParam(value = "source") Integer source){
        List<TemplateParameterVO> resList = Lists.newArrayList();
        try{
            List<TemplateParameterBO> BOList = pushTemplateParameterService.getAllParameterByType(parameterName, source);
            if(CollectionUtils.isNotEmpty(BOList)){
                resList = MapperWrapper.instance().mapList(BOList, TemplateParameterVO.class);
            }
        }catch (Exception e){
            log.info("获取模板参数选项异常：{}", e);
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(), "获取模板参数选项异常");
        }
        return BaseResponse.success(resList);
    }

    /**
     * 根据长链类型获取长链配置信息
     * @param urlType （1-C端appPush链接，2-C端微信小程序链接,）
     * @return com.oyo.common.response.BaseResponse<java.util.List<com.oyo.ump.member.web.vo.TemplateLongUrlVO>>
     */
    @GetMapping("/getLongUrl")
    public BaseResponse<List<TemplateLongUrlVO>> getLongUrlByType(@RequestParam(value = "urlType") Integer urlType){
        List<TemplateLongUrlVO> urlVOList = Lists.newArrayList();
//        TemplateLongUrlVO internalMsgLongUrlVO = new TemplateLongUrlVO();
//        internalMsgLongUrlVO.setUrlName("站内信");
//        internalMsgLongUrlVO.setId(0L);
        try{
           List<TemplateUrlParameterBO> urlBOList = pushTemplateParameterService.getAllUrlParameter(urlType);
           urlVOList = MapperWrapper.instance().mapList(urlBOList, TemplateLongUrlVO.class);
        }catch (Exception e){
            log.info("根据长链类型获取长链配置信息：{}", e);
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(),"根据长链类型获取长链配置信息");
        }
//        if(TemplateUrlTypeEnum.B_WECHAT_MINIAPP.getType().equals(urlType)){
//            urlVOList.add(internalMsgLongUrlVO);
//        }
        return BaseResponse.success(urlVOList);
    }

    /**
     * 根据小程序APPid获取长链配置信息
     * @param
     * @return com.oyo.common.response.BaseResponse<java.util.List<com.oyo.ump.member.web.vo.TemplateLongUrlVO>>
     */
    @GetMapping("/getLongUrlByMiniAppId")
    public BaseResponse<List<TemplateLongUrlVO>> getLongUrlByMiniAppId(@RequestParam(value = "miniAppId") String miniAppId){
        List<TemplateLongUrlVO> urlVOList = Lists.newArrayList();
        try{
            List<TemplateUrlParameterBO> urlBOList = pushTemplateParameterService.getAllUrlParameterByMiniAppId(miniAppId);
            urlVOList = MapperWrapper.instance().mapList(urlBOList, TemplateLongUrlVO.class);
        }catch (Exception e){
            log.info("根据小程序APPid获取长链配置信息：{}", e);
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(),"根据小程序APPid获取长链配置信息");
        }
        return BaseResponse.success(urlVOList);
    }

    /**
     * 获取短信类型列表
     * @return
     */
    @GetMapping("/messageTypes")
    public BaseResponse<List<SmsTemplateTypeVO>> allSmsTemplateType() {
        List<SmsTemplateTypeVO> voList = new ArrayList<>();

        SmsTemplateTypeVO vo2 = new SmsTemplateTypeVO();
        vo2.setName(NOTIFICATION.getName());
        vo2.setOrdinal(NOTIFICATION.getOrdinal());

        SmsTemplateTypeVO vo3 = new SmsTemplateTypeVO();
        vo3.setName(MARKETING.getName());
        vo3.setOrdinal(MARKETING.getOrdinal());

        voList.add(vo2);
        voList.add(vo3);

        return BaseResponse.success(voList);
    }

    /**
     * 获取短信签名列表
     * @return
     */
    @GetMapping("/messageSigns")
    public BaseResponse<List<SmsSignVO>> allSmsSigns() {
        List<SmsSignVO> voList = new ArrayList<>();

        SmsSignVO v1 = new SmsSignVO();
        v1.setName(OYO_HOTEL.getName());
        v1.setOrdinal(OYO_HOTEL.getOrdinal());

        SmsSignVO v2 = new SmsSignVO();
        v2.setName(OYO_WECHAT_PLATFORM.getName());
        v2.setOrdinal(OYO_WECHAT_PLATFORM.getOrdinal());

        voList.add(v1);
        voList.add(v2);

        return BaseResponse.success(voList);
    }

    /**
     * 模板页面获取公众号的列表
     * @param userType (1-c端用户，2-B端用户)
     * @return com.oyo.common.response.BaseResponse<java.util.List<com.oyo.ump.member.web.vo.WeChatPublicAccountVO>>
     */
    @GetMapping("/publicAccountLists")
    @ApiOperation("公众号列表")
    public BaseResponse<List<WeChatPublicAccountVO>> getPublicAccountList(@RequestParam(value = "userType", required = false, defaultValue = "1") Integer userType){
        List<WeChatPublicAccountVO> result = new ArrayList<>();
        List<WeChatPublicAccountEnum> enums= WeChatPublicAccountEnum.getByUserType(userType);
        if(CollectionUtils.isNotEmpty(enums)){
            for(WeChatPublicAccountEnum e:enums){
                WeChatPublicAccountVO vo = new WeChatPublicAccountVO();
                vo.setAppId(e.getAppId());
                vo.setMp(e.getMp());
                vo.setAppName(e.getAppNme());
                result.add(vo);
            }
        }

        if(CollectionUtils.isNotEmpty(result)){
            return BaseResponse.success(result);
        }
        return BaseResponse.success(new ArrayList<>());
    }

    /**
     * 模板页面获取微信小程序的列表
     * @param userType (1-c端用户，2-B端用户)
     * @return com.oyo.common.response.BaseResponse<java.util.List<com.oyo.ump.member.web.vo.WeChatMiniAppVO>>
     */
    @GetMapping("/weChatMiniAppLists")
    @ApiOperation("微信小程序列表")
    public BaseResponse<List<WeChatMiniAppVO>> getWeChatMiniAppList(@RequestParam(value = "userType", required = false, defaultValue = "1") Integer userType){
        List<WeChatMiniAppVO> result = new ArrayList<>();
        List<WeChatMiniAPPEnum> enums= WeChatMiniAPPEnum.getByUserType(userType);
        if(CollectionUtils.isNotEmpty(enums)){
            for(WeChatMiniAPPEnum e:enums){
                WeChatMiniAppVO vo = new WeChatMiniAppVO();
                vo.setAppId(e.getAppId());
                vo.setMp(e.getMp());
                vo.setAppName(e.getAppNme());
                vo.setMiniappEnum(e.getMiniappEnum());
                vo.setInterMsgDetailPageRootPath(e.getInterMsgDetailPageRootPath());
                result.add(vo);
            }
        }

        if(CollectionUtils.isNotEmpty(result)){
            return BaseResponse.success(result);
        }
        return BaseResponse.success(new ArrayList<>());
    }

    /**
     * 获取公众号或者小程序对应的模板信息
     * @param appType （1-公众号；2-小程序）
     * @param appId 公众号或者小程序的appId
     * @return com.oyo.common.response.BaseResponse<java.util.List<com.oyo.ump.member.web.vo.WeChatTemplateContextVO>>
     */
    @GetMapping("/getTemplateLists")
    @ApiOperation("获取公众号或者小程序对应的模板信息")
    public BaseResponse<List<WeChatTemplateContextVO>> getTemplateLists(@RequestParam(value = "appType") Integer appType, @RequestParam(value = "appId") String appId){
        if(1==appType){
            GetAllPrivateTemplateRequest request = new GetAllPrivateTemplateRequest();
            request.setAppName(WeChatPublicAccountEnum.getByAppId(appId).getAppNme());
            List<PrivateTemplate> privateTemplates = messageTemplateService.getTemplateList(request);
            List<WeChatTemplateContextVO> weChatTemplateContextVOs= MapperWrapper.instance().mapList(privateTemplates,WeChatTemplateContextVO.class);
            return BaseResponse.success(weChatTemplateContextVOs);
        }else if(2==appType){
            List<SubscribeTemplateDto> miniAppTemplates =  messageTemplateService.getMiniappTemplateList(WeChatMiniAPPEnum.getByAppId(appId).getMiniappEnum());
            List<WeChatTemplateContextVO> weChatTemplateContextVOs = Lists.newArrayList();
            if(CollectionUtils.isNotEmpty(miniAppTemplates)){
                miniAppTemplates.forEach(miniAppTemplate->{
                    WeChatTemplateContextVO weChatTemplateContextVO = new WeChatTemplateContextVO();
                    weChatTemplateContextVO.setTemplateId(miniAppTemplate.getPriTmplId());
                    weChatTemplateContextVO.setContent(miniAppTemplate.getContent());
                    weChatTemplateContextVOs.add(weChatTemplateContextVO);
                });
            }
            return BaseResponse.success(weChatTemplateContextVOs);
        }
        return BaseResponse.fail(ResponseCode.FAILURE);
    }

    @GetMapping("/testSendMessage")
    public BaseResponse<String> testSendMessage(@RequestParam("pushId") Long pushId,
                                                @RequestParam("templateNum") String templateNum,
                                                @RequestParam("memberId") String phone){
        try {
            pushProcessService.testPushMessage(pushId,templateNum,phone);
        }catch (Exception e){
            e.printStackTrace();
            return BaseResponse.fail("999",e.getMessage());
        }
        return BaseResponse.success("ok");
    }
    @GetMapping("/testBusinessMessage")
    public BaseResponse<String> testBusinessMessage(@RequestParam("pushId") Long pushId, @RequestParam("userId") String userId){
        try {
            pushProcessService.testBusinessMessage(pushId,userId);
        }catch (Exception e){
            e.printStackTrace();
            return BaseResponse.fail("999",e.getMessage());
        }
        return BaseResponse.success("ok");
    }

    @GetMapping("/findTemplateRelationList")
    public BaseResponse<List<String>> findTemplateRelationList(@RequestParam("pushId") Long pushId){
       List<String> list= pushTemplateRelationService.getTemplateNumList(pushId);
       return BaseResponse.success(list);
    }


    @GetMapping("/getChanneledActivities")
    public  BaseResponse<List<ActivityBasisVo>> getChanneledActivities(@RequestParam(name = "keyWords",required = false) String keyWords){
        List<ActivityBasisVo> result=new ArrayList<>();
        List<ActivityBasisBo> list= pushTemplateRelationService.getChanneledActivities(keyWords);
        list.stream().forEach(item->{
            ActivityBasisVo activityBasisVo=new ActivityBasisVo();
            activityBasisVo.setLabel(item.getActivityName());
            activityBasisVo.setValue(item.getId());
            result.add(activityBasisVo);
        });
        return BaseResponse.success(result);
    }
    @GetMapping("/getChanneledPromotes")
    public BaseResponse<List<PromoteBasisVo>> getChanneledPromotes(@RequestParam(name = "promoteName",required = false)String promoteName,@RequestParam("activityId") Long activityId){
        List<PromoteBasisVo> result=new ArrayList<>();
        List<PromoteBasisBo> list= pushTemplateRelationService.getChanneledPromotes(promoteName,activityId);
        list.stream().forEach(item->{
            PromoteBasisVo promoteBasisVo=new PromoteBasisVo();
            promoteBasisVo.setActivityId(item.getActivityId());
            promoteBasisVo.setLabel(item.getPromoteName());
            promoteBasisVo.setValue(item.getId());
            result.add(promoteBasisVo);
        });
        return BaseResponse.success(result);
    }
    @GetMapping("/getTopDepartmentCode")
    public BaseResponse<List<SelectComponentVo>> getTopDepartmentCode(){
        List<SelectComponentVo> result=new ArrayList<>();
        Map<String,String> map=  pushTemplateRelationService.getTopDepartmentCode();
        map.keySet().forEach(item->{
            SelectComponentVo selectComponentVo=new SelectComponentVo();
            selectComponentVo.setLabel(map.get(item));
            selectComponentVo.setValue(item);
            result.add(selectComponentVo);
        });
        return BaseResponse.success(result);
    }

    @GetMapping("/getActivityChannelTypes")
    public BaseResponse<List<SelectComponentVo>> getActivityChannelTypes(){
        List<SelectComponentVo> result=new ArrayList<>();
        Map<String,String> map= pushTemplateRelationService.getActivityChannelTypes();
        map.keySet().forEach(item->{
            SelectComponentVo selectComponentVo=new SelectComponentVo();
            selectComponentVo.setLabel(item);
            selectComponentVo.setValue(map.get(item));
            result.add(selectComponentVo);
        });
        return BaseResponse.success(result);
    }

    @PostMapping("/createChannelLink")
    public BaseResponse<String> createChannelLink(@RequestBody @Valid ChannelLinkBasicVo channelLinkBasicVo){
        ChannelLinkBasicBo channelLinkBasicBo=new ChannelLinkBasicBo();
        channelLinkBasicBo.setChannelName(channelLinkBasicVo.getActivityChannelName());
        channelLinkBasicBo.setPromoteBasisId(channelLinkBasicVo.getActivityUtilId());
        channelLinkBasicBo.setUtmSource(channelLinkBasicVo.getUtmSource());
        channelLinkBasicBo.setUtmMedium(channelLinkBasicVo.getUtmMedium());
        channelLinkBasicBo.setUtmCampaign(channelLinkBasicVo.getUtmCampaign());
        channelLinkBasicBo.setUtmContent(channelLinkBasicVo.getUtmContent());
        String url=pushTemplateRelationService.createChannelLink(channelLinkBasicBo);
        if(url==null){
            return BaseResponse.fail("999","创建名称重复！");
        }
        return BaseResponse.success(url);
    }
}
