package com.oyo.ump.member.web.vo;

import lombok.Data;

import java.io.Serializable;

/**
 * @Description: 会员详情VO
 * @Author: fang
 * @create: 2019-03-25
 **/
@Data
public class MemberDetailVO implements Serializable {
    //基础信息
    private Long userId;
    private String certificateType;//证件类型
    private String certificateNo;
    private String address;
    private String userName;
    private String phone;
    private String bonus;
    private String bonusLimitTime;
    private String icon;
    private String validTime;
    private String grade;

}
