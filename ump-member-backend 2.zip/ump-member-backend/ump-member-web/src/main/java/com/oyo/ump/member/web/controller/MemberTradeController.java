package com.oyo.ump.member.web.controller;

import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import com.oyo.sso.core.user.SsoUser;
import com.oyo.sso.core.util.SsoUtil;
import com.oyo.ump.member.common.beanutils.MapperWrapper;
import com.oyo.ump.member.service.TradeService;
import com.oyo.ump.member.service.dto.*;
import com.oyo.ump.member.web.common.RequirePermission;
import com.oyo.ump.member.web.vo.MemberBonusVO;
import com.oyo.ump.member.web.vo.MemberOrderVO;
import com.oyo.ump.member.web.vo.RefundVO;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.text.SimpleDateFormat;

/**
 * @Description: todo 需要搞个时间utile
 * @Author: fang
 * @create: 2019-03-29
 **/
@RestController
@RequestMapping(value = "/member/order")
@Api(tags = {"Order"}, value = "Order")
@Slf4j
public class MemberTradeController {
    @Autowired
    private TradeService tradeService;
    private static final SimpleDateFormat BEGIN_FORMATE = new SimpleDateFormat("yyyy-MM-dd");
    private static final SimpleDateFormat END_FORMATE = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");


    @GetMapping("/upgrade/query")
    @RequirePermission(value = "membershipStatus_membershipStatusList$button$memberQuery")
    public BaseResponse<MemberOrderVO> queryUpgradeOrderList(@RequestParam(value = "userId", required = true) Long userId,
                                                       @RequestParam(value = "fromDate" ,required = false ,defaultValue = "2017-01-01") String fromDate,
                                                       @RequestParam(value = "toDate",required = false,defaultValue = "2027-01-01 23:59:59") String toDate,
                                                       @RequestParam(value = "orderNo", required = false, defaultValue = "") String orderNo) {
        MemberOrderRequestDTO requestDTO = new MemberOrderRequestDTO();
        requestDTO.setUserId(userId);
        requestDTO.setOrderNo(orderNo);
        try {
            if (StringUtils.isNotEmpty(fromDate)) {
                requestDTO.setFromDate(BEGIN_FORMATE.parse(fromDate));
            }
            if (StringUtils.isNotEmpty(toDate)) {
                requestDTO.setToDate(END_FORMATE.parse(toDate));
            }
        } catch (Exception e) {
            log.error("时间参数异常" + fromDate + toDate, e);
        }
        MemberOrderResponseDTO responseDTO = tradeService.queryUserTradeList(requestDTO);
        if(responseDTO!=null){
            return  BaseResponse.success(MapperWrapper.instance().map(responseDTO, MemberOrderVO.class));
        }
        return BaseResponse.fail(ResponseCode.DATA_NOT_EXISTS);
    }
    @GetMapping("/bonus/query")
    @RequirePermission(value = "membershipStatus_membershipStatusList$button$memberQuery")
    public BaseResponse<MemberBonusVO> queryBonusOrderList(@RequestParam(value = "userId", required = true) Long userId,
                                                           @RequestParam(value = "fromDate" ,required = false,defaultValue = "2017-01-01") String fromDate,
                                                           @RequestParam(value = "toDate",required = false,defaultValue = "2027-01-01 23:59:59") String toDate,
                                                           @RequestParam(value = "orderNo", required = false, defaultValue = "") String orderNo,
                                                           @RequestParam(value = "pageNum", required = false, defaultValue = "1") Integer pageNum,
                                                           @RequestParam(value = "pageSize", required = false, defaultValue = "5") Integer pageSize,
                                                           @RequestParam(value = "queryType") String queryType,
                                                           @RequestParam(value = "tenant", required = false, defaultValue = "OYO") String tenant) {
        MemberPointRequestDTO requestDTO =new MemberPointRequestDTO();
        requestDTO.setUserId(userId);
        requestDTO.setOrderNo(orderNo);
        requestDTO.setPageSize(pageSize);
        requestDTO.setPageNum(pageNum);
        requestDTO.setTenant(tenant);
        requestDTO.setQueryType(queryType);
        try {
            if (StringUtils.isNotEmpty(fromDate)) {
                requestDTO.setFromDate(BEGIN_FORMATE.parse(fromDate));
            }
            if (StringUtils.isNotEmpty(toDate)) {
                requestDTO.setToDate(END_FORMATE.parse(toDate));
            }
        } catch (Exception e) {
            log.error("时间参数异常" + fromDate + toDate, e);
        }
        MemberPointResponseDTO responseDTO =tradeService.queryPointsList(requestDTO);
        if(responseDTO!=null){
            return BaseResponse.success(MapperWrapper.instance().map(responseDTO, MemberBonusVO.class));
        }

        return BaseResponse.fail(ResponseCode.DATA_NOT_EXISTS);
    }
    @GetMapping("/upgrade/refund")
    @RequirePermission(value = "membershipStatus_membershipStatusList$button$memberQuery")
    public BaseResponse<RefundVO> refund(@RequestParam(value = "userId", required = false)Long userId,
                                         @RequestParam(value = "operatorId", required = false) Long operatorId,
                                         @RequestParam(value = "orderSn", required = true) String orderSn,
                                         @RequestParam(value = "productCode", required = true) String productCode ){

        RefundRequestDTO refundRequestDTO =new RefundRequestDTO();
        SsoUser ssoUser = SsoUtil.currentUser();
        if(ssoUser==null||ssoUser.getUserId()==null){
            return BaseResponse.fail(ResponseCode.FAILURE.getCode(),"操作人信息异常");
        }
        refundRequestDTO.setOperatorId(ssoUser.getUserId());
        refundRequestDTO.setOrderSn(orderSn);
//        refundRequestDTO.setUserId(userId);
        refundRequestDTO.setProductCode(productCode);
        RefundResponseDTO responseDTO = tradeService.refund(refundRequestDTO);
        if(refundRequestDTO!=null){
            return BaseResponse.success(MapperWrapper.instance().map(responseDTO,RefundVO.class));
        }
        return BaseResponse.fail(ResponseCode.FAILURE);


    }

}
