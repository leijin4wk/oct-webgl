package com.oyo.ump.member.web.controller;

import com.oyo.common.enums.ResponseCode;
import com.oyo.common.response.BaseResponse;
import com.oyo.ump.member.service.PushTemplateMapService;
import com.oyo.ump.member.service.bo.PushTemplateMapBo;
import com.oyo.ump.member.web.vo.PushTemplateMapVo;
import com.oyo.ump.member.web.vo.request.PushTemplateMapInsertVo;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping(value = "/member/pushTemplateMap")
@Api(tags = {"pushTemplateMap"}, value = "pushTemplateMap")
@Slf4j
public class PushTemplateMapController {
    @Autowired
    private PushTemplateMapService pushTemplateMapService;

    @GetMapping("/list")
    public BaseResponse<List<PushTemplateMapVo>> getPushTemplateMapVoList() {
        BaseResponse baseResponse = new BaseResponse();
        baseResponse.setCode(ResponseCode.SUCCESS.getCode());
        baseResponse.setMsg(ResponseCode.SUCCESS.getMsg());
        List<PushTemplateMapBo> list = pushTemplateMapService.getPushTemplateMapBoList();
        baseResponse.setData(list.stream().map(item -> {
            PushTemplateMapVo vo = PushTemplateMapVo.builder()
                    .id(item.getId())
                    .createTime(item.getCreateTime())
                    .detail(item.getDetail())
                    .templateName(item.getTempleteName())
                    .updateTime(item.getUpdateTime())
                    .isDeleted(item.getIsDeleted())
                    .aliTemplateId(item.getAliTempleteId()
                    )
                    .build();
            return vo;
        }).collect(Collectors.toList()));
        return baseResponse;
    }

    @GetMapping("/findById")
    public BaseResponse<List<PushTemplateMapVo>> getPushTemplateMapVoById(@RequestParam("id") Long id) {
        BaseResponse baseResponse = new BaseResponse();
        baseResponse.setCode(ResponseCode.SUCCESS.getCode());
        baseResponse.setMsg(ResponseCode.SUCCESS.getMsg());
        PushTemplateMapBo bo = pushTemplateMapService.getPushTemplateById(id);
        PushTemplateMapVo vo = PushTemplateMapVo.builder()
                .id(bo.getId())
                .createTime(bo.getCreateTime())
                .detail(bo.getDetail())
                .templateName(bo.getTempleteName())
                .updateTime(bo.getUpdateTime())
                .isDeleted(bo.getIsDeleted())
                .aliTemplateId(bo.getAliTempleteId()
                )
                .build();
        baseResponse.setData(vo);
        return baseResponse;
    }
    @PostMapping("/update")
    public BaseResponse<String> updatePushTemplateMapd(@Valid @RequestBody PushTemplateMapVo pushTemplateMapVo) {
        BaseResponse baseResponse = new BaseResponse();
        baseResponse.setCode(ResponseCode.SUCCESS.getCode());
        baseResponse.setMsg(ResponseCode.SUCCESS.getMsg());
        PushTemplateMapBo pushTemplateMapBo= PushTemplateMapBo.builder()
                .id(pushTemplateMapVo.getId())
                .templeteName(pushTemplateMapVo.getTemplateName())
                .aliTempleteId(pushTemplateMapVo.getAliTemplateId())
                .detail(pushTemplateMapVo.getDetail())
                .build();
        pushTemplateMapService.updatePushTemplateMap(pushTemplateMapBo);
        baseResponse.setData("ok");
        return baseResponse;
    }

    @PostMapping("/insert")
    public BaseResponse<String> insetPushTemplateMapd(@Valid @RequestBody PushTemplateMapInsertVo pushTemplateMapVo) {
        BaseResponse baseResponse = new BaseResponse();
        baseResponse.setCode(ResponseCode.SUCCESS.getCode());
        baseResponse.setMsg(ResponseCode.SUCCESS.getMsg());
        PushTemplateMapBo pushTemplateMapBo= PushTemplateMapBo.builder()
                .templeteName(pushTemplateMapVo.getTemplateName())
                .aliTempleteId(pushTemplateMapVo.getAliTemplateId())
                .detail(pushTemplateMapVo.getDetail())
                .build();
        pushTemplateMapService.insertPushTemplateMap(pushTemplateMapBo);
        baseResponse.setData("ok");
        return baseResponse;
    }
}
