package com.oyo.ump.member.web.vo;

import lombok.Data;

import java.io.Serializable;

/**
 * @author Dong
 * @Classname MemberDefRecordVO
 * @Description TODO
 * @Date 2019-07-25
 */
@Data
public class MemberDefRecordVO implements Serializable {
    private Long activityId;
    private String activityName;
    private String activityStatus;
    private Integer riskUserType;
    private String highTime;
    private String highRiskResult;
    private String lastTime;
    private String lastRiskResult;
    private Integer resultSource;
    private String resultSourceDesc;
    private String description;
    private Boolean frozenStatus;
}
