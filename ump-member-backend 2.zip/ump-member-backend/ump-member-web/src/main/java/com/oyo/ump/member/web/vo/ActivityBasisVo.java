package com.oyo.ump.member.web.vo;

import lombok.Data;

import java.io.Serializable;
@Data
public class ActivityBasisVo implements Serializable {
    private String label;
    private Long value;
}
