create database  ump_member;

use ump_member;

drop table if exists subscriptions;
drop table if exists plans;
drop table if exists transaction;
drop table if exists templates;
drop table if exists policies;
drop table if exists acknowledgements;
drop table if exists parameter_cfg;

create table subscriptions (`subscription_code` varchar(100) not null default '',`user_id` varchar(255),
`identity_id` varchar(255), `user_name` varchar(255), `user_email` varchar(255),
`hotel_id` int(16) not null default 0,`broker_id` varchar(255) not null default '',
`broker_type` varchar(255) not null default '',`country_calling_code` varchar(20) not null default '',
`phone` varchar(30) not null default '',`created_at` timestamp not null default current_timestamp,
`updated_at` timestamp not null  default current_timestamp on update current_timestamp,
`status` int(10) not null default 0,`policy_name` varchar(255) not null  default  '',
`personalized_increment_rate` double not null default 0,primary key (`subscription_code`),
index `index_phone`(`phone`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 comment '迁移aws数据库表结构';


create table plans (`id` BIGINT not null default 0,`discount_primary` double not null default 0,
`discount_secondary` double not null default 0,`order_limit` int(12),`discount_limit` double not null default 0,
`currency_id` varchar(255) not null default '',`duration_cycle` varchar(100) not null default '',
`subscription_fee` double not null default 0,`policy_category` varchar(100) not null default '',
`discount_category` varchar(100) not null default '',primary key (`id`))ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 comment '迁移aws数据库表结构';

create table transaction(
`transaction_id` varchar(100) not null default '',`subscription_code` varchar(100) not null default '',
`user_id` varchar(100) not null default '',`identity_id` varchar(100),`country_calling_code` varchar(20) not null default '',
`phone` varchar(30) not null default '',`amount` double not null default 0,`currency_id` varchar(255) not null default '',`type` varchar(20) not null default '',
`created_at` timestamp not null default current_timestamp,`payment_mode` varchar(20) not null default '',`status` int(10) not null default 0,
primary key (`transaction_id`),index `subscriptions_code_index`(`subscription_code`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 comment '迁移aws数据库表结构';

create table templates(`id` bigint not null default 0,`status` int(10) not null default 0,`namespace` varchar(100) not null default '',`type` varchar(100) not null default '',
`message_type` varchar(100) not null default '',`contents` varchar(255) not null default '',primary key (`id`),INDEX `index_message_type`(`message_type`))ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 comment '迁移aws数据库表结构';

create table policies(`id` bigint not null  default 0,`policy_name` varchar(100) not null default '',`start_date` timestamp,`end_date` timestamp,
`status` int(10) not null default 0,`country_id` int(10) not null default 0,`plan_id` bigint not null default 0)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 comment '迁移aws数据库表结构';

create table acknowledgements(`id` BIGINT not null default 0,`subscription_id` varchar(100) not null default '',
  `type` varchar(100) not null default '',`created_at` timestamp not null default current_timestamp,
  primary key (`id`),index `subscriptions_code_index`(`subscription_id`))ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 comment '迁移aws数据库表结构';

create table parameter_cfg(`id` bigint not null default 0,`sms_key` varchar(255) not null default '' comment '对应aws表里的key',
`sms_value` varchar(4000) not null default '' comment '对应aws表里的value',`description` varchar(4000) not null default '' comment '描述',
`status` integer(12) not null default 0 comment '状态 1: 有效 0: 无效',`create_by` varchar(255) not null default '' comment '创建人',
`create_time` timestamp not null default current_timestamp comment '创建时间',`last_update_by` varchar(255) not null default '' comment '最后更新人',
`last_update_time` timestamp not null default current_timestamp on update current_timestamp comment '最后更新时间',
primary key (`id`))ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 comment '迁移aws数据库表结构';
